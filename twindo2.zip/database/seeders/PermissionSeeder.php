<?php

namespace Database\Seeders;

use App\Models\Module;
use App\Models\Permission;
use Illuminate\Database\Seeder;

class PermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Dashboard
        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'Dashboard']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Dashboard',
        //     'slug' => 'dashboard_access',
        // ]);


        // User management
        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'Users']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'User List Access',
        //     'slug' => 'user_list_access',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'User Create',
        //     'slug' => 'user_create',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'User Edit',
        //     'slug' => 'user_edit',
        // ]);

        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'User Delete',
        //     'slug' => 'user_delete',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Export',
        //     'slug' => 'user_export',
        // ]);


        //  $moduleAppDashboard = Module::updateOrCreate(['name' => 'Role Permission']);
        //         Permission::updateOrCreate([
        //             'module_id' => $moduleAppDashboard->id,
        //             'name' => 'Role List Access',
        //             'slug' => 'role_list_access',
        //         ]);
        //         Permission::updateOrCreate([
        //             'module_id' => $moduleAppDashboard->id,
        //             'name' => 'Role & Permission Create',
        //             'slug' => 'role_permission_create',
        //         ]);
        //         Permission::updateOrCreate([
        //             'module_id' => $moduleAppDashboard->id,
        //             'name' => 'Role & Permission Edit',
        //             'slug' => 'role_permission_edit',
        //         ]);
        //         Permission::updateOrCreate([
        //             'module_id' => $moduleAppDashboard->id,
        //             'name' => 'Role & Permission Delete',
        //             'slug' => 'role_permission_delete',
        //         ]);
        //         Permission::updateOrCreate([
        //             'module_id' => $moduleAppDashboard->id,
        //             'name' => 'Role & Permission Export',
        //             'slug' => 'role_permission_export',
        //         ]);

    }
}
