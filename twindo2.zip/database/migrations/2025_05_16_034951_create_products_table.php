<?php

use App\Models\Category;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id();
            $table->foreignIdFor(Category::class);

            $table->string('image')->nullable();
            $table->string('title');
            $table->decimal('price_per_month', 8, 2)->nullable();
            $table->decimal('price_annual', 8, 2)->nullable();
            $table->enum('price_type',['monthly','yearly'])->nullable();
            $table->string('product_status')->nullable();
            $table->string('tags')->nullable();
            $table->float('rating', 2, 1)->nullable();
            $table->integer('rating_count')->nullable();
            $table->string('website_link')->nullable();
            $table->string('phone')->nullable();
            $table->text('description')->nullable();
            $table->text('seo_notes')->nullable();
            $table->tinyInteger('status')->default(0)->comment('0 for draft 1 for publish');
            $table->unsignedBigInteger('created_by')->nullable();
            $table->unsignedBigInteger('updated_by')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
