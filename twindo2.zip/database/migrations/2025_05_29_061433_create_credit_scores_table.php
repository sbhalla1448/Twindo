<?php

use App\Enums\CreditRefAgency;
use App\Models\User;
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('credit_scores', function (Blueprint $table) {
            $table->id();
            $table->foreignIdFor(User::class);
            $table->enum('credit_ref_agency', array_column(CreditRefAgency::cases(), 'value'))->nullable();
            $table->integer('score')->nullable();
            $table->date('score_date')->nullable();
            $table->string('score_description')->nullable();
            $table->string('image')->nullable();
            $table->tinyInteger('tagable')->default(0)->comment('0 for  lowest, 1 for highest');
            $table->enum('score_status', ['Approve', 'Reject', 'Unseen'])->default('Unseen');
            $table->unsignedBigInteger('approved_by')->nullable();
            $table->foreign('approved_by')->references('id')->on('users');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('credit_scores');
    }
};
