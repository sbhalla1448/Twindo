<?php

use App\Models\User;
use Illuminate\Support\Facades\Schema;
use App\Livewire\Customer\MessageAction;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('message_threads', function (Blueprint $table) {
            $table->id();
            $table->foreignIdFor(MessageAction::class)->constrained()->cascadeOnDelete();
            $table->longText('message');
            $table->unsignedBigInteger(User::class)->nullable();
            $table->unsignedBigInteger('receiver_id')->nullable();
            $table->string('admin_id')->nullable();
            $table->string('subject')->nullable();
            $table->string('file')->nullable();
            $table->boolean('is_seen_user')->default(0);
            $table->boolean('is_seen_admin')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('message_threads');
    }
};
