<?php

use App\Models\User;
use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('user_notifications', function (Blueprint $table) {
            $table->id();
            $table->foreignIdFor(User::class);
            $table->boolean('email_weekly_summary')->default(false);
            $table->boolean('email_account_changes')->default(false);
            $table->boolean('email_new_user')->default(false);
            $table->boolean('sms_login_alerts')->default(false);
            $table->boolean('sms_critical_alerts')->default(false);
            $table->string('email_frequency')->nullable()->comment('instant, daily, weekly');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('user_notifications');
    }
};
