<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('message_actions', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id')->nullable();
            $table->string('recipient')->nullable();
            $table->string('subject');
            $table->text('messages');
            $table->tinyInteger('status')->default(0)->comment('0 for pending 1 for complete');
            $table->tinyInteger('done_status')->default(0)->comment('o for unmark 1 for mark');
            $table->tinyInteger('draft_status')->default(0)->comment('1 for draft 0 for ok');
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('message_actions');
    }
};
