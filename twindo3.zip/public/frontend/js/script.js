let menu_btn = document.getElementById('menu_btn');
let side_menu = document.getElementById('side_menu');
let close_side_menu = document.getElementById('close_side_menu');
menu_btn.addEventListener('click', function () {
   side_menu.classList.add('flex!');
});
close_side_menu.addEventListener('click', function () {
   side_menu.classList.remove('flex!');
});
