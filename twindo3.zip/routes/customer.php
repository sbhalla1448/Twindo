<?php

use App\Http\Controllers\Customer\AccountSettingController;
use App\Http\Controllers\Customer\CommonController;
use App\Http\Controllers\Customer\CreditScoreController;
use App\Http\Controllers\Customer\DashboardController;
use App\Http\Controllers\Customer\DocumentController;
use App\Http\Controllers\Customer\MessageActionController;
use App\Http\Controllers\Customer\PaymentController;
use App\Http\Controllers\Customer\SubscriptionController;
use App\Http\Middleware\CustomerTwoFactorMiddleware;
use App\Livewire\Customer\ReportAnalysis;
use Illuminate\Support\Facades\Route;







Route::get('twofa/security', [CommonController::class, 'index'])->name('twofactor.auth');

    Route::post('checkout', [PaymentController::class, 'Checkout'])->name('checkout');
    Route::get('stripe/success', [PaymentController::class, 'successStripe'])->name('stripe.success');
    Route::get('stripe/cancel', [PaymentController::class, 'cancelStripe'])->name('stripe.cancel');
    Route::get('paypal/payment/success', [PaymentController::class, 'paymentSuccessPaypal'])->name('paypal.payment.success');
    Route::get('paypal/payment/cancel', [PaymentController::class, 'stripePaymentCancel'])->name('paypal.payment.cancel');


    // Route::get('/checkout', [PaymentController::class, 'checkoutPage'])->name('checkout.page');
//     Route::post('/create-payment-intent', [PaymentController::class, 'createPaymentIntent'])->name('payment.intent');
//     Route::post('/confirm-payment', [PaymentController::class, 'confirmPayment'])->name('payment.confirm');
//     Route::get('/payment-success', [PaymentController::class, 'success'])->name('payment.success');
//     Route::get('/payment-error', [PaymentController::class, 'error'])->name('payment.error');

    Route::get('subsctiption', [SubscriptionController::class, 'mySubscription'])->name('subscription');
    Route::get('cancel/subsctiption', [SubscriptionController::class, 'cancelMySubscription'])->name('cancel.my.subscription');


    Route::get('/payment', [PaymentController::class, 'showPaymentForm'])->name('payment.form');
//     Route::post('/payment/create-intent', [PaymentController::class, 'createPaymentIntent'])
//     ->name('payment.create-intent');
// Route::post('/payment/process', [PaymentController::class, 'processPayment'])
//     ->name('payment.process');

// Route::get('/payment/process', [PaymentController::class, 'processPayment'])
//     ->name('checkout.success');



Route::middleware([CustomerTwoFactorMiddleware::class])->group(function () {


Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
Route::get('/credit/history/score', [CreditScoreController::class, 'index'])->name('credit.history');
Route::get('/credit/upload/create', [CreditScoreController::class, 'createUploadScore'])->name('credit.score.create');
Route::post('/credit/upload/store', [CreditScoreController::class, 'store'])->name('credit.score.store');
Route::get('/tool/resource', [DashboardController::class, 'toolResource'])->name('tool.resource');
Route::get('/message/action', [MessageActionController::class, 'index'])->name('message.action');
Route::post('/uploads/documents', [DocumentController::class, 'uploadDocuments'])->name('document.upload');
Route::get('/my/documents', [DocumentController::class, 'index'])->name('my.documents');
Route::get('/documents/{id}/files', [DocumentController::class, 'getFiles']);
Route::post('/store/note', [MessageActionController::class, 'storeNote'])->name('store.note');
Route::get('/settings', [AccountSettingController::class, 'index'])->name('account.settings');
Route::get('/comparison', [CommonController::class, 'comparison'])->name('comparison');
Route::get('/product/service', [CommonController::class, 'productService'])->name('product.service');
Route::get('/analysis/report', [CommonController::class, 'analysisReport'])->name('analysis.report');
Route::get('/view/analysis/report/{id}', [CommonController::class, 'analysisReportShow'])->name('analysis.report.show');



});