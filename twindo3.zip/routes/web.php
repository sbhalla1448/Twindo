<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\SocialLoginController;
use App\Http\Controllers\Frontend\FrontendController;
use App\Http\Controllers\Frontend\CheckoutSuccessController;
use Illuminate\Http\Request;
use Stripe\Stripe;
use Stripe\PaymentIntent;


Route::get('/dd', function () {
    \Log::info('Test log from route');
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');


Route::get('/', [FrontendController::class, 'index'])->name('index');
Route::get('/comarison', [FrontendController::class, 'comparison'])->name('comparison');
Route::get('/sign/up', [FrontendController::class, 'signUp'])->name('sign.up');
Route::get('/checkout/{slug}', [FrontendController::class, 'frontendCheckout'])->name('checkout.page');
// Route::get('/checkout/success', [FrontendController::class, 'paymentSuccess'])->name('checkout.success');


Route::get('/account/payment/process', CheckoutSuccessController::class)->name('checkout.success');




Route::get('/auth/{provider}', [SocialLoginController::class, 'redirect'])->name('social.redirect');
Route::get('/auth/{provider}/callback', [SocialLoginController::class, 'callback'])->name('social.callback');


Route::get('/login/apple', [SocialLoginController::class, 'redirectToApple']);
Route::get('/login/apple/callback', [SocialLoginController::class, 'handleAppleCallback']);


Route::get('/debug-payment', function (Request $request) {
    Stripe::setApiKey(config('stripe.stripe_sk'));

    $paymentIntentId = $request->get('payment_intent');

    try {
        $intent = PaymentIntent::retrieve($paymentIntentId);
        return $intent;
    } catch (\Exception $e) {
        return response()->json([
            'error' => $e->getMessage(),
            'id' => $paymentIntentId,
        ]);
    }
});