<?php

use Illuminate\Support\Facades\Route;
use App\Http\Middleware\TwoFactorMiddlewar;
use App\Http\Middleware\UserSuspendMiddleware;
use App\Http\Controllers\Backend\RoleController;



use App\Http\Controllers\Backend\UserController;
use App\Http\Controllers\Backend\CommonController;
use App\Http\Controllers\Backend\CouponController;
use App\Http\Controllers\Backend\ExportController;
use App\Http\Controllers\Backend\ProductController;
use App\Http\Controllers\Backend\SettingController;
use App\Http\Controllers\Backend\CategoryController;
use App\Http\Controllers\Backend\DashboardControler;
use App\Http\Controllers\Backend\DocumentController;
use App\Http\Middleware\UserTemporaryLockMiddleware;
use App\Http\Controllers\Backend\SystemLogController;
use App\Http\Middleware\UserForceToResetCreMiddleware;
use App\Http\Controllers\Backend\SubscriptionController;
use App\Http\Controllers\Backend\ToolResourceController;
use App\Http\Controllers\Backend\CreditHistoryController;
use App\Http\Controllers\Backend\MessageActionController;
use App\Http\Controllers\Backend\TemplateReportController;
use App\Http\Controllers\Backend\UserNotificationController;


Route::get('twofa/security', [CommonController::class, 'index'])->name('twofa.auth');
Route::post('session/logout', [CommonController::class, 'sessionLogout'])->name('sessionlogout');
Route::get('user/account/status', [CommonController::class, 'accountStatusSuspendOrLock'])->name('suspend.dashboard');
Route::get('user/reset/credential', [CommonController::class, 'resetUserCredential'])->name('force.reset.credential');

Route::middleware([TwoFactorMiddlewar::class, UserTemporaryLockMiddleware::class, UserSuspendMiddleware::class, UserForceToResetCreMiddleware::class])->group(function () {
    Route::get('dashboard', [DashboardControler::class, 'index'])->name('dashboard');
    Route::get('/download-csv', [CreditHistoryController::class, 'downloadCSV'])->name('download.csv');
    Route::get('credit/history', [CreditHistoryController::class, 'index'])->name('credit.history');
    Route::get('system_log', [SystemLogController::class, 'index'])->name('system.log');
    Route::get('settings', [SettingController::class, 'index'])->name('settings.index');
    Route::get('setting/user', [SettingController::class, 'userSetting'])->name('settings.user');
    Route::get('setting/manage/user/{id}', [SettingController::class, 'manageUser'])->name('mamage.user');
    Route::post('setting/user', [SettingController::class, 'profileUpdate'])->name('profile.update');
    Route::get('setting/security', [SettingController::class, 'securitySetting'])->name('settings.security');
    Route::get('setting/manage/notification', [UserNotificationController::class, 'index'])->name('settings.notification');
    Route::post('setting/manage/notification/update', [UserNotificationController::class, 'updateNotification'])->name('settings.notification.update');



    // Route::get('/users', [UserController::class, 'index'])->name('users.index');
    Route::get('/user/delete/{encrypted_id}', [UserController::class, 'delete'])->name('user.delete');
    Route::get('/user/{encrypted_id}', [UserController::class, 'show'])->name('users.show');
    Route::post('user/status/change', [UserController::class, 'userStatusChange'])->name('user.status.change');
    Route::get('/user/reactive/{encrypted_id}', [UserController::class, 'reactiveUser'])->name('user.reactive');
    Route::get('/user/reset/credentials/{encrypted_id}', [UserController::class, 'resetUserCredentials'])->name('user.reset.credential');
    Route::get('/user/suspend/{encrypted_id}', [UserController::class, 'suspendUser'])->name('user.suspend');
    Route::get('/user/locked/{encrypted_id}', [UserController::class, 'lockedUser'])->name('user.locked');
    Route::get('/change/email', [UserController::class, 'changeEmail'])->name('change.email');
    Route::get('/user/login/history/{id}', [UserController::class, 'userLoginHistory'])->name('login.history');
    Route::post('/change/email/update', [UserController::class, 'changeEmailUpdate'])->name('change.email.update');
    Route::resource('users', UserController::class);
    // Route::resource('settings', SettingController::class);
    Route::get('ro', [RoleController::class, 'per']);

    Route::get('/roles/{id}/permissions', [RoleController::class, 'getPermissions']);
    Route::post('/role/permission/control', [RoleController::class, 'permissionControllStore'])->name('role.persmission.store');
    Route::post('/role/based/visibility', [RoleController::class, 'roleBasedVisibilityUpdate'])->name('role.based.visibility.update');
    Route::get('/role/based/visibility', [RoleController::class, 'roleBasedVisibility'])->name('role.based.visibility');
    Route::get('/role/permission/control', [RoleController::class, 'permissionControll'])->name('permission.controll');
    Route::resource('roles', RoleController::class);
    Route::resource('categories', CategoryController::class);
    Route::resource('toolResources', ToolResourceController::class);
    Route::resource('messageActions', MessageActionController::class);
    // web.php
    Route::get('products/duplicate', [ProductController::class, 'duplicate'])->name('products.duplicate');
    Route::get('subscriptions', [SubscriptionController::class, 'index'])->name('subscriptions.index');

    Route::resource('products', ProductController::class);

    Route::get('/documents/file/{id}', [DocumentController::class, 'deleteFile'])->name('documents.file.delete');
    Route::get('/archived/documents', [DocumentController::class, 'documentArchivedIndex'])->name('documents.archive.index');
    Route::get('/documents/archived/restore/{encrypted_id}', [DocumentController::class, 'documentArchivedRestore'])->name('documents.document.restore');
    Route::get('/documents/archived/{encrypted_id}', [DocumentController::class, 'documentArchived'])->name('documents.document.archived');
    Route::get('/documents/delete/{encrypted_id}', [DocumentController::class, 'documentDelete'])->name('documents.document.delete');
    Route::resource('documents', DocumentController::class);

    Route::resource('coupons', CouponController::class);
    Route::resource('tempateReports', TemplateReportController::class);

    Route::get('/activity/logs', [ExportController::class, 'activityLog'])->name('activity.log');
});
