@extends('customer.master')

@section('content')
<h2>🎉 Payment Successful!</h2>
@endsection