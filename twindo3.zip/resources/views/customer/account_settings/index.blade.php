@extends('customer.master')

@section('content')
    <main class="flex-1 overflow-auto">
        <div class="max-w-7xl mx-auto px-6 py-10 space-y-10">

            <!-- Manage Profile -->
           <livewire:user.manage-user :user="$user" />

            <!-- Security Settings -->
          <livewire:customer.customer-security-setting />

            <!-- Address Management -->
            <livewire:user.address-management :user="$user" />
            <!-- GDPR & Marketing Preferences -->

                <livewire:customer.g-d-r-p-marketing-prefernece />


            <!-- Download Your Data Card -->
            <div class="bg-white rounded-xl shadow p-6">
                <h3 class="text-lg font-semibold text-gray-800 mb-2">📂 Download Your Data</h3>
                <p class="text-sm text-gray-600 mb-3">Once your export is ready, you can download it here.</p>
                <a href="#"
                    class="inline-block bg-indigo-100 text-indigo-700 px-4 py-2 rounded text-sm hover:bg-indigo-200">⬇️
                    Download Export File</a>
            </div>

            <div id="successToast"
                class="fixed bottom-4 right-4 hidden bg-green-100 text-green-800 px-4 py-3 rounded shadow-lg text-sm z-50">
                ✅ Request submitted successfully!
            </div>

            <!-- Sample Billing Reminder Modal -->
            <div id="billingPreview"
                class="fixed inset-0 hidden bg-black bg-opacity-30 flex items-center justify-center z-50">
                <div class="bg-white p-6 rounded-xl shadow-xl max-w-md w-full">
                    <h3 class="text-lg font-semibold text-gray-800 mb-3">📧 Billing Reminder Preview</h3>
                    <p class="text-sm text-gray-700 mb-4">Subject: Your Twindo Plan Renews Soon</p>
                    <p class="text-sm text-gray-600 mb-4">Hi John, just a reminder your Twindo Essential Plan will renew on
                        <strong>12 May 2025</strong>. To make changes or cancel, log in to your account before this date.
                    </p>
                    <div class="flex justify-end space-x-3">
                        <button class="text-sm text-gray-600 hover:underline"
                            onclick="closeModal('billingPreview')">Close</button>
                    </div>
                </div>
            </div>



        </div>


    </main>
@endsection

      <script>
                function openModal(id) {
                    document.getElementById(id).classList.remove('hidden');
                }

                function closeModal(id) {
                    document.getElementById(id).classList.add('hidden');
                }

                function showToast() {
                    const toast = document.getElementById('successToast');
                    toast.classList.remove('hidden');
                    setTimeout(() => toast.classList.add('hidden'), 3000);
                }
                // Example bindings for Confirm buttons
                document.querySelectorAll('button').forEach(btn => {
                    if (btn.textContent.includes('Confirm') || btn.textContent.includes('Delete')) {
                        btn.addEventListener('click', showToast);
                    }
                });
            </script>

  <script>
    function openModal(id) {
      document.getElementById(id).classList.remove('hidden');
    }
    function closeModal(id) {
      document.getElementById(id).classList.add('hidden');
    }
  </script>






