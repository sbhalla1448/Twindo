@extends('customer.master')

@section('content')
    <!-- Main Content -->
    <main class="flex-1 overflow-auto">
        <div class="max-w-7xl mx-auto px-6 py-10">

            <!-- Welcome Section -->
            <section class="bg-white rounded-xl shadow p-8 mb-8">
                <h3 class="text-2xl font-semibold text-gray-700">Welcome Back!</h3>
                <p class="text-gray-500 mt-2">Here is a quick summary of your account activity and important
                    updates.</p>
            </section>

            <!-- Metrics Section -->
            <section class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="bg-indigo-100 text-indigo-700 rounded-xl p-6">
                    <div class="text-sm">Current Credit Score</div>
                    <div class="text-2xl font-bold">{{ $currentScore ?? '0' }}</div>
                </div>
                <div class="bg-green-100 text-green-700 rounded-xl p-6">
                    <div class="text-sm">Active Subscriptions</div>
                    <div class="text-2xl font-bold">{{$currentSubscription ? 1:0}}</div>
                </div>
                <div class="bg-yellow-100 text-yellow-700 rounded-xl p-6">
                    <div class="text-sm">Unread Messages</div>
                    <div class="text-2xl font-bold">{{$unreadMsg}}</div>
                </div>
                <div class="bg-gray-100 text-gray-700 rounded-xl p-6">
                    <div class="text-sm">Uploaded Documents</div>
                    <div class="text-2xl font-bold">{{$uploadDocument}}</div>
                </div>
            </section>

            <!-- Credit Score Chart -->
            <section class="bg-white rounded-xl shadow p-6 mb-8">
                <h3 class="text-lg font-semibold text-gray-700 mb-4">📈 Credit Score Trend</h3>
                <canvas id="creditScoreChart"></canvas>
            </section>

            <script>
                const ctx = document.getElementById('creditScoreChart').getContext('2d');
                const labels = @json($labels);
                const data = @json($dataS);

                new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Credit Score',
                            data: data,
                            backgroundColor: 'rgba(99, 102, 241, 0.2)',
                            borderColor: 'rgba(99, 102, 241, 1)',
                            borderWidth: 2,
                            fill: true,
                            tension: 0.4
                        }]
                    },
                    options: {
                        scales: {
                            y: {
                                beginAtZero: false
                            }
                        },
                        plugins: {
                            legend: {
                                display: false
                            }
                        }
                    }
                });
            </script>

            <!-- Progress Tracker -->
            <section class="bg-white rounded-xl shadow p-6 mb-8">
                <h3 class="text-lg font-semibold text-gray-700 mb-4">🎯 Account Progress</h3>
                <div class="w-full bg-gray-200 rounded-full h-4">
                    <div class="bg-indigo-600 h-4 rounded-full" style="width: 70%"></div>
                </div>
                <p class="text-sm text-gray-500 mt-2">You have completed 70% of your account setup. Upload missing
                    documents to reach 100%!</p>
            </section>

            <!-- Quick Links -->
            <section class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <a href="{{ route('credit.history') }}" class="transition transform hover:scale-105 bg-white p-6 rounded-xl shadow">
                    <h4 class="text-lg font-semibold">View Credit Report</h4>
                    <p class="text-sm text-gray-500 mt-2">Check your latest credit score and report history.</p>
                </a>
                <a href="{{ route('subscription') }}" class="transition transform hover:scale-105 bg-white p-6 rounded-xl shadow">
                    <h4 class="text-lg font-semibold">Manage Subscription</h4>
                    <p class="text-sm text-gray-500 mt-2">Upgrade, pause, or cancel your subscription anytime.</p>
                </a>
                <a href="{{ route('tool.resource') }}" class="transition transform hover:scale-105 bg-white p-6 rounded-xl shadow">
                    <h4 class="text-lg font-semibold">Browse Tools & Resources</h4>
                    <p class="text-sm text-gray-500 mt-2">Access member-only resources and financial tools.</p>
                </a>
            </section>

            <!-- Credit Repair Journey - 6 Stages -->
            <section class="bg-white rounded-xl shadow p-6 mb-8">
                <h3 class="text-lg font-semibold text-gray-700 mb-6">🧩 Twindo Ultimate 6-Step UK Credit Repair
                    Journey</h3>
                <div class="grid md:grid-cols-2 gap-6">

                    <!-- Step 1 -->
                    <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition relative">
                        <span
                            class="absolute top-2 right-2 bg-green-100 text-green-700 text-xs font-semibold px-2 py-1 rounded-full">✅
                            In Progress</span>
                        <h4 class="text-indigo-700 font-bold mb-2">Step 1: Submit Key Documents</h4>
                        <ul class="text-gray-600 text-sm list-disc list-inside space-y-1">
                            <li>✅ Proof of Identity (passport or driver's licence)</li>
                            <li>✅ Proof of Address (utility bill, council tax bill, or bank statement)</li>
                            <li>✅ Latest Credit Report (Experian, Equifax, or TransUnion)</li>
                        </ul>
                        <p class="text-gray-600 text-sm mt-2">📂 Being fully verified allows us to liaise with
                            Credit Agencies securely and start correcting your profile.</p>
                        </ul>
                        <div class="flex flex-col space-y-2">
                            <div class="flex space-x-4">
                                <a href="{{ route('my.documents') }}"
                                    class="inline-block mt-4 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded px-4 py-2">📂
                                    Upload Documents</a>
                            </div>
                            <div class="mt-4">
                                <p class="text-gray-600 text-sm">📱 How to get your Experian Credit Report:</p>
                                <ul class="text-gray-600 text-sm list-disc list-inside space-y-1 mt-2">
                                    <li>Download the Experian app from the Apple App Store or Google Play Store.
                                    </li>
                                    <li>Create a free Experian account or log in with your existing credentials.
                                    </li>
                                    <li>Verify your identity by answering a few security questions.</li>
                                    <li>Access your credit score and full credit report.</li>
                                    <li>Take a screenshot of your credit score summary.</li>
                                    <li>Upload the screenshot back into Twindo using the Upload Documents button
                                        above.</li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <!-- Step 2 -->
                    <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition">
                        <h4 class="text-indigo-700 font-bold mb-2">Step 2: Enhanced Basics for UK Credit Repair</h4>
                        <ul class="text-gray-600 text-sm list-disc list-inside space-y-1">
                            <li>✅ Register at your current address (not a previous or old one)</li>
                            <li>✅ Use the Register to Vote UK Government Site</li>
                            <li>✅ Ensure your full name matches across all agencies</li>
                            <li>✅ Update ALL lenders about new address</li>
                            <li>✅ Register immediately if recently moved</li>
                            <li>✅ Get a written confirmation letter</li>
                            <li>✅ Use the same address formatting consistently</li>
                        </ul>
                        <p class="text-gray-600 text-sm mt-2">🗳️ Being registered to vote is worth up to 50–100
                            points by itself and prevents automatic rejections.</p>
                        </ul>
                        <a href="https://www.gov.uk/register-to-vote" target="_blank"
                            class="inline-block mt-4 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded px-4 py-2">🗳️
                            Register Now</a>
                    </div>

                    <!-- Step 3 -->
                    <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition">
                        <h4 class="text-indigo-700 font-bold mb-2">Step 3: Correct & Dispute Inaccurate Information
                        </h4>
                        <ul class="text-gray-600 text-sm list-disc list-inside space-y-1">
                            <li>✅ Identify incorrect markers (defaults, missed payments)</li>
                            <li>✅ Submit formal Disputes</li>
                            <li>✅ File Correction Notices</li>
                            <li>✅ Notice of Disassociation if needed</li>
                        </ul>
                        <p class="text-gray-600 text-sm mt-2">🛡️ Cleaning your file removes risk flags
                            dramatically.</p>
                        </ul>
                        <a href="{{ route('message.action') }}"
                            class="inline-block mt-4 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded px-4 py-2">💬
                            Start Dispute</a>
                    </div>

                    <!-- Step 4 -->
                    <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition">
                        <h4 class="text-indigo-700 font-bold mb-2">Step 4: Build & Report Positive Payment History
                        </h4>
                        <ul class="text-gray-600 text-sm list-disc list-inside space-y-1">
                            <li>✅ Set up Rent Reporting (CreditLadder, Canopy)</li>
                            <li>✅ Use Credit Builder Products (Ocean Card, Loqbox)</li>
                            <li>✅ Report Mobile Phone Payments</li>
                        </ul>
                        <p class="text-gray-600 text-sm mt-2">🏦 New positive data shows your reliability and
                            financial health.</p>
                        </ul>
                        <a  href="{{ route('comparison') }}"
                            class="inline-block mt-4 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded px-4 py-2">🛍️
                            Compare Options</a>
                    </div>

                    <!-- Step 5 -->
                    <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition">
                        <h4 class="text-indigo-700 font-bold mb-2">Step 5: Apply Strategically & Protect Your Score
                        </h4>
                        <ul class="text-gray-600 text-sm list-disc list-inside space-y-1">
                            <li>✅ Use Soft Search tools (Capital One QuickCheck)</li>
                            <li>✅ Space applications by at least 3 months</li>
                            <li>✅ Apply only for matched products</li>
                        </ul>
                        <p class="text-gray-600 text-sm mt-2">🚀 Protecting your score ensures better long-term
                            improvements.</p>
                        </ul>
                        <a href="{{ route('credit.history') }}"
                            class="inline-block mt-4 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded px-4 py-2">📈
                            View Credit Score</a>
                    </div>

                    <!-- Step 6 -->
                    <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition">
                        <h4 class="text-indigo-700 font-bold mb-2">Step 6: Monitor, Maintain and Optimise</h4>
                        <ul class="text-gray-600 text-sm list-disc list-inside space-y-1">
                            <li>✅ Monitor your scores monthly</li>
                            <li>✅ Keep card usage under 30%</li>
                            <li>✅ Pay bills and credit on time</li>
                            <li>✅ Review reports every 6 months</li>
                        </ul>
                        <p class="text-gray-600 text-sm mt-2">🔒 Long-term habits are key to excellent credit
                            maintenance.</p>
                        </ul>
                        <a  href="{{ route('tool.resource') }}"
                            class="inline-block mt-4 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium rounded px-4 py-2">📚
                            Credit Maintenance Tips</a>
                    </div>

                </div>
            </section>

            {{-- message --}}
            <livewire:customer.latest-message />

            <!-- Profile & Settings -->
            <section class="bg-white rounded-xl shadow p-6">
                <h3 class="text-xl font-bold text-gray-800 mb-4">👤 Profile & Settings</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <p class="text-sm text-gray-600">Full Name:</p>
                        <p class="text-lg text-gray-900 font-semibold">{{ $user->name }}</p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">Email Address:</p>
                        <p class="text-lg text-gray-900 font-semibold">{{ $user->email }}</p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">Phone:</p>
                        <p class="text-lg text-gray-900 font-semibold">{{ $user->phone }}</p>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">Account Status:</p>
                        <p class="text-lg text-green-600 font-semibold">{{ $user->status_label }}</p>
                    </div>
                </div>
                <div class="mt-6">
                    <a    href="{{ route('account.settings') }}"class="text-indigo-600 hover:underline text-sm">⚙️ Edit Profile Settings</a>
                </div>
            </section>

        </div>
    </main>
@endsection
