@extends('customer.master')

@section('content')
<livewire:customer.tool-resource>
@endsection