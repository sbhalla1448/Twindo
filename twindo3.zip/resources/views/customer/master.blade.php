<!-- My Account Dashboard - Twindo Platform (Fully Restored with All Sections + Latest Enhancements) -->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Account - Dashboard | Twindo</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    @livewireStyles
</head>

<body class="bg-gray-50 min-h-screen">

    @include('customer.partials.header')

    <div class="flex pt-20">

        <!-- Sidebar -->
        @include('customer.partials.sidebar')


        @yield('content')
    </div>

    @stack('js')
    @livewireScripts
</body>

</html>
