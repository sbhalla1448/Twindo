@extends('customer.master')

@section('content')
<h2>❌ Payment Failed!</h2>
<a href="{{ route('checkout.page') }}">Try Again</a>
@endsection