
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Twindo - Secure Checkout</title>
    <script src="https://js.stripe.com/v3/"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f0f8ff 0%, #e6f7ff 100%);
            padding: 20px;
            min-height: 100vh;
            color: #033333;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
        }

        /* Header */
        header {
            background: linear-gradient(135deg, #033333 0%, #0a4a4a 100%);
            border-radius: 20px 20px 0 0;
            padding: 25px 40px;
            color: white;
            position: relative;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
            margin-bottom: 3px;
        }

        header::before {
            content: "";
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(92, 180, 106, 0.15) 0%, transparent 70%);
            transform: rotate(15deg);
        }

        .logo {
            font-size: 36px;
            font-weight: 800;
            letter-spacing: -0.5px;
            margin-bottom: 8px;
            color: #EEFCFC;
            position: relative;
            z-index: 2;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .tagline {
            font-weight: 300;
            font-size: 18px;
            opacity: 0.85;
            color: #5CB46A;
            position: relative;
            z-index: 2;
            font-style: italic;
        }

        .secure-checkout {
            display: flex;
            align-items: center;
            position: relative;
            z-index: 2;
            margin-top: 15px;
        }

        .secure-checkout i {
            color: #5CB46A;
            margin-right: 10px;
            font-size: 20px;
        }

        /* Header progress bar container */
        .header-progress {
            margin: 30px 0; /* Increased space above and below */
            position: relative;
            z-index: 2;
        }

        /* Main Content */
        .main-content {
            display: grid;
            grid-template-columns: 1fr;
            gap: 30px;
            margin-bottom: 50px;
            margin-top: 33px; /* Added 20px space below header */
        }

        /* Form Container */
        .form-container, .order-summary, .confirmation-container {
            background: white;
            border-radius: 20px;
            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.1);
            padding: 30px;
            position: relative;
        }

        .section-title {
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 25px;
            color: #033333;
            display: flex;
            align-items: center;
            position: relative;
        }

        .section-title::after {
            content: "";
            display: block;
            width: 60px;
            height: 4px;
            background: linear-gradient(90deg, #5CB46A, #033333);
            border-radius: 2px;
            margin-top: 10px;
            position: absolute;
            bottom: -10px;
            left: 0;
        }

        .section-title i {
            margin-right: 12px;
            color: #5CB46A;
            font-size: 24px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }

        /* Three column layout for card details */
        .form-row.three-col {
            grid-template-columns: 1fr 1fr 1fr;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            font-size: 14px;
            color: #033333;
        }

        .form-control {
            width: 100%;
            padding: 14px 18px;
            border: 1px solid #d9f0f0;
            border-radius: 12px;
            font-size: 16px;
            transition: all 0.3s;
            background: #f8fdfd;
            color: #033333;
        }

        .form-control:disabled {
            background-color: #f0f8f8;
            color: #5a6a6a;
        }

        .form-control:focus {
            outline: none;
            border-color: #5CB46A;
            box-shadow: 0 0 0 3px rgba(92, 180, 106, 0.2);
        }

        .password-container {
            position: relative;
        }

        .toggle-password {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #5CB46A;
            background: none;
            border: none;
            font-size: 18px;
        }

        .checkbox-container {
            display: flex;
            align-items: center;
            margin-top: 15px;
        }

        .checkbox-container input {
            margin-right: 10px;
            accent-color: #5CB46A;
        }

        .checkbox-container label {
            color: #033333;
            font-size: 14px;
        }

        .checkbox-container a {
            color: #5CB46A;
            text-decoration: none;
            font-weight: 600;
        }

        .checkbox-container a:hover {
            text-decoration: underline;
        }

        .btn {
            display: inline-block;
            background: linear-gradient(135deg, #5CB46A 0%, #4CA05A 100%);
            color: white !important;
            text-decoration: none;
            padding: 16px 36px;
            border-radius: 50px;
            font-weight: 700;
            font-size: 17px;
            margin: 25px 0;
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: 0 6px 20px rgba(92, 180, 106, 0.35);
            border: none;
            cursor: pointer;
            width: 100%;
            position: relative;
            overflow: hidden;
        }

        .btn::before {
            content: "";
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: 0.6s;
        }

        .btn:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 25px rgba(92, 180, 106, 0.5);
            background: linear-gradient(135deg, #4CA05A 0%, #3e8e4c 100%);
        }

        .btn:hover::before {
            left: 100%;
        }

        .btn-outline {
            background: transparent;
            border: 2px solid #5CB46A;
            color: #5CB46A !important;
            box-shadow: none;
        }

        .btn-outline:hover {
            background: rgba(92, 180, 106, 0.1);
            transform: translateY(-4px);
            box-shadow: 0 4px 15px rgba(92, 180, 106, 0.25);
        }

        /* Order Summary */
        .order-summary {
            background: white;
            border-radius: 20px;
            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.1);
            padding: 30px;
            align-self: start;
            position: sticky;
            top: 30px;
        }

        .summary-title {
            font-size: 22px;
            font-weight: 600;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 1px solid #e0f0f0;
            position: relative;
        }

        .summary-title::after {
            content: "";
            display: block;
            width: 60px;
            height: 4px;
            background: linear-gradient(90deg, #5CB46A, #033333);
            border-radius: 2px;
            margin-top: 10px;
            position: absolute;
            bottom: -1px;
            left: 0;
        }

        .plan-card {
            background: rgba(92, 180, 106, 0.05);
            border-radius: 16px;
            padding: 20px;
            margin-bottom: 25px;
            border: 1px solid #e0f0f0;
        }

        .plan-name {
            font-weight: 700;
            margin-bottom: 5px;
            color: #033333;
            font-size: 18px;
        }

        .plan-price {
            font-size: 28px;
            font-weight: 800;
            color: #5CB46A;
            margin: 10px 0;
        }

        .plan-period {
            color: #5a6a6a;
            font-size: 16px;
        }

        .features-list {
            margin: 20px 0;
            padding-left: 0; /* Remove padding for bullet points */
            list-style-type: none; /* Remove bullet points */
        }

        .features-list li {
            margin-bottom: 12px;
            position: relative;
            padding-left: 25px;
            color: #033333;
        }

        .features-list li::before {
            content: "✓";
            color: #5CB46A;
            font-weight: bold;
            position: absolute;
            left: 0;
            font-size: 18px;
        }

        .summary-row {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid #e0f0f0;
            color: #033333;
            font-size: 16px;
        }

        .summary-row.total {
            font-weight: 700;
            font-size: 20px;
            border-bottom: none;
            margin-top: 10px;
            color: #033333;
        }

        /* Payment Methods */
        .payment-methods {
            margin: 30px 0;
        }

        .payment-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 15px;
            color: #033333;
        }

        .payment-options {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 10px;
            margin-bottom: 20px;
        }

        .payment-option {
            border: 1px solid #d9f0f0;
            border-radius: 12px;
            padding: 15px 10px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            background: #f8fdfd;
        }

        .payment-option.active {
            border-color: #5CB46A;
            background: rgba(92, 180, 106, 0.05);
            box-shadow: 0 4px 10px rgba(92, 180, 106, 0.15);
        }

        .payment-option img {
            height: 24px;
            display: block;
            margin: 0 auto 8px;
        }

        .payment-option span {
            font-size: 12px;
            color: #5a6a6a;
        }

        /* Trust Badges */
        .trust-badges {
            display: flex;
            justify-content: space-around;
            align-items: center;
            margin-top: 30px;
            padding-top: 25px;
            border-top: 1px solid #e0f0f0;
        }

        .trust-badge {
            display: flex;
            flex-direction: column;
            align-items: center;
            text-align: center;
        }

        .trust-badge i {
            font-size: 28px;
            color: #5CB46A;
            margin-bottom: 10px;
        }

        .trust-badge span {
            font-size: 13px;
            color: #033333;
            line-height: 1.4;
            font-weight: 500;
        }

        /* Footer */
        footer {
            background: #f0fafa;
            padding: 30px 0;
            border-radius: 0 0 20px 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .copyright {
            color: #5a6a6a;
            font-size: 14px;
        }

        .footer-links {
            display: flex;
            gap: 20px;
        }

        .footer-links a {
            color: #5CB46A;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.2s;
            font-size: 14px;
        }

        .footer-links a:hover {
            color: #033333;
            text-decoration: underline;
        }

        /* Responsive */
        @media (max-width: 900px) {
            .main-content {
                grid-template-columns: 1fr;
            }

            .stage1-container,
            .stage2-container {
                grid-template-columns: 1fr;
            }

            .form-row {
                grid-template-columns: 1fr;
                gap: 0;
            }

            .form-row.three-col {
                grid-template-columns: 1fr;
            }

            .payment-options {
                grid-template-columns: repeat(2, 1fr);
            }

            .footer-content {
                flex-direction: column;
                text-align: center;
                gap: 15px;
            }

            .footer-links {
                flex-wrap: wrap;
                justify-content: center;
            }
        }

        @media (max-width: 600px) {
            header {
                padding: 20px;
            }

            .logo {
                font-size: 30px;
            }

            .form-container, .order-summary {
                padding: 25px 20px;
            }

            .trust-badges {
                flex-direction: column;
                gap: 20px;
            }
        }

        /* Confirmation Styles */
        .confirmation-container {
            text-align: center;
            padding: 50px 30px;
        }

        .confirmation-icon {
            font-size: 80px;
            color: #5CB46A;
            margin-bottom: 25px;
            animation: scaleUp 0.5s ease;
        }

        .confirmation-title {
            font-size: 32px;
            font-weight: 700;
            margin-bottom: 20px;
            color: #033333;
        }

        .confirmation-subtitle {
            font-size: 18px;
            color: #5a6a6a;
            margin-bottom: 40px;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
            line-height: 1.6;
        }

        .order-details {
            background: rgba(92, 180, 106, 0.05);
            border-radius: 16px;
            padding: 25px;
            margin: 30px 0;
            text-align: left;
            max-width: 600px;
            margin-left: auto;
            margin-right: auto;
        }

        .detail-row {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid rgba(92, 180, 106, 0.2);
        }

        .detail-row:last-child {
            border-bottom: none;
        }

        .detail-label {
            font-weight: 600;
            color: #033333;
        }

        .detail-value {
            color: #033333;
        }

        .confirmation-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 40px;
        }

        .confirmation-buttons .btn {
            width: auto;
            min-width: 200px;
            margin: 0;
        }

        /* Toggle Container */
        .toggle-container {
            display: flex;
            margin-bottom: 30px;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }

        .toggle-option {
            flex: 1;
            padding: 20px;
            text-align: center;
            cursor: pointer;
            background: #f8fdfd;
            transition: all 0.3s ease;
            border: 1px solid #d9f0f0;
        }

        .toggle-option.active {
            background: rgba(92, 180, 106, 0.1);
            border-color: #5CB46A;
        }

        .toggle-option i {
            font-size: 28px;
            margin-bottom: 15px;
            color: #5CB46A;
        }

        .toggle-option h3 {
            font-size: 18px;
            margin-bottom: 8px;
            color: #033333;
        }

        .toggle-option p {
            font-size: 14px;
            color: #5a6a6a;
        }

        /* Animation */
        @keyframes scaleUp {
            0% {
                transform: scale(0.5);
                opacity: 0;
            }
            100% {
                transform: scale(1);
                opacity: 1;
            }
        }

        /* Step Navigation */
        .step-navigation {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
        }

        .step-navigation .btn {
            width: auto;
            min-width: 150px;
            margin: 0;
        }

        .step-navigation .btn-outline {
            margin-right: 10px;
        }

        /* Hidden Step */
        .step-content {
            display: none;
        }

        .step-content.active {
            display: block;
        }

        /* Stage Layouts */
        .stage1-container,
        .stage2-container {
            display: grid;
            grid-template-columns: 1fr 350px;
            gap: 30px;
        }

        /* New styles for social buttons */
        .social-signup {
            display: flex;
            gap: 15px;
            margin-bottom: 25px;
        }

        .btn-google {
            background: #4285F4;
            color: white !important;
            border: none;
        }

        .btn-apple {
            background: #000;
            color: white !important;
            border: none;
        }

        .btn-social {
            flex: 1;
            padding: 12px;
            border-radius: 12px;
            font-weight: 600;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.1);
        }

        .btn-social:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }

        .social-icon {
            font-size: 18px;
        }

        .or-divider {
            text-align: center;
            margin: 20px 0;
            position: relative;
        }

        .or-divider::before {
            content: "";
            position: absolute;
            top: 50%;
            left: 0;
            right: 0;
            height: 1px;
            background: #d9f0f0;
            z-index: 1;
        }

        .or-divider span {
            position: relative;
            z-index: 2;
            background: white;
            padding: 0 15px;
            color: #5a6a6a;
        }

        /* Password rules styling */
        .password-rules {
            background: rgba(92, 180, 106, 0.05);
            border-radius: 12px;
            padding: 15px;
            margin-top: 10px;
            font-size: 13px;
            color: #5a6a6a;
            display: none; /* Hidden by default */
        }

        .password-rules.show {
            display: block; /* Show when toggled */
        }

        .password-rules ul {
            padding-left: 20px;
            margin-top: 8px;
        }

        .password-rules li {
            margin-bottom: 5px;
        }

        .password-rules li.valid {
            color: #5CB46A;
        }

        .password-rules li.valid::before {
            content: "✓ ";
        }

        .password-rules li.invalid::before {
            content: "✗ ";
        }

        .password-toggle {
            display: flex;
            align-items: center;
            margin-top: 8px;
            cursor: pointer;
            color: #5a6a6a;
            font-size: 14px;
        }

        .password-toggle i {
            margin-right: 8px;
            color: #5CB46A;
        }

        /* Stripe element styling */
        .StripeElement {
            padding: 14px 18px;
            border: 1px solid #d9f0f0;
            border-radius: 12px;
            background: #f8fdfd;
        }

        .StripeElement--focus {
            border-color: #5CB46A;
            box-shadow: 0 0 0 3px rgba(92, 180, 106, 0.2);
        }

        .card-errors {
            color: #e63946;
            font-size: 14px;
            margin-top: 8px;
        }

        /* Coupon section */
        .coupon-section {
            display: flex;
            gap: 10px;
            margin: 15px 0;
        }

        .coupon-input {
            flex: 1;
        }

        .apply-btn {
            background: #5CB46A;
            color: white;
            border: none;
            border-radius: 8px;
            padding: 0 20px;
            cursor: pointer;
            font-weight: 600;
            transition: background 0.3s;
        }

        .apply-btn:hover {
            background: #4CA05A;
        }

        /* Progress Bar - Enhanced Design */
        .progress-container-inner {
            margin-bottom: 0;
        }

        .progress-steps-inner {
            display: flex;
            justify-content: space-between;
            position: relative;
            margin-bottom: 0;
        }

        .progress-steps-inner::before {
            content: "";
            position: absolute;
            top: 50%;
            left: 0;
            height: 8px; /* Thicker progress bar */
            width: 100%;
            background: rgba(255, 255, 255, 0.4); /* More visible track */
            transform: translateY(-50%);
            z-index: 1;
            border-radius: 4px;
        }

        .progress-bar-inner {
            position: absolute;
            top: 50%;
            left: 0;
            height: 8px; /* Thicker progress bar */
            width: var(--progress-width, 0%);
            background: linear-gradient(90deg, #5CB46A, #4CA05A);
            transform: translateY(-50%);
            z-index: 2;
            transition: width 0.3s ease;
            border-radius: 4px;
        }

        .step-inner {
            width: 50px; /* Larger circles */
            height: 50px; /* Larger circles */
            border-radius: 50%;
            background: transparent;
            border: 3px solid rgba(255, 255, 255, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700; /* Bold numbers */
            position: relative;
            z-index: 3;
            color: rgba(255, 255, 255, 0.9);
            transition: all 0.3s ease;
            font-size: 18px; /* Larger numbers */
        }

        .step-inner i {
            font-size: 20px;
        }

        .step-inner .number {
            display: none; /* Hide numbers */
        }

        .step-inner.active {
            border-color: #5CB46A;
            background: #5CB46A;
            color: white;
        }

        .step-inner.completed {
            border-color: #5CB46A;
            background: #5CB46A;
            color: white;
        }

        .step-label-inner {
            position: absolute;
            top: 55px; /* Adjusted position */
            left: 50%;
            transform: translateX(-50%);
            white-space: nowrap;
            font-size: 16px; /* Larger labels */
            color: rgba(255, 255, 255, 0.9);
            font-weight: 600; /* Bold labels */
        }

        .step-inner.active .step-label-inner {
            color: white;
            font-weight: 700;
        }

        .step-inner.completed .step-label-inner {
            color: white;
        }

        /* NEW PAYMENT METHOD SELECTOR */
        .payment-selector {
            margin-bottom: 25px;
        }

        .payment-selector-title {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 15px;
            color: #033333;
        }

        .payment-methods-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
        }

        .payment-method-card {
            border: 2px solid #e0f0f0;
            border-radius: 12px;
            padding: 15px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
            background: #f8fdfd;
            position: relative;
            overflow: hidden;
        }

        .payment-method-card.active {
            border-color: #5CB46A;
            background: rgba(92, 180, 106, 0.05);
            box-shadow: 0 4px 15px rgba(92, 180, 106, 0.2);
        }

        .payment-method-card.active::after {
            content: "✓";
            position: absolute;
            top: 5px;
            right: 5px;
            width: 20px;
            height: 20px;
            background: #5CB46A;
            color: white;
            border-radius: 50%;
            font-weight: bold;
            font-size: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .payment-method-icon {
            font-size: 28px;
            margin-bottom: 10px;
            color: #033333;
        }

        .payment-method-name {
            font-weight: 600;
            color: #033333;
            font-size: 15px;
        }

        /* PAYMENT METHOD CONTENT */
        .payment-method-content {
            margin-top: 20px;
            border-top: 1px solid #e0f0f0;
            padding-top: 20px;
        }

        .payment-method-section {
            display: none;
        }

        .payment-method-section.active {
            display: block;
        }

        .payment-option-desc {
            margin-bottom: 20px;
            color: #5a6a6a;
            font-size: 14px;
        }

        .payment-plan-toggle {
            display: flex;
            margin: 20px 0;
            border-radius: 12px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
            background: #f8fdfd;
        }

        .payment-plan-option {
            flex: 1;
            padding: 15px;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
        }

        .payment-plan-option.active {
            background: rgba(92, 180, 106, 0.1);
            color: #5CB46A;
            font-weight: 600;
        }

        .payment-plan-name {
            font-size: 16px;
            font-weight: 600;
        }

        .payment-plan-price {
            font-size: 18px;
            margin-top: 5px;
            font-weight: 700;
        }

        .payment-plan-savings {
            font-size: 12px;
            color: #5CB46A;
            margin-top: 5px;
            font-weight: 500;
        }

        .apple-pay-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: #000;
            color: #fff;
            border: none;
            border-radius: 10px;
            padding: 15px 20px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            width: 100%;
            margin-top: 10px;
        }

        .apple-pay-button i {
            font-size: 24px;
            margin-right: 10px;
        }

        .apple-pay-button:hover {
            background: #333;
        }

        .klarna-button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            background: #ffb3c7;
            color: #000;
            border: none;
            border-radius: 10px;
            padding: 15px 20px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s;
            width: 100%;
            margin-top: 10px;
        }

        .klarna-button:hover {
            background: #ff99b7;
        }

        .klarna-logo {
            height: 24px;
            margin-right: 10px;
        }

        /* Payment method icons */
        .payment-icons {
            display: flex;
            justify-content: center;
            gap: 10px;
            margin-top: 15px;
        }

        .payment-icon {
            height: 24px;
            filter: grayscale(100%);
            opacity: 0.7;
        }

        /* NEW: Card number input with icon */
        .card-input-with-icon {
            position: relative;
        }

        .card-input-with-icon i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #5a6a6a;
        }

        .card-input-with-icon input {
            padding-left: 45px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->

        @yield('content')

        <!-- Footer -->
        <footer>
            <div class="footer-content">
                <div class="copyright">
                    © 2025 Twindo t/a EDPLX Limited. Registered in England and Wales No. 12345678.
                </div>
                <div class="footer-links">
                    <a href="#">Privacy Policy</a>
                    <a href="#">Terms of Service</a>
                    <a href="#">Contact Us</a>
                    <a href="#">Support</a>
                </div>
            </div>
        </footer>
    </div>

    <script>
        // Toggle password visibility
        document.querySelectorAll('.toggle-password').forEach(button => {
            button.addEventListener('click', function() {
                const passwordInput = this.previousElementSibling;
                const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordInput.setAttribute('type', type);
                this.querySelector('i').classList.toggle('fa-eye');
                this.querySelector('i').classList.toggle('fa-eye-slash');
            });
        });

        // Payment method selection
        const paymentMethodCards = document.querySelectorAll('.payment-method-card');
        paymentMethodCards.forEach(card => {
            card.addEventListener('click', () => {
                paymentMethodCards.forEach(c => c.classList.remove('active'));
                card.classList.add('active');

                const method = card.dataset.method;
                document.querySelectorAll('.payment-method-section').forEach(section => {
                    section.classList.remove('active');
                });
                document.getElementById(`${method}-method`).classList.add('active');
            });
        });

        // Payment plan selection
        const paymentPlanOptions = document.querySelectorAll('.payment-plan-option');
        paymentPlanOptions.forEach(option => {
            option.addEventListener('click', () => {
                paymentPlanOptions.forEach(o => o.classList.remove('active'));
                option.classList.add('active');

                const plan = option.dataset.plan;
                if (plan === 'monthly') {
                    document.getElementById('plan-price-display').textContent = '£59.99';
                    document.getElementById('plan-period-display').textContent = 'per month';
                    document.getElementById('subtotal-display').textContent = '£59.99';
                    document.getElementById('total-display').textContent = '£59.99';
                } else {
                    document.getElementById('plan-price-display').textContent = '£599.99';
                    document.getElementById('plan-period-display').textContent = 'per year';
                    document.getElementById('subtotal-display').textContent = '£599.99';
                    document.getElementById('total-display').textContent = '£599.99';
                }
            });
        });

        // Toggle between Create Account and Sign In
        const toggleOptions = document.querySelectorAll('.toggle-option');
        toggleOptions.forEach(option => {
            option.addEventListener('click', () => {
                toggleOptions.forEach(opt => opt.classList.remove('active'));
                option.classList.add('active');

                if (option.dataset.option === 'create') {
                    document.getElementById('create-account-form').style.display = 'block';
                    document.getElementById('login-form').style.display = 'none';
                } else {
                    document.getElementById('create-account-form').style.display = 'none';
                    document.getElementById('login-form').style.display = 'block';
                }
            });
        });

        // Password validation rules
        const passwordInput = document.getElementById('password');
        const rules = {
            length: document.getElementById('rule-length'),
            uppercase: document.getElementById('rule-uppercase'),
            lowercase: document.getElementById('rule-lowercase'),
            number: document.getElementById('rule-number'),
            special: document.getElementById('rule-special')
        };

        passwordInput.addEventListener('input', function() {
            const password = this.value;

            // Check each rule
            const hasLength = password.length >= 8;
            const hasUppercase = /[A-Z]/.test(password);
            const hasLowercase = /[a-z]/.test(password);
            const hasNumber = /[0-9]/.test(password);
            const hasSpecial = /[!@#$%^&*(),.?":{}|<>]/.test(password);

            // Update UI
            updateRule(rules.length, hasLength);
            updateRule(rules.uppercase, hasUppercase);
            updateRule(rules.lowercase, hasLowercase);
            updateRule(rules.number, hasNumber);
            updateRule(rules.special, hasSpecial);
        });

        function updateRule(element, isValid) {
            element.classList.toggle('valid', isValid);
            element.classList.toggle('invalid', !isValid);
        }

        // Toggle password rules visibility
        document.getElementById('password-toggle').addEventListener('click', function() {
            const rules = document.getElementById('password-rules');
            rules.classList.toggle('show');
        });

        // Navigation between steps
        const steps = document.querySelectorAll('.step-content');
        const progressBar = document.querySelector('.progress-bar-inner');
        const stepLabels = document.querySelectorAll('.step-inner');

        // function navigateToStep(stepNumber) {
        //     // Hide all steps
        //     steps.forEach(step => step.classList.remove('active'));

        //     // Show selected step
        //     // document.getElementById(`step${stepNumber}`).classList.add('active');

        //     // Update progress bar
        //     // progressBar.style.setProperty('--progress-width', `${(stepNumber - 1) * 50}%`);

        //     // Update step indicators
        //     stepLabels.forEach((step, index) => {
        //         step.classList.remove('active', 'completed');
        //         if (index + 1 < stepNumber) {
        //             step.classList.add('completed');
        //         } else if (index + 1 === stepNumber) {
        //             step.classList.add('active');
        //         }
        //     });
        // }

        // Set initial step
        navigateToStep(1);

        // Button event listeners
        document.getElementById('continue-to-payment').addEventListener('click', () => {
            navigateToStep(2);
        });

        document.getElementById('back-to-account').addEventListener('click', () => {
            navigateToStep(1);
        });

        document.getElementById('complete-purchase').addEventListener('click', () => {
            const selectedMethod = document.querySelector('.payment-method-card.active').dataset.method;

            if (selectedMethod === 'card') {
                // Validate card inputs
                const cardNumber = document.getElementById('card-number').value;
                const cardExpiry = document.getElementById('card-expiry').value;
                const cardCvc = document.getElementById('card-cvc').value;

                if (!cardNumber || !cardExpiry || !cardCvc) {
                    alert('Please fill in all card details');
                    return;
                }

                // Simulate payment processing
                setTimeout(() => {
                    navigateToStep(3);
                }, 1500);
            } else if (selectedMethod === 'apple') {
                // Simulate Apple Pay flow
                setTimeout(() => {
                    navigateToStep(3);
                }, 2000);
            } else if (selectedMethod === 'klarna') {
                // Simulate Klarna flow
                setTimeout(() => {
                    navigateToStep(3);
                }, 2000);
            }
        });

        document.getElementById('apple-pay-button').addEventListener('click', () => {
            document.getElementById('complete-purchase').click();
        });

        document.getElementById('klarna-button').addEventListener('click', () => {
            document.getElementById('complete-purchase').click();
        });

        document.getElementById('go-to-dashboard').addEventListener('click', () => {
            alert('Redirecting to your dashboard...');
        });

        document.getElementById('back-to-home').addEventListener('click', () => {
            alert('Redirecting to home page...');
        });

        // Social signup handlers
        document.getElementById('google-signup').addEventListener('click', () => {
            alert('Redirecting to Google signup...');
        });

        document.getElementById('apple-signup').addEventListener('click', () => {
            alert('Redirecting to Apple signup...');
        });
    </script>

    @stack('js')
</body>
</html>