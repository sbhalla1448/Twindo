@extends('customer.payment.master')

@section('content')
    <livewire:checkout.checkout-page :splan="$splan">
@endsection