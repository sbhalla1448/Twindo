@extends('customer.payment.master')

@section('content')
    <div class="alert alert-danger">
        <h2>Payment Failed</h2>
        <p>{{ $message }}</p>
    </div>
@endsection