<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Checkout - ADEX Unit Prep</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://js.stripe.com/v3/"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        .card-input {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 12px;
            transition: all 0.3s ease;
        }
        .card-input:focus-within {
            border-color: #3b82f6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
        }
        .spinner {
            border: 2px solid #f3f3f3;
            border-top: 2px solid #3b82f6;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            animation: spin 1s linear infinite;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <div class="container mx-auto px-4 py-8">
        <div class="max-w-7xl mx-auto">
            <!-- Header -->
            <div class="mb-8">
                <h1 class="text-3xl font-bold text-gray-900 mb-2">Complete Your Purchase</h1>
                <p class="text-gray-600">Secure checkout powered by Stripe</p>
            </div>

            <div class="grid lg:grid-cols-2 gap-8">
                <!-- Left Side - Product Information -->
                <div class="space-y-6">
                    <!-- Product Card -->
                    <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
                        <div class="gradient-bg p-6 text-white relative">
                            <div class="absolute top-4 right-4">
                                <span class="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-semibold">
                                    Limited Time Offer
                                </span>
                            </div>
                            <div class="flex items-center space-x-4">
                                <div class="bg-white/20 p-3 rounded-lg">
                                    <i class="fas fa-tooth text-2xl"></i>
                                </div>
                                <div>
                                    <h2 class="text-xl font-bold">ADEX PREP ACADEMY</h2>
                                    <p class="text-white/80">PERIODONTAL SCALING</p>
                                </div>
                            </div>
                        </div>

                        <div class="p-6">
                            <h3 class="text-2xl font-bold text-gray-900 mb-4">
                                ADEX Unit Prep - Periodontal-scaling
                            </h3>

                            <div class="prose text-gray-600 mb-6">
                                <p class="leading-relaxed">
                                    Our online Periodontal scaling course helps you develop the precision and
                                    technique needed to excel in the ADEX exam. With expert guidance and a
                                    structured approach, you'll build the confidence to perform the preparations
                                    of the anterior and posterior prosthodontics exams.
                                </p>
                                <p class="leading-relaxed mt-4">
                                    This course ensures you're fully prepared, so you can focus on perfecting
                                    your skills and achieving exam success without stress.
                                </p>
                            </div>

                            <!-- Course Features -->
                            <div class="space-y-3 mb-6">
                                <div class="flex items-center space-x-3">
                                    <i class="fas fa-check-circle text-green-500"></i>
                                    <span class="text-gray-700">Expert instructor guidance</span>
                                </div>
                                <div class="flex items-center space-x-3">
                                    <i class="fas fa-check-circle text-green-500"></i>
                                    <span class="text-gray-700">Structured learning approach</span>
                                </div>
                                <div class="flex items-center space-x-3">
                                    <i class="fas fa-check-circle text-green-500"></i>
                                    <span class="text-gray-700">Practical exam preparation</span>
                                </div>
                                <div class="flex items-center space-x-3">
                                    <i class="fas fa-check-circle text-green-500"></i>
                                    <span class="text-gray-700">Lifetime access</span>
                                </div>
                            </div>

                            <!-- Pricing -->
                            <div class="bg-gray-50 rounded-xl p-4">
                                <div class="flex items-center justify-between">
                                    <div>
                                        <p class="text-gray-500 line-through text-lg">$797</p>
                                        <p class="text-3xl font-bold text-gray-900">$647</p>
                                    </div>
                                    <div class="text-right">
                                        <p class="text-green-600 font-semibold">Save $150</p>
                                        <p class="text-sm text-gray-500">Limited time</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Security Notice -->
                    <div class="bg-blue-50 border border-blue-200 rounded-xl p-4">
                        <div class="flex items-start space-x-3">
                            <i class="fas fa-shield-alt text-blue-600 mt-1"></i>
                            <div>
                                <h4 class="font-semibold text-blue-900 mb-1">Guaranteed Security</h4>
                                <p class="text-blue-700 text-sm">
                                    Your information is processed and encrypted securely using industry-leading
                                    encryption and fraud prevention tools.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Right Side - Checkout Form -->
                <div class="bg-white rounded-2xl shadow-lg p-8">
                    <!-- Success/Error Messages -->
                    <div id="success-message" class="hidden mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                        <div class="flex items-center space-x-2">
                            <i class="fas fa-check-circle text-green-600"></i>
                            <span class="text-green-800 font-medium">Payment successful! Thank you for your purchase.</span>
                        </div>
                    </div>

                    <div id="error-message" class="hidden mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                        <div class="flex items-center space-x-2">
                            <i class="fas fa-exclamation-circle text-red-600"></i>
                            <span class="text-red-800 font-medium" id="error-text"></span>
                        </div>
                    </div>

                    <form id="checkout-form" class="space-y-6">
                        <!-- Account Information -->
                        <div>
                            <h3 class="text-xl font-semibold text-gray-900 mb-4">Sign Up</h3>

                            <div class="grid md:grid-cols-2 gap-4 mb-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">
                                        What's your name? <span class="text-red-500">*</span>
                                    </label>
                                    <input type="text" id="customer-name" required
                                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                           placeholder="Full Name">
                                </div>

                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">
                                        What's your e-mail? <span class="text-red-500">*</span>
                                    </label>
                                    <input type="email" id="customer-email" required
                                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                           placeholder="Email Address">
                                </div>
                            </div>

                            <div class="mb-4">
                                <label class="block text-sm font-medium text-gray-700 mb-2">
                                    Your password? <span class="text-red-500">*</span>
                                </label>
                                <div class="relative">
                                    <input type="password" id="customer-password" required
                                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors pr-12"
                                           placeholder="Password">
                                    <button type="button" class="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>

                            <!-- Social Login Options -->
                            <div class="text-center mb-4">
                                <span class="text-gray-500 text-sm">— or —</span>
                            </div>

                            <div class="flex space-x-3 mb-4">
                                <button type="button" class="flex-1 flex items-center justify-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                                    <i class="fab fa-google text-red-500 mr-2"></i>
                                    <span class="text-sm">Google</span>
                                </button>
                                <button type="button" class="flex-1 flex items-center justify-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                                    <i class="fab fa-facebook text-blue-600 mr-2"></i>
                                    <span class="text-sm">Facebook</span>
                                </button>
                                <button type="button" class="flex-1 flex items-center justify-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                                    <i class="fab fa-linkedin text-blue-700 mr-2"></i>
                                    <span class="text-sm">LinkedIn</span>
                                </button>
                                <button type="button" class="flex-1 flex items-center justify-center px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors">
                                    <i class="fab fa-apple text-gray-900 mr-2"></i>
                                    <span class="text-sm">Apple</span>
                                </button>
                            </div>

                            <p class="text-sm text-gray-600">
                                Do you already have an account?
                                <a href="#" class="text-blue-600 hover:text-blue-800 font-medium">Log in here.</a>
                            </p>
                        </div>

                        <hr class="border-gray-200">

                        <!-- Billing Details -->
                        <div>
                            <h3 class="text-xl font-semibold text-gray-900 mb-4">Billing Details</h3>

                            <div class="grid md:grid-cols-2 gap-4 mb-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">
                                        Name <span class="text-red-500">*</span>
                                    </label>
                                    <input type="text" id="billing-name" required
                                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors">
                                </div>

                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">
                                        Address <span class="text-red-500">*</span>
                                    </label>
                                    <input type="text" id="billing-address" required
                                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors">
                                </div>
                            </div>

                            <div class="grid md:grid-cols-3 gap-4 mb-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">City</label>
                                    <input type="text" id="billing-city"
                                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors">
                                </div>

                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">
                                        Postal code <span class="text-red-500">*</span>
                                    </label>
                                    <input type="text" id="billing-postal" required
                                           class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors">
                                </div>

                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">
                                        Country <span class="text-red-500">*</span>
                                    </label>
                                    <select id="billing-country" required
                                            class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors">
                                        <option value="">Select Country</option>
                                        <option value="US">United States</option>
                                        <option value="CA">Canada</option>
                                        <option value="GB">United Kingdom</option>
                                        <option value="AU">Australia</option>
                                        <option value="DE">Germany</option>
                                        <option value="FR">France</option>
                                    </select>
                                </div>
                            </div>

                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-2">Business Tax ID</label>
                                <input type="text" id="business-tax-id"
                                       class="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                       placeholder="Optional">
                            </div>
                        </div>

                        <hr class="border-gray-200">

                        <!-- Payment Method -->
                        <div>
                            <h3 class="text-xl font-semibold text-gray-900 mb-4">Payment Method</h3>

                            <!-- Payment Options -->
                            <div class="grid grid-cols-3 gap-3 mb-6">
                                <button type="button" id="card-payment-btn" class="payment-method-btn active flex items-center justify-center px-4 py-3 border-2 border-blue-500 bg-blue-50 rounded-lg transition-all">
                                    <i class="fas fa-credit-card text-blue-600 mr-2"></i>
                                    <span class="text-blue-600 font-medium">Card</span>
                                </button>
                                <button type="button" class="payment-method-btn flex items-center justify-center px-4 py-3 border-2 border-gray-200 rounded-lg transition-all hover:border-gray-300">
                                    <span class="bg-pink-500 text-white px-3 py-1 rounded text-sm font-bold">Klarna</span>
                                </button>
                                <button type="button" class="payment-method-btn flex items-center justify-center px-4 py-3 border-2 border-gray-200 rounded-lg transition-all hover:border-gray-300">
                                    <span class="bg-green-600 text-white px-3 py-1 rounded text-sm font-bold">afterpay</span>
                                </button>
                            </div>

                            <!-- Card Details -->
                            <div id="card-details" class="space-y-4">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700 mb-2">Card number</label>
                                    <div id="card-number-element" class="card-input"></div>
                                </div>

                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Expiration date</label>
                                        <div id="card-expiry-element" class="card-input"></div>
                                    </div>
                                    <div>
                                        <label class="block text-sm font-medium text-gray-700 mb-2">Security code</label>
                                        <div id="card-cvc-element" class="card-input"></div>
                                    </div>
                                </div>

                                <div id="card-errors" class="text-red-600 text-sm"></div>
                            </div>

                            <!-- Coupon -->
                            <div class="mt-6">
                                <div class="flex space-x-2">
                                    <input type="text" id="coupon-code"
                                           class="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors"
                                           placeholder="Have a coupon?">
                                    <button type="button" id="apply-coupon"
                                            class="px-6 py-3 bg-red-400 text-white rounded-lg hover:bg-red-500 transition-colors font-medium">
                                        Redeem
                                    </button>
                                </div>
                            </div>
                        </div>

                        <hr class="border-gray-200">

                        <!-- Order Summary -->
                        <div class="bg-gray-50 rounded-xl p-6">
                            <div class="flex items-center justify-between text-xl font-bold text-gray-900">
                                <span>Total:</span>
                                <span id="total-amount">$647</span>
                            </div>
                        </div>

                        <!-- Submit Button -->
                        <button type="submit" id="submit-payment"
                                class="w-full bg-red-400 text-white py-4 rounded-xl font-semibold text-lg hover:bg-red-500 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center">
                            <span id="button-text">Buy Now</span>
                            <div id="button-spinner" class="hidden spinner ml-3"></div>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Initialize Stripe
        const stripe = Stripe('{{ $stripe_public_key ?? "pk_test_your_key_here" }}');
        const elements = stripe.elements();

        // Create card elements
        const cardNumber = elements.create('cardNumber');
        const cardExpiry = elements.create('cardExpiry');
        const cardCvc = elements.create('cardCvc');

        // Mount elements
        cardNumber.mount('#card-number-element');
        cardExpiry.mount('#card-expiry-element');
        cardCvc.mount('#card-cvc-element');

        // Handle errors
        [cardNumber, cardExpiry, cardCvc].forEach(element => {
            element.on('change', function(event) {
                const displayError = document.getElementById('card-errors');
                if (event.error) {
                    displayError.textContent = event.error.message;
                } else {
                    displayError.textContent = '';
                }
            });
        });

        // Payment method selection
        document.querySelectorAll('.payment-method-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.querySelectorAll('.payment-method-btn').forEach(b => {
                    b.classList.remove('active', 'border-blue-500', 'bg-blue-50');
                    b.classList.add('border-gray-200');
                });
                this.classList.add('active', 'border-blue-500', 'bg-blue-50');
                this.classList.remove('border-gray-200');
            });
        });

        // Form submission
        document.getElementById('checkout-form').addEventListener('submit', async function(e) {
            e.preventDefault();

            const submitButton = document.getElementById('submit-payment');
            const buttonText = document.getElementById('button-text');
            const buttonSpinner = document.getElementById('button-spinner');

            // Disable button and show loading
            submitButton.disabled = true;
            buttonText.textContent = 'Processing...';
            buttonSpinner.classList.remove('hidden');

            hideMessages();

            try {
                // Get form data
                const customerEmail = document.getElementById('customer-email').value;
                const customerName = document.getElementById('customer-name').value;
                const amount = 647; // $647

                // Validate required fields
                if (!customerEmail || !customerName) {
                    throw new Error('Please fill in all required fields');
                }

                console.log('Creating payment intent...', { amount, customerEmail, customerName });

                // Create payment intent
                const intentResponse = await fetch('/payment/create-intent', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    body: JSON.stringify({
                        amount: amount,
                        currency: 'usd',
                        customer_email: customerEmail,
                        customer_name: customerName
                    })
                });

                console.log('Intent response status:', intentResponse.status);

                // Check if response is JSON
                const contentType = intentResponse.headers.get('content-type');
                if (!contentType || !contentType.includes('application/json')) {
                    const textResponse = await intentResponse.text();
                    console.error('Non-JSON response:', textResponse);
                    throw new Error('Server returned invalid response. Please check your configuration.');
                }

                const intentData = await intentResponse.json();
                console.log('Intent data:', intentData);

                if (!intentResponse.ok) {
                    throw new Error(intentData.error || intentData.message || 'Failed to create payment intent');
                }

                if (!intentData.client_secret) {
                    throw new Error('Invalid payment intent response');
                }

                console.log('Confirming payment...');

                // Confirm payment
                const {error, paymentIntent} = await stripe.confirmCardPayment(
                    intentData.client_secret,
                    {
                        payment_method: {
                            card: cardNumber,
                            billing_details: {
                                name: customerName,
                                email: customerEmail,
                                address: {
                                    line1: document.getElementById('billing-address').value || '',
                                    city: document.getElementById('billing-city').value || '',
                                    postal_code: document.getElementById('billing-postal').value || '',
                                    country: document.getElementById('billing-country').value || '',
                                }
                            }
                        }
                    }
                );

                if (error) {
                    console.error('Stripe error:', error);
                    throw new Error(error.message);
                } else {
                    console.log('Payment confirmed, processing...');

                    // Process successful payment
                    const processResponse = await fetch('/payment/process', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'Accept': 'application/json',
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content'),
                            'X-Requested-With': 'XMLHttpRequest'
                        },
                        body: JSON.stringify({
                            payment_intent_id: paymentIntent.id
                        })
                    });

                    const processContentType = processResponse.headers.get('content-

        function showSuccess() {
            document.getElementById('success-message').classList.remove('hidden');
            document.getElementById('error-message').classList.add('hidden');
            window.scrollTo(0, 0);
        }

        function showError(message) {
            document.getElementById('error-text').textContent = message;
            document.getElementById('error-message').classList.remove('hidden');
            document.getElementById('success-message').classList.add('hidden');
            window.scrollTo(0, 0);
        }

        function hideMessages() {
            document.getElementById('success-message').classList.add('hidden');
            document.getElementById('error-message').classList.add('hidden');
        }

        // Auto-fill billing name from customer name
        document.getElementById('customer-name').addEventListener('input', function() {
            const billingName = document.getElementById('billing-name');
            if (!billingName.value) {
                billingName.value = this.value;
            }
        });

        // Coupon functionality
        document.getElementById('apply-coupon').addEventListener('click', function() {
            const couponCode = document.getElementById('coupon-code').value;
            if (couponCode) {
                // Implement coupon logic here
                alert('Coupon functionality would be implemented here');
            }
        });
    </script>
</body>
</html>