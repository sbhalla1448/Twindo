
@extends('customer.master')

@section('content')
<main class="flex-1 overflow-auto">
  <div class="max-w-4xl mx-auto px-6 py-10 space-y-10">

    <section class="bg-white rounded-xl shadow p-8">
      <h2 class="text-3xl font-bold text-gray-800 mb-6">Upload Your Credit Score</h2>
      <p class="text-gray-600 mb-8">Please upload your latest Experian credit score and a screenshot showing your report summary to keep your profile up-to-date.</p>

      <form action="{{ route('credit.score.store') }}"  class="space-y-8" onsubmit="simulateUpload(event)" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="space-y-6">
          <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <label for="score" class="block text-sm font-semibold text-gray-700 mb-2">Current Credit Score</label>
              <input type="number" id="score" name="score" placeholder="e.g., 720" class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 py-3 px-4" required>
                @error('score')
                    <span class="text-red-700">{{$message}}</span>
                @enderror
            </div>

            <div>
              <label for="reportDate" class="block text-sm font-semibold text-gray-700 mb-2">Date of Report</label>
              <input type="date" id="reportDate" name="score_date" class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 py-3 px-4" required>
              @error('score_date')
              <span class="text-red-700">{{$message}}</span>
          @enderror
            </div>

            <div>
              <label for="agency" class="block text-sm font-semibold text-gray-700 mb-2">Credit Reference Agency</label>
              <select id="agency" name="credit_ref_agency" class="w-full border-gray-300 rounded-lg shadow-sm focus:ring-indigo-500 focus:border-indigo-500 py-3 px-4" required>
                <option value="">Credit Reference Agency</option>

                @foreach (\App\Enums\CreditRefAgency::options() as $status)
                <option value="{{ $status->value }}">
                    {{ $status->label() }}
                </option>
            @endforeach
              </select>
              @error('credit_ref_agency')
                    <span class="text-red-700">{{$message}}</span>
                @enderror
            </div>
          </div>

          <div>
            <label class="block text-sm font-semibold text-gray-700 mb-2">Upload Screenshot</label>
            <div id="dropzone" class="flex items-center justify-center w-full h-40 p-4 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer text-gray-400 hover:border-indigo-400 hover:text-indigo-500">
              Drag & Drop file here or click to select
            </div>
            <input type="file" id="screenshot" name="image" accept="image/*" class="hidden">
            @error('image')
                    <span class="text-red-700">{{$message}}</span>
                @enderror
            {{-- <div id="progressBar" class="hidden mt-4 w-full bg-gray-200 rounded-full">
              <div id="progress" class="bg-indigo-600 text-xs leading-none py-1 text-center text-white rounded-full" style="width: 0%;">0%</div>
            </div> --}}
          </div>
          <div id="uploadProgressBar" class="hidden w-full bg-gray-200 rounded-full h-4 mt-4">
            <div class="bg-indigo-600 h-4 rounded-full transition-all duration-300" style="width: 0%"></div>
        </div>

        <div id="cancelUploadButton" class="hidden flex justify-end mt-2">
            <button type="button" onclick="cancelUpload()"
                class="text-red-600 hover:text-red-800 font-semibold text-sm">Cancel Upload</button>
        </div>
        </div>

        <div class="flex justify-end">
          <button type="submit"  class="px-8 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg transition duration-300">Submit</button>
        </div>
      </form>
    </section>

    <section class="bg-white rounded-xl shadow p-8">
      <h2 class="text-2xl font-bold text-gray-800 mb-6">How to Get Your Experian Credit Report</h2>
      <ul class="list-disc list-inside space-y-3 text-gray-700">
        <li><strong>Download the Experian App:</strong> Available on the Apple App Store or Google Play Store.</li>
        <li><strong>Create a free account:</strong> Or log in with your existing details.</li>
        <li><strong>Verify your identity:</strong> Using your name, address, and credit history.</li>
        <li><strong>Access your credit dashboard:</strong> View your full report and credit score.</li>
        <li><strong>Take a screenshot:</strong> Ensure your Experian score and summary are clearly visible.</li>
        <li><strong>Upload here:</strong> Use the form above to submit your latest score and screenshot.</li>
      </ul>
    </section>

  </div>
</main>

@endsection

@push('js')
<script>
let uploadInterval;

function showToast(message = '✅ Document uploaded successfully!') {
    const toast = document.getElementById('successToast');
    toast.innerText = message;
    toast.classList.remove('hidden');
    setTimeout(() => toast.classList.add('hidden'), 3000);
}

function updateFileName(event) {
    const files = Array.from(event.target.files).map(f => f.name).join(', ');
    const fileLabel = document.getElementById('fileNameDisplay');
    fileLabel.innerText = files ? `Selected Files: ${files}` : '';
}

function simulateUpload(event) {
    event.preventDefault();

    const progressBar = document.getElementById('uploadProgressBar');
    const cancelButton = document.getElementById('cancelUploadButton');
    const form = event.target;

    progressBar.classList.remove('hidden');
    cancelButton.classList.remove('hidden');

    let width = 1;
    uploadInterval = setInterval(() => {
        if (width >= 100) {
            clearInterval(uploadInterval);
            progressBar.classList.add('hidden');
            cancelButton.classList.add('hidden');
            progressBar.firstElementChild.style.width = '0%';

            // Now submit the form after simulation completes
            form.submit();
        } else {
            width++;
            progressBar.firstElementChild.style.width = width + '%';
        }
    }, 10); // Simulate faster upload
}

function cancelUpload() {
    clearInterval(uploadInterval);
    const progressBar = document.getElementById('uploadProgressBar');
    const cancelButton = document.getElementById('cancelUploadButton');
    progressBar.classList.add('hidden');
    cancelButton.classList.add('hidden');
    progressBar.firstElementChild.style.width = '0%';
}


// Drag & Drop functionality
const dropzone = document.getElementById('dropzone');
const fileInput = document.getElementById('screenshot');

dropzone.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', () => {
  dropzone.textContent = fileInput.files[0].name;
});

dropzone.addEventListener('dragover', (e) => {
  e.preventDefault();
  dropzone.classList.add('drag-over');
});

dropzone.addEventListener('dragleave', () => {
  dropzone.classList.remove('drag-over');
});

dropzone.addEventListener('drop', (e) => {
  e.preventDefault();
  dropzone.classList.remove('drag-over');
  fileInput.files = e.dataTransfer.files;
  dropzone.textContent = fileInput.files[0].name;
});
</script>
@endpush