@extends('customer.master')

@section('content')
<!-- Main Content -->

<livewire:customer.message-action />

@endsection