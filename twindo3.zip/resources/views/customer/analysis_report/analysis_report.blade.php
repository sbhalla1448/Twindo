@extends('customer.master')

@section('content')

<main class="flex-1 overflow-auto">
    <div class="max-w-7xl mx-auto px-6 py-10">

      <section class="bg-white rounded-xl shadow p-8 mb-8">
        <h3 class="text-2xl font-bold text-gray-800 mb-2">📈 Analysis Report</h3>

        <div class="border-t border-gray-200 mb-8"></div>
{{--
        <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <input id="searchResources" type="search" wire:model.live="search" placeholder="🔍 Search Resources..." class="w-full md:w-1/3 border rounded-md p-2 text-sm mb-4 md:mb-0">
          <select wire:model.live="categoryId" class="w-full md:w-48 border rounded-md p-2 text-sm">
            <option value="">All Categories</option>
            {{-- @foreach ($categories as $category)
            <option value="{{ $category->id }}">{{$category->name}}</option>
            @endforeach --}}
          {{-- </select>
        </div> --}}

   <!-- Upcoming Tasks -->
   <div class="bg-white p-8 rounded-xl shadow">
    <h3 class="text-2xl font-bold text-indigo-700 mb-4">Analysis Reports ({{ count($reports) }})</h3>
    <div class="overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="bg-gray-100 text-gray-700">
          <tr>
            <th class="py-3 px-4 text-left">Title</th>
            <th class="py-3 px-4 text-left">Date</th>

            <th class="py-3 px-4 text-left">Action</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-200">
            @foreach ($reports as $report)


          <tr>
            <td class="py-3 px-4">{{ $report->title }}</td>

            <td class="py-3 px-4">{{ $report->date->format('d M Y') }}</td>

            <td class="py-3 px-4"><a href="{{ route('analysis.report.show',$report->id) }}" target="_blank"  class="text-indigo-600 hover:underline">View</a></td>
          </tr>
          @endforeach
        </tbody>
      </table>
    </div>
  </div>


      </section>

    </div>
         <!-- View Resource Modal -->

  </main>




@endsection