
{!! $templateReport->html_content!!}


