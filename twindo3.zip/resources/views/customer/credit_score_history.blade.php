@extends('customer.master')

@section('content')
<!-- Main Content -->
<main class="flex-1 overflow-auto">
  <div class="max-w-6xl mx-auto px-4 py-10 space-y-10">

    <!-- Hero Section -->

    <!-- Insights Card -->
    <div class="grid md:grid-cols-3 gap-6">
      <div class="bg-white shadow rounded-xl p-5 text-center">
        <p class="text-gray-600 text-sm">Current Score</p>
        <p class="text-3xl font-bold text-green-600">{{ $currentScore->score }}</p>
        <p class="text-xs text-gray-500">{{ creditScoreDescription($currentScore->score) }}</p>
      </div>
      <div class="bg-white shadow rounded-xl p-5 text-center">
        <p class="text-gray-600 text-sm">Change Since First Credit Score</p>
        @php
    $diff = $currentScore?->score - $current2ndScore?->score;
@endphp
        <p class="text-3xl font-bold text-indigo-600">{{ $diff > 0 ? '+' : '' }}{{ $diff }}</p>
        <p class="text-xs text-gray-500">From {{ $current2ndScore->score ?? '0' }} to {{ $currentScore->score ?? '0' }}</p>
      </div>
      <div class="bg-white shadow rounded-xl p-5 text-center">
        <p class="text-gray-600 text-sm">Agency</p>
        <p class="text-lg font-bold text-gray-700">{{ $currentScore->credit_ref_agency }}</p>
        <p class="text-xs text-gray-500">Last updated {{$currentScore->created_at->format('d M Y')}}</p>
      </div>
    </div>

    <div class="flex items-center justify-between">
      <div>
        <h2 class="text-3xl font-bold text-gray-800">Credit Score History</h2>
        <p class="text-gray-500">View your previous scores and track your improvement over time.</p>
      </div>
      <a href="{{ route('credit.score.create') }}">
      <button class="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-lg font-semibold">Upload New Score</button></a>
    </div>

    <!-- Filters -->
    <div class="flex items-center gap-4">
      <label for="filter" class="text-sm font-semibold text-gray-600">Filter By:</label>
      <form method="GET" action="">
      <select name="filter" id="filter" onchange="this.form.submit()" class="border border-gray-300 rounded-lg px-3 py-2 focus:ring-indigo-500 focus:border-indigo-500">
        <option value="3m" {{ $filter == '3m' ? 'selected' : '' }} >Last 3 Months</option>
        <option value="6m" {{ $filter == '6m' ? 'selected' : '' }} >Last 6 Months</option>
        <option value="12m" {{ $filter == '12m' ? 'selected' : '' }} >Last 12 Months</option>
        <option  value="all" {{ $filter == 'all' ? 'selected' : '' }} >All Time</option>
      </select>
      </form>
    </div>

    <!-- Sparkline Chart -->
<section class="bg-white rounded-xl shadow p-6">
  <h3 class="text-lg font-semibold text-gray-800 mb-4">📈 Credit Score Trend</h3>
  <canvas id="sparkline" height="100"></canvas>
</section>

<!-- Understanding Your Experian Score -->
<section class="bg-white rounded-xl shadow p-6 mt-6">
  <h3 class="text-lg font-semibold text-gray-800 mb-3">📚 Understanding Your Experian Score</h3>
  <p class="text-sm text-gray-600 mb-4">Experian scores range between 0 and 999. Here's what it means:</p>
  <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm text-gray-700">
    <div class="bg-gray-50 border border-gray-200 p-4 rounded-lg">
      <p><strong>0–560:</strong> <span class="text-red-600">Very Poor</span> – High risk.</p>
      <p><strong>561–720:</strong> <span class="text-yellow-600">Poor</span> – Higher interest rates or limited credit options.</p>
      <p><strong>721–880:</strong> <span class="text-blue-600">Fair</span> – Average access to credit.</p>
    </div>
    <div class="bg-gray-50 border border-gray-200 p-4 rounded-lg">
      <p><strong>881–960:</strong> <span class="text-green-600">Good</span> – Better deals and improved credit confidence.</p>
      <p><strong>961–999:</strong> <span class="text-emerald-600">Excellent</span> – Best credit terms and rates.</p>
    </div>
  </div>
</section>

    <section class="bg-white rounded-xl shadow p-6">
      <table class="w-full text-left text-sm">
        <thead>
          <tr class="text-gray-600">
            <th class="pb-3">Date <span class="ml-1">🔽</span></th>
            <th class="pb-3">Credit Score</th>
            <th class="pb-3">Agency</th>
            <th class="pb-3">Tags</th>
          </tr>
        </thead>
        <tbody>

            @foreach ($allScores as $ascore)
            {{-- @php
            $isHighest = $ascore->score == $highestScore;
            $isLowest = $ascore->score == $lowestScore;
            $class = $isHighest ? 'text-xs bg-green-100 text-green-700 px-2 py-1 rounded' : ($isLowest ? 'text-xs bg-red-100 text-red-700 px-2 py-1 rounded' : '');
            $dd = $isHighest ? 'Highest Score' : ($isLowest ? 'Lowest Score' : '');
        @endphp --}}

          <tr class="border-t hover:bg-gray-50">
            <td class="py-4">{{$ascore->created_at->format('d M Y')}}</td>
            <td class="py-4 font-bold text-green-600">{{ $ascore->score }}</td>
            <td class="py-4">{{ $ascore->credit_ref_agency }}</td>
            <td class="py-4">
                @if ($ascore->score == $highestScore)
                <span class="ml-2 text-xs bg-green-100 text-green-700 px-2 py-1 rounded">Highest Score</span>
            @elseif ($ascore->score == $lowestScore)
                <span class="ml-2 text-xs bg-red-100 text-red-700 px-2 py-1 rounded">Lowest Score</span>
            @endif
                {{-- <span class="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">Highest Score</span> --}}
            </td>
          </tr>
          @endforeach
          {{-- <tr class="border-t hover:bg-gray-50">
            <td class="py-4">12 Jan 2025</td>
            <td class="py-4 font-bold text-yellow-600">720</td>
            <td class="py-4">Experian</td>
            <td class="py-4"></td>
          </tr>
          <tr class="border-t hover:bg-gray-50">
            <td class="py-4">12 Oct 2024</td>
            <td class="py-4 font-bold text-red-600">560</td>
            <td class="py-4">Experian</td>
            <td class="py-4"><span class="text-xs bg-red-100 text-red-700 px-2 py-1 rounded">Lowest Score</span></td>
          </tr> --}}
        </tbody>
      </table>
    </section>



<!-- How to Improve Your Score Card -->
<section class="bg-white rounded-xl shadow p-6 mt-6">
  <div class="flex items-center justify-between mb-4">
    <h3 class="text-lg font-semibold text-gray-800">🚀 How to Improve Your Score</h3>
    <span class="text-sm text-indigo-600 font-medium">Pro tips for better credit</span>
  </div>
  <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    <ul class="list-disc list-inside text-sm text-gray-600 space-y-2">
      <li><span class="font-semibold text-gray-700">✔️ Pay on time:</span> Your payment history is the biggest scoring factor.</li>
      <li><span class="font-semibold text-gray-700">📉 Keep credit usage low:</span> Stay under 30% of your limit.</li>
      <li><span class="font-semibold text-gray-700">🗳️ Register to vote:</span> Shows stability and boosts score.</li>
      <li><span class="font-semibold text-gray-700">🚫 Limit credit applications:</span> Too many can signal risk.</li>
    </ul>
    <ul class="list-disc list-inside text-sm text-gray-600 space-y-2">
      <li><span class="font-semibold text-gray-700">🔍 Check for errors:</span> Fix inaccuracies on your reports.</li>
      <li><span class="font-semibold text-gray-700">📂 Keep old accounts:</span> Longer history helps.</li>
      <li><span class="font-semibold text-gray-700">🧰 Use credit builders:</span> Try Loqbox or CreditLadder.</li>
      <li><span class="font-semibold text-gray-700">🧩 Diversify credit types:</span> Mix of credit improves scoring.</li>
    </ul>
  </div>
</section>



<section class="bg-white rounded-xl shadow p-6 mt-6">
  <div class="flex justify-between items-start mb-4">
    <div>
      <h3 class="text-lg font-semibold text-gray-800 mb-1">📤 Upload New Credit Score</h3>
      <p class="text-sm text-gray-600">Use the form below to securely submit your most recent score.</p>
    </div>
    <a href="{{ route('credit.score.create') }}" >
    <button class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 text-sm rounded-lg shadow">Submit Score</button>
</a>
  </div>
  <a href="{{ route('credit.score.create') }}" >
  <div class="grid md:grid-cols-2 gap-6 mb-6">
    <div class="bg-gray-50 p-4 rounded-lg border border-gray-200">
      <h4 class="text-sm font-semibold text-gray-700 mb-2">📱 How to Retrieve Your Score</h4>
      <ul class="list-disc list-inside text-sm text-gray-600 space-y-1">
        <li>Download the Experian App from the App Store or Google Play.</li>
        <li>Create a free account and verify your identity.</li>
        <li>Take a screenshot of your latest score and summary.</li>
        <li>Return here to upload the screenshot.</li>
      </ul>
    </div>
    <div class="bg-gray-50 p-4 rounded-lg border border-gray-200">
      <h4 class="text-sm font-semibold text-gray-700 mb-2">📁 Upload Your Score File</h4>
      <div class="border-2 border-dashed border-indigo-300 p-4 rounded-md text-center cursor-pointer hover:bg-indigo-50 transition">
        <p class="text-sm text-gray-600 mb-2">Drag & drop file here or click to select</p>
        <input type="text" class="hidden">
        <p class="text-xs text-gray-400">Accepted formats: JPG, PNG, PDF</p>
      </div>
    </div>
  </div>
</a>
  <!-- Success Modal Placeholder -->
  <div class="hidden mt-4 bg-green-100 text-green-800 px-4 py-3 rounded" id="uploadSuccess">
    ✅ Credit score uploaded successfully! Our team will review and confirm shortly.
  </div>

  <!-- Admin Review Status -->
  <div class="mt-6">
    <p class="text-sm text-gray-600 mb-2">Admin Verification Status:</p>
    <span class="inline-block bg-yellow-100 text-yellow-800 px-3 py-1 rounded text-xs">Pending Review</span>
  </div>

  <div class="mt-8">
    <h4 class="text-md font-semibold text-gray-800 mb-2">📚 Upload History</h4>
    <table class="w-full text-sm text-left border-t mt-2">
      <thead class="text-gray-600">
        <tr>
          <th class="py-2">Date</th>
          <th class="py-2">Score</th>
          <th class="py-2">Status</th>
          <th class="py-2">Reviewed By</th>
          <th class="py-2">Comments</th>
        </tr>
      </thead>
      <tbody>
            @foreach ($allScoresWithStatus as $history)


        <tr class="border-t hover:bg-gray-50">
          <td class="py-2">{{$history->created_at->format('d M Y')}}</td>
          <td class="py-2">{{ $history->score }}</td>
          <td class="py-2 text-green-600 font-medium">{{ $history->score_status }}</td>
          {{-- <td class="py-2 text-green-600 font-medium">✅ Approved</td> --}}
          <td class="py-2">{{ $history->approved->name ?? '-' }}</td>
          <td class="py-2">{{$history->latestComment->body ?? ''}}</td>
        </tr>
        @endforeach

        {{-- <tr class="border-t hover:bg-gray-50">
          <td class="py-2">12 Jan 2025</td>
          <td class="py-2">720</td>
          <td class="py-2 text-yellow-600 font-medium">🕒 Pending</td>
          <td class="py-2">—</td>
          <td class="py-2">—</td>
        </tr>
        <tr class="border-t hover:bg-gray-50">
          <td class="py-2">12 Oct 2024</td>
          <td class="py-2">560</td>
          <td class="py-2 text-red-600 font-medium">❌ Rejected</td>
          <td class="py-2">Admin B</td>
          <td class="py-2">Blurry image, please re-upload.</td>
        </tr> --}}
      </tbody>
    </table>
  </div>
</section>

</div>
</main>
@endsection



@push('js')
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
{{-- <script>
  const ctx = document.getElementById('sparkline').getContext('2d');
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: ['Oct 2024', 'Jan 2025', 'Apr 2025'],
      datasets: [{
        label: 'Score Trend',
        data: [560, 720, 845],
        borderColor: '#6366f1',
        backgroundColor: 'rgba(99, 102, 241, 0.1)',
        tension: 0.4,
        fill: true,
        pointRadius: 4,
        pointHoverRadius: 6,
      }]
    },
    options: {
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: { beginAtZero: false }
      }
    }
  });
</script> --}}
<script>
    const ctx = document.getElementById('sparkline').getContext('2d');

    const labels = @json($labels);
    const data = @json($dataS);

    new Chart(ctx, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{
          label: 'Score Trend',
          data: data,
          borderColor: '#6366f1',
          backgroundColor: 'rgba(99, 102, 241, 0.1)',
          tension: 0.4,
          fill: true,
          pointRadius: 4,
          pointHoverRadius: 6,
        }]
      },
      options: {
        plugins: {
          legend: { display: false }
        },
        scales: {
          y: { beginAtZero: false }
        }
      }
    });
  </script>
@endpush