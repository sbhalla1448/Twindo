@extends('layouts.app')
@push('css')
<style>
    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }

    body {
        font-family: 'Inter', sans-serif;
        background-color: #f4f7f5;
        color: #1a1a1a;
    }

    header {
        background-color: #0e3b29;
        padding: 60px 20px 40px;
        text-align: center;
        color: #fff;
    }

    header h1 {
        font-size: 2rem;
        font-weight: 700;
    }

    header p {
        font-size: 1rem;
        margin-top: 10px;
        opacity: 0.9;
    }

    .search-box {
        margin: 20px auto 0;
        max-width: 576px;
    }

    .search-box input {
        width: 100%;
        padding: 12px;
        border-radius: 0;
        border: none;
        font-size: 1rem;
    }

    .filters {
        background: #0e3b29;
        color: #fff;
        margin: 30px auto 0;
        padding: 16px;
        border-radius: 0;
        max-width: 1000px;
    }

    .filters h2 {
        font-size: 1.2rem;
        margin-bottom: 12px;
        text-align: center;
    }

    .filters .filter-controls {
        display: flex;
        flex-wrap: nowrap;
        justify-content: space-between;
        gap: 20px;
    }

    .filters label {
        flex: 1;
        font-weight: 600;
        display: flex;
        flex-direction: column;
        font-size: 0.95rem;
    }

    .filters select {
        padding: 10px 14px;
        border-radius: 0;
        border: none;
        margin-top: 6px;
    }

    .reset-link {
        text-align: right;
        font-size: 0.9rem;
        margin-top: 10px;
    }

    .reset-link a {
        color: #fff;
        text-decoration: underline;
    }

    .card {
        background: #f5f5f5;
        width: 1000px;
        margin: 0 auto;
        border-left: 2px solid #cce3da;
        border-right: 2px solid #cce3da;
        border-bottom: 1px solid #cce3da;
        padding: 20px;
        position: relative;
        display: flex;
        flex-direction: column;
        justify-content: center;
        height: 196px;
        border-radius: 0;
    }

    .card:first-of-type {
        border-top: 2px solid #cce3da;
    }

    .card.featured {
        background: #e5fff0;
        border-color: #00cc66;
    }

    .card .tag {
        position: absolute;
        top: 15px;
        left: 20px;
        color: red;
        font-weight: 700;
        font-size: 0.9rem;
    }

    .card h3 {
        color: #064d38;
        font-size: 1.3rem;
        margin-bottom: 10px;
    }

    .card p {
        margin-bottom: 10px;
    }

    .stars {
        color: #fbbf24;
        font-size: 1rem;
        margin: 5px 0;
    }

    .phone {
        color: #0e3b29;
        font-weight: 500;
    }

    .price-box {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-top: 0;
        position: relative;
    }

    .price-box>div:first-child {
        margin-top: -80px;
    }

    .price-box .price {
        font-size: 1.1rem;
        font-weight: 700;
        margin-bottom: 4px;
    }

    .price-box .total {
        font-size: 0.95rem;
        color: #444;
    }

    .cta-buttons {
        position: absolute;
        top: 150%;
        right: 20px;
        transform: translateY(-150%);
        display: flex;
        flex-direction: column;
        gap: 8px;
    }

    .cta-buttons button {
        background-color: #00cc66;
        color: white;
        padding: 10px 18px;
        border: none;
        border-radius: 6px;
        font-weight: 600;
        font-size: 0.95rem;
        cursor: pointer;
        min-width: 130px;
    }

    .cta-buttons .visit {
        background: #003d29;
    }

    @media (max-width: 768px) {
        .price-box {
            flex-direction: column;
            align-items: flex-start;
            gap: 16px;
        }

        .cta-buttons {
            position: static;
            transform: none;
            flex-direction: row;
            justify-content: flex-start;
            width: 100%;
            gap: 12px;
            margin-top: 10px;
        }

        .cta-buttons button {
            width: 100%;
            max-width: 160px;
        }
    }

    .pagination {
        display: flex;
        justify-content: center;
        margin: 30px auto;
        gap: 10px;
    }

    .pagination-btn {
        padding: 8px 12px;
        border: none;
        background-color: #0e3b29;
        color: white;
        border-radius: 4px;
        cursor: pointer;
        font-weight: 600;
    }

    .pagination-btn.active {
        background-color: #00cc66;
    }

    .load-more {
        text-align: center;
        margin: 20px 0 40px;
    }

    .load-more-btn {
        background-color: #003d29;
        color: #fff;
        padding: 12px 24px;
        font-size: 1rem;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-weight: 600;
    }
</style>
@endpush

@section('content')
<livewire:comparison />
@endsection