@extends('customer.master')

@section('content')
<livewire:customer.product-service />
@endsection