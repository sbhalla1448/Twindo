@extends('customer.master')

@push('css')
<meta name="csrf-token" content="{{ csrf_token() }}">

@endpush

@section('content')
<h2>Pay $10</h2>

<div id="card-element"></div>
<button id="submit-button">Pay</button>

<form id="confirm-form" method="POST" action="{{ route('payment.confirm') }}">
    @csrf
    <input type="hidden" name="intent_id" id="intent-id">
    <input type="hidden" name="status" id="payment-status">
    <input type="hidden" name="amount" id="amount" value="1000">
    <input type="hidden" name="currency" id="currency" value="usd">
</form>

<p id="payment-message" style="color: green;"></p>
<p id="payment-error" style="color: red;"></p>

@endsection

@push('js')
<script src="https://js.stripe.com/v3/"></script>
<script>
    const stripe = Stripe("{{ config('stripe.stripe_pk') }}");

    fetch("{{ route('payment.intent') }}", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            "X-CSRF-TOKEN": document.querySelector('meta[name="csrf-token"]').content
        },
        body: JSON.stringify({ amount: 1000 })
    })
    .then(res => res.json())
    .then(data => {
        const elements = stripe.elements();
        const card = elements.create("card");
        card.mount("#card-element");

        document.getElementById("submit-button").addEventListener("click", async () => {
            const { error, paymentIntent } = await stripe.confirmCardPayment(data.clientSecret, {
                payment_method: {
                    card: card
                }
            });

            if (error) {
                document.getElementById("payment-error").textContent = error.message;
            } else if (paymentIntent.status === 'succeeded') {
                document.getElementById("intent-id").value = paymentIntent.id;
                document.getElementById("payment-status").value = paymentIntent.status;
                document.getElementById("confirm-form").submit();
            }
        });
    });
</script>
@endpush