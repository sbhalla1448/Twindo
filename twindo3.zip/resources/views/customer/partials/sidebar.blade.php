<aside class="w-56 bg-white shadow-sm min-h-screen">
    <nav class="mt-8 px-4 space-y-2">
        <a  href="{{ route('dashboard') }}"
            class="block py-2 px-3 {{ request()->is(['admin/dashboard*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">🏠
            Dashboard</a>
        <a href="{{ route('credit.history') }}"
            class="block py-2 px-3 {{ request()->is(['account/sasdsdaf*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">📈
            Credit Score History</a>
        <a href="{{ route('analysis.report') }}"
            class="block py-2 px-3 {{ request()->is(['account/sasdsdaf*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">📈
            Analysis Report</a>
        <a href="{{ route('message.action') }}"
            class="block py-2 px-3 {{ request()->is(['account/sasdsdaf*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">📩
            Messages & Actions</a>
        <a href="{{ route('product.service') }}"
            class="block py-2 px-3 {{ request()->is(['account/product/service']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">🛍️
            Products & Services</a>
        <a href="{{ route('tool.resource') }}"
            class="block py-2 px-3 {{ request()->is(['account/tool/resource*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">🛠️
            Tools & Resources</a>
        <a href="{{ route('my.documents') }}"
            class="block py-2 px-3 {{ request()->is(['account/my/documents*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">📄
            My Documents</a>
        <a href="{{ route('subscription') }}"
            class="block py-2 px-3 {{ request()->is(['account/subsctiption*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">💳
            My Subscription</a>
        {{-- <a href="#"
            class="block py-2 px-3 {{ request()->is(['account/sasdsdaf*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">💳
            Payment Methods</a> --}}
        <a href="{{ route('account.settings') }}"
            class="block py-2 px-3 {{ request()->is(['account/settings*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">⚙️
            Account
            Settings</a>
        <a href="{{ route('logout') }}"
            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"
            class="block py-2 px-3 rounded-md hover:bg-gray-100">🔓 Logout</a>

        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
            @csrf
        </form>
    </nav>
</aside>
