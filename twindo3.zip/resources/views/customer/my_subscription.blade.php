@extends('customer.master')

@section('content')
    <main class="flex-1 overflow-auto">
        <div class="max-w-7xl mx-auto px-6 py-10">
            <section class="bg-white rounded-xl shadow p-8">
                <h2 class="text-2xl font-bold text-gray-800 mb-4">📦 Your Subscription Plan</h2>

                <div class="bg-gray-50 p-6 rounded-lg shadow-sm mb-6">
                    <div class="flex justify-between items-center">
                        <div>
                            <p class="text-lg font-semibold text-gray-700">Plan: <span
                                    class="text-indigo-600">{{ $subscription->plan->name }}</span></p>
                            <p class="text-sm text-gray-500">Signed Up: {{ $subscription->start_date->format('d M Y') }}</p>
                            <p class="text-sm text-gray-500">Status: <span
                                    class="text-green-600 font-medium">{{ $subscription->status }}</span></p>
                            <p class="text-sm text-gray-500">Next Billing Date:
                                {{ $subscription->end_date->format('d M Y') }}</p>
                            <p class="text-sm text-gray-500">Payment Cycle: {{ $subscription->subcription_type }}</p>
                                @if(!empty($subscription->extra_plan))
                            <p class="text-sm text-gray-500">Extra Service:  {{ implode(', ', $subscription?->extra_plan) }}</p>
                            @endif


                        </div>
                        <div class="flex gap-4">
                            {{-- <button onclick="confirmAction('manage')"
                                class="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600">Manage Plan</button> --}}
                            @if ($subscription->status == 'Active')
                                <button onclick="confirmationModalCancel('cancel')"
                                    class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">Cancel Plan</button>
                            @endif
                        </div>

                    </div>

                </div>
<h2 class="text-2xl font-bold text-gray-800 mb-4">Manage Plan</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-10">
                    <div class="bg-white border rounded-lg p-4 shadow">
                        <h4 class="font-semibold text-gray-700 mb-1">Guaranteed Essentials</h4>
                        <p class="text-sm text-gray-500 mb-2">Includes basic credit repair tools, templates and priority
                            support.</p>
                                 <button
                           {{-- data-plan-name="Guaranteed Essentials"
                           data-onetime-amount="100"
                           data-job="1"
                           data-plan-id="5" --}}

                            class="planButtonOneTime bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 w-full">
                            <a  href="{{ route('checkout.page','guaranteed_essentials') }}" >
                            Add to
                            Plan </a></button>
                    </div>
                    <div class="bg-white border rounded-lg p-4 shadow">
                        <h4 class="font-semibold text-gray-700 mb-1">Guaranteed Mobility</h4>
                        <p class="text-sm text-gray-500 mb-2">Assistance with car finance and vehicle-related credit tools.
                        </p>
                          <button
                           {{-- data-plan-name="Guaranteed Mobility"
                           data-onetime-amount="100"
                           data-job="1"
                           data-plan-id="6" --}}
                            class="planButtonOneTime bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 w-full">
                            <a  href="{{ route('checkout.page','guaranteed_mobility') }}" >
                            Add to
                            Plan </a></button>
                    </div>
                    <div class="bg-white border rounded-lg p-4 shadow">
                        <h4 class="font-semibold text-gray-700 mb-1">Platinum Package</h4>
                        <p class="text-sm text-gray-500 mb-2">Unlock every feature Twindo has to offer — one-time payment.
                        </p>
                        @if ($subscription->subscription_plan_id != 4)
                            <button
                            {{-- data-plan-name="Platinum" data-monthly-amount="0" data-yearly-amount="2500"
                                data-plan-id="4" --}}
                                class="planButton bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 w-full">
                                <a  href="{{ route('checkout.page','platinum _plan') }}" >
                                Upgrade
                                Now </a></button>
                        @else
                            <button class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 w-full">Activate
                                Plan</button>
                        @endif

                    </div>

                    <div class="bg-white border rounded-lg p-4 shadow">
                        <h4 class="font-semibold text-gray-700 mb-1">Elite Plan</h4>
                        <p class="text-sm text-gray-500 mb-2">Everything in Essential plus added features and faster
                            support.</p>
                            @if ($subscription->subscription_plan_id != 3)
                        <button
                        {{-- data-plan-name="Elite" data-monthly-amount="99.99" data-yearly-amount="999" data-plan-id="3" --}}
                            class="planButton bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 w-full">
                            <a  href="{{ route('checkout.page','elite_plan') }}" >
                            Upgrade
                            Now </a></button>
                            @else
                            <button class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 w-full">Activate
                                Plan</button>
                        @endif
                    </div>


                    <div class="bg-white border rounded-lg p-4 shadow">
                        <h4 class="font-semibold text-gray-700 mb-1">Plus Plan</h4>
                        <p class="text-sm text-gray-500 mb-2">Extra tools and monthly check-ins for better performance.</p>
                        @if ($subscription->subscription_plan_id != 2)
                        <button
                        {{-- data-plan-name="Plus" data-monthly-amount="59.99" data-yearly-amount="2500" data-plan-id="2" --}}
                            class="planButton bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 w-full">
                            <a  href="{{ route('checkout.page','plus_plan') }}" >Upgrade
                            Now </a></button>
                            @else
                            <button class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 w-full">Activate
                                Plan</button>
                        @endif
                    </div>


                    <div class="bg-white border rounded-lg p-4 shadow">
                        <h4 class="font-semibold text-gray-700 mb-1">Essential Plan</h4>
                        <p class="text-sm text-gray-500 mb-2">Extra tools and monthly check-ins for better performance.</p>
                          @if ($subscription->subscription_plan_id != 1)
                        <button
                        {{-- data-plan-name="Essential" data-monthly-amount="29.99" data-yearly-amount="299" data-plan-id="1" --}}
                            class="planButton bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 w-full">
                            <a  href="{{ route('checkout.page','essential_plan') }}" >Upgrade
                            Now</a></button>
                            @else
                            <button class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 w-full">Activate
                                Plan</button>
                        @endif
                    </div>

                </div>

                <div class="border-t border-gray-200 pt-6 mb-10">
                    <h3 class="text-xl font-bold text-gray-800 mb-4">🧾 Billing History</h3>
                    <table class="min-w-full text-sm text-left text-gray-600">
                        <thead class="bg-gray-100 text-xs uppercase">
                            <tr>
                                <th class="px-4 py-3">Date</th>
                                <th class="px-4 py-3">Amount</th>
                                <th class="px-4 py-3">Payment Method</th>
                                <th class="px-4 py-3">Status</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white">
                            @forelse ($payments as $payment)
                                <tr>
                                    <td class="px-4 py-3">{{ $payment->created_at->format('d M Y') }}</td>
                                    <td class="px-4 py-3">£{{ $payment->amount }}</td>
                                    <td class="px-4 py-3">{{ $payment->payment_gateway }}</td>
                                    <td class="px-4 py-3 text-green-600 font-medium">{{ $payment->status }}</td>
                                </tr>
                            @empty

                                <tr>
                                    <td class="px-4 py-3" colspan="3">No Payment Yet</td>

                                </tr>
                            @endforelse




                        </tbody>
                    </table>
                </div>

                <div class="border-t border-gray-200 pt-6">
                    <h3 class="text-xl font-bold text-gray-800 mb-4">❓ Subscription FAQs</h3>
                    <div class="space-y-4 text-sm text-gray-600">
                        <p><strong>Can I upgrade or downgrade my plan?</strong><br>Yes, you can switch your plan at any time
                            from the 'Manage Your Plan' section above.</p>
                        <p><strong>How do I cancel my subscription?</strong><br>Click the 'Cancel' button above or contact
                            Twindo Support for help.</p>
                        <p><strong>What happens after I cancel?</strong><br>Your subscription will remain active until the
                            end of your current billing period.</p>
                        <p><strong>Can I pause my subscription?</strong><br>Currently, pausing is not available, but you can
                            cancel and restart when needed.</p>
                        <p><strong>Will I lose my progress if I cancel?</strong><br>Your account history is saved, and you
                            can resume anytime.</p>
                    </div>
                </div>

            </section>
        </div>
    </main>
    <!-- Confirmation Modal (simplified) -->
    <div id="confirmationModal" class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
        <div class="bg-white rounded-lg shadow-lg p-6 max-w-sm">
            <h3 class="text-lg font-bold text-gray-800 mb-4">Are you sure?</h3>
            <p class="text-sm text-gray-600 mb-6">This action will affect your subscription. Please confirm.</p>
            <div class="flex justify-end gap-4">
                <button onclick="closeModal()" class="bg-gray-300 px-4 py-2 rounded hover:bg-gray-400">Cancel</button>
                <button onclick="closeModal()"
                    class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700">Confirm</button>
            </div>
        </div>
    </div>
    <div id="confirmationModalCancel"
        class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
        <div class="bg-white rounded-lg shadow-lg p-6 max-w-sm">
            <h3 class="text-lg font-bold text-gray-800 mb-4">Are you sure?</h3>
            <p class="text-sm text-gray-600 mb-6">This action will affect your subscription. Please confirm.</p>
            <div class="flex justify-end gap-4">
                <button onclick="closeModalCancel()" class="bg-gray-300 px-4 py-2 rounded hover:bg-gray-400">Cancel</button>
                <a href="{{ route('cancel.my.subscription') }}"> <button onclick="closeModal()"
                        class="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700">Confirm</button></a>
            </div>
        </div>
    </div>

    {{-- Modal for Essential --}}
    <form id="paymentForm" action="{{ route('checkout') }}" method="POST">
        @csrf

        <div id="modal" class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
            <div class="bg-white rounded-lg shadow-lg p-6 max-w-sm p-6 w-1/2 relative">
                <!-- Close Button -->
                <button type="button" id="closeModalBtn"
                    class="absolute top-2 right-2 text-gray-500 text-2xl font-bold hover:text-gray-700">&times;</button>

                <!-- Modal Header -->
                <h2 id="modalPlanName" class="text-2xl font-bold mb-4 text-gray-800">Loading...</h2>

                <!-- Hidden Inputs for Form Submission -->
                <input type="hidden" name="plan_id" id="planId">
                <input type="hidden" name="plan_name" id="planName">
                <input type="hidden" name="amount" id="planAmount">
                <input type="hidden" name="duration" id="planDuration">
                <input type="hidden" name="payment_method" id="planPaymentMethod">

                <!-- Duration Selector -->
                <div class="mb-4">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Billing Cycle</label>
                    <div class="flex space-x-4">
                        <label class="inline-flex items-center">
                            <input type="radio" name="duration" value="monthly"
                                class="form-radio h-5 w-5 text-blue-600" checked>
                            <span id="monthlyLabel" class="ml-2 text-gray-700">Monthly ($0)</span>
                        </label>
                        <label class="inline-flex items-center">
                            <input type="radio" name="duration" value="yearly"
                                class="form-radio h-5 w-5 text-green-600">
                            <span id="yearlyLabel" class="ml-2 text-gray-700">Yearly ($0)</span>
                        </label>
                    </div>
                </div>

                <!-- Payment Method -->
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Payment Method</label>
                    <div class="space-y-3">
                        <label class="flex items-center p-3 border rounded-lg hover:bg-purple-50 cursor-pointer">
                            <input type="radio" name="payment" value="stripe"
                                class="form-radio h-5 w-5 text-purple-600" checked>
                            <span class="ml-3 font-medium text-gray-800">Stripe</span>
                        </label>
                        <label class="flex items-center p-3 border rounded-lg hover:bg-blue-50 cursor-pointer">
                            <input type="radio" name="payment" value="paypal"
                                class="form-radio h-5 w-5 text-blue-600">
                            <span class="ml-3 font-medium text-gray-800">PayPal</span>
                        </label>
                    </div>
                </div>

                <!-- Summary -->
                <div class="p-3 bg-gray-100 rounded mb-4">
                    <p class="text-sm text-gray-600">You are subscribing to:</p>
                    <p class="font-semibold text-gray-800" id="summary">Loading...</p>
                </div>

                <!-- Buttons -->
                <div class="flex justify-end space-x-2">
                    <button type="button" id="cancelBtn"
                        class="px-4 py-2 bg-gray-300 text-gray-800 rounded hover:bg-gray-400">
                        Cancel
                    </button>
                    <button type="submit" id="submitBtn"
                        class="px-4 py-2 bg-gray-300 text-gray-800 rounded hover:bg-gray-400" style="cursor: pointer;">
                        Proceed to Payment
                    </button>
                </div>
            </div>
        </div>


    </form>

      <!-- Modal -->
<div id="planModal" class="hidden fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
   <div class="bg-white rounded-lg shadow-lg p-6 max-w-sm p-6 w-1/2 relative">
    <!-- Modal Header -->
    <div class="flex justify-between items-center mb-4">
      <h2 class="text-lg font-semibold text-gray-800">One Time Plan</h2>
      <button id="closeModal" class="text-gray-500 hover:text-gray-700 text-2xl">&times;</button>
    </div>

    <!-- Form Start -->
   <form id="paymentForm" action="{{ route('checkout') }}" method="POST">
    @csrf

      <!-- Hidden inputs -->
      <input type="hidden" name="plan_name" id="inputPlanName">
      <input type="hidden" name="amount" id="inputAmount">
      <input type="hidden" name="job_id" id="inputJobId">
      <input type="hidden" name="plan_id" id="inputPlanId">

      <!-- Plan Info -->
      <div class="mb-4">
        <p class="text-sm text-gray-700"><strong>Plan:</strong> <span id="modalPlanName"></span></p>
        <p class="text-sm text-gray-700"><strong>Amount:</strong> $<span id="modalAmount"></span></p>
      </div>

      <!-- Payment Method -->
      <div class="mb-4">
        <p class="text-sm font-medium text-gray-700 mb-2">Choose Payment Method:</p>
        <label class="flex items-center space-x-2 mb-2">
          <input type="radio" name="payment_method" value="stripe" class="form-radio text-blue-600" checked>
          <span>Stripe</span>
        </label>
        <label class="flex items-center space-x-2">
          <input type="radio" name="payment_method" value="paypal" class="form-radio text-blue-600">
          <span>PayPal</span>
        </label>
      </div>


        {{-- <button type="submit" class="bg-[#033333] text-white px-4 py-2 rounded hover:bg-secondary" style="cursor: pointer;">
          Proceed to Pay
        </button>  --}}
         <!-- Buttons -->
            <div class="flex justify-end space-x-2">

                <button type="submit"  class="bg-[#033333] text-white px-4 py-2 rounded hover:bg-secondary" style="cursor: pointer;">
                    Proceed to Payment
                </button>
            </div>

    </form>
    <!-- Form End -->
  </div>
</div>

@endsection

@push('js')
    <script>
        function confirmAction(action) {
            document.getElementById('confirmationModal').classList.remove('hidden');
        }

        function confirmationModalCancel(action) {
            document.getElementById('confirmationModalCancel').classList.remove('hidden');
        }

        function closeModalCancel() {
            document.getElementById('confirmationModalCancel').classList.add('hidden');
        }

        function closeModal() {
            document.getElementById('confirmationModal').classList.add('hidden');
        }
    </script>

    <script>
        const modal = document.getElementById('modal');
        const modalPlanName = document.getElementById('modalPlanName');
        const monthlyLabel = document.getElementById('monthlyLabel');
        const yearlyLabel = document.getElementById('yearlyLabel');
        const summary = document.getElementById('summary');

        const planButtons = document.querySelectorAll('.planButton');

        // Hidden inputs
        const planIdInput = document.getElementById('planId');
        const planNameInput = document.getElementById('planName');
        const planAmountInput = document.getElementById('planAmount');
        const planDurationInput = document.getElementById('planDuration');
        const planPaymentInput = document.getElementById('planPaymentMethod');

        function updateSummary() {
            const durationRadio = document.querySelector('input[name=duration]:checked');
            const paymentRadio = document.querySelector('input[name=payment]:checked');

            const duration = durationRadio.value;
            const payment = paymentRadio.value;

            const monthlyAmount = parseFloat(monthlyLabel.dataset.amount);
            const yearlyAmount = parseFloat(yearlyLabel.dataset.amount);

            const amount = duration === 'monthly' ? `$${monthlyAmount}` : `$${yearlyAmount}`;

            summary.textContent =
                `${duration.charAt(0).toUpperCase() + duration.slice(1)} plan - ${amount} via ${payment.charAt(0).toUpperCase() + payment.slice(1)}`;

            // Update hidden inputs
            planDurationInput.value = duration;
            planPaymentInput.value = payment;
            planAmountInput.value = duration === 'monthly' ? monthlyAmount : yearlyAmount;
        }

        planButtons.forEach(button => {
            button.addEventListener('click', () => {
                const planName = button.getAttribute('data-plan-name');
                const planId = button.getAttribute('data-plan-id');
                const monthlyAmount = button.getAttribute('data-monthly-amount');
                const yearlyAmount = button.getAttribute('data-yearly-amount');

                // Set UI
                modalPlanName.textContent = planName;
                monthlyLabel.textContent = `Monthly ($${monthlyAmount})`;
                yearlyLabel.textContent = `Yearly ($${yearlyAmount})`;

                monthlyLabel.dataset.amount = monthlyAmount;
                yearlyLabel.dataset.amount = yearlyAmount;

                // Set hidden fields
                planIdInput.value = planId;
                planNameInput.value = planName;

                // Default duration
                document.querySelector('input[name=duration][value="monthly"]').checked = true;

                modal.classList.remove('hidden');
                updateSummary();
            });
        });

        document.querySelectorAll('input[name=duration], input[name=payment]').forEach(input => {
            input.addEventListener('change', updateSummary);
        });

        document.querySelectorAll('#closeModalBtn, #cancelBtn').forEach(btn => {
            btn.addEventListener('click', () => {
                modal.classList.add('hidden');
            });
        });

        window.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.classList.add('hidden');
            }
        });
    </script>


<!-- Script -->
<script>
  document.querySelectorAll('.planButtonOneTime').forEach(button => {
    button.addEventListener('click', function () {
      const modal = document.getElementById('planModal');

      // Fill in modal content
      document.getElementById('modalPlanName').textContent = this.dataset.planName;
      document.getElementById('modalAmount').textContent = this.dataset.onetimeAmount;

      // Fill in hidden inputs
      document.getElementById('inputPlanName').value = this.dataset.planName;
      document.getElementById('inputAmount').value = this.dataset.onetimeAmount;
      document.getElementById('inputJobId').value = this.dataset.job;
      document.getElementById('inputPlanId').value = this.dataset.planId;

      // Show modal
      modal.classList.remove('hidden');
    });
  });

  document.getElementById('closeModal').addEventListener('click', function () {
    document.getElementById('planModal').classList.add('hidden');
  });
</script>
@endpush
