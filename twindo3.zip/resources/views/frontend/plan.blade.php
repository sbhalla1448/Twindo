
<!DOCTYPE html>
<html>
   <head>
      <meta charset="UTF-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1.0" />
      <title>Twindo || pricing</title>
      <link href="{{ asset('frontend/css/output.css')}}" rel="stylesheet" />
      {{-- <link href="./src/css/output.css" rel="stylesheet" /> --}}
      <link
         rel="stylesheet"
         href="{{ asset('frontend/RemixIcon_Fonts_v4.6.0/fonts/remixicon.css')}}"
      />
      {{-- <link
         rel="stylesheet"
         href="./src/RemixIcon_Fonts_v4.6.0/fonts/remixicon.css"
      /> --}}
   </head>
   <body
      class="text-body-text text-[1.063rem] font-normal leading-[1.688rem] font-raleway relative"
   >
      <!-- offcanvas -->
      <div
         class="justify-end bg-transparent absolute inset-0 z-10 before:absolute before:content-[''] before:inset-0 before:bg-white before:opacity-[0.9] before:-z-1 hidden"
         id="side_menu"
      >
         <div
            class="p-10 h-screen fixed max-w-[25rem] w-full bg-white overflow-y-scroll"
         >
            <button
               class="bg-[#5cb46a] size-[2.188rem] flex items-center justify-center rounded-[0.188rem] cursor-pointer absolute right-3 top-[0.313rem] xl:top-[1.875rem] xl:right-[1.875rem] z-10 text-[1.313rem] text-white"
               id="close_side_menu"
            >
               <i class="ri-close-line"></i>
            </button>
            <div>
               <a class="w-[14.625rem] h-10 block mb-[1.563rem]" href="#"
                  ><img
                     class="w-full h-full"
                     src="{{ asset('frontend/img/logo.webp') }}"
                     alt=""
               /></a>
               <!-- offcanvas nav -->
               <nav class="py-[0.531rem] xl:hidden">
                  <ul class="mt-[0.688rem]">
                     <li class="border-b border-[#0000000f]">
                        <a
                           class="py-2.5 pr-10 text-[#033333] font-semibold block transition-all duration-[0.3s] delay-[0] ease-in hover:text-[#5cb46a]"
                           href="#"
                           >Home</a
                        >
                     </li>
                     <li class="border-b border-[#0000000f]">
                        <a
                           class="py-2.5 pr-10 text-[#033333] font-semibold block transition-all duration-[0.3s] delay-[0] ease-in hover:text-[#5cb46a] relative"
                           href="#"
                           >About Us
                           <button
                              class="size-10 flex items-center justify-center bg-[#f9f9f9] cursor-pointer text-[1.375rem] absolute right-0 bottom-0"
                           >
                              <i class="ri-arrow-down-s-line"></i>
                           </button>
                        </a>
                        <ul class="pl-5">
                           <li class="border-b border-[#0000000f]">
                              <a
                                 class="py-2.5 pr-10 text-[#033333] font-semibold block transition-all duration-[0.3s] delay-[0] ease-in hover:text-[#5cb46a]"
                                 href="#"
                                 >How It Works</a
                              >
                           </li>
                           <li class="border-b border-[#0000000f]">
                              <a
                                 class="py-2.5 pr-10 text-[#033333] font-semibold block transition-all duration-[0.3s] delay-[0] ease-in hover:text-[#5cb46a]"
                                 href="#"
                                 >Testimonials</a
                              >
                           </li>
                           <li class="">
                              <a
                                 class="py-2.5 pr-10 text-[#033333] font-semibold block transition-all duration-[0.3s] delay-[0] ease-in hover:text-[#5cb46a]"
                                 href="#"
                                 >Finance Calculator</a
                              >
                           </li>
                        </ul>
                     </li>
                     <li class="border-b border-[#0000000f]">
                        <a
                           class="py-2.5 pr-10 text-[#033333] font-semibold block transition-all duration-[0.3s] delay-[0] ease-in hover:text-[#5cb46a] relative"
                           href="#"
                           >Services
                           <button
                              class="size-10 flex items-center justify-center bg-[#f9f9f9] cursor-pointer text-[1.375rem] absolute right-0 bottom-0"
                           >
                              <i class="ri-arrow-down-s-line"></i>
                           </button>
                        </a>
                        <ul class="pl-5">
                           <li class="border-b border-[#0000000f]">
                              <a
                                 class="py-2.5 pr-10 text-[#033333] font-semibold block transition-all duration-[0.3s] delay-[0] ease-in hover:text-[#5cb46a]"
                                 href="#"
                                 >Credit Report Analysis</a
                              >
                           </li>
                           <li class="border-b border-[#0000000f]">
                              <a
                                 class="py-2.5 pr-10 text-[#033333] font-semibold block transition-all duration-[0.3s] delay-[0] ease-in hover:text-[#5cb46a]"
                                 href="#"
                                 >Credit Score Strategies</a
                              >
                           </li>
                           <li class="border-b border-[#0000000f]">
                              <a
                                 class="py-2.5 pr-10 text-[#033333] font-semibold block transition-all duration-[0.3s] delay-[0] ease-in hover:text-[#5cb46a]"
                                 href="#"
                                 >Dispute Resolution</a
                              >
                           </li>
                           <li class="border-b border-[#0000000f]">
                              <a
                                 class="py-2.5 pr-10 text-[#033333] font-semibold block transition-all duration-[0.3s] delay-[0] ease-in hover:text-[#5cb46a]"
                                 href="#"
                                 >Debt Management</a
                              >
                           </li>
                           <li class="border-b border-[#0000000f]">
                              <a
                                 class="py-2.5 pr-10 text-[#033333] font-semibold block transition-all duration-[0.3s] delay-[0] ease-in hover:text-[#5cb46a]"
                                 href="#"
                                 >Credit Builder Products</a
                              >
                           </li>
                           <li class="">
                              <a
                                 class="py-2.5 pr-10 text-[#033333] font-semibold block transition-all duration-[0.3s] delay-[0] ease-in hover:text-[#5cb46a]"
                                 href="#"
                                 >Maintain, Build & Protect</a
                              >
                           </li>
                        </ul>
                     </li>
                     <li class="border-b border-[#0000000f]">
                        <a
                           class="py-2.5 pr-10 text-[#033333] font-semibold block transition-all duration-[0.3s] delay-[0] ease-in hover:text-[#5cb46a]"
                           href="#"
                           >Marketplace</a
                        >
                     </li>
                     <li class="border-b border-[#0000000f]">
                        <a
                           class="py-2.5 pr-10 text-[#033333] font-semibold block transition-all duration-[0.3s] delay-[0] ease-in hover:text-[#5cb46a]"
                           href="#"
                           >Packages</a
                        >
                     </li>
                     <li class="border-b border-[#0000000f]">
                        <a
                           class="py-2.5 pr-10 text-[#033333] font-semibold block transition-all duration-[0.3s] delay-[0] ease-in hover:text-[#5cb46a]"
                           href="#"
                           >Learn</a
                        >
                     </li>
                     <li class="border-b border-[#0000000f]">
                        <a
                           class="py-2.5 pr-10 text-[#033333] font-semibold block transition-all duration-[0.3s] delay-[0] ease-in hover:text-[#5cb46a] relative"
                           href="#"
                           >Contact
                           <button
                              class="size-10 flex items-center justify-center bg-[#f9f9f9] cursor-pointer text-[1.375rem] absolute right-0 bottom-0"
                           >
                              <i class="ri-arrow-down-s-line"></i>
                           </button>
                        </a>
                        <ul class="pl-5">
                           <li class="border-b border-[#0000000f]">
                              <a
                                 class="py-2.5 pr-10 text-[#033333] font-semibold block transition-all duration-[0.3s] delay-[0] ease-in hover:text-[#5cb46a]"
                                 href="#"
                                 >Careers</a
                              >
                           </li>
                           <li class="">
                              <a
                                 class="py-2.5 pr-10 text-[#033333] font-semibold block transition-all duration-[0.3s] delay-[0] ease-in hover:text-[#5cb46a]"
                                 href="#"
                                 >Apply Now</a
                              >
                           </li>
                        </ul>
                     </li>
                  </ul>
               </nav>
               <div class="mt-[1.875rem] xl:hidden">
                  <h4
                     class="text-[#033333] font-bold text-[1.375rem] leading-7 mb-[1.625rem]"
                  >
                     Contact us
                  </h4>
                  <ul class="mb-[2.125rem]">
                     <li class="mb-2 flex gap-2">
                        <i
                           class="ri-map-pin-line text-[1.375rem] text-[#5cb46a]"
                        ></i>
                        <span>124 City Road, London, EC1V 2NX</span>
                     </li>
                     <li class="mb-2 flex gap-2">
                        <i
                           class="ri-phone-line text-[1.438rem] text-[#5cb46a]"
                        ></i>
                        <a class="text-[#728383]" href="tell:08443571110"
                           >0844 357 1110</a
                        >
                     </li>
                     <li class="mb-2 flex gap-2">
                        <i
                           class="ri-mail-send-line text-[1.25rem] text-[#5cb46a]"
                        ></i>
                        <a
                           class="text-[#728383]"
                           href="mailto:hello@twindo.co.uk"
                           >hello@twindo.co.uk</a
                        >
                     </li>
                  </ul>
                  <h4
                     class="text-[#033333] font-bold text-[1.375rem] leading-7 mb-[1.625rem]"
                  >
                     Follow us
                  </h4>
                  <div class="flex items-center gap-2.5">
                     <a
                        class="size-[2.25rem] rounded-full border border-[#00000010] text-[#728383] flex items-center justify-center text-base"
                        href="#"
                        ><i class="ri-facebook-fill"></i
                     ></a>
                     <a
                        class="size-[2.25rem] rounded-full border border-[#00000010] text-[#728383] flex items-center justify-center text-base"
                        href="#"
                        ><i class="ri-twitter-x-fill"></i
                     ></a>
                     <a
                        class="size-[2.25rem] rounded-full border border-[#00000010] text-[#728383] flex items-center justify-center text-base"
                        href="#"
                        ><i class="ri-linkedin-fill"></i
                     ></a>
                     <a
                        class="size-[2.25rem] rounded-full border border-[#00000010] text-[#728383] flex items-center justify-center text-base"
                        href="#"
                        ><i class="ri-instagram-line"></i
                     ></a>
                  </div>
               </div>
               <div class="hidden xl:block">
                  <h4
                     class="text-[#033333] font-bold text-[1.375rem] leading-7 mb-[1.625rem]"
                  >
                     Testimonials
                  </h4>
                  <p>
                     We specialise in empowering individuals and families to
                     rebuild and strengthen their credit, so you can confidently
                     pursue life’s milestones, whether that’s buying a home,
                     funding education, or planning a holiday.
                  </p>
               </div>
            </div>
         </div>
      </div>
      <!-- offcanvas end -->
      <!-- scrollup start -->
      <div
         class="h-10 w-[2.625rem] text-white text-2xl bg-[#5cb46a] rounded-[0.313rem] flex items-center justify-center shadow-[0_0_2px_rgba(0,0,0,0.2)] transition-all duration-[0.3s] delay-[0] ease-in cursor-pointer hover:opacity-[0.8] fixed bottom-2.5 right-2.5 md:bottom-10 md:right-10 z-50"
      >
         <i class="ri-arrow-up-s-line"></i>
      </div>
      <!-- scrollup end-->

      <!-- header section start -->
      <header
         class="bg-secondary text-white text-[0.938rem] leading-[1.563rem] hidden md:block"
      >
         <div class="px-2.5 mx-auto xl:px-[6.25rem]">
            <div
               class="flex items-center justify-center xl:justify-between gap-5"
            >
               <div class="w-1/2 items-center gap-[2.188rem] hidden xl:flex">
                  <div class="flex items-center gap-[0.688rem]">
                     <div>
                        <svg
                           class="fill-primary size-5"
                           xmlns="http://www.w3.org/2000/svg"
                           viewBox="0 0 24 24"
                        >
                           <path
                              d="M12 20.8995L16.9497 15.9497C19.6834 13.2161 19.6834 8.78392 16.9497 6.05025C14.2161 3.31658 9.78392 3.31658 7.05025 6.05025C4.31658 8.78392 4.31658 13.2161 7.05025 15.9497L12 20.8995ZM12 23.7279L5.63604 17.364C2.12132 13.8492 2.12132 8.15076 5.63604 4.63604C9.15076 1.12132 14.8492 1.12132 18.364 4.63604C21.8787 8.15076 21.8787 13.8492 18.364 17.364L12 23.7279ZM12 13C13.1046 13 14 12.1046 14 11C14 9.89543 13.1046 9 12 9C10.8954 9 10 9.89543 10 11C10 12.1046 10.8954 13 12 13ZM12 15C9.79086 15 8 13.2091 8 11C8 8.79086 9.79086 7 12 7C14.2091 7 16 8.79086 16 11C16 13.2091 14.2091 15 12 15Z"
                           ></path>
                        </svg>
                     </div>
                     <p>124 City Road, London, EC1V 2NX.</p>
                  </div>
                  <div class="w-px h-[2.813rem] bg-[#1D4848]"></div>
                  <div class="flex items-center gap-[0.688rem]">
                     <div>
                        <svg
                           class="fill-primary w-5 h-[1.625rem]"
                           xmlns="http://www.w3.org/2000/svg"
                           width="20"
                           height="21"
                           viewBox="0 0 20 21"
                        >
                           <path
                              d="M15.8147 12.407C15.4047 11.98 14.9101 11.7518 14.3859 11.7518C13.866 11.7518 13.3671 11.9758 12.9402 12.4028L11.6044 13.7344C11.4945 13.6752 11.3846 13.6202 11.2789 13.5653C11.1267 13.4892 10.983 13.4173 10.8604 13.3412C9.6091 12.5465 8.47196 11.5108 7.38132 10.1708C6.85291 9.50286 6.49782 8.94063 6.23995 8.36994C6.58659 8.0529 6.90786 7.72317 7.22068 7.40612C7.33905 7.28776 7.45741 7.16517 7.57577 7.0468C8.4635 6.15908 8.4635 5.00926 7.57577 4.12153L6.42173 2.96748C6.29068 2.83643 6.15541 2.70116 6.02859 2.56589C5.77495 2.3038 5.50863 2.03325 5.23386 1.77961C4.82381 1.37379 4.33345 1.1582 3.81772 1.1582C3.30199 1.1582 2.80317 1.37379 2.38045 1.77961C2.37622 1.78384 2.37622 1.78384 2.37199 1.78807L0.934715 3.23803C0.393623 3.77912 0.0850311 4.43857 0.0173946 5.20371C-0.0840601 6.43808 0.279486 7.5879 0.558487 8.34035C1.24331 10.1877 2.26631 11.8997 3.79236 13.7344C5.64391 15.9452 7.87168 17.6911 10.4165 18.9212C11.3888 19.382 12.6866 19.9273 14.1365 20.0203C14.2253 20.0246 14.3183 20.0288 14.4028 20.0288C15.3793 20.0288 16.1994 19.6779 16.842 18.9804C16.8462 18.972 16.8547 18.9677 16.8589 18.9593C17.0787 18.693 17.3323 18.452 17.5987 18.1941C17.7804 18.0208 17.9664 17.8391 18.1482 17.6488C18.5667 17.2134 18.7865 16.7061 18.7865 16.1862C18.7865 15.662 18.5625 15.159 18.1355 14.7362L15.8147 12.407ZM17.3281 16.8583C17.3239 16.8583 17.3239 16.8626 17.3281 16.8583C17.1632 17.0359 16.9942 17.1965 16.8124 17.3741C16.5376 17.6361 16.2586 17.9109 15.9965 18.2195C15.5696 18.6761 15.0665 18.8916 14.4071 18.8916C14.3437 18.8916 14.276 18.8916 14.2126 18.8874C12.9571 18.8071 11.7904 18.3167 10.9153 17.8982C8.52269 16.74 6.42173 15.0955 4.67586 13.0115C3.23436 11.2741 2.27054 9.66772 1.63222 7.94299C1.23908 6.8904 1.09535 6.0703 1.15876 5.29671C1.20103 4.80212 1.39126 4.39207 1.74213 4.04121L3.18363 2.59971C3.39077 2.40525 3.61058 2.29957 3.82618 2.29957C4.09249 2.29957 4.30809 2.46021 4.44336 2.59548C4.44759 2.59971 4.45181 2.60393 4.45604 2.60816C4.7139 2.84912 4.95909 3.09853 5.21695 3.36484C5.348 3.50012 5.48327 3.63539 5.61854 3.77489L6.77259 4.92894C7.22068 5.37703 7.22068 5.7913 6.77259 6.2394C6.65 6.36199 6.53163 6.48458 6.40904 6.60294C6.05395 6.96649 5.71577 7.30467 5.348 7.6344C5.33954 7.64285 5.33109 7.64708 5.32686 7.65553C4.96331 8.01908 5.03095 8.37417 5.10704 8.61513C5.11127 8.62781 5.1155 8.64049 5.11972 8.65317C5.41986 9.38026 5.84259 10.0651 6.48514 10.8809L6.48936 10.8852C7.65609 12.3225 8.88623 13.4427 10.2432 14.3008C10.4165 14.4107 10.5941 14.4995 10.7631 14.584C10.9153 14.6601 11.0591 14.732 11.1816 14.8081C11.1986 14.8165 11.2155 14.8292 11.2324 14.8377C11.3761 14.9095 11.5114 14.9434 11.6509 14.9434C12.0017 14.9434 12.2216 14.7235 12.2934 14.6517L13.7391 13.206C13.8829 13.0622 14.1112 12.8889 14.3775 12.8889C14.6396 12.8889 14.8552 13.0538 14.9862 13.1975C14.9904 13.2017 14.9904 13.2017 14.9947 13.206L17.3239 15.5352C17.7593 15.9664 17.7593 16.4102 17.3281 16.8583Z"
                           ></path>
                           <path
                              d="M10.8096 4.76393C11.9171 4.94993 12.9232 5.47412 13.7264 6.2773C14.5296 7.08048 15.0496 8.08658 15.2398 9.19412C15.2863 9.47312 15.5272 9.66758 15.802 9.66758C15.8358 9.66758 15.8654 9.66335 15.8992 9.65912C16.2121 9.6084 16.4192 9.31249 16.3685 8.99967C16.1402 7.65962 15.5061 6.43794 14.5381 5.46989C13.57 4.50184 12.3483 3.86775 11.0083 3.63948C10.6955 3.58875 10.4038 3.79589 10.3488 4.10448C10.2939 4.41307 10.4968 4.71321 10.8096 4.76393Z"
                           ></path>
                           <path
                              d="M19.9914 8.83526C19.6152 6.62862 18.5752 4.62066 16.9773 3.02275C15.3794 1.42484 13.3715 0.384928 11.1648 0.00870037C10.8562 -0.0462543 10.5645 0.16511 10.5096 0.473701C10.4589 0.78652 10.666 1.0782 10.9788 1.13316C12.9487 1.46711 14.7453 2.40134 16.1741 3.82594C17.603 5.25476 18.533 7.05135 18.8669 9.02126C18.9134 9.30026 19.1544 9.49472 19.4292 9.49472C19.463 9.49472 19.4926 9.49049 19.5264 9.48626C19.835 9.43976 20.0463 9.14385 19.9914 8.83526Z"
                           ></path>
                        </svg>
                     </div>
                     <a class="tracking-[1px]" href="tel:08443571110"
                        >0844 357 1110</a
                     >
                  </div>
               </div>
               <div
                  class="w-1/2 flex items-center gap-[2.188rem] justify-center xl:justify-end"
               >
                  <div class="flex items-center gap-[0.688rem]">
                     <div>
                        <svg
                           class="fill-primary size-5"
                           xmlns="http://www.w3.org/2000/svg"
                           viewBox="0 0 24 24"
                        >
                           <path
                              d="M21 3C21.5523 3 22 3.44772 22 4V20.0066C22 20.5552 21.5447 21 21.0082 21H2.9918C2.44405 21 2 20.5551 2 20.0066V19H20V7.3L12 14.5L2 5.5V4C2 3.44772 2.44772 3 3 3H21ZM8 15V17H0V15H8ZM5 10V12H0V10H5ZM19.5659 5H4.43414L12 11.8093L19.5659 5Z"
                           ></path>
                        </svg>
                     </div>
                     <a class="tracking-[1px]" href="mailto:hello@twindo.co.uk"
                        >hello@twindo.co.uk</a
                     >
                  </div>
                  <div class="w-px h-[2.813rem] bg-[#1D4848]"></div>
                  <div class="flex items-center gap-[1.563rem]">
                     <a href="#">
                        <svg
                           class="fill-white size-[0.938rem] transition-all duration-[0.3s] delay-[0] ease-in hover:fill-primary"
                           viewBox="0 0 320 512"
                           xmlns="http://www.w3.org/2000/svg"
                        >
                           <path
                              d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"
                           ></path>
                        </svg>
                     </a>
                     <a href="#">
                        <svg
                           class="fill-white size-[0.938rem] transition-all duration-[0.3s] delay-[0] ease-in hover:fill-primary"
                           viewBox="0 0 512 512"
                           xmlns="http://www.w3.org/2000/svg"
                        >
                           <path
                              d="M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z"
                           ></path>
                        </svg>
                     </a>
                     <a href="#">
                        <svg
                           class="fill-white size-[0.938rem] transition-all duration-[0.3s] delay-[0] ease-in hover:fill-primary"
                           viewBox="0 0 512 512"
                           xmlns="http://www.w3.org/2000/svg"
                        >
                           <path
                              d="M256 8C119.252 8 8 119.252 8 256s111.252 248 248 248 248-111.252 248-248S392.748 8 256 8zm163.97 114.366c29.503 36.046 47.369 81.957 47.835 131.955-6.984-1.477-77.018-15.682-147.502-6.818-5.752-14.041-11.181-26.393-18.617-41.614 78.321-31.977 113.818-77.482 118.284-83.523zM396.421 97.87c-3.81 5.427-35.697 48.286-111.021 76.519-34.712-63.776-73.185-116.168-79.04-124.008 67.176-16.193 137.966 1.27 190.061 47.489zm-230.48-33.25c5.585 7.659 43.438 60.116 78.537 122.509-99.087 26.313-186.36 25.934-195.834 25.809C62.38 147.205 106.678 92.573 165.941 64.62zM44.17 256.323c0-2.166.043-4.322.108-6.473 9.268.19 111.92 1.513 217.706-30.146 6.064 11.868 11.857 23.915 17.174 35.949-76.599 21.575-146.194 83.527-180.531 142.306C64.794 360.405 44.17 310.73 44.17 256.323zm81.807 167.113c22.127-45.233 82.178-103.622 167.579-132.756 29.74 77.283 42.039 142.053 45.189 160.638-68.112 29.013-150.015 21.053-212.768-27.882zm248.38 8.489c-2.171-12.886-13.446-74.897-41.152-151.033 66.38-10.626 124.7 6.768 131.947 9.055-9.442 58.941-43.273 109.844-90.795 141.978z"
                           ></path>
                        </svg>
                     </a>
                     <a href="#">
                        <svg
                           class="fill-white size-[0.938rem] transition-all duration-[0.3s] delay-[0] ease-in hover:fill-primary"
                           viewBox="0 0 448 512"
                           xmlns="http://www.w3.org/2000/svg"
                        >
                           <path
                              d="M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"
                           ></path>
                        </svg>
                     </a>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <!-- header section end -->
      <!-- navigation section start -->
      <nav
         class="bg-[#EEFCFC] py-2.5 min-h-[4.688rem] flex items-center xl:py-0 xl:h-auto"
      >
         <div class="w-full px-2.5 xl:px-[6.25rem] mx-auto">
            <div class="flex gap-5 items-center justify-between">
               <a
                  href="#"
                  class="block w-[10.616rem] md:w-[20.974rem] lg:w-[28.175rem] xl:w-[12.981rem] 2xl:w-[18.158rem]"
               >
                  <img
                     class="w-full max-w-full h-auto"
                     src="{{asset('frontend')}}/img/logo.webp"
                     alt="site logo"
                  />
               </a>
               <div class="grow items-center hidden xl:flex 2xl:justify-center">
                  <ul class="flex justify-center header-menu -mx-[0.938rem]">
                     <li class="relative group">
                        <a
                           class="py-[2.063rem] px-[0.938rem] block text-accent font-semibold hover:text-primary"
                           href="#"
                           >Home</a
                        >
                     </li>
                     <li class="relative group">
                        <a
                           class="py-[2.063rem] px-[0.938rem] text-accent font-semibold hover:text-primary flex items-center gap-1"
                           href="#"
                           >About Us <i class="ri-arrow-down-s-line"></i
                        ></a>
                        <ul
                           class="absolute left-[0.938rem] top-full border-b-2 border-[#5CB46A80] w-[13.75rem] bg-[#062727] rounded-bl-[0.313rem] rounded-br-[0.313rem] shadow-[0_4px_10px_-2px_rgba(0,0,0,0.1)] transition-all duration-[0.5s] delay-[0] ease-in transform hidden group-hover:block group-hover:translate-y-1"
                        >
                           <li class="border-b border-[#033333]">
                              <a
                                 class="py-[0.938rem] px-5 block text-white text-[0.938rem] font-medium leading-none hover:text-primary"
                                 href="#"
                                 >How It Works</a
                              >
                           </li>
                           <li class="border-b border-[#033333]">
                              <a
                                 class="py-[0.938rem] px-5 block text-white text-[0.938rem] font-medium leading-none hover:text-primary"
                                 href="#"
                                 >Testimonials</a
                              >
                           </li>
                           <li class="border-b border-[#033333]">
                              <a
                                 class="py-[0.938rem] px-5 block text-white text-[0.938rem] font-medium leading-none hover:text-primary"
                                 href="#"
                                 >Finance Calculator</a
                              >
                           </li>
                        </ul>
                     </li>
                     <li class="relative group">
                        <a
                           class="py-[2.063rem] px-[0.938rem] text-accent font-semibold hover:text-primary flex items-center gap-1"
                           href="#"
                           >Service <i class="ri-arrow-down-s-line"></i
                        ></a>
                        <ul
                           class="absolute left-[0.938rem] top-full border-b-2 border-[#5CB46A80] w-[13.75rem] bg-[#062727] rounded-bl-[0.313rem] rounded-br-[0.313rem] shadow-[0_4px_10px_-2px_rgba(0,0,0,0.1)] transition-all duration-[0.5s] delay-[0] ease-in transform hidden group-hover:block group-hover:translate-y-1"
                        >
                           <li class="border-b border-[#033333]">
                              <a
                                 class="py-[0.938rem] px-5 block text-white text-[0.938rem] font-medium leading-none hover:text-primary"
                                 href="#"
                                 >Credit Report Analysis</a
                              >
                           </li>
                           <li class="border-b border-[#033333]">
                              <a
                                 class="py-[0.938rem] px-5 block text-white text-[0.938rem] font-medium leading-none hover:text-primary"
                                 href="#"
                                 >Credit Score Strategies</a
                              >
                           </li>
                           <li class="border-b border-[#033333]">
                              <a
                                 class="py-[0.938rem] px-5 block text-white text-[0.938rem] font-medium leading-none hover:text-primary"
                                 href="#"
                                 >Dispute Resolution</a
                              >
                           </li>
                           <li class="border-b border-[#033333]">
                              <a
                                 class="py-[0.938rem] px-5 block text-white text-[0.938rem] font-medium leading-none hover:text-primary"
                                 href="#"
                                 >Debt Management</a
                              >
                           </li>
                           <li class="border-b border-[#033333]">
                              <a
                                 class="py-[0.938rem] px-5 block text-white text-[0.938rem] font-medium leading-none hover:text-primary"
                                 href="#"
                                 >Credit Builder Products</a
                              >
                           </li>
                           <li class="border-b border-[#033333]">
                              <a
                                 class="py-[0.938rem] px-5 block text-white text-[0.938rem] font-medium leading-none hover:text-primary"
                                 href="#"
                                 >Maintain, Build & Protect</a
                              >
                           </li>
                        </ul>
                     </li>
                     <li class="relative group">
                        <a
                           class="py-[2.063rem] px-[0.938rem] block text-accent font-semibold hover:text-primary"
                           href="#"
                           >Marketplace</a
                        >
                     </li>
                     <li class="relative group">
                        <a
                           class="py-[2.063rem] px-[0.938rem] block text-accent font-semibold hover:text-primary"
                           href="#"
                           >Packages</a
                        >
                     </li>
                     <li class="relative group">
                        <a
                           class="py-[2.063rem] px-[0.938rem] block text-accent font-semibold hover:text-primary"
                           href="#"
                           >Learn</a
                        >
                     </li>
                     <li class="relative group">
                        <a
                           class="py-[2.063rem] px-[0.938rem] text-accent font-semibold hover:text-primary flex items-center gap-1"
                           href="#"
                           >Contact <i class="ri-arrow-down-s-line"></i
                        ></a>
                        <ul
                           class="absolute left-[0.938rem] top-full border-b-2 border-[#5CB46A80] w-[13.75rem] bg-[#062727] rounded-bl-[0.313rem] rounded-br-[0.313rem] shadow-[0_4px_10px_-2px_rgba(0,0,0,0.1)] transition-all duration-[0.5s] delay-[0] ease-in transform hidden group-hover:block group-hover:translate-y-1"
                        >
                           <li class="border-b border-[#033333]">
                              <a
                                 class="py-[0.938rem] px-5 block text-white text-[0.938rem] font-medium leading-none hover:text-primary"
                                 href="#"
                                 >Careers</a
                              >
                           </li>
                           <li class="border-b border-[#033333]">
                              <a
                                 class="py-[0.938rem] px-5 block text-white text-[0.938rem] font-medium leading-none hover:text-primary"
                                 href="#"
                                 >Apply Now</a
                              >
                           </li>
                        </ul>
                     </li>
                  </ul>
               </div>
               <div
                  class="flex items-center justify-end gap-2.5 md:gap-5 lg:gap-5"
               >
                  <a href="">
                     <svg
                        class="size-5 fill-secondary"
                        aria-hidden="true"
                        viewBox="0 0 448 512"
                        xmlns="http://www.w3.org/2000/svg"
                     >
                        <path
                           d="M224 256c70.7 0 128-57.3 128-128S294.7 0 224 0 96 57.3 96 128s57.3 128 128 128zm89.6 32h-16.7c-22.2 10.2-46.9 16-72.9 16s-50.6-5.8-72.9-16h-16.7C60.2 288 0 348.2 0 422.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-41.6c0-74.2-60.2-134.4-134.4-134.4z"
                        ></path>
                     </svg>
                  </a>
                  <a href="#" class="text-[1.375rem] text-[#033333]">
                     <i class="ri-search-line"></i>
                  </a>
                  <div class="w-px h-[1.625rem] bg-[#B7CCBA]"></div>
                  <button
                     id="menu_btn"
                     class="text-2xl text-[#033333] cursor-pointer"
                  >
                     <i class="ri-menu-3-line"></i>
                  </button>
                  <a
                     class="py-[0.813rem] px-[1.563rem] rounded-[1.75rem] text-white bg-[#5cb46a] hidden xl:block"
                     href=""
                     >Let’s Talk</a
                  >
               </div>
            </div>
         </div>
      </nav>
      <!-- navigation section end -->
      <!-- hero section start -->
      <section
         class="py-[3.75rem] text-white md:bg-position-[top_center]!"
         style="
            background-image: url({{ asset('frontend/img/hero-img.webp') }});
            background-size: cover;
            background-position: center left;
            background-repeat: no-repeat;
            background-color: #eefcfc;
         "
      >
         <div class="px-2.5 xl:max-w-[83.125rem] mx-auto">
            <div
               class="md:max-w-[69%] flex flex-col gap-5 font-normal text-lg leading-[1.875rem]"
            >
               <h1
                  class="text-[#5CB46A] font-bold text-[1.875rem] leading-10 md:text-4xl md:leading-[2.875rem] xl:text-6xl xl:leading-[4.375rem]"
               >
                  Package Subscriptions
               </h1>
               <p>
                  Twindo specialise in helping individuals and families
                  <span class="font-bold"
                     >regain control of their finances</span
                  >
                  by
                  <span class="font-bold"
                     >repairing and improving credit scores</span
                  >, managing debts, and providing access to financial products
                  designed for those with poor or bad credit.
               </p>
               <div
                  class="mt-2.5 w-[4.375rem] h-[0.313rem] rounded-xs bg-primary"
               ></div>
            </div>
         </div>
      </section>
      <!-- hero section end -->
      <!-- pricing plan section start -->
      <section class="mt-[3.125rem] 2xl:mt-0 py-4 2xl:py-5 bg-[#EEFCFC]">
         <div class="w-full px-4 xl:max-w-[81.25rem] mx-auto">
            <div class="space-y-[1.875rem] md:space-y-[3.125rem]">
               <div class="flex justify-center">
                  <button
                     class="py-3 px-6 bg-[#00CC66] font-semibold text-white leading-[1.125rem] flex flex-col items-center justify-center text-center cursor-pointer basis-full md:basis-[content]"
                  >
                     Pay Monthly
                  </button>
                  <button
                     class="py-3 px-6 bg-[#0E3B29] font-semibold text-white leading-[1.125rem] hidden md:flex flex-col items-center justify-center text-center cursor-pointer basis-full md:basis-[content]"
                  >
                     Pay Annually
                     <span>(Save 20%)</span>
                  </button>
               </div>
               <div class="grid grid-cols-1 md:grid-cols-3 gap-5 md:gap-y-10">
                  <!-- item  -->
                  <div
                     class="p-3.5 2xl:p-6 border border-[#728383] rounded-lg flex flex-col gap-5 bg-linear-[170deg,#cfffe7_0%,#fefefe_100%]"
                  >
                     <div
                        class="bg-[#0E3B29] min-h-[3.25rem] flex items-center justify-center"
                     >
                        <h2
                           class="text-2xl leading-[3.25rem] font-extrabold text-white text-center"
                        >
                           Essential Plan
                        </h2>
                     </div>
                     <div class="flex flex-col items-center text-center">
                        <h5
                           class="text-[#0E3B29] text-[1.375rem] font-bold leading-[1.875rem]"
                        >
                           £29.99/month
                        </h5>
                        <p
                           class="text-[#333333] text-[0.938rem] font-medium leading-none"
                        >
                           Basic credit repair & debt advice
                        </p>
                     </div>
                     <div class="flex flex-col gap-5 grow">
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              Credit File Review & Dispute Support
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>
                                 Review Experian, Equifax & TransUnion reports
                              </li>
                              <li>Identify incorrect markers & defaults</li>
                              <li>Dispute letter templates for corrections</li>
                           </ul>
                        </div>
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              Debt Guidance & Budgeting Tools
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>Debt health check</li>
                              <li>Budget planner & savings strategies</li>
                              <li>Guidance on repayment plans</li>
                           </ul>
                        </div>
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              Credit-Building Products
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>
                                 Compare bad-credit cards & phone contracts
                              </li>
                              <li>Rent reporting services & recommendations</li>
                           </ul>
                        </div>
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              Correction Submissions
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>Help submitting notices to agencies</li>
                              <li>Remove outdated financial associations</li>
                           </ul>
                        </div>
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              Email Support & Monthly Tips
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>Monthly guidance & educational content</li>
                              <li>Email support for credit & debt queries</li>
                           </ul>
                        </div>
                     </div>
                     <div class="h-[0.188rem] bg-[#0E3B29]"></div>
                     {{-- @guest
                     <div class="p-2.5 border border-primary">
                        <a
                           class="py-3 px-6 bg-[#033333] block text-center rounded-[0.188rem] text-white text-sm font-medium leading-none hover:bg-secondary"
                           href="{{ route('sign.up') }}"
                           >Sign Up to Essentials kk</a>



                     </div>
                     @else --}}
                     <div class="p-2.5 border border-primary">


                           {{-- <button type="button"
        data-plan-name="Essentials Plan"
        data-monthly-amount="29.99"
        data-yearly-amount="348"
        data-plan-id="1"
        class="planButton py-3 px-6 bg-[#033333] block text-center rounded-[0.188rem] text-white text-sm font-medium leading-none hover:bg-secondary">
        Buy Essentials
    </button> --}}
    {{-- <form action="{{ route('payment.intent') }}">
                            <input type="hidden" name="plan_name" value="Essentials Plan">
                            <input type="hidden" name="monthly_amount" value="29.99">
                            <input type="hidden" name="yearly_amount" value="348">
                            <input type="hidden" name="plan_id" value="1">
                            <button type="submit"class="planButton py-3 px-6 bg-[#033333] block text-center rounded-[0.188rem] text-white text-sm font-medium leading-none hover:bg-secondary">
                            Buy Essentials
                        </button>
    </form> --}}
                           {{-- <button type="button"
        data-plan-name="Essentials Plan"
        data-monthly-amount="29.99"
        data-yearly-amount="348"
        data-plan-id="1"
        class="planButton py-3 px-6 bg-[#033333] block text-center rounded-[0.188rem] text-white text-sm font-medium leading-none hover:bg-secondary">
        Buy Essentials
    </button> --}}
    <a
    class="py-3 px-6 bg-[#033333] block text-center rounded-[0.188rem] text-white text-sm font-medium leading-none hover:bg-secondary"
    href="{{ route('checkout.page','essential_plan') }}"
    >Sign Up to Essentials </a
 >


                     </div>
                     {{-- @endguest --}}

                  </div>




                  <!-- item -->
                  <div
                     class="p-3.5 2xl:p-6 border border-[#728383] rounded-lg flex flex-col gap-5 bg-linear-[170deg,#cff7ff_0%,#fefefe_100%]"
                  >
                     <div
                        class="bg-[#0E3B29] min-h-[3.25rem] flex items-center justify-center"
                     >
                        <h2
                           class="text-2xl leading-[3.25rem] font-extrabold text-white text-center"
                        >
                           Plus Plan
                        </h2>
                     </div>
                     <div class="flex flex-col items-center text-center">
                        <h5
                           class="text-[#0E3B29] text-[1.375rem] font-bold leading-[1.875rem]"
                        >
                           £59.99/month
                        </h5>
                        <p
                           class="text-[#333333] text-[0.938rem] font-medium leading-none"
                        >
                           Everything in Essential + Score & Debt Help
                        </p>
                     </div>
                     <div class="flex flex-col gap-5 grow">
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              Credit Score Improvement
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>3–6 month score boost plan</li>
                              <li>Debt-to-credit ratio guidance</li>
                              <li>Improve affordability & lending chances</li>
                           </ul>
                        </div>
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              Debt Negotiation
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>Negotiate lower repayments</li>
                              <li>Freeze interest & charges</li>
                              <li>Consolidation plan guidance</li>
                           </ul>
                        </div>
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              Insolvency Assessment
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>IVA, DRO & Bankruptcy guidance</li>
                              <li>Referral to regulated specialists</li>
                           </ul>
                        </div>
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              Guaranteed Credit Access
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>Low-interest loans & mobile contracts</li>
                              <li>Secured credit accounts & rent reporting</li>
                           </ul>
                        </div>
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              Monthly Advisor Check-in
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>30-minute review with a Twindo advisor</li>
                              <li>Tailored advice & progress tracking</li>
                           </ul>
                        </div>
                     </div>
                     <div class="h-[0.188rem] bg-[#0E3B29]"></div>
                     {{-- @guest --}}
                     <div class="p-2.5 border border-primary">
                        <a
                           class="py-3 px-6 bg-[#033333] block text-center rounded-[0.188rem] text-white text-sm font-medium leading-none hover:bg-secondary"
                         href="{{ route('checkout.page','plus_plan') }}"
                           >Sign Up to Plus</a
                        >
                     </div>
                        {{-- @else --}}
                          {{-- <div class="p-2.5 border border-primary">
                        <button type="button"
            data-plan-name="Plus Plan"
            data-monthly-amount="59.99"
            data-yearly-amount="708"
             data-plan-id="2"
                           class="planButton py-3 px-6 bg-[#033333] block text-center rounded-[0.188rem] text-white text-sm font-medium leading-none hover:bg-secondary"

                           >Buy Plus</button
                        >


                     </div> --}}
                     {{-- @endguest --}}
                  </div>
                  <!-- item -->
                  <div
                     class="p-3.5 2xl:p-6 border border-[#728383] rounded-lg flex flex-col gap-5 bg-linear-[170deg,#ffe6bf_0%,#fefefe_100%]"
                  >
                     <div
                        class="bg-[#0E3B29] min-h-[3.25rem] flex items-center justify-center"
                     >
                        <h2
                           class="text-2xl leading-[3.25rem] font-extrabold text-white text-center"
                        >
                           Elite Plan
                        </h2>
                     </div>
                     <div class="flex flex-col items-center text-center">
                        <h5
                           class="text-[#0E3B29] text-[1.375rem] font-bold leading-[1.875rem]"
                        >
                           £99.99/month
                        </h5>
                        <p
                           class="text-[#333333] text-[0.938rem] font-medium leading-none"
                        >
                           Everything in Plus + Credit & Legal Support
                        </p>
                     </div>
                     <div class="flex flex-col gap-5 grow">
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              Dispute Management
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>Handle disputes with credit agencies</li>
                              <li>Remove inaccurate markers</li>
                              <li>Fix incorrect financial associations</li>
                           </ul>
                        </div>
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              Debt Settlement
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>Negotiate with creditors to reduce debt</li>
                              <li>Affordable repayment plans</li>
                              <li>CCJ & default assistance</li>
                           </ul>
                        </div>
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              Financial Coaching
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>1-to-1 support for money management</li>
                              <li>Priority access to rebuild credit</li>
                           </ul>
                        </div>
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              Fast-Track Access
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>Secured cards, apps & rent reporting</li>
                              <li>Exclusive pre-approved finance</li>
                           </ul>
                        </div>
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              Legal Support
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>Review of court & creditor letters</li>
                              <li>Personal Case Manager</li>
                           </ul>
                        </div>
                     </div>
                     <div class="h-[0.188rem] bg-[#0E3B29]"></div>

                     {{-- @guest --}}
                     <div class="p-2.5 border border-primary">
                        <a
                           class="py-3 px-6 bg-[#033333] block text-center rounded-[0.188rem] text-white text-sm font-medium leading-none hover:bg-secondary"
                          href="{{ route('checkout.page','elite_plan') }}"
                           >Sign Up to Elite</a
                        >
                     </div>
                     {{-- @else
                          <div class="p-2.5 border border-primary">
                        <button type="button"
            data-plan-name="Elite Plan"
            data-monthly-amount="99.99"
            data-yearly-amount="999"
             data-plan-id="3"
                           class="planButton py-3 px-6 bg-[#033333] block text-center rounded-[0.188rem] text-white text-sm font-medium leading-none hover:bg-secondary"

                           >Buy Elite</button
                        >


                     </div>
                     @endguest --}}
                  </div>
                  <!-- button -->
                  <button
                     class="py-3 px-6 bg-[#0E3B29] font-semibold text-white leading-[1.125rem] flex flex-col items-center justify-center text-center cursor-pointer basis-full md:basis-[content] -mt-5 mb-5 md:hidden"
                  >
                     Pay Annually
                     <span>(Save 20%)</span>
                  </button>
                  <!-- item -->
                  <div
                     class="p-3.5 2xl:p-6 border border-[#728383] rounded-lg flex flex-col gap-5"
                  >
                     <div
                        class="bg-[#0E3B29] min-h-[3.25rem] flex items-center justify-center"
                     >
                        <h2
                           class="text-2xl leading-[3.25rem] font-extrabold text-white text-center"
                        >
                           Platinum Plan
                        </h2>
                     </div>
                     <div class="flex flex-col items-center text-center">
                        <h5
                           class="text-[#0E3B29] text-[1.375rem] font-bold leading-[1.875rem]"
                        >
                           £2,500 One-Off
                        </h5>
                        <p
                           class="text-[#333333] text-[0.938rem] font-medium leading-none"
                        >
                           All-in credit rebuild + 1-to-1 coaching
                        </p>
                     </div>
                     <div class="flex flex-col gap-5 grow">
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              Full Credit Rebuild Strategy
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>Everything in Elite</li>
                              <li>3-month fast-track recovery roadmap</li>
                              <li>Custom dispute & settlement plan</li>
                           </ul>
                        </div>
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              Personal Finance Coach
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>Dedicated coach for 1-to-1 guidance</li>
                              <li>Weekly check-ins + 24/7 WhatsApp support</li>
                           </ul>
                        </div>
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              Exclusive Financial Products
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>
                                 Pre-approved high-limit credit builder tools
                              </li>
                              <li>VIP access to loan & finance partners</li>
                           </ul>
                        </div>
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              Partner Benefits
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>Access to cashback & budgeting apps</li>
                              <li>
                                 Free legal letter templates & email support
                              </li>
                           </ul>
                        </div>
                     </div>
                     <div class="h-[0.188rem] bg-[#0E3B29]"></div>
                     {{-- @guest --}}
                     <div class="p-2.5 border border-primary">
                        <a
                           class="py-3 px-6 bg-[#033333] block text-center rounded-[0.188rem] text-white text-sm font-medium leading-none hover:bg-secondary"
                         href="{{ route('checkout.page','platinum _plan') }}"
                           >Sign Up to Platinum</a
                        >
                     </div>
                          {{-- @else
                          <div class="p-2.5 border border-primary">
                        <button type="button"
            data-plan-name="Platinum Plan"
            data-monthly-amount="0"
            data-yearly-amount="2500"
             data-plan-id="4"
                           class="planButton py-3 px-6 bg-[#033333] block text-center rounded-[0.188rem] text-white text-sm font-medium leading-none hover:bg-secondary"

                           >Buy Platinum</button
                        >


                     </div>
                     @endguest --}}
                  </div>
                  <!-- item -->
                  <div
                     class="p-3.5 2xl:p-6 border border-[#728383] rounded-lg flex flex-col gap-5"
                  >
                     <div
                        class="bg-[#0E3B29] min-h-[3.25rem] flex items-center justify-center"
                     >
                        <h2
                           class="text-2xl leading-[3.25rem] font-extrabold text-white text-center"
                        >
                           Guaranteed Essentials
                        </h2>
                     </div>
                     <div class="flex flex-col items-center text-center">
                        <h5
                           class="text-[#0E3B29] text-[1.375rem] font-bold leading-[1.875rem]"
                        >
                           £100 One-Off
                        </h5>
                        <p
                           class="text-[#333333] text-[0.938rem] font-medium leading-none"
                        >
                           Guaranteed Bank Account, Mobile Contract & Credit
                           Card
                        </p>
                     </div>
                     <div class="flex flex-col gap-5 grow">
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              What’s Included
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>
                                 UK-regulated basic current account – no credit
                                 check required
                              </li>
                              <li>
                                 Guaranteed acceptance mobile SIM or handset
                                 contract
                              </li>
                              <li>
                                 Guaranteed credit builder card with manageable
                                 limits
                              </li>
                              <li>
                                 Approved providers only: UK banks, mobile
                                 networks & lenders
                              </li>
                              <li>60-Day Money-Back Guarantee</li>
                           </ul>
                        </div>
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              How It Helps Your Credit Score
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>
                                 Regular mobile payments reported to credit
                                 agencies
                              </li>
                              <li>
                                 Credit card usage builds repayment history &
                                 credit age
                              </li>
                              <li>
                                 Bank account setup shows financial stability
                              </li>
                              <li>
                                 All three create a more positive credit
                                 footprint
                              </li>
                           </ul>
                        </div>
                     </div>
                     <div class="h-[0.188rem] bg-[#0E3B29]"></div>
                     <div class="p-2.5 border border-primary">
                         <button>
                         <a class="planButtonOneTime py-3 px-6 bg-[#033333] block text-center rounded-[0.188rem] text-white text-sm font-medium leading-none hover:bg-secondary"
                           href="{{ route('checkout.page','guaranteed_essentials') }}" >
                          Sign Up to Guaranteed Essentials
                         </a>
                           </button>
                         {{-- <button
                           data-plan-name="Guaranteed Essentials"
                           data-onetime-amount="100"
                           data-job="1"
                           data-plan-id="6"
                           class="planButtonOneTime py-3 px-6 bg-[#033333] block text-center rounded-[0.188rem] text-white text-sm font-medium leading-none hover:bg-secondary"
                           >
                          Sign Up to Guaranteed Essentials
                           </button> --}}


                     </div>
                  </div>
                  <!-- item -->
                  <div
                     class="p-3.5 2xl:p-6 border border-[#728383] rounded-lg flex flex-col gap-5"
                  >
                     <div
                        class="bg-[#0E3B29] min-h-[3.25rem] flex items-center justify-center"
                     >
                        <h2
                           class="text-2xl leading-[3.25rem] font-extrabold text-white text-center"
                        >
                           Guaranteed Mobility
                        </h2>
                     </div>
                     <div class="flex flex-col items-center text-center">
                        <h5
                           class="text-[#0E3B29] text-[1.375rem] font-bold leading-[1.875rem]"
                        >
                           £100 One-Off
                        </h5>
                        <p
                           class="text-[#333333] text-[0.938rem] font-medium leading-none"
                        >
                           Guaranteed Car or Van Finance
                        </p>
                     </div>
                     <div class="flex flex-col gap-5 grow">
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              What’s Included
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>
                                 Access to approved lenders offering guaranteed
                                 acceptance
                              </li>
                              <li>
                                 Car or van finance regardless of credit score
                              </li>
                              <li>
                                 No broker fees – direct application guidance
                              </li>
                              <li>
                                 Lenders report payment history to major credit
                                 agencies
                              </li>
                              <li>60-Day Money-Back Guarantee</li>
                           </ul>
                        </div>
                        <div class="p-3 bg-white rounded-sm shadow-base grow">
                           <h6
                              class="text-[#0E3B29] text-base font-bold leading-7"
                           >
                              How It Helps Your Credit Score
                           </h6>
                           <ul class="pricing-inner-list pl-[0.688rem]">
                              <li>
                                 Builds a strong payment history with regular
                                 monthly repayments
                              </li>
                              <li>
                                 Increases credit mix by adding a hire
                                 purchase/finance product
                              </li>
                              <li>
                                 Shows responsible use of larger credit limits
                              </li>
                           </ul>
                        </div>
                     </div>
                     <div class="h-[0.188rem] bg-[#0E3B29]"></div>
                     <div class="p-2.5 border border-primary">

                           <button>
                       <a href="{{ route('checkout.page','guaranteed_mobility') }}"
                           class="planButtonOneTime py-3 px-6 bg-[#033333] block text-center rounded-[0.188rem] text-white text-sm font-medium leading-none hover:bg-secondary"
                           >
                           Sign Up to Guaranteed Mobility
                       </a>
                           </button>
                           {{-- <button
                           data-plan-name="Guaranteed Mobility"
                           data-onetime-amount="100"
                           data-job="1"
                           data-plan-id="6"
                           class="planButtonOneTime py-3 px-6 bg-[#033333] block text-center rounded-[0.188rem] text-white text-sm font-medium leading-none hover:bg-secondary"
                           >
                           Sign Up to Guaranteed Mobility
                           </button> --}}
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- pricing plan section end -->
      <!-- cta section start -->
      <section
         class="py-20 2xl:py-[2.188rem] bg-[#EEFCFC] px-5"
         style="
            background-image: url({{ asset('frontend/img/cta_bg.webp') }});
            background-repeat: no-repeat;
            background-position: top center;
            background-size: cover;
         "
      >
         <div class="xl:max-w-[81.875rem] mx-auto">
            <div class="md:w-[73%] 2xl:[68.913%] space-y-[2.188rem]">
               <h2
                  class="text-white text-[1.875rem] leading-10 md:text-[2.5rem] md:leading-[3.25rem] xl:text-[2.625rem] font-bold xl:leading-[3.25rem]"
               >
                  <span class="text-primary"
                     >Act Now! Propel Your Journey to Financial Freedom with
                     our</span
                  >
                  Platinum Plan – £2,500 (One-Off Payment, 3- 6 Month Service)
               </h2>
               <a
                  href="#"
                  class="inline-block py-[1.188rem] px-[1.813rem] bg-primary text-white rounded-[0.188rem] font-medium leading-[1.438rem] text-[1.063rem] hover:bg-secondary transition-all duration-[0.3s] delay-[0] ease-in"
                  >Let’s get Started</a
               >
            </div>
         </div>
      </section>
      <!-- cta section end -->
      <!-- footer section start -->
      <footer>
         <div
            class="pt-[3.125rem] pb-[1.875rem] overflow-hidden min-h-[12.563rem] relative"
         >
            <div class="px-2.5">
               <div
                  class="flex flex-col gap-10 md:flex-row md:gap-0 xl:absolute left-0"
               >
                  <div class="flex gap-5 md:basis-[22.913rem] shrink-0">
                     <div
                        class="flex items-center justify-center w-[4.688rem] h-[7.5rem] bg-[#1D4B49] shrink-0"
                     >
                        <svg
                           class="fill-primary"
                           xmlns="http://www.w3.org/2000/svg"
                           xmlns:xlink="http://www.w3.org/1999/xlink"
                           x="0px"
                           y="0px"
                           viewBox="0 0 200 200"
                           xml:space="preserve"
                        >
                           <path
                              d="M100.232,149.198c-2.8,0-5.4-1.8-7.2-5.2c-22.2-41-22.4-41.4-22.4-41.6c-3.2-5.1-4.9-11.3-4.9-17.6 c0-19.1,15.5-34.6,34.6-34.6s34.6,15.5,34.6,34.6c0,6.5-1.8,12.8-5.2,18.2c0,0-1.2,2.4-22.2,41 C105.632,147.398,103.132,149.198,100.232,149.198z M100.332,54.198c-16.9,0-30.6,13.7-30.6,30.6c0,5.6,1.5,11.1,4.5,15.9 c0.6,1.3,16.4,30.4,22.4,41.5c2.1,3.9,5.2,3.9,7.4,0c7.5-13.8,21.7-40.1,22.2-41c3.1-5,4.7-10.6,4.7-16.3 C130.832,67.898,117.132,54.198,100.332,54.198z"
                           ></path>
                           <path
                              d="M100.332,105.598c-10.6,0-19.1-8.6-19.1-19.1s8.5-19.2,19.1-19.2c10.6,0,19.1,8.6,19.1,19.1 S110.832,105.598,100.332,105.598z M100.332,71.298c-8.3,0-15.1,6.8-15.1,15.1c0,8.3,6.8,15.1,15.1,15.1c8.3,0,15.1-6.8,15.1-15.1 C115.432,78.098,108.632,71.298,100.332,71.298z"
                           ></path>
                        </svg>
                     </div>
                     <div class="grow space-y-2">
                        <h4
                           class="text-white text-[1.375rem] font-bold leading-8"
                        >
                           Office Address
                        </h4>
                        <p class="text-[#F3F3F3]">
                           EDPLX Limited t/a Twindo <br />124 City Road, London
                           <br />EC1V 2NX
                        </p>
                     </div>
                  </div>
                  <div
                     class="flex gap-5 md:basis-[22.913rem] shrink-0 xl:hidden"
                  >
                     <div
                        class="flex items-center justify-center w-[4.688rem] h-[7.5rem] bg-[#1D4B49] shrink-0"
                     >
                        <svg
                           class="fill-primary size-10"
                           xmlns="http://www.w3.org/2000/svg"
                           data-name="Layer 1"
                           viewBox="0 0 128 128"
                        >
                           <title>LETTER</title>
                           <path
                              d="M128,59.315a1.827,1.827,0,0,0-.646-1.358L105.417,40.13V6.962a1.75,1.75,0,0,0-1.75-1.75H24.333a1.75,1.75,0,0,0-1.75,1.75V40.13L.646,57.957A1.827,1.827,0,0,0,0,59.315v61.723a1.78,1.78,0,0,0,1.75,1.75h124.5a1.78,1.78,0,0,0,1.75-1.75ZM3.5,62.1,35.437,77.5,3.5,116.171ZM38.684,79.068,63.24,90.91a1.747,1.747,0,0,0,1.52,0L89.316,79.068l33.218,40.22H5.465ZM92.563,77.5,124.5,62.1v54.069Zm30.445-18.567-17.591,8.483V44.64ZM26.083,8.712h75.834V69.106L64,87.391,26.083,69.106Zm-3.5,35.928V67.419L4.992,58.936Z"
                           ></path>
                           <path
                              d="M35.125,18.8H64a1.75,1.75,0,1,0,0-3.5H35.125a1.75,1.75,0,0,0,0,3.5Z"
                           ></path>
                           <path
                              d="M35.125,28.3h57.75a1.75,1.75,0,0,0,0-3.5H35.125a1.75,1.75,0,0,0,0,3.5Z"
                           ></path>
                           <path
                              d="M35.125,37.795h57.75a1.75,1.75,0,0,0,0-3.5H35.125a1.75,1.75,0,0,0,0,3.5Z"
                           ></path>
                           <path
                              d="M35.125,47.294h57.75a1.75,1.75,0,0,0,0-3.5H35.125a1.75,1.75,0,0,0,0,3.5Z"
                           ></path>
                           <path
                              d="M35.125,56.792h57.75a1.75,1.75,0,0,0,0-3.5H35.125a1.75,1.75,0,0,0,0,3.5Z"
                           ></path>
                           <path
                              d="M35.125,66.292h57.75a1.75,1.75,0,0,0,0-3.5H35.125a1.75,1.75,0,0,0,0,3.5Z"
                           ></path>
                        </svg>
                     </div>
                     <div class="grow space-y-2">
                        <h4
                           class="text-white text-[1.375rem] font-bold leading-8"
                        >
                           Contact Us
                        </h4>
                        <p class="text-[#F3F3F3]">
                           <a href="mailto:hello@twindo.co.uk"
                              >hello@twindo.co.uk</a
                           >
                           <br />
                           <a href="tell:08443571110">0844 357 1110</a>
                           <br />
                           <a href="tell:07990830420">07990 830 420</a>
                        </p>
                     </div>
                  </div>
                  <div
                     class="flex gap-5 md:basis-[22.913rem] shrink-0 xl:hidden"
                  >
                     <div
                        class="flex items-center justify-center w-[4.688rem] h-[7.5rem] bg-[#1D4B49] shrink-0"
                     >
                        <svg
                           class="fill-primary size-[3.438rem]"
                           xmlns="http://www.w3.org/2000/svg"
                           data-name="Layer 1"
                           viewBox="0 0 128 128"
                        >
                           <title>CLOCK_1</title>
                           <path
                              d="M74.328,13.791a1.25,1.25,0,0,0-.5,2.449A48.8,48.8,0,1,1,64,15.25a1.25,1.25,0,0,0,0-2.5,51.193,51.193,0,1,0,10.328,1.041Z"
                           ></path>
                           <path
                              d="M19.75,64A44.25,44.25,0,1,0,64,19.75,44.3,44.3,0,0,0,19.75,64Zm86,0A41.75,41.75,0,1,1,64,22.25,41.8,41.8,0,0,1,105.75,64Z"
                           ></path>
                           <path
                              d="M62.75,34.594V62.757l-20.09.108a1.25,1.25,0,0,0,.007,2.5h.007l21.333-.115A1.25,1.25,0,0,0,65.25,64V34.594a1.25,1.25,0,0,0-2.5,0Z"
                           ></path>
                        </svg>
                     </div>
                     <div class="grow space-y-2">
                        <h4
                           class="text-white text-[1.375rem] font-bold leading-8"
                        >
                           Opening Hours
                        </h4>
                        <p class="text-[#F3F3F3]">
                           09:00 AM - 09:00 PM
                           <br />
                           Monday to Saturday
                           <br />
                           (Closed Bank Holidays)
                        </p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
         <!--  -->
         <div class="border-t border-[#FFFFFF14]">
            <div
               class="px-2.5 flex flex-wrap flex-col md:flex-row gap-5 mx-auto xl:max-w-[83.125rem]"
            >
               <div
                  class="pt-[4.063rem] py-5 xl:pr-2.5 flex flex-col gap-[1.875rem] text-white shrink-0 w-full xl:w-[22%] xl:border-r xl:border-r-[#FFFFFF14] xl:py-5"
               >
                  <div>
                     <a href="#" class="w-[12.313rem] block"
                        ><img
                           class="w-full h-auto"
                           src="{{asset('frontend')}}/img/footer-logo.webp"
                           alt=""
                     /></a>
                  </div>
                  <p class="pr-2.5">
                     We specialise in empowering individuals and families to
                     rebuild and strengthen their credit, so you can confidently
                     pursue life’s milestones, whether that’s buying a home,
                     funding education, or planning a holiday.
                  </p>
                  <div class="flex gap-5 mt-2.5">
                     <a
                        class="max-w-[8.125rem] rounded-sm overflow-hidden"
                        href=""
                        ><img src="{{asset('frontend')}}/img/google.webp" alt=""
                     /></a>
                     <a
                        class="max-w-[8.125rem] rounded-sm overflow-hidden"
                        href=""
                        ><img src="{{asset('frontend')}}/img/app.webp" alt=""
                     /></a>
                  </div>
               </div>
               <div
                  class="pt-0 py-5 xl:pl-[4.375rem] flex flex-col gap-2.5 md:gap-5 text-white shrink-0 md:w-[47%] xl:w-[22%] xl:pt-5"
               >
                  <h5 class="text-white text-[1.375rem] leading-8 font-bold">
                     Useful Links
                  </h5>
                  <ul class="inline-flex flex-col">
                     <li>
                        <a class="py-2.5 pr-[1.875rem] block" href=""></a>
                           About Us</a
                        >
                        <!-- <i class="ri-arrow-right-line"></i> -->
                     </li>
                     <li>
                        <a class="py-2.5 pr-[1.875rem] block" href=""
                           >Packages</a
                        >
                     </li>
                     <li>
                        <a class="py-2.5 pr-[1.875rem] block" href=""
                           >How It Works</a
                        >
                     </li>
                     <li>
                        <a class="py-2.5 pr-[1.875rem] block" href=""
                           >Marketplace</a
                        >
                     </li>
                     <li>
                        <a class="py-2.5 pr-[1.875rem] block" href="">Learn</a>
                     </li>
                     <li>
                        <a class="py-2.5 pr-[1.875rem] block" href=""
                           >Contact</a
                        >
                     </li>
                  </ul>
               </div>
               <div
                  class="pt-0 py-5 flex flex-col gap-2.5 md:gap-5 text-white shrink-0 md:w-[47%] xl:w-[22%] xl:pt-5"
               >
                  <h5 class="text-white text-[1.375rem] leading-8 font-bold">
                     Our Services
                  </h5>
                  <ul class="inline-flex flex-col">
                     <li>
                        <a class="py-2.5 pr-[1.875rem] block" href=""
                           >Credit Report Analysis</a
                        >
                     </li>
                     <li>
                        <a class="py-2.5 pr-[1.875rem] block" href=""
                           >Credit Score Strategies</a
                        >
                     </li>
                     <li>
                        <a class="py-2.5 pr-[1.875rem] block" href=""
                           >Dispute Resolution</a
                        >
                     </li>
                     <li>
                        <a class="py-2.5 pr-[1.875rem] block" href=""
                           >Debt Management</a
                        >
                     </li>
                     <li>
                        <a class="py-2.5 pr-[1.875rem] block" href=""
                           >Credit Builder Products</a
                        >
                     </li>
                     <li>
                        <a class="py-2.5 pr-[1.875rem] block" href=""
                           >Maintain, Build & Protect</a
                        >
                     </li>
                  </ul>
               </div>
               <div
                  class="pt-0 py-5 flex flex-col gap-5 text-white shrink-0 md:w-1/2 xl:w-[22%] md:pb-[3.125rem] xl:pt-5"
               >
                  <h5 class="text-white text-[1.375rem] leading-8 font-bold">
                     WhatsApp Newsletter
                  </h5>
                  <form action="" class="flex flex-col gap-[0.938rem]">
                     <input
                        class="py-[1.063rem] px-[1.875rem] rounded-[0.188rem] bg-[#11423F] text-[#FFFFFFE3] w-full h-[3.125rem] border border-[#3636361a]"
                        type="text"
                        name=""
                        id=""
                        placeholder="WhatsApp Number"
                     />
                     <input
                        class="px-10 py-[1.125rem] rounded-[0.188rem] bg-[#5CB46A] text-white text-[1.063rem] font-medium leading-none cursor-pointer uppercase"
                        type="submit"
                        value="Subscribe Now"
                     />
                  </form>
                  <div
                     class="mt-[0.938rem] pt-[0.313rem] flex items-center gap-2.5"
                  >
                     <a
                        class="flex items-center justify-center size-10 rounded-full bg-[#104042] transition-all duration-[0.3s] delay-[0] ease-in hover:bg-primary transform hover:-translate-y-[4px]"
                        href="#"
                     >
                        <svg
                           class="size-[1.125rem] fill-white"
                           aria-hidden="true"
                           viewBox="0 0 320 512"
                           xmlns="http://www.w3.org/2000/svg"
                        >
                           <path
                              d="M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"
                           ></path>
                        </svg>
                     </a>
                     <a
                        class="flex items-center justify-center size-10 rounded-full bg-[#104042] transition-all duration-[0.3s] delay-[0] ease-in hover:bg-primary transform hover:-translate-y-[4px]"
                        href="#"
                     >
                        <svg
                           aria-hidden="true"
                           class="size-[1.125rem] fill-white"
                           viewBox="0 0 448 512"
                           xmlns="http://www.w3.org/2000/svg"
                        >
                           <path
                              d="M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"
                           ></path>
                        </svg>
                     </a>
                     <a
                        class="flex items-center justify-center size-10 rounded-full bg-[#104042] transition-all duration-[0.3s] delay-[0] ease-in hover:bg-primary transform hover:-translate-y-[4px]"
                        href="#"
                     >
                        <svg
                           aria-hidden="true"
                           class="size-[1.125rem] fill-white"
                           viewBox="0 0 512 512"
                           xmlns="http://www.w3.org/2000/svg"
                        >
                           <path
                              d="M389.2 48h70.6L305.6 224.2 487 464H345L233.7 318.6 106.5 464H35.8L200.7 275.5 26.8 48H172.4L272.9 180.9 389.2 48zM364.4 421.8h39.1L151.1 88h-42L364.4 421.8z"
                           ></path>
                        </svg>
                     </a>
                     <a
                        class="flex items-center justify-center size-10 rounded-full bg-[#104042] transition-all duration-[0.3s] delay-[0] ease-in hover:bg-primary transform hover:-translate-y-[4px]"
                        href="#"
                     >
                        <svg
                           aria-hidden="true"
                           class="size-[1.125rem] fill-white"
                           viewBox="0 0 448 512"
                           xmlns="http://www.w3.org/2000/svg"
                        >
                           <path
                              d="M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"
                           ></path>
                        </svg>
                     </a>
                  </div>
               </div>
            </div>
         </div>
         <!-- footer-bottom -->
         <div class="py-5 text-white bg-[#033333]">
            <div
               class="px-2.5 flex flex-col md:flex-row gap-3 items-center justify-between mx-auto xl:max-w-[83.125rem]"
            >
               <div class="md:w-1/2">
                  <p>© 2025 Designed by <a href="">Twindo.</a></p>
               </div>
               <ul
                  class="md:w-1/2 flex flex-wrap items-center lg:justify-end gap-x-10"
               >
                  <li>
                     <a class="text-[#FFFFFFCC]" href="">Contact</a>
                  </li>
                  <li
                     class="shrink-0 relative before:content-[''] before:absolute before:w-[6px] before:h-[6px] before:rounded-full before:bg-[#7E999C] before:left-[-22.5px] before:top-1/2 before:-translate-y-1/2"
                  >
                     <a class="text-[#FFFFFFCC]" href="">Privacy Policy</a>
                  </li>
                  <li
                     class="shrink-0 relative before:content-[''] before:absolute before:w-[6px] before:h-[6px] before:rounded-full before:bg-[#7E999C] before:left-[-22.5px] before:top-1/2 before:-translate-y-1/2"
                  >
                     <a class="text-[#FFFFFFCC]" href="">Terms & Conditions</a>
                  </li>
               </ul>
            </div>
         </div>
      </footer>





      <!-- footer section end -->
      <script src="{{ asset('frontend/js/script.js ')}}"></script>


   </body>
</html>
