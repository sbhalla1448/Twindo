@extends('layouts.app')
@push('css')
<style>
    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }

    body {
        font-family: 'Inter', sans-serif;
        background-color: #f4f7f5;
        color: #1a1a1a;
    }

    header {
        background-color: #0e3b29;
        padding: 60px 20px 40px;
        text-align: center;
        color: #fff;
    }

    header h1 {
        font-size: 2rem;
        font-weight: 700;
    }

    header p {
        font-size: 1rem;
        margin-top: 10px;
        opacity: 0.9;
    }

    .search-box {
        margin: 20px auto 0;
        max-width: 576px;
    }

    .search-box input {
        width: 100%;
        padding: 12px;
        border-radius: 0;
        border: none;
        font-size: 1rem;
    }

    .filters {
        background: #0e3b29;
        color: #fff;
        margin: 30px auto 0;
        padding: 16px;
        border-radius: 0;
        max-width: 1000px;
    }

    .filters h2 {
        font-size: 1.2rem;
        margin-bottom: 12px;
        text-align: center;
    }

    .filters .filter-controls {
        display: flex;
        flex-wrap: nowrap;
        justify-content: space-between;
        gap: 20px;
    }

    .filters label {
        flex: 1;
        font-weight: 600;
        display: flex;
        flex-direction: column;
        font-size: 0.95rem;
    }

    .filters select {
        padding: 10px 14px;
        border-radius: 0;
        border: none;
        margin-top: 6px;
    }

    .reset-link {
        text-align: right;
        font-size: 0.9rem;
        margin-top: 10px;
    }

    .reset-link a {
        color: #fff;
        text-decoration: underline;
    }

    .card {
        background: #f5f5f5;
        width: 1000px;
        margin: 0 auto;
        border-left: 2px solid #cce3da;
        border-right: 2px solid #cce3da;
        border-bottom: 1px solid #cce3da;
        padding: 20px;
        position: relative;
        display: flex;
        flex-direction: column;
        justify-content: center;
        height: 196px;
        border-radius: 0;
    }

    .card:first-of-type {
        border-top: 2px solid #cce3da;
    }

    .card.featured {
        background: #e5fff0;
        border-color: #00cc66;
    }

    .card .tag {
        position: absolute;
        top: 15px;
        left: 20px;
        color: red;
        font-weight: 700;
        font-size: 0.9rem;
    }

    .card h3 {
        color: #064d38;
        font-size: 1.3rem;
        margin-bottom: 10px;
    }

    .card p {
        margin-bottom: 10px;
    }

    .stars {
        color: #fbbf24;
        font-size: 1rem;
        margin: 5px 0;
    }

    .phone {
        color: #0e3b29;
        font-weight: 500;
    }

    .price-box {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        margin-top: 0;
        position: relative;
    }

    .price-box>div:first-child {
        margin-top: -80px;
    }

    .price-box .price {
        font-size: 1.1rem;
        font-weight: 700;
        margin-bottom: 4px;
    }

    .price-box .total {
        font-size: 0.95rem;
        color: #444;
    }

    .cta-buttons {
        position: absolute;
        top: 150%;
        right: 20px;
        transform: translateY(-150%);
        display: flex;
        flex-direction: column;
        gap: 8px;
    }

    .cta-buttons button {
        background-color: #00cc66;
        color: white;
        padding: 10px 18px;
        border: none;
        border-radius: 6px;
        font-weight: 600;
        font-size: 0.95rem;
        cursor: pointer;
        min-width: 130px;
    }

    .cta-buttons .visit {
        background: #003d29;
    }

    @media (max-width: 768px) {
        .price-box {
            flex-direction: column;
            align-items: flex-start;
            gap: 16px;
        }

        .cta-buttons {
            position: static;
            transform: none;
            flex-direction: row;
            justify-content: flex-start;
            width: 100%;
            gap: 12px;
            margin-top: 10px;
        }

        .cta-buttons button {
            width: 100%;
            max-width: 160px;
        }
    }

    .pagination {
        display: flex;
        justify-content: center;
        margin: 30px auto;
        gap: 10px;
    }

    .pagination-btn {
        padding: 8px 12px;
        border: none;
        background-color: #0e3b29;
        color: white;
        border-radius: 4px;
        cursor: pointer;
        font-weight: 600;
    }

    .pagination-btn.active {
        background-color: #00cc66;
    }

    .load-more {
        text-align: center;
        margin: 20px 0 40px;
    }

    .load-more-btn {
        background-color: #003d29;
        color: #fff;
        padding: 12px 24px;
        font-size: 1rem;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        font-weight: 600;
    }
</style>
@endpush
@section('content')
    <header>
        <h1>Compare Credit Repair & Financial Products</h1>
        <p>Browse and filter trusted services across banking, loans, credit cards, and more.</p>
        <div class="search-box" style="position: relative;">
            <input type="text" placeholder="Search for product, company or category...">
            <svg style="position: absolute; right: 12px; top: 50%; transform: translateY(-50%); width: 20px; height: 20px; fill: #888;"
                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <path
                    d="M10 2a8 8 0 105.293 14.707l4.147 4.147 1.414-1.414-4.147-4.147A8 8 0 0010 2zm0 2a6 6 0 110 12 6 6 0 010-12z" />
            </svg>
        </div>
    </header>
    <main>
        <section class="filters">
            <h2>Filter Your Results</h2>
            <div class="filter-controls">
                <label>Sort by
                    <select>
                        <option>Best Match</option>
                        <option>Lowest Cost</option>
                        <option>Highest Rated</option>
                        <option>Newest</option>
                    </select>
                </label>
                <label>Category
                    <select>
                        <option>All</option>
                        <option>Credit Builder</option>
                        <option>Debt Management</option>
                        <option>Rent Reporting</option>
                        <option>Credit Reference Agencies</option>
                    </select>
                </label>
                <label>Product or Service
                    <select>
                        <option>All</option>
                        <option>Loqbox</option>
                        <option>Wollit</option>
                        <option>CreditLadder</option>
                    </select>
                </label>
            </div>
            <div class="reset-link">
                <a href="#">Reset Filters</a>
            </div>
        </section>

        <section class="card featured">
            <div class="tag">Featured</div>
            <h3 style="width: 40%;">Loqbox - Credit Builder</h3>
            <p>Save money monthly while building your credit profile.<br>Reports to all credit bureaus. FCA registered.
            </p>
            <div class="stars"><span style="color:#064d38; font-weight: 600;">⭐⭐⭐⭐⭐</span> <span
                    style="color:#0e3b29; font-weight: 600;">4.8</span> <span style="color:#666">(2,345 reviews)</span>
            </div>
            <div class="phone">📞 0800 123 4567</div>
            <div class="price-box">
                <div style="position: absolute; right: 20px; bottom: 80px; text-align: right;">
                    <div class="price">£0.00/mo</div>
                    <div class="total">Total Cost: £0.00</div>
                </div>
                <div class="cta-buttons">
                    <button class="visit">Visit Now</button>
                </div>
            </div>
        </section>

        <section class="card">
            <div class="tag">Online Exclusive</div>
            <h3 style="width: 40%;">Wollit</h3>
            <p
                style="width: 60%; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                Turn subscriptions into credit activity. Trusted by 100,000+ users in the UK. Free trial available.
                Reports to Experian.</p>
            <div class="stars"><span style="color:#0e3b29; font-weight: 600;">⭐⭐⭐⭐⯪</span> <span
                    style="color:#0e3b29; font-weight: 600;">4.5</span> <span style="color:#666">(1,783 reviews)</span>
            </div>
            <div class="phone">📞 0800 765 4321</div>
            <div class="price-box">
                <div style="position: absolute; right: 20px; bottom: 80px; text-align: right;">
                    <div class="price">£9.99/mo</div>
                    <div class="total">Total Cost: £119.88/year</div>
                </div>
                <div class="cta-buttons">
                    <button class="visit">Visit Now</button>
                </div>
            </div>
        </section>

        <section class="card">
            <div class="tag">Popular</div>
            <h3 style="width: 40%;">CreditLadder</h3>
            <p
                style="width: 60%; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                Report your rent to credit reference agencies to boost your score. No credit check. FCA regulated
                service.</p>
            <div class="stars"><span style="color:#0e3b29; font-weight: 600;">⭐⭐⭐⭐⭐</span> <span
                    style="color:#0e3b29; font-weight: 600;">4.6</span> <span style="color:#666">(2,012 reviews)</span>
            </div>
            <div class="phone">📞 0800 654 3210</div>
            <div class="price-box">
                <div style="position: absolute; right: 20px; bottom: 80px; text-align: right;">
                    <div class="price">£5.99/mo</div>
                    <div class="total">Total Cost: £71.88/year</div>
                </div>
                <div class="cta-buttons">
                    <button class="visit">Visit Now</button>
                </div>
            </div>
        </section>
        <section class="card">
            <div class="tag">Top Rated</div>
            <h3 style="width: 40%;">Salad Money</h3>
            <p
                style="width: 60%; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                Affordable loans for NHS and public sector workers. No credit score required. Regulated by the FCA.</p>
            <div class="stars"><span style="color:#0e3b29; font-weight: 600;">⭐⭐⭐⭐⭐</span> <span
                    style="color:#0e3b29; font-weight: 600;">4.7</span> <span style="color:#666">(1,529 reviews)</span>
            </div>
            <div class="phone">📞 0800 321 9876</div>
            <div class="price-box">
                <div style="position: absolute; right: 20px; bottom: 80px; text-align: right;">
                    <div class="price">£15.00/mo</div>
                    <div class="total">Total Cost: £180.00/year</div>
                </div>
                <div class="cta-buttons">
                    <button class="visit">Visit Now</button>
                </div>
            </div>
        </section>

        <section class="card">
            <div class="tag">Trusted Choice</div>
            <h3 style="width: 40%;">Ocean Credit Card</h3>
            <p
                style="width: 60%; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                Credit card designed for rebuilding your credit history. QuickCheck eligibility checker available.</p>
            <div class="stars"><span style="color:#0e3b29; font-weight: 600;">⭐⭐⭐⭐</span> <span
                    style="color:#0e3b29; font-weight: 600;">4.2</span> <span style="color:#666">(3,210 reviews)</span>
            </div>
            <div class="phone">📞 0800 456 7890</div>
            <div class="price-box">
                <div style="position: absolute; right: 20px; bottom: 80px; text-align: right;">
                    <div class="price">£3.00/mo</div>
                    <div class="total">Total Cost: £36.00/year</div>
                </div>
                <div class="cta-buttons">
                    <button class="visit">Visit Now</button>
                </div>
            </div>
        </section>
        <div class="pagination">
            <button class="pagination-btn">«</button>
            <button class="pagination-btn active">1</button>
            <button class="pagination-btn">2</button>
            <button class="pagination-btn">3</button>
            <button class="pagination-btn">»</button>
        </div>
        <div class="load-more">
            <button class="load-more-btn">Load More</button>
        </div>
    </main>
@endsection
