@extends('layouts.app')

@push('css')
<style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(135deg, #e5f4ec, #ffffff);
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .login-card {
      background: white;
      padding: 3rem;
      border-radius: 12px;
      box-shadow: 0 0 25px rgba(0, 0, 0, 0.08);
      width: 100%;
      max-width: 420px;
      text-align: center;
      margin-top: auto;
    }
    .login-card h2 {
      color: #004225;
      margin-bottom: 1rem;
    }
    .login-card p {
      color: #666;
      margin-bottom: 2rem;
      font-size: 0.95rem;
    }
    .form-group {
      text-align: left;
      margin-bottom: 1.5rem;
    }
    label {
      display: block;
      font-weight: bold;
      margin-bottom: 0.5rem;
      color: #004225;
    }
    input[type="email"],
    input[type="password"] {
      width: 100%;
      padding: 0.75rem;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 1rem;
    }
    button {
      width: 100%;
      padding: 1rem;
      background-color: #00cc66;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 1rem;
      font-weight: bold;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }
    button:hover {
      background-color: #00994d;
    }
    .social-login {
      margin-top: 2rem;
    }
    .social-login button {
      background-color: #ffffff;
      color: #1a1a1a;
      border: 1px solid #ccc;
      margin: 0.5rem 0;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .social-login img {
      width: 20px;
      height: 20px;
      margin-right: 10px;
    }
    .divider {
      margin: 2rem 0 1rem;
      font-size: 0.85rem;
      color: #999;
    }
    .login-footer {
      margin-top: 1.5rem;
      font-size: 0.9rem;
    }
    .login-footer a {
      color: #004225;
      text-decoration: none;
      font-weight: bold;
    }
    .social-icons {
      margin-top: 1.5rem;
    }
    .social-icons a {
      display: inline-block;
      margin: 0 8px;
    }
    .social-icons img {
      width: 24px;
      height: 24px;
    }
  </style>
  <script src="https://cdn.tailwindcss.com"></script>
@endpush

@section('content')

<livewire:frontend.user-signup />
@endsection
