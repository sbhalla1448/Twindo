





@if($templateReport && $templateReport->html_content)
    <iframe srcdoc="{!! addslashes($templateReport->html_content) !!}"
            style="width: 100%; height: 600px; border: none;">
    </iframe>
@else
    <p>No content found</p>
@endif