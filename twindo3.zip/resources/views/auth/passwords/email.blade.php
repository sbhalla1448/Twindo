@extends('layouts.app')

@push('css')
<style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(135deg, #e5f4ec, #ffffff);
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .reset-card {
      background: white;
      padding: 3rem;
      border-radius: 12px;
      box-shadow: 0 0 25px rgba(0, 0, 0, 0.08);
      width: 100%;
      max-width: 420px;
      text-align: center;
    }
    .reset-card h2 {
      color: #004225;
      margin-bottom: 1rem;
    }
    .reset-card p {
      color: #555;
      font-size: 0.95rem;
      margin-bottom: 2rem;
    }
    .form-group {
      text-align: left;
      margin-bottom: 1.5rem;
    }
    label {
      display: block;
      font-weight: bold;
      margin-bottom: 0.5rem;
      color: #004225;
    }
    input[type="email"] {
      width: 100%;
      padding: 0.75rem;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 1rem;
    }
    button {
      width: 100%;
      padding: 1rem;
      background-color: #00cc66;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 1rem;
      font-weight: bold;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }
    button:hover {
      background-color: #00994d;
    }
    .back-link {
      margin-top: 2rem;
      display: block;
      font-size: 0.9rem;
    }
    .back-link a {
      color: #004225;
      text-decoration: none;
      font-weight: bold;
    }
  </style>
@endpush


@section('content')
<div class="reset-card">
    <h2>Forgot your password?</h2>
    <p>No worries — just enter your email below and we’ll send you a link to reset it.</p>
    @if (session('status'))
    <div class="alert alert-success" role="alert">
        {{ session('status') }}
    </div>
@endif

    <form method="POST" action="{{ route('password.email') }}">
        @csrf
      <div class="form-group">
        <label for="email">Email Address</label>
        <input type="email" id="email" name="email" placeholder="you@twindo.co.uk" required>
        @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
        @enderror
      </div>
      <button type="submit">Send Reset Link</button>
    </form>
    <div class="back-link">
      <p><a href="#">Back to login</a></p>
    </div>
  </div>



{{-- <div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Reset Password') }}</div>

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    <form method="POST" action="{{ route('password.email') }}">
                        @csrf

                        <div class="row mb-3">
                            <label for="email" class="col-md-4 col-form-label text-md-end">{{ __('Email Address') }}</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Send Password Reset Link') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div> --}}
@endsection
