<!-- Twindo Admin — 2FA Setup Modal -->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>2FA Setup - Twindo Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-900 bg-opacity-80 min-h-screen flex items-center justify-center">

    <!-- 2FA Modal -->
    <livewire:verify-o-t-p>

</body>

</html>