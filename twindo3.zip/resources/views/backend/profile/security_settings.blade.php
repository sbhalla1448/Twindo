@extends('backend.master')

@section('content')
    <!-- Main -->
    <livewire:security-setting>
    @endsection
