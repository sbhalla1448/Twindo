@extends('backend.setting_master')

@section('content')
    <main class="pt-20 max-w-5xl mx-auto px-6 py-10">

        <section class="bg-white rounded-xl shadow p-8">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-2xl font-bold text-gray-800">👤 Manage Profile</h2>
                <span class="inline-block text-sm bg-green-100 text-green-800 px-3 py-1 rounded-full font-medium">✅
                    Active</span>
            </div>
            <p class="text-sm text-gray-600 mb-6">Update your profile details and admin credentials for your Twindo
                account.</p>

            <form action="{{ route('admin.profile.update') }}" method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-6">
                @csrf
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                    <input type="text"
                        class="w-full border border-gray-300 rounded-lg p-2 text-sm shadow-sm focus:ring-2 focus:ring-indigo-500"
                        value="{{ Auth::user()->name }}" name="name">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                    <input type="email"
                        class="w-full border border-gray-300 rounded-lg p-2 text-sm shadow-sm focus:ring-2 focus:ring-indigo-500"
                        value="{{ Auth::user()->email }}" name="email">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                    <input type="text" class="w-full border border-gray-300 rounded-lg p-2 text-sm shadow-sm"
                        placeholder="+44 123 456 7890" value="{{ Auth::user()->phone }}" name="phone">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Profile Picture</label>
                    <input type="file" name="image"
                        class="w-full border border-gray-300 rounded-lg p-2 text-sm shadow-sm">
                </div>


                <div class="mt-6 text-right">
                    <button type="submit"
                        class="bg-indigo-600 text-white px-5 py-2 rounded hover:bg-indigo-700 text-sm shadow focus:outline-none focus:ring-2 focus:ring-indigo-500">💾
                        Save Changes</button>
                </div>
            </form>
        </section>

    </main>
@endsection
