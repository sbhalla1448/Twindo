@extends('backend.master')

@section('content')
<main class="flex-1 overflow-auto">
    <div class="max-w-7xl mx-auto px-6 py-10">

    <h1 class="text-2xl font-bold mb-4">Add New Coupon</h1>

    <form action="{{ route('admin.coupons.store') }}" method="POST" class="max-w-md">
        @csrf
        {{-- <div class="mb-4">
            <label for="code" class="block text-gray-700 font-medium mb-2">Coupon Code</label>
            <input type="text" name="code" id="code" value="{{ old('code') }}" required
                   class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div> --}}

        <div class="mb-4">
            <label for="type" class="block text-gray-700 font-medium mb-2">Type</label>
            <select name="type" id="type" required
                    class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option value="fixed" {{ old('type', $coupon->type ?? '') == 'fixed' ? 'selected' : '' }}>Fixed</option>
                <option value="percent" {{ old('type', $coupon->type ?? '') == 'percent' ? 'selected' : '' }}>Percent</option>
            </select>
        </div>

        <div class="mb-4">
            <label for="value" class="block text-gray-700 font-medium mb-2">Value</label>
            <input type="number" name="value" id="value" value="{{ old('value') }}" step="0.01" required
                   class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <div class="mb-4">
            <label for="min_spend" class="block text-gray-700 font-medium mb-2">Minimum Spend (Optional)</label>
            <input type="number" name="min_spend" id="min_spend" value="{{ old('min_spend') }}" step="0.01"
                   class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <div class="mb-4">
            <label for="valid_from" class="block text-gray-700 font-medium mb-2">Valid From (Optional)</label>
            <input type="datetime-local" name="valid_from" id="valid_from" value="{{ old('valid_from') }}"
                   class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <div class="mb-4">
            <label for="valid_to" class="block text-gray-700 font-medium mb-2">Valid Until (Optional)</label>
            <input type="datetime-local" name="valid_to" id="valid_to" value="{{ old('valid_to') }}"
                   class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <div class="mb-4">
            <label for="usage_limit" class="block text-gray-700 font-medium mb-2">Usage Limit</label>
            <input type="number" name="usage_limit" id="usage_limit" value="{{ old('usage_limit') }}" min="1" required
                   class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500">
        </div>

        <div class="mt-6">
            <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
                Submit
            </button>
        </div>
    </form>
</div>
</div>
</main>
@endsection