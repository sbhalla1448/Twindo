@extends('backend.master')

@section('content')

<main class="flex-1 overflow-auto">
    <div class="max-w-7xl mx-auto px-6 py-10">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold">Coupons</h1>
        <a href="{{ route('admin.coupons.create') }}" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            Add New Coupon
        </a>
    </div>

    @if(session('success'))
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
            <p>{{ session('success') }}</p>
        </div>
    @endif

    <table class="min-w-full bg-white border border-gray-300">
        <thead>
            <tr class="bg-gray-100">
                <th class="py-2 px-4 border-b">Code</th>
                <th class="py-2 px-4 border-b">Type</th>
                <th class="py-2 px-4 border-b">Value</th>
                <th class="py-2 px-4 border-b">Min Spend</th>
                <th class="py-2 px-4 border-b">Valid From</th>
                <th class="py-2 px-4 border-b">Valid To</th>
                <th class="py-2 px-4 border-b">Usage Limit</th>
                <th class="py-2 px-4 border-b">Actions</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($coupons as $coupon)
                <tr class="hover:bg-gray-50">
                    <td class="py-2 px-4 border-b">{{ $coupon->code }}</td>
                    <td class="py-2 px-4 border-b">{{ ucfirst($coupon->type) }}</td>
                    <td class="py-2 px-4 border-b">{{ $coupon->value }}</td>
                    <td class="py-2 px-4 border-b">{{ $coupon->min_spend ?? 'N/A' }}</td>
                    <td class="py-2 px-4 border-b">{{ $coupon->valid_from ? \Carbon\Carbon::parse($coupon->valid_from)->format('Y-m-d') : 'N/A' }}</td>
                    <td class="py-2 px-4 border-b">{{ $coupon->valid_to ? \Carbon\Carbon::parse($coupon->valid_to)->format('Y-m-d') : 'N/A' }}</td>
                    <td class="py-2 px-4 border-b">{{ $coupon->usage_limit }}</td>
                    <td class="py-2 px-4 border-b">
                        <a href="{{ route('admin.coupons.edit', $coupon) }}" class="text-blue-500 hover:text-blue-700 mr-2">Edit</a>
                        <a href="{{ route('admin.coupons.show', $coupon) }}" class="text-blue-500 hover:text-blue-700 mr-2">Show</a>
                        <form action="{{ route('admin.coupons.destroy', $coupon) }}" method="POST" class="inline">
                            @csrf
                            @method('DELETE')
                            <button type="submit" class="text-red-500 hover:text-red-700">Delete</button>
                        </form>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="8" class="py-2 px-4 text-center text-gray-500">No coupons found.</td>
                </tr>
            @endforelse
        </tbody>
    </table>
</div>
</div>
</main>

@endsection