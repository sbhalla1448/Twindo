@extends('backend.master')


@section('content')
<main class="flex-1 overflow-auto">
    <div class="max-w-7xl mx-auto px-6 py-10">
    <h1 class="text-2xl font-bold mb-4">Edit Coupon</h1>

    <form action="{{ route('admin.coupons.update', $coupon) }}" method="POST" class="max-w-md">
        @csrf
        @method('PUT')
        @include('backend.coupons.form')
    </form>
</div>
</div>
</main>
@endsection