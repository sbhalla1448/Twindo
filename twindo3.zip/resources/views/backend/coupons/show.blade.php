@extends('backend.master')

@section('content')

<main class="flex-1 overflow-auto">
    <div class="max-w-7xl mx-auto px-6 py-10">



    <h1 class="text-2xl font-bold mb-6">Coupon Preview</h1>

    <div class="max-w-lg mx-auto bg-white shadow rounded-lg p-6 space-y-4">
        <div>
            <label class="block text-gray-500 text-sm font-medium">Coupon Code</label>
            <p class="mt-1 text-gray-800 font-semibold">{{ $coupon->code }}</p>
        </div>

        <div>
            <label class="block text-gray-500 text-sm font-medium">Type</label>
            <p class="mt-1 text-gray-800 capitalize">{{ $coupon->type }}</p>
        </div>

        <div>
            <label class="block text-gray-500 text-sm font-medium">Value</label>
            <p class="mt-1 text-gray-800">
                @if($coupon->type === 'fixed')
                    ${{ number_format($coupon->value, 2) }}
                @else
                    {{ $coupon->value }}%
                @endif
            </p>
        </div>

        <div>
            <label class="block text-gray-500 text-sm font-medium">Minimum Spend</label>
            <p class="mt-1 text-gray-800">
                {{ $coupon->min_spend ? '$' . number_format($coupon->min_spend, 2) : 'N/A' }}
            </p>
        </div>

        <div>
            <label class="block text-gray-500 text-sm font-medium">Valid From</label>
            <p class="mt-1 text-gray-800">
                {{ $coupon->valid_from ? \Carbon\Carbon::parse($coupon->valid_from)->format('M d, Y h:i A') : 'N/A' }}
            </p>
        </div>

        <div>
            <label class="block text-gray-500 text-sm font-medium">Valid Until</label>
            <p class="mt-1 text-gray-800">
                {{ $coupon->valid_to ? \Carbon\Carbon::parse($coupon->valid_to)->format('M d, Y h:i A') : 'N/A' }}
            </p>
        </div>

        <div>
            <label class="block text-gray-500 text-sm font-medium">Usage Limit</label>
            <p class="mt-1 text-gray-800">{{ $coupon->usage_limit }}</p>
        </div>

        <div>
            <label class="block text-gray-500 text-sm font-medium">Used Count</label>
            <p class="mt-1 text-gray-800">{{ $coupon->used_count }}</p>
        </div>

        <div>
            <label class="block text-gray-500 text-sm font-medium">Status</label>
            <p class="mt-1">
                @if($coupon->active && $coupon->isValid())
                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        Active
                    </span>
                @else
                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                        Inactive
                    </span>
                @endif
            </p>
        </div>
    </div>

    <div class="mt-6 flex justify-between max-w-lg mx-auto">
        <a href="{{ route('admin.coupons.edit', $coupon) }}" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            Edit Coupon
        </a>

        <form action="{{ route('admin.coupons.destroy', $coupon) }}" method="POST" onsubmit="return confirm('Are you sure?');">
            @csrf
            @method('DELETE')
            <button type="submit" class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
                Delete Coupon
            </button>
        </form>
    </div>
</div>
</div>
</main>
@endsection