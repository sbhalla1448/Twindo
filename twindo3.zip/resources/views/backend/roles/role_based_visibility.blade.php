@extends('backend.master')

@section('content')
    <main class="flex-1 overflow-auto">
        <div class="max-w-7xl mx-auto px-6 py-10">

            <!-- Header -->
            <section class="flex justify-between items-center">
                <div>
                    <h1 class="text-3xl font-bold text-gray-800">👁️ Role-Based Visibility</h1>
                    <p class="text-sm text-gray-600 mt-1">Define what different roles can see across the Twindo admin
                        platform.
                    </p>
                </div>
            </section>

            <!-- Visibility Controls Table -->
            {{-- <section class="bg-white shadow rounded-xl p-6">
                <h2 class="text-xl font-semibold text-gray-800 mb-4">🔒 Visibility Rules by Role</h2>
                <table class="w-full text-sm text-left text-gray-700">
                    <thead class="text-xs text-gray-500 border-b">

                        <tr>
                            <th class="py-2 px-4">fff</th>
                            @foreach ($roles as $role)
                                <th class="py-2 px-4">{{ $role->name }}</th>
                            @endforeach --}}
            {{-- <th class="py-2 px-4">Admin</th>
                                <th class="py-2 px-4">Support Agent</th>
                                <th class="py-2 px-4">Viewer</th> --}}
            {{-- </tr>

                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        @foreach ($permissions as $permission)
                            <tr>
                                <td class="py-2 px-4 font-medium">{{ $permission->name }}</td>

                                @foreach ($roles as $role)
                                    <td class="py-2 px-4"><input type="checkbox">{{ $role->name }}</td>
                                @endforeach --}}
            {{-- <td class="py-2 px-4"><input type="checkbox"></td> --}}
            {{-- <td class="py-2 px-4"><input type="checkbox"></td>
                            </tr>
                        @endforeach --}}

            {{-- <tr>
                        <td class="py-2 px-4 font-medium">Documents</td>
                        <td class="py-2 px-4"><input type="checkbox" checked></td>
                        <td class="py-2 px-4"><input type="checkbox" checked></td>
                        <td class="py-2 px-4"><input type="checkbox" checked></td>
                    </tr>
                    <tr>
                        <td class="py-2 px-4 font-medium">Subscription Management</td>
                        <td class="py-2 px-4"><input type="checkbox" checked></td>
                        <td class="py-2 px-4"><input type="checkbox"></td>
                        <td class="py-2 px-4"><input type="checkbox"></td>
                    </tr>
                    <tr>
                        <td class="py-2 px-4 font-medium">Tools & Resources</td>
                        <td class="py-2 px-4"><input type="checkbox" checked></td>
                        <td class="py-2 px-4"><input type="checkbox" checked></td>
                        <td class="py-2 px-4"><input type="checkbox"></td>
                    </tr> --}}
            {{-- </tbody>
                </table>
                <div class="mt-6 text-right">
                    <button class="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-indigo-700">💾 Save
                        Visibility
                        Settings</button>
                </div>
            </section> --}}
            <section class="bg-white shadow rounded-xl p-6">
                <h2 class="text-xl font-semibold text-gray-800 mb-4">🔒 Visibility Rules by Role</h2>

                <form action="{{ route('admin.role.based.visibility.update') }}" method="POST">
                    @csrf

                    <table class="w-full text-sm text-left text-gray-700">
                        <thead class="text-xs text-gray-500 border-b">
                            <tr>
                                <th class="py-2 px-4">Admin Section</th>
                                @foreach ($roles as $role)
                                    <th class="py-2 px-4">{{ $role->name }}</th>
                                @endforeach
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                            {{-- @foreach ($permissions as $permission)
                                <tr>
                                    <td class="py-2 px-4 font-medium">{{ $permission->name }}</td>

                                    @foreach ($roles as $role)
                                        <td class="py-2 px-4">
                                            <input type="checkbox" name="permissions[{{ $role->id }}][]"
                                                value="{{ $permission->id }}"
                                                {{ $role->permissions->contains($permission->id) ? 'checked' : '' }}>
                                        </td>
                                    @endforeach
                                </tr>
                            @endforeach --}}

                            @foreach ($sections as $section)
                                <tr>
                                    <td>{{ $section->section }}</td>
                                    @foreach ($roles as $role)
                                        <td>
                                            <input type="checkbox"
                                                name="visibility[{{ $section->id }}][{{ $role->id }}]" value="1"
                                                {{ $section->roles->contains($role->id) && $section->roles->where('id', $role->id)->first()->pivot->can_view ? 'checked' : '' }}>
                                        </td>
                                    @endforeach
                                </tr>
                            @endforeach
                        </tbody>
                    </table>

                    <div class="mt-6 text-right">
                        <button type="submit"
                            class="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-indigo-700">💾 Save
                            Visibility Settings</button>
                    </div>
                    {{-- </form> --}}
            </section>

        </div>
    </main>
@endsection
