@extends('backend.master')

@section('content')
    <main class="flex-1 overflow-auto">
        <form id="submitFromDisable" method="POST"
            action="{{ isset($role) ? route('admin.roles.update', $role->id) : route('admin.role.persmission.store') }}">
            @csrf
            @if (isset($role))
                @method('PUT')
            @endif
            <div class="max-w-7xl mx-auto px-6 py-10">


                <!-- Role Selection Dropdown -->
                <section class="bg-white rounded-xl shadow p-6">
                    <h2 class="text-xl font-semibold text-gray-800 mb-4">🎯 Select Role to Configure</h2>
                    @if ($errors->any())
                        @foreach ($errors->all() as $error)
                            <p>{{ $error }}</p>
                        @endforeach
                    @endif
                    <select name="role_id" class="w-full border rounded-lg p-2 text-sm">
                        <option value="">Select Role</option>
                        @foreach ($roles as $ro)
                            <option value="{{ $ro->id }}">{{ $ro->name }}</option>
                        @endforeach
                    </select>
                </section>

                <section class="bg-white rounded-xl shadow p-6">
                    <h2 class="text-xl font-semibold text-gray-800 mb-4">🧩 Action Permissions</h2>

                    <!-- form start -->

                    <div class="p-6">

                        <div class="mb-4 flex items-center">
                            <input type="checkbox" id="select-all"
                                class="h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500">
                            <label for="select-all" class="ml-2 text-sm text-gray-700">Select All</label>
                        </div>

                        <!-- Permission Checkboxes Grouped by Module -->
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                            @forelse ($modules->chunk(3) as $chunk)
                                @foreach ($chunk as $module)
                                    <div class="border border-gray-200 rounded-md p-4">
                                        <h5 class="font-semibold text-gray-800 mb-3">Feature:
                                            {{ $module->name }}</h5>
                                        @foreach ($module->permissions as $permission)
                                            <div class="flex items-center mb-2">
                                                <input type="checkbox" name="permissions[]" value="{{ $permission->id }}"
                                                    id="permission-{{ $permission->id }}"
                                                    class="h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
                                                    @if (isset($role) && $role->permissions->contains($permission->id)) checked @endif>
                                                <label for="permission-{{ $permission->id }}"
                                                    class="ml-2 text-sm text-gray-700">{{ $permission->name }}</label>
                                            </div>
                                        @endforeach
                                    </div>
                                @endforeach
                            @empty
                                <div class="col-span-full text-center text-gray-500">
                                    No modules found.
                                </div>
                            @endforelse
                        </div>

                        <!-- Action Buttons -->
                        <div class="mt-8 flex justify-end space-x-3">
                            <button type="reset" onclick="resetForm('roleFrom')"
                                class="px-4 py-2 text-sm text-gray-600 bg-gray-200 hover:bg-gray-300 rounded transition">
                                <i class="fas fa-redo mr-1"></i> Reset
                            </button>

                            <button type="submit"
                                class="px-4 py-2 text-sm text-white bg-indigo-600 hover:bg-indigo-700 rounded transition"
                                id="submitBtnDisable">
                                @isset($role)
                                    <i class="fas fa-arrow-circle-up mr-1"></i> Update
                                @else
                                    <i class="fas fa-plus-circle mr-1"></i> Create
                                @endisset
                            </button>
                        </div>

                    </div>




                </section>
        </form>
    </main>
@endsection

@push('js')
    <script type="text/javascript">
        // Select all checkboxes
        document.getElementById('select-all').addEventListener('click', function(e) {
            const checkboxes = document.querySelectorAll('input[type="checkbox"]');
            checkboxes.forEach(cb => cb.checked = e.target.checked);
        });
    </script>
    <script>
        document.querySelector('select[name="role_id"]').addEventListener('change', function() {
            const roleId = this.value;
            const checkboxes = document.querySelectorAll('input[name="permissions[]"]');

            if (roleId && !isNaN(roleId)) {
                fetch(`/admin/roles/${roleId}/permissions`)
                    .then(res => res.json())
                    .then(permissionIds => {
                        // Uncheck all first
                        checkboxes.forEach(cb => cb.checked = false);

                        // Then check only assigned ones
                        permissionIds.forEach(id => {
                            const cb = document.querySelector(`#permission-${id}`);
                            if (cb) cb.checked = true;
                        });
                    });
            }
        });
    </script>
@endpush
