@extends('backend.master')

@section('content')
    <main class="flex-1 overflow-auto">
        <div class="max-w-7xl mx-auto px-6 py-10">

            <!-- Role Selection Dropdown -->
            <section class="bg-white rounded-xl shadow p-6">
                <h2 class="text-xl font-semibold text-gray-800 mb-4">🎯 Select Role to Configure</h2>
                <div class="shrink-0 text-base text-gray-500 select-none sm:text-sm/6">Role name</div>
                <input type="text" name="price" id="price"
                    class="block min-w-0 grow py-1.5 pr-3 pl-1 text-base text-gray-900 placeholder:text-gray-400 focus:outline-none sm:text-sm/6"
                    placeholder="0.00">
                <div class="shrink-0 text-base text-gray-500 select-none sm:text-sm/6">Descriptions</div>

                <input type="text" name="price" id="price"
                    class="block min-w-0 grow py-1.5 pr-3 pl-1 text-base text-gray-900 placeholder:text-gray-400 focus:outline-none sm:text-sm/6"
                    placeholder="0.00">
            </section>

            <!-- Permissions Table -->
            <section class="bg-white rounded-xl shadow p-6">
                <h2 class="text-xl font-semibold text-gray-800 mb-4">🧩 Action Permissions</h2>
                <div class="overflow-auto">
                    <table class="w-full table-auto text-left border border-gray-200">
                        <thead class="bg-gray-100 text-sm text-gray-600">
                            <tr>
                                <th class="px-4 py-2 border">Feature</th>
                                <th class="px-4 py-2 border text-center">View</th>
                                <th class="px-4 py-2 border text-center">Edit</th>
                                <th class="px-4 py-2 border text-center">Delete</th>
                                <th class="px-4 py-2 border text-center">Export</th>
                            </tr>
                        </thead>
                        <tbody class="text-sm text-gray-700">
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-2 border">Users</td>
                                <td class="text-center border"><input type="checkbox" checked></td>
                                <td class="text-center border"><input type="checkbox"></td>
                                <td class="text-center border"><input type="checkbox"></td>
                                <td class="text-center border"><input type="checkbox" checked></td>
                            </tr>
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-2 border">Credit Score Data</td>
                                <td class="text-center border"><input type="checkbox" checked></td>
                                <td class="text-center border"><input type="checkbox"></td>
                                <td class="text-center border"><input type="checkbox"></td>
                                <td class="text-center border"><input type="checkbox"></td>
                            </tr>
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-2 border">Subscription Plans</td>
                                <td class="text-center border"><input type="checkbox" checked></td>
                                <td class="text-center border"><input type="checkbox" checked></td>
                                <td class="text-center border"><input type="checkbox"></td>
                                <td class="text-center border"><input type="checkbox"></td>
                            </tr>
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-2 border">Messages</td>
                                <td class="text-center border"><input type="checkbox" checked></td>
                                <td class="text-center border"><input type="checkbox" checked></td>
                                <td class="text-center border"><input type="checkbox"></td>
                                <td class="text-center border"><input type="checkbox"></td>
                            </tr>
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-2 border">Settings Access</td>
                                <td class="text-center border"><input type="checkbox" checked></td>
                                <td class="text-center border"><input type="checkbox" checked></td>
                                <td class="text-center border"><input type="checkbox"></td>
                                <td class="text-center border"><input type="checkbox" checked></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="mt-6 text-right">
                    <button class="bg-indigo-600 text-white px-5 py-2 rounded hover:bg-indigo-700 text-sm shadow">💾 Save
                        Permissions</button>
                </div>
            </section>

        </div>
    </main>
@endsection
