@extends('backend.master')

@section('content')
    <main class="flex-1 overflow-auto">
        <div class="max-w-7xl mx-auto px-6 py-10">

            <!-- Header -->
            <section>
                <h1 class="text-3xl font-bold text-gray-800">🧑‍💼 Admin Roles</h1>
                <p class="text-sm text-gray-600 mt-1">Assign and manage roles with specific access permissions for each
                    admin.</p>
            </section>

            <!-- Roles Table -->
            <section class="bg-white p-6 rounded-xl shadow">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-xl font-semibold text-gray-800">Current Roles</h2>
                    <button id="openModalBtn" class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 text-sm">➕
                        Add New
                        Role</button>
                    {{-- <button class="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700 text-sm"><a
                            href="{{ route('admin.roles.create') }}">➕
                            Add New
                            Role </a></button> --}}
                </div>

                <table class="w-full text-sm text-left">
                    <thead class="text-gray-500 border-b">
                        <tr>
                            <th class="py-2">Role Name</th>
                            <th class="py-2">Description</th>
                            <th class="py-2">Permissions</th>
                            <th class="py-2">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        @foreach ($roles as $key => $role)
                            <tr>
                                <td class="py-2 font-medium text-gray-800">{{ $role->name }}</td>
                                <td class="py-2 text-gray-600">{{ $role->description }}</td>
                                <td class="py-2 text-gray-600">

                                    @if ($role->permissions->count() > 0)
                                        <span class="badge text-bg-success">{{ $role->permissions->count() }}</span>
                                        {{-- <span class="badge badge-info">{{ $role->permissions->name }}</span> --}}
                                    @else
                                        <span class="badge text-bg-danger">No permission found :(</span>
                                    @endif
                                </td>
                                <td class="py-2">
                                    <button class="text-sm text-indigo-600 hover:underline mr-2"
                                        onclick="openEditModal({
            id: {{ $role->id }},
            name: '{{ $role->name }}',
            description: '{{ addslashes($role->description) }}'
        })">Edit</button>
                                    <button class="text-sm text-indigo-600 hover:underline mr-2"><a href="{{ route('admin.roles.edit',$role->id) }}">Edit Permission </a></button>
                                    @if ($role->deletable == true)
                                        <form action="{{ route('admin.roles.destroy', $role->id) }}" method="POST"
                                            style="display: inline;">
                                            @csrf()
                                            @method('DELETE')
                                            <button type="submit" onclick="return confirm('Are your sure?')"
                                                class="text-sm text-red-600 hover:underline"> Delete </button>
                                        </form>
                                    @endif

                                </td>
                            </tr>
                        @endforeach

                    </tbody>
                </table>
            </section>
        </div>


        <!-- Modal Overlay -->
        <div id="addRoleModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50 px-4">
            <div class="bg-white rounded-lg shadow-lg max-w-md w-full p-6 transform transition-all mx-auto">
                <h2 class="text-xl font-semibold text-gray-800 mb-4">Add New Role</h2>

                <!-- Form Fields -->
                <form action="{{ route('admin.roles.store') }}" method="POST">
                    @csrf
                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700 mb-1" for="roleName">Role Name</label>
                        <input type="text" name="name" placeholder="e.g., Moderator"
                            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>

                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700 mb-1"
                            for="roleDescription">Description</label>

                        <textarea required name="description"
                            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"></textarea>
                    </div>



                    <!-- Buttons -->
                    <div class="flex justify-end space-x-3">
                        <button type="button" id="cancelModalBtn"
                            class="px-4 py-2 text-sm text-gray-600 hover:bg-gray-100 rounded">Cancel</button>
                        <button type="submit"
                            class="px-4 py-2 text-sm bg-indigo-600 text-white hover:bg-indigo-700 rounded">Save</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Edit Modal Overlay -->
        <div id="editRoleModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50 px-4">
            <div class="bg-white rounded-lg shadow-lg max-w-md w-full p-6 transform transition-all mx-auto">
                <h2 class="text-xl font-semibold text-gray-800 mb-4">Edit Role</h2>

                <!-- Form Fields -->
                <form id="editRoleForm" method="POST">
                    @csrf
                    @method('PUT')

                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700 mb-1" for="editRoleName">Role Name</label>
                        <input type="text" name="name" id="editRoleName"
                            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    </div>

                    <div class="mb-4">
                        <label class="block text-sm font-medium text-gray-700 mb-1"
                            for="editRoleDescription">Description</label>
                        <textarea name="description" id="editRoleDescription"
                            class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"></textarea>
                    </div>

                    <!-- Buttons -->
                    <div class="flex justify-end space-x-3">
                        <button type="button" id="cancelEditModalBtn"
                            class="px-4 py-2 text-sm text-gray-600 hover:bg-gray-100 rounded">Cancel</button>
                        <button type="submit"
                            class="px-4 py-2 text-sm bg-indigo-600 text-white hover:bg-indigo-700 rounded">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </main>
    <!-- Modal Overlay -->
@endsection


@push('js')
    {{-- <script>
        const modal = document.getElementById('addRoleModal');
        const openModalBtn = document.getElementById('openModalBtn');
        const closeModalBtn = document.getElementById('cancelModalBtn');

        openModalBtn.addEventListener('click', () => {
            modal.classList.remove('hidden');
        });

        closeModalBtn.addEventListener('click', () => {
            modal.classList.add('hidden');
        });

        // Optional: Close modal when clicking outside of it
        window.addEventListener('click', (e) => {
            if (e.target === modal) {
                modal.classList.add('hidden');
            }
        });
    </script> --}}

    <script>
        const addModal = document.getElementById('addRoleModal');
        const editModal = document.getElementById('editRoleModal');

        const openModalBtn = document.getElementById('openModalBtn');
        const cancelAddModalBtn = document.getElementById('cancelModalBtn');
        const cancelEditModalBtn = document.getElementById('cancelEditModalBtn');

        function openEditModal(data) {
            const form = document.getElementById('editRoleForm');
            const url = "{{ route('admin.roles.update', ':id') }}".replace(':id', data.id);
            form.action = url;

            document.getElementById('editRoleName').value = data.name;
            document.getElementById('editRoleDescription').value = data.description;

            editModal.classList.remove('hidden');
        }

        // Open Add Modal
        openModalBtn && openModalBtn.addEventListener('click', () => {
            addModal.classList.remove('hidden');
        });

        // Close Add Modal
        cancelAddModalBtn.addEventListener('click', () => {
            addModal.classList.add('hidden');
        });

        // Close Edit Modal
        cancelEditModalBtn.addEventListener('click', () => {
            editModal.classList.add('hidden');
        });

        // Optional: Close modals by clicking outside
        window.addEventListener('click', (e) => {
            if (e.target === addModal) addModal.classList.add('hidden');
            if (e.target === editModal) editModal.classList.add('hidden');
        });
    </script>
@endpush
