<!-- Twindo Admin - Manage Profile Settings Page -->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Profile | Twindo Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-50 min-h-screen">

    <header class="bg-white shadow fixed top-0 inset-x-0 z-10">
        <div class="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
            <h1 class="text-xl font-bold text-indigo-700">⚙️ Admin Settings</h1>
            <span class="text-gray-600">Welcome, {{ Auth::user()->name }}</span>
        </div>
    </header>

    @yield('content')


    @stack('js')


    @auth
        <script>
            let inactivityTimeout;

            function resetTimer() {
                clearTimeout(inactivityTimeout);
                inactivityTimeout = setTimeout(logout, 15 * 60 * 1000); // 15 minutes in milliseconds
            }

            function logout() {
                fetch('{{ route('admin.sessionlogout') }}', {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}',
                        'Accept': 'application/json',
                    },
                }).then(response => {
                    if (response.ok) {
                        window.location.href = '/login';
                    }
                });
            }

            // Listen for user activity
            window.onload = resetTimer;
            ['mousemove', 'mousedown', 'keypress', 'scroll', 'touchstart'].forEach(event => {
                document.addEventListener(event, resetTimer);
            });
        </script>
    @endauth
</body>

</html>
