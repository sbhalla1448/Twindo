@extends('backend.master')

@section('content')
    <!-- Main Content -->
    <main class="flex-1 overflow-auto">
        <div class="max-w-3xl mx-auto px-6 py-10">

            <!-- Breadcrumb & Hero -->
            <section class="mb-8">
                <nav class="text-sm text-gray-500">Home / Admin / Documents / Archive</nav>
                <h2 class="text-3xl font-bold text-yellow-600">Archive Document</h2>
                <p class="text-gray-600 mt-2">You are about to move the following document to Archive:</p>
            </section>

            <!-- Document Details Card -->
            <section class="bg-white rounded-xl shadow p-6 mb-6">
                <dl class="divide-y divide-gray-200">
                    <div class="py-4 flex justify-between text-sm">
                        <dt class="text-gray-600">Document Name</dt>
                        <dd class="font-medium text-gray-900">{{ $doc->document_name }}</dd>
                    </div>
                    <div class="py-4 flex justify-between text-sm">
                        <dt class="text-gray-600">Uploaded By</dt>
                        <dd class="font-medium text-gray-900">{{ $doc->user->name }}</dd>
                    </div>
                    <div class="py-4 flex justify-between text-sm">
                        <dt class="text-gray-600">Uploaded On</dt>
                        <dd class="font-medium text-gray-900">1{{ $doc->created_at->format('d M Y') }}</dd>
                    </div>
                    <div class="py-4 flex justify-between text-sm">
                        <dt class="text-gray-600">Document Type</dt>
                        <dd class="font-medium text-gray-900">{{ $doc->document_type }}</dd>
                    </div>
                </dl>
            </section>

            <!-- Archive Action -->
            <section class="flex justify-end">
                <form onclick="return confirm('Are your sure?')"
                    action="{{ route('admin.documents.document.archived', \Illuminate\Support\Facades\Crypt::encryptString($doc->id)) }}">
                    <input type="hidden" name="archived" value="yes">
                    <button type="submit"
                        class="bg-yellow-500 hover:bg-yellow-600 text-white px-6 py-3 rounded-xl shadow">📦 Archive
                        Document</button>
                </form>
            </section>

        </div>
    @endsection
