@extends('backend.master')

@section('content')

<livewire:document.document-index />
@endsection
