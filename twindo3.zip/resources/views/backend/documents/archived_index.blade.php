@extends('backend.master')

@section('content')
    <!-- Main Content -->
    <main class="flex-1 overflow-auto">
        <div class="max-w-7xl mx-auto px-6 py-10">

            <!-- Breadcrumb & Hero -->
            <section class="mb-8">
                <nav class="text-sm text-gray-500">Home / Admin / Documents / Archived</nav>
                <h2 class="text-3xl font-bold text-gray-800">Archived Documents</h2>
                <p class="text-gray-600 mt-2">Manage documents that have been archived. You can restore them or permanently
                    delete them.</p>
            </section>

            <!-- Archived Documents Table -->
            <section class="bg-white rounded-xl shadow p-6">
                <table class="w-full text-left">
                    <thead>
                        <tr class="text-sm text-gray-400">
                            <th class="py-2">Document Name</th>
                            <th class="py-2">Uploaded By</th>
                            <th class="py-2">Uploaded On</th>
                            <th class="py-2">Type</th>
                            <th class="py-2 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>

                        @foreach ($documents as $doc)
                            <tr class="border-t hover:bg-gray-50">

                                <td class="py-3">{{ $doc?->document_name }}</td>

                                <td class="py-3">{{ $doc->user->name }}</td>
                                <td class="py-3">{{ $doc->created_at->format('d M Y') }}</td>
                                <td class="py-3">{{ $doc->document_type }}</td>


                                <td class="py-3 flex justify-end space-x-2">
                                    <button
                                        class="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-md text-sm"><a
                                            href="{{ route('admin.documents.document.restore', \Illuminate\Support\Facades\Crypt::encryptString($doc->id)) }}">Restore
                                        </a></button>
                                    <button class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-md text-sm">
                                        <a
                                            href="{{ route('admin.documents.document.delete', \Illuminate\Support\Facades\Crypt::encryptString($doc->id)) }}">Delete</a>
                                    </button>
                                </td>
                            </tr>
                        @endforeach
                        <!-- Additional rows as needed -->
                    </tbody>
                </table>
            </section>

        </div>
    </main>
@endsection
