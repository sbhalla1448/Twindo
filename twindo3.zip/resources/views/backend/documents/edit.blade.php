@extends('backend.master')

@push('css')
@endpush

@section('content')
    <!-- Main Content -->
    <main class="flex-1 overflow-auto">
        <div class="max-w-6xl mx-auto px-6 py-10">

            <!-- Breadcrumb & Hero -->
            <section class="mb-6">
                <nav class="text-sm text-gray-500">Home / Admin / Documents / Upload</nav>
                <h2 class="text-2xl md:text-3xl font-bold text-gray-800 mt-2">Edit Document</h2>
            </section>

            <!-- Upload Document Form -->
            <section class="bg-white rounded-xl shadow p-6 md:p-8">
                <form class="space-y-6 md:space-y-8" action="{{ route('admin.documents.update', $doc->id) }}" method="POST"
                    enctype="multipart/form-data" onsubmit="simulateUpload(event)">
                    @csrf
                    @method('PUT')

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Selected Customer</label>
                        <select name="user_id"
                            class="mt-1 block w-full bg-gray-100 text-gray-800 px-4 py-2 rounded-md border border-gray-300">
                            <option value="">Select Customer</option>
                            @foreach ($users as $user)
                                <option value="{{ $user->id }}" @if ($doc->user_id == $user->id) selected @endif>
                                    {{ $user->name }}</option>
                            @endforeach
                        </select>
                        @error('user_id')
                            <p>{{ $message }}</p>
                        @enderror
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Document Type</label>
                        <select name="document_type"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm px-4 py-2 focus:ring-indigo-500 focus:border-indigo-500">
                            <option value="">Select Document Type</option>
                            @foreach (\App\Enums\DocumentType::options() as $status)
                                <option value="{{ $status->value }}" @if ($doc->document_type == $status->value) selected @endif>
                                    {{ $status->label() }}
                                </option>
                            @endforeach
                        </select>
                        @error('document_type')
                            <p>{{ $message }}</p>
                        @enderror
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Document Name</label>
                        <input type="text" name="document_name" value="{{ $doc->document_name }}"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm px-4 py-2 focus:ring-indigo-500 focus:border-indigo-500">
                        @error('document_name')
                            <p>{{ $message }}</p>
                        @enderror
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Notes (optional)</label>
                        <textarea name="remarks"
                            class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm px-4 py-2 focus:ring-indigo-500 focus:border-indigo-500"
                            rows="3" placeholder="Internal notes (optional)">{{ $doc->remarks }}</textarea>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Upload Files</label>
                        <div
                            class="mt-2 flex flex-col items-center justify-center px-6 pt-5 pb-6 border-2 border-dashed border-gray-300 rounded-md text-center">
                            <svg class="mx-auto h-10 w-10 text-gray-400" fill="none" stroke="currentColor"
                                viewBox="0 0 48 48">
                                <path d="M14 22l10-10 10 10m-10-10v20M5 38h38" stroke-width="2" stroke-linecap="round"
                                    stroke-linejoin="round" />
                            </svg>
                            <label class="mt-2 text-sm text-indigo-600 font-medium cursor-pointer hover:underline">
                                <span>Upload files</span>
                                <input name="file_names[]" type="file" class="sr-only" multiple
                                    onchange="updateFileName(event)">
                            </label>
                            <p class="text-xs text-gray-500 mt-1">PNG, JPG, PDF up to 10MB each</p>
                            <p id="fileNameDisplay" class="text-sm text-gray-700 mt-2"></p>
                        </div>
                        @error('file_names')
                            <p>{{ $message }}</p>
                        @enderror
                    </div>



                    <div id="uploadProgressBar" class="hidden w-full bg-gray-200 rounded-full h-4 mt-4">
                        <div class="bg-indigo-600 h-4 rounded-full transition-all duration-300" style="width: 0%"></div>
                    </div>

                    <div id="cancelUploadButton" class="hidden flex justify-end mt-2">
                        <button type="button" onclick="cancelUpload()"
                            class="text-red-600 hover:text-red-800 font-semibold text-sm">Cancel Upload</button>
                    </div>
                    <!-- Existing Files -->
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Existing Files</label>
                        <div class="mt-2 space-y-3">
                            @if ($doc->files && $doc->files->count() > 0)
                                @foreach ($doc->files as $file)
                                    <div class="flex items-center justify-between bg-gray-50 p-3 rounded-md border">


                                        @if ($file->file_type == ['png', 'jpg', 'jped', 'gif', 'webp'])
                                            <!-- Image Preview -->
                                            <img src="{{ asset('storage/uploads/' . $file->file_name) }}"
                                                alt="Document Image" class="h-16 w-auto rounded object-cover cursor-pointer"
                                                onclick="window.open('{{ asset('storage/uploads/' . $file->file_name) }}')">
                                        @else
                                            <!-- File Link -->
                                            <a href="{{ asset('storage/uploads/' . $file->file_name) }}" target="_blank"
                                                class="text-indigo-600 hover:underline flex items-center">
                                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none"
                                                    viewBox="0 0 24 24" stroke="currentColor">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                                        d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.586a6 6 0 108.486 8.486L20.5 13" />
                                                </svg>
                                                {{ basename($file->file_name) }}
                                            </a>
                                        @endif

                                        <!-- Optional Delete Button -->
                                        <a href="{{ route('admin.documents.file.delete', $file->id) }}"
                                            class="text-red-500 text-sm hover:underline"> Remove</a>
                                        {{-- <button type="button" class="text-red-500 text-sm hover:underline"
                                            onclick="confirm('Are you sure?') ? document.getElementById('delete-form-{{ $file->id }}').submit() : false;">
                                            Remove
                                        </button>
                                        <form id="delete-form-{{ $file->id }}"
                                            action="{{ route('admin.documents.file.delete', $file->id) }}" method="POST"
                                            style="display: none;">
                                            @csrf
                                            @method('DELETE')
                                        </form> --}}

                                    </div>
                                @endforeach
                            @else
                                <p class="text-sm text-gray-500 italic">No existing files found.</p>
                            @endif
                        </div>
                    </div>

                    <div class="flex justify-end">
                        <button type="submit"
                            class="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700 transition-all">Upload
                            Document</button>
                    </div>

                </form>
            </section>

        </div>
    </main>
@endsection


@push('js')
    <script>
        let uploadInterval;

        function showToast(message = '✅ Document uploaded successfully!') {
            const toast = document.getElementById('successToast');
            toast.innerText = message;
            toast.classList.remove('hidden');
            setTimeout(() => toast.classList.add('hidden'), 3000);
        }

        function updateFileName(event) {
            const files = Array.from(event.target.files).map(f => f.name).join(', ');
            const fileLabel = document.getElementById('fileNameDisplay');
            fileLabel.innerText = files ? `Selected Files: ${files}` : '';
        }

        function simulateUpload(event) {
            event.preventDefault(); // Prevent immediate form submission

            const progressBar = document.getElementById('uploadProgressBar');
            const cancelButton = document.getElementById('cancelUploadButton');
            const form = event.target;

            progressBar.classList.remove('hidden');
            cancelButton.classList.remove('hidden');

            let width = 1;
            uploadInterval = setInterval(() => {
                if (width >= 100) {
                    clearInterval(uploadInterval);
                    progressBar.classList.add('hidden');
                    cancelButton.classList.add('hidden');
                    progressBar.firstElementChild.style.width = '0%';

                    // Now submit the form after simulation completes
                    form.submit();
                } else {
                    width++;
                    progressBar.firstElementChild.style.width = width + '%';
                }
            }, 20); // Simulate faster upload
        }

        function cancelUpload() {
            clearInterval(uploadInterval);
            const progressBar = document.getElementById('uploadProgressBar');
            const cancelButton = document.getElementById('cancelUploadButton');
            progressBar.classList.add('hidden');
            cancelButton.classList.add('hidden');
            progressBar.firstElementChild.style.width = '0%';
        }
    </script>
@endpush
