<aside class="w-56 bg-white shadow-sm min-h-screen">
    <nav class="mt-8 px-4 space-y-2">
        <a href="{{ route('admin.dashboard') }}"
            class="block py-2 px-3 {{ request()->is(['admin/dashboard*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">🏠
            Dashboard</a>
            @if (user_can_view('Credit Score History'))
            <a href="{{ route('admin.credit.history') }}" class="block py-2 px-3 {{ request()->is(['admin/credit/history*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">📊 Credit Score History</a>
            @endif
            @if (user_can_view('Report Analysis'))
            <a href="{{ route('admin.tempateReports.index') }}" class="block py-2 px-3 {{ request()->is(['admin/tempateReports*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">📊 Report Analysis</a>
            @endif
        @if (user_can_view('Users'))
            <a href="{{ route('admin.users.index') }}"
                class="block py-2 px-3 {{ request()->is(['admin/users*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">👤
                Users</a>
        @endif
        @if (user_can_view('Subscription Management'))
            <a href="{{ route('admin.subscriptions.index') }}"
                class="block py-2 px-3 {{ request()->is(['admin/sdfs*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">💳
                Subscriptions</a>
        @endif
        {{-- @if (user_can_view('Payment Methods'))
            <a href="#"
                class="block py-2 px-3 {{ request()->is(['admin/sfsdfsdff*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">💳
                Payment Methods</a>
        @endif --}}
        @if (user_can_view('Coupon Management'))
            <a href="{{ route('admin.coupons.index') }}"
                class="block py-2 px-3 {{ request()->is(['admin/coupons*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">🛍️
                Coupon</a>
        @endif
        @if (user_can_view('Product Management'))
            <a href="{{ route('admin.products.index') }}"
                class="block py-2 px-3 {{ request()->is(['admin/products*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">🛍️
                Products</a>
        @endif
        @if (user_can_view('Documents'))
            <a href="{{ route('admin.documents.index') }}"
                class="block py-2 px-3 {{ request()->is(['admin/documents*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">📄
                Documents</a>
        @endif
        @if (user_can_view('Messages & Actions'))
            <a href="{{ route('admin.messageActions.index') }}"
                class="block py-2 px-3 {{ request()->is(['admin/sdfsdfsadf*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">📩
                Messages & Actions</a>
        @endif
        @if (user_can_view('Tools & Resources'))
            <a href="{{ route('admin.toolResources.index') }}"
                class="block py-2 px-3 {{ request()->is(['admin/toolResources*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">🛠️
                Tools & Resources</a>
        @endif
        {{-- @if (user_can_view('Payment Methods')) --}}
        <a href="{{ route('admin.settings.index') }}"
            class="block py-2 px-3 {{ request()->is(['admin/settings*', 'admin/roles*', 'admin/role/permission/control']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">⚙️
            Settings</a>
        {{-- @endif --}}
        @if (user_can_view('System Logs'))
            <a href="{{ route('admin.system.log') }}"
                class="block py-2 px-3 {{ request()->is(['admin/system_log*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100' }}">📋
                System
                Logs</a>
        @endif

        <a href="{{ route('logout') }}"
            onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();"
            class="block py-2 px-3 rounded-md hover:bg-gray-100">🔓 Logout</a>

        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
            @csrf
        </form>
    </nav>
</aside>
