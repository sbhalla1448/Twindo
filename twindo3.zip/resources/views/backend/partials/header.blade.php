 <!-- Top Navigation -->
 <header class="bg-white shadow fixed top-0 inset-x-0 z-10">
     <div class="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
         <h1 class="text-xl font-bold text-indigo-700">Twindo Admin</h1>
         <span class="text-gray-600">{{ Auth::user()->name }}</span>
     </div>
 </header>
