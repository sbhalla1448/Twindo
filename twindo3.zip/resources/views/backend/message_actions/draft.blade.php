@extends('backend.master')

@section('content')
    {{-- <livewire:system-log :systemLogs="$systemLogs"/> --}}

    <!-- Main Content -->
    <main class="flex-1 overflow-auto">
        <div class="max-w-7xl mx-auto px-6 py-10">

            <!-- Breadcrumb & Hero -->
            <section class="mb-8">
                <nav class="text-sm text-gray-500">Home / Admin / Messages & Actions / Drafts</nav>
                <h2 class="text-3xl font-bold text-gray-800">Manage Drafts</h2>
                <p class="text-gray-600 mt-2">View, edit, or delete saved message drafts.</p>
            </section>

            <!-- Drafts Table -->
            <section class="bg-white rounded-xl shadow p-6">
                <table class="w-full text-left">
                    <thead>
                        <tr class="text-sm text-gray-400">
                            <th class="py-2">Recipient</th>
                            <th class="py-2">Subject</th>
                            <th class="py-2">Saved On</th>
                            <th class="py-2 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr class="border-t hover:bg-gray-50">
                            <td class="py-3">Jane Doe</td>
                            <td class="py-3">Update Subscription Plan</td>
                            <td class="py-3">15 Apr 2025</td>
                            <td class="py-3 flex justify-end space-x-2">
                                <button
                                    class="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-md text-sm">Edit</button>
                                <button
                                    class="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-md text-sm">Delete</button>
                            </td>
                        </tr>
                        <!-- More rows here -->
                    </tbody>
                </table>

                <!-- Pagination -->
                <div class="flex justify-between items-center mt-6">
                    <span class="text-sm text-gray-600">Showing 1-10 of 50 drafts</span>
                    <div class="flex space-x-2">
                        <button class="px-3 py-1 border rounded-md hover:bg-gray-100">Previous</button>
                        <button class="px-3 py-1 border rounded-md hover:bg-gray-100">Next</button>
                    </div>
                </div>

            </section>

        </div>
    </main>
@endsection
