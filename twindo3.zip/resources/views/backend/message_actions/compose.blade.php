@extends('backend.master')

@push('css')

@endpush

@section('content')
    {{-- <livewire:system-log :systemLogs="$systemLogs"/> --}}

    <!-- Main Content -->
    <livewire:message.message-compose />
@endsection
