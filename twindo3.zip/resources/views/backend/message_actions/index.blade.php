@extends('backend.master')

@section('content')
    {{-- <livewire:system-log :systemLogs="$systemLogs"/> --}}

    <!-- Main Content -->

    <livewire:message.message-index />
@endsection
