@extends('backend.master')

@section('content')
{{-- <livewire:product.product-add /> --}}

<div class="max-w-6xl mx-auto px-6 py-12">
    <h1 class="text-3xl font-bold mb-8 text-indigo-700">➕ Add New Product</h1>
    <div class="grid md:grid-cols-2 gap-10">
      <form action="{{ route('admin.products.store') }}" method="POST" class="space-y-6" oninput="updatePreview()"  enctype="multipart/form-data">
        @csrf
        <!-- Image Upload -->
        <div>
          <label class="block font-medium text-sm text-gray-700 mb-1">Product Image</label>
          <input name="image" type="file" accept="image/*" onchange="showImagePreview(event)" class="w-full border border-gray-300 rounded p-2">
          @error('image') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
        </div>

        <!-- Title -->
        <div>
          <label class="block font-medium text-sm text-gray-700 mb-1">Product Title</label>
          <input name="title" id="title" type="text" class="w-full border border-gray-300 rounded p-2" placeholder="Enter product name">
          @error('title') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
        </div>

        <!-- Pricing -->
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block font-medium text-sm text-gray-700 mb-1">Price per Month (£)</label>
            <input name="price_per_month" id="priceMonth" type="number" step="0.01" class="w-full border border-gray-300 rounded p-2">
            @error('price_per_month') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
        </div>
          <div>
            <label class="block font-medium text-sm text-gray-700 mb-1">Annual Price (£)</label>
            <input name="price_annual" id="priceAnnual" type="number" step="0.01" class="w-full border border-gray-300 rounded p-2">
            @error('price_annual') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
        </div>
        </div>

        <!-- Category -->
        <div>
          <label class="block font-medium text-sm text-gray-700 mb-1">Category</label>
          <select name="category_id"  id="category" class="w-full border border-gray-300 rounded p-2">
            @foreach ($categories as $cat)

            <option value="{{ $cat->id }}" > {{$cat->name}}</option>
            @endforeach

          </select>
          @error('category_id') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
        </div>

        <!-- Product Status -->
        <div>
          <label class="block font-medium text-sm text-gray-700 mb-1">Product Status</label>
          <select name="product_status" id="status" class="w-full border border-gray-300 rounded p-2">

            @foreach (\App\Enums\ProductStatus::options() as $status)
        <option value="{{ $status->value }}" >
            {{ $status->label() }}
        </option>
    @endforeach
            {{-- <option value="Featured">Featured</option>
            <option value="Online Exclusive">Online Exclusive</option>
            <option value="Popular">Popular</option>
            <option value="Twindo Recommended">Twindo Recommended</option>
            <option value="Top Rated">Top Rated</option>
            <option value="Trusted Choice">Trusted Choice</option> --}}
          </select>
          @error('product_status') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
        </div>

        <!-- Tags -->
        <div>
          <label class="block font-medium text-sm text-gray-700 mb-1">Product Tags (comma separated)</label>
          <input name="tags" id="tags" type="text" class="w-full border border-gray-300 rounded p-2" placeholder="tag1, tag2, tag3">
          @error('tags') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
        </div>

        <!-- Rating -->
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block font-medium text-sm text-gray-700 mb-1">Rating (out of 5)</label>
            <input name="rating" id="rating" type="number" step="0.1" max="5" min="0" class="w-full border border-gray-300 rounded p-2">
            @error('rating') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
        </div>
          <div>
            <label class="block font-medium text-sm text-gray-700 mb-1">Number of Ratings</label>
            <input name="rating_count" id="ratingCount" type="number" class="w-full border border-gray-300 rounded p-2">
          </div>
          @error('rating_count') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
        </div>

        <!-- Website and Phone -->
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block font-medium text-sm text-gray-700 mb-1">Website Link</label>
            <input name="website_link" id="link" type="url" class="w-full border border-gray-300 rounded p-2" placeholder="https://example.com">
            @error('website_link') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
        </div>
          <div>
            <label class="block font-medium text-sm text-gray-700 mb-1">Phone Number</label>
            <input name="phone" id="phone" type="text" class="w-full border border-gray-300 rounded p-2" placeholder="+44 123 456 7890">
          </div>
          @error('phone') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
        </div>

        <!-- Description -->
        <div>
          <label class="block font-medium text-sm text-gray-700 mb-1">Product Description</label>
          <textarea name="description" id="description" rows="5" maxlength="300" oninput="document.getElementById('char-count').textContent = 300 - this.value.length" class="w-full border border-gray-300 rounded p-2"></textarea>
          <p class="text-xs text-gray-500 mt-1">Characters remaining: <span id="char-count">300</span></p>
          @error('description') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
        </div>

        <!-- SEO Notes -->
        <div>
          <label class="block font-medium text-sm text-gray-700 mb-1">SEO Notes or Internal Description</label>
          <textarea name="seo_notes" id="seoNotes" rows="3" class="w-full border border-gray-300 rounded p-2"></textarea>
          @error('seo_notes') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
        </div>
        <input type="hidden" name="submit_type" id="submit_type">
        <!-- Actions -->
        <div class="flex justify-between items-center">
            <button type="button" onclick="openDuplicateTab()" class="text-sm text-indigo-600 hover:underline">
                🔁 Duplicate from Existing
            </button>
          <div class="space-x-4">
            <button type="submit" onclick="setSubmitType('0')" class="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded">💾 Save as Draft</button>
            <button type="submit" onclick="setSubmitType('1')" class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded">🚀 Create Product</button>
          </div>
        </div>
      </form>

      <!-- Live Preview -->
      <div class="bg-white rounded-xl shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">🔍 Live Product Preview</h2>
        <img id="preview-image" class="h-32 object-cover rounded mb-4" src="#" alt="Product Image Preview" style="display:none;">
        <p class="font-semibold text-lg text-gray-700 mb-1" id="preview-title">Product Title</p>
        <p class="text-sm text-gray-500 mb-2" id="preview-category">Category</p>
        <p class="text-sm text-gray-600" id="preview-price">£0.00 / month</p>
        <p class="text-sm text-gray-600 mb-2" id="preview-annual">£0.00 annually</p>
        <p class="text-sm text-gray-600 mb-1" id="preview-status">Status</p>
        <p class="text-sm text-yellow-600" id="preview-rating">0.0 ⭐</p>
        <p class="text-xs text-gray-500 mb-2" id="preview-rating-count">(0 reviews)</p>
        <p class="text-sm text-blue-600 mb-1" id="preview-link">https://</p>
        <p class="text-sm text-gray-700 mb-2" id="preview-phone">Phone</p>
        <p class="text-sm text-gray-600 mb-2" id="preview-description">Product description...</p>
        <p class="text-xs text-indigo-500 mb-2" id="preview-tags">#tags</p>
        <p class="text-xs text-gray-400" id="preview-seo">SEO Notes...</p>
      </div>
    </div>
  </div>


    @push('js')
    <script>
        function updatePreview() {
            const categorySelect = document.getElementById('category');
            const selectedCategoryName = categorySelect.options[categorySelect.selectedIndex].text;

          document.getElementById('preview-title').textContent = document.getElementById('title').value;
          document.getElementById('preview-price').textContent = '£' + document.getElementById('priceMonth').value + ' / month';
          document.getElementById('preview-annual').textContent = '£' + document.getElementById('priceAnnual').value + ' annually';
        //   document.getElementById('preview-category').textContent = document.getElementById('category').value;
        document.getElementById('preview-category').textContent = selectedCategoryName;
          document.getElementById('preview-status').textContent = document.getElementById('status').value;
          document.getElementById('preview-rating').textContent = document.getElementById('rating').value + ' ⭐';
          document.getElementById('preview-rating-count').textContent = '(' + document.getElementById('ratingCount').value + ' reviews)';
          document.getElementById('preview-link').textContent = document.getElementById('link').value;
          document.getElementById('preview-phone').textContent = document.getElementById('phone').value;
          document.getElementById('preview-description').textContent = document.getElementById('description').value;
          document.getElementById('preview-tags').textContent = document.getElementById('tags').value;
          document.getElementById('preview-seo').textContent = document.getElementById('seoNotes').value;
        }

        function showImagePreview(event) {
          const file = event.target.files[0];
          const preview = document.getElementById('preview-image');
          if (file) {
            preview.src = URL.createObjectURL(file);
            preview.style.display = 'block';
          } else {
            preview.style.display = 'none';
          }
        }
      </script>
<script>
    function setSubmitType(type) {
        document.getElementById('submit_type').value = type;
    }
</script>
<script>
    function openDuplicateTab() {
        const params = new URLSearchParams({
            title: document.getElementById('title').value,
            price_per_month: document.getElementById('priceMonth').value,
            price_annual: document.getElementById('priceAnnual').value,
            category_id: document.getElementById('category').value,
            product_status: document.getElementById('status').value,
            tags: document.getElementById('tags').value,
            rating: document.getElementById('rating').value,
            rating_count: document.getElementById('ratingCount').value,
            website_link: document.getElementById('link').value,
            phone: document.getElementById('phone').value,
            description: document.getElementById('description').value,
            seo_notes: document.getElementById('seoNotes').value,
        });

        const duplicateUrl = `{{ route('admin.products.duplicate') }}?${params.toString()}`;
        window.open(duplicateUrl, '_blank');
    }
</script>

    @endpush

@endsection