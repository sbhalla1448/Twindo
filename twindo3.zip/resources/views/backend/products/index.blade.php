@extends('backend.master')

@section('content')
<livewire:product.product-index />
@endsection