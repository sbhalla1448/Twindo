@extends('backend.master')

@section('content')
<main class="flex-1 overflow-auto">
    <div class="max-w-4xl mx-auto px-6 py-10">
    <h1 class="text-3xl font-bold text-indigo-700 mb-8">✏️ Edit Product</h1>

    <!-- Edit Product Form -->
    <section class="bg-white p-6 rounded-xl shadow space-y-6">

            <form action="{{ route('admin.products.update',$product->id) }}" method="POST" class="space-y-6"   enctype="multipart/form-data">
                @method('PUT')
                @csrf
            <!-- Image Upload -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Product Image</label>
                <input name="image" type="file" class="w-full border rounded p-2 text-sm shadow-sm">
                <p class="text-xs text-gray-500 mt-1 italic">Upload a square image, recommended size 600x600px</p>
            </div>

            <div class="grid md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Product Title</label>
                    <input name="title" type="text"  class="w-full border rounded p-2 text-sm shadow-sm" value="{{ $product->title }}">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Category</label>
                    <select name="category_id" class="w-full border rounded p-2 text-sm shadow-sm">
                        @foreach ($categories as $cat)

                        <option value="{{ $cat->id }}" @if($product->category_id == $cat->id) selected @endif> {{$cat->name}}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Price / Month (£)</label>
                    <input name="price_per_month" type="number" value="49.99" class="w-full border rounded p-2 text-sm shadow-sm" value="{{ $product->price_per_month }}">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Price / Year (£)</label>
                    <input name="price_annual" type="number" value="499.99" class="w-full border rounded p-2 text-sm shadow-sm" value="{{ $product->price_annual }}">
                </div>
            </div>

            <!-- Status and Tags -->
            <div class="grid md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Product Status</label>
                    <select name="product_status" class="w-full border rounded p-2 text-sm shadow-sm">
                        @foreach (\App\Enums\ProductStatus::options() as $status)
                        <option value="{{ $status->value }}" @if($product->product_status === $status->value) selected @endif>
                            {{ $status->label() }}
                        </option>
                    @endforeach
                        {{-- <option value="Featured" @if($product->product_status == 'Featured') selected @endif>Featured</option>
            <option value="Online Exclusive" @if($product->product_status == 'Online Exclusive') selected @endif>Online Exclusive</option>
            <option value="Popular" @if($product->product_status == 'Popular') selected @endif>Popular</option>
            <option value="Twindo Recommended" @if($product->product_status == 'Twindo Recommended') selected @endif>Twindo Recommended</option>
            <option value="Top Rated" @if($product->product_status == 'Top Rated') selected @endif>Top Rated</option>
            <option value="Trusted Choice" @if($product->product_status == 'Trusted Choice') selected @endif>Trusted Choice</option>
                    </select> --}}
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Product Tags</label>
                    <input name="tags" type="text" value="Credit Repair, Premium, Support"
                        class="w-full border rounded p-2 text-sm shadow-sm"
                        placeholder="e.g. Credit Repair, Trusted" value="{{ $product->tags }}">
                </div>
            </div>

            <!-- Description -->
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">Product Description</label>
                <textarea name="description" rows="5"
                    class="w-full border rounded p-2 text-sm shadow-sm">{{ $product->description }}</textarea>
            </div>

            <!-- Ratings -->
            <div class="grid md:grid-cols-3 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Rating (out of 5)</label>
                    <input name="rating" type="number" max="5" step="0.1" value="4.8"
                        class="w-full border rounded p-2 text-sm shadow-sm" value="{{ $product->rating }}">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">No. of Ratings</label>
                    <input name="rating_count" type="number" value="128" class="w-full border rounded p-2 text-sm shadow-sm" value="{{ $product->rating_count }}">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Last Updated</label>
                    <input type="text" disabled value="{{ $product->editor->name }} . {{ $product->updated_at->format('d M Y') }}"
                        class="w-full border rounded p-2 text-sm bg-gray-100 text-gray-600" value="{{ $product->title }}">
                </div>
            </div>

            <!-- Contact Details -->
            <div class="grid md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Website Link</label>
                    <input type="url" value="https://example.com"
                        class="w-full border rounded p-2 text-sm shadow-sm" name="website_link" value="{{ $product->website_link }}">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                    <input name="phone" type="tel" value="0800 123 4567" class="w-full border rounded p-2 text-sm shadow-sm" value="{{ $product->phone }}">
                </div>
            </div>

            <input type="hidden" name="submit_type" id="submit_type">
            <!-- Buttons -->
            <div class="flex justify-between items-center pt-6">
                <button type="submit" onclick="setSubmitType('0')"
                    class="bg-gray-100 text-gray-800 px-4 py-2 rounded text-sm hover:bg-gray-200">💾 Save as
                    Draft</button>
                <div class="space-x-3">
                    <button type="button" onclick="openPreview()" class="text-sm text-indigo-600 hover:underline">👁️ Preview
                        Product</button>
                    <button type="submit" onclick="setSubmitType('1')"
                        class="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded text-sm">✅ Save
                        Changes</button>
                </div>
            </div>
        </form>
    </section>
</div>
<!-- Preview Modal -->
<div id="previewModal" class="fixed inset-0 z-50 hidden bg-black bg-opacity-50 flex items-center justify-center">
    <div class="bg-white w-full max-w-2xl rounded-lg shadow-lg p-6 relative">
        <button onclick="closePreview()" class="absolute top-2 right-3 text-gray-500 hover:text-gray-700">&times;</button>
        <h2 class="text-xl font-bold mb-4">👁️ Product Preview</h2>
        <div class="space-y-4 text-sm">
            <div><strong>Title:</strong> <span id="previewTitle"></span></div>
            <div><strong>Category:</strong> <span id="previewCategory"></span></div>
            <div><strong>Price/Month:</strong> £<span id="previewMonthly"></span></div>
            <div><strong>Price/Year:</strong> £<span id="previewYearly"></span></div>
            <div><strong>Status:</strong> <span id="previewStatus"></span></div>
            <div><strong>Tags:</strong> <span id="previewTags"></span></div>
            <div><strong>Description:</strong> <p id="previewDescription"></p></div>
            <div><strong>Rating:</strong> <span id="previewRating"></span> (out of <span id="previewRatingCount"></span> ratings)</div>
            <div><strong>Website:</strong> <span id="previewWebsite"></span></div>
            <div><strong>Phone:</strong> <span id="previewPhone"></span></div>
        </div>
    </div>
</div>

</main>
@endsection

@push('js')
<script>
function setSubmitType(type) {
    document.getElementById('submit_type').value = type;
}
function openPreview() {
    // Fill modal with form data
    document.getElementById('previewTitle').innerText = document.querySelector('input[name="title"]').value;
    document.getElementById('previewCategory').innerText = document.querySelector('select[name="category_id"] option:checked').text;
    document.getElementById('previewMonthly').innerText = document.querySelector('input[name="price_per_month"]').value;
    document.getElementById('previewYearly').innerText = document.querySelector('input[name="price_annual"]').value;
    document.getElementById('previewStatus').innerText = document.querySelector('select[name="product_status"] option:checked').text;
    document.getElementById('previewTags').innerText = document.querySelector('input[name="tags"]').value;
    document.getElementById('previewDescription').innerText = document.querySelector('textarea[name="description"]').value;
    document.getElementById('previewRating').innerText = document.querySelector('input[name="rating"]').value;
    document.getElementById('previewRatingCount').innerText = document.querySelector('input[name="rating_count"]').value;
    document.getElementById('previewWebsite').innerText = document.querySelector('input[name="website_link"]').value;
    document.getElementById('previewPhone').innerText = document.querySelector('input[name="phone"]').value;

    // Show the modal
    document.getElementById('previewModal').classList.remove('hidden');
}

function closePreview() {
    document.getElementById('previewModal').classList.add('hidden');
}
</script>



@endpush