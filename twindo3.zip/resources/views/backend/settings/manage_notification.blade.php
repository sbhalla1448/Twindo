@extends('backend.master')

@section('content')
    <main class="max-w-4xl mx-auto px-6 py-12">
        <form method="POST" action="{{ route('admin.settings.notification.update') }}">
            @csrf


            <div>
                <h2 class="text-xl font-semibold text-gray-800 mb-2">📩 Email Notifications</h2>
                <label class="flex items-center space-x-3 mb-2">
                    <input type="checkbox" value="1" name="email_weekly_summary" {{ old('email_weekly_summary', $preferences->email_weekly_summary) ? 'checked' : '' }} class="form-checkbox text-indigo-600">
                    <span class="text-sm text-gray-700">Weekly summary of user activity</span>
                </label>
                <label class="flex items-center space-x-3 mb-2">
                    <input type="checkbox" value="1" name="email_account_changes" {{ old('email_account_changes', $preferences->email_account_changes) ? 'checked' : '' }} class="form-checkbox text-indigo-600">
                    <span class="text-sm text-gray-700">Notify me of account changes</span>
                </label>
                <label class="flex items-center space-x-3">
                    <input type="checkbox" value="1" name="email_new_user" {{ old('email_new_user', $preferences->email_new_user) ? 'checked' : '' }} class="form-checkbox text-indigo-600">
                    <span class="text-sm text-gray-700">Email when a new user registers</span>
                </label>
            </div>

            <div class="border-t pt-6">
                <h2 class="text-xl font-semibold text-gray-800 mb-2">📱 SMS Notifications</h2>
                <label class="flex items-center space-x-3 mb-2">
                    <input type="checkbox" value="1" name="sms_login_alerts" {{ old('sms_login_alerts', $preferences->sms_login_alerts) ? 'checked' : '' }} class="form-checkbox text-indigo-600">
                    <span class="text-sm text-gray-700">Login alerts via SMS</span>
                </label>
                <label class="flex items-center space-x-3">
                    <input type="checkbox" value="1" name="sms_critical_alerts" {{ old('sms_critical_alerts', $preferences->sms_critical_alerts) ? 'checked' : '' }} class="form-checkbox text-indigo-600">
                    <span class="text-sm text-gray-700">Critical system alerts via SMS</span>
                </label>
            </div>

            <div class="border-t pt-6">
                <h2 class="text-xl font-semibold text-gray-800 mb-2">⚙️ Preferences</h2>
                <label class="flex items-center space-x-3 mb-2">
                    <input type="radio" name="email_frequency" value="instant" {{ old('email_frequency', $preferences->email_frequency) == 'instant' ? 'checked' : '' }} class="form-radio text-indigo-600">
                    <span class="text-sm text-gray-700">Send instantly</span>
                </label>
                <label class="flex items-center space-x-3 mb-2">
                    <input type="radio" name="email_frequency" value="daily" {{ old('email_frequency', $preferences->email_frequency) == 'daily' ? 'checked' : '' }} class="form-radio text-indigo-600">
                    <span class="text-sm text-gray-700">Daily digest</span>
                </label>
                <label class="flex items-center space-x-3">
                    <input type="radio" name="email_frequency" value="weekly" {{ old('email_frequency', $preferences->email_frequency) == 'weekly' ? 'checked' : '' }} class="form-radio text-indigo-600">
                    <span class="text-sm text-gray-700">Weekly digest</span>
                </label>
            </div>

            <div class="text-right pt-6">
                <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded shadow">💾 Save Preferences</button>
            </div>
        </form>
    </main>
    {{-- <main class="max-w-4xl mx-auto px-6 py-12">
        <h1 class="text-3xl font-bold text-gray-800 mb-6">🔔 Notification Preferences</h1>

        <div class="bg-white shadow rounded-xl p-6 space-y-6">

            <div>
                <h2 class="text-xl font-semibold text-gray-800 mb-2">📩 Email Notifications</h2>
                <label class="flex items-center space-x-3 mb-2">
                    <input type="checkbox" checked class="form-checkbox text-indigo-600">
                    <span class="text-sm text-gray-700">Weekly summary of user activity</span>
                </label>
                <label class="flex items-center space-x-3 mb-2">
                    <input type="checkbox" class="form-checkbox text-indigo-600">
                    <span class="text-sm text-gray-700">Notify me of account changes</span>
                </label>
                <label class="flex items-center space-x-3">
                    <input type="checkbox" class="form-checkbox text-indigo-600">
                    <span class="text-sm text-gray-700">Email when a new user registers</span>
                </label>
            </div>

            <div class="border-t pt-6">
                <h2 class="text-xl font-semibold text-gray-800 mb-2">📱 SMS Notifications</h2>
                <label class="flex items-center space-x-3 mb-2">
                    <input type="checkbox" class="form-checkbox text-indigo-600">
                    <span class="text-sm text-gray-700">Login alerts via SMS</span>
                </label>
                <label class="flex items-center space-x-3">
                    <input type="checkbox" class="form-checkbox text-indigo-600">
                    <span class="text-sm text-gray-700">Critical system alerts via SMS</span>
                </label>
            </div>

            <div class="border-t pt-6">
                <h2 class="text-xl font-semibold text-gray-800 mb-2">⚙️ Preferences</h2>
                <label class="flex items-center space-x-3 mb-2">
                    <input type="radio" name="frequency" class="form-radio text-indigo-600" checked>
                    <span class="text-sm text-gray-700">Send instantly</span>
                </label>
                <label class="flex items-center space-x-3 mb-2">
                    <input type="radio" name="frequency" class="form-radio text-indigo-600">
                    <span class="text-sm text-gray-700">Daily digest</span>
                </label>
                <label class="flex items-center space-x-3">
                    <input type="radio" name="frequency" class="form-radio text-indigo-600">
                    <span class="text-sm text-gray-700">Weekly digest</span>
                </label>
            </div>

            <div class="text-right pt-6">
                <button class="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded shadow">💾 Save
                    Preferences</button>
            </div>

        </div>
    </main> --}}
@endsection
