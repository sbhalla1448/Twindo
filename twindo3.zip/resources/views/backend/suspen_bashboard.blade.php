@extends('backend.master')


@push('css')
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
@endpush


@section('content')
    <!-- Main Content -->
    <main class="flex-1 overflow-auto">
        <div class="max-w-7xl mx-auto px-6 py-10">

            <!-- Breadcrumb & Hero -->
            <section class="mb-8">
                <nav class="text-sm text-gray-500">Home / Admin / Dashboard/status</nav>
                <h2 class="text-3xl font-bold text-gray-800">Dashboard</h2>
            </section>

            <!-- Quick Actions -->
            <section class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                @if(auth()->check())
                @if(auth()->user()->status == 2)
                    <p>Your Account has been suspended. Please contact helpline.</p>
                @elseif(auth()->user()->status == 3)
                    <p>Your Account has been temporarily locked. Please contact helpline.</p>
                @else
                    {{-- Other statuses --}}
                @endif
            @else
                <p>You are not logged in.</p>
            @endif
            </section>


            </section>

        </div>
    </main>
@endsection


@push('js')

@endpush
