@extends('backend.master')

@section('content')
 <!-- Main -->
<livewire:credit.credit-socre-history>
@endsection