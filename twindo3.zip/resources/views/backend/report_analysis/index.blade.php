@extends('backend.master')


@push('css')
@endpush

@section('content')
 <!-- Main Content -->
 <livewire:report-analysis.report-analysis />
@endsection