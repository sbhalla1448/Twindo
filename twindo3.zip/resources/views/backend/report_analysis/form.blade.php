@extends('backend.master')


@push('css')
@endpush

@section('content')
 <!-- Main Content -->
 <main class="flex-1 overflow-auto">
    <div class="max-w-4xl mx-auto px-6 py-10">

        <!-- Breadcrumb & Title -->
        <section class="mb-8">
            <nav class="text-sm text-gray-500 mb-2">Home / Admin / Report Analysis / Create Report</nav>

            <h2 class="text-2xl md:text-3xl font-bold text-gray-800"> @isset($templateReport) Edit @else Add New @endisset Report</h2>
        </section>

        <!-- Add User Form -->
        <section class="bg-white rounded-xl shadow p-6 md:p-8">
            <form action="{{ isset($templateReport) ? route('admin.tempateReports.update', $templateReport->id) : route('admin.tempateReports.store') }}" method="POST" class="space-y-6">
                @csrf
                @if (isset($templateReport))
                                @method('PUT')
                            @endif
                <div>
                    <label for="role" class="block text-sm font-medium text-gray-700 mb-1">Role</label>
                    <select name="user_id" id="role"
                        class="w-full px-4 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                        required>
                        <option value="">Select Customer</option>
                        @foreach ($users as $user)
                            {{-- Make sure you pass $roles from controller --}}
                            <option value="{{ $user->id }}" @isset($templateReport)
                                @if($templateReport->user_id == $user->id) selected @endif
                            @endisset>{{ $user->name }}</option>
                        @endforeach
                    </select>
                </div>
                <!-- Name -->
                <div>
                    <label for="name" class="block text-sm font-medium text-gray-700 mb-1">Report Title</label>
                    <input type="text" name="title" id="title" value="{{ old('meta_title', $templateReport->title ?? '') }}"
                        class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
                        placeholder="John Doe">
                </div>
                <div>
                    <label for="name" class="block text-sm font-medium text-gray-700 mb-1">Date</label>
                    <input type="date"name="date" id="date" @isset($templateReport) value="{{ old('date', $templateReport->date ? $templateReport->date->format('Y-m-d') : '') }}" @endisset
    class="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-indigo-500 focus:border-indigo-500"
>
                </div>
                <!-- Name -->
                {{-- <div>
                    <label for="name" class="block text-sm font-medium text-gray-700 mb-1">Descriptions</label>

                        <textarea name="description" id=""></textarea>
                </div> --}}

                <div>
                    <label for="name" class="block text-sm font-medium text-gray-700 mb-1">Report HTML Content</label>

                    <textarea
                    name="html_content"
                    id="html_content"
                    class="w-full resize-x rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring focus:ring-indigo-200 focus:ring-opacity-50 bg-sky-500/10"
                    rows="6"
                  >@isset($templateReport){{ $templateReport->html_content }}@endisset</textarea>
                </div>





                <!-- Role -->


                <!-- Submit Button -->
                <div class="flex justify-end pt-4">
                    <button type="submit"
                        class="px-6 py-2 bg-indigo-600 text-white font-semibold rounded-md hover:bg-indigo-700 transition-colors duration-200">
                        @isset($templateReport)
                        <i class="fas fa-arrow-circle-up"></i>
                        update
                    @else
                        <i class="fas fa-plus-circle"></i>
                        Submit
                    @endisset
                    </button>
                </div>
            </form>
        </section>

    </div>
</main>

@endsection