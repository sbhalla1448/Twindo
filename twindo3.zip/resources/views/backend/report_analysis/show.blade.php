{!! $templateReport->html_content ?? 'No content found' !!}

<!-- You can add Laravel-specific scripts here -->
<script>
    // Add any Laravel-specific JavaScript
    window.Laravel = {
        csrfToken: '{{ csrf_token() }}'
    };
</script>