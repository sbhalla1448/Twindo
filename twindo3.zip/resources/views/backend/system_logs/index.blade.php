@extends('backend.master')

@section('content')

{{-- <livewire:system-log :systemLogs="$systemLogs"/> --}}
<livewire:system-log />

@endsection


@push('js')
<script>
    function openLogDetails(user, action, ip, timestamp) {
        document.getElementById('logUser').innerText = user;
        document.getElementById('logAction').innerText = action;
        document.getElementById('logIP').innerText = ip;
        document.getElementById('logTime').innerText = timestamp;
        document.getElementById('logModal').classList.remove('hidden');
    }

    function closeLogModal() {
        document.getElementById('logModal').classList.add('hidden');
    }
</script>
@endpush