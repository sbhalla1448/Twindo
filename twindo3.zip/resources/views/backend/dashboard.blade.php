@extends('backend.master')


@push('css')
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
@endpush


@section('content')
    <!-- Main Content -->
    <main class="flex-1 overflow-auto">
        <div class="max-w-7xl mx-auto px-6 py-10">

            <!-- Breadcrumb & Hero -->
            <section class="mb-8">
                <nav class="text-sm text-gray-500">Home / Admin / Dashboard</nav>
                <h2 class="text-3xl font-bold text-gray-800">Dashboard</h2>
            </section>

            <!-- Quick Actions -->
            <section class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <a href="{{ route('admin.users.create') }}"
                    class="bg-indigo-100 text-indigo-700 rounded-xl p-4 flex items-center space-x-3 hover:bg-indigo-200">
                    <span>➕ Add New User</span>
                </a>
                <a href="{{route('admin.products.create')}}"
                    class="bg-green-100 text-green-700 rounded-xl p-4 flex items-center space-x-3 hover:bg-green-200">
                    <span>➕ Add New Product</span>
                </a>
                <a href="{{route('admin.messageActions.create')}}"
                    class="bg-yellow-100 text-yellow-700 rounded-xl p-4 flex items-center space-x-3 hover:bg-yellow-200">
                    <span>📩 Compose Message</span>
                </a>
                <a href="{{route('admin.settings.index')}}"
                    class="bg-gray-100 text-gray-700 rounded-xl p-4 flex items-center space-x-3 hover:bg-gray-200">
                    <span>⚙️ Go to Settings</span>
                </a>
            </section>

            <!-- Metrics Cards -->
            <section class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <div class="bg-white rounded-xl shadow p-6">
                    <div class="text-sm text-gray-400">Total Users</div>
                    <div class="text-2xl font-semibold text-gray-800">{{ $userCount }}</div>
                </div>
                <div class="bg-white rounded-xl shadow p-6">
                    <div class="text-sm text-gray-400">Active Subscriptions</div>
                    <div class="text-2xl font-semibold text-gray-800">{{ $subscriptions }}</div>
                </div>
                <div class="bg-white rounded-xl shadow p-6">
                    <div class="text-sm text-gray-400">Monthly Revenue</div>
                    <div class="text-2xl font-semibold text-gray-800">£{{ $currentMonthTotal }}</div>
                </div>
                <div class="bg-white rounded-xl shadow p-6">
                    <div class="text-sm text-gray-400">Pending Messages</div>
                    <div class="text-2xl font-semibold text-gray-800">{{ $unseenmsg }}</div>
                </div>
                <div class="bg-white rounded-xl shadow p-6">
                    <div class="text-sm text-gray-400">Documents Uploaded</div>
                    <div class="text-2xl font-semibold text-gray-800">{{ $uploadCount }}</div>
                </div>
                <div class="bg-white rounded-xl shadow p-6">
                    <div class="text-sm text-gray-400">Products Available</div>
                    <div class="text-2xl font-semibold text-gray-800">{{ $productAccount }}</div>
                </div>
                <div class="bg-white rounded-xl shadow p-6">
                    <div class="text-sm text-gray-400">Tools & Resources</div>
                    <div class="text-2xl font-semibold text-gray-800">{{ $toolsCount }}</div>
                </div>
                <div class="bg-white rounded-xl shadow p-6">
                    <div class="text-sm text-gray-400">System Alerts</div>
                    <div class="text-2xl font-semibold text-gray-800">2</div>
                </div>
            </section>

            <!-- Mini Charts -->
            <section class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div class="bg-white rounded-xl shadow p-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4">New Users (7 days)</h3>
                    <canvas id="usersChart"></canvas>
                </div>
                <div class="bg-white rounded-xl shadow p-6">
                    <h3 class="text-lg font-semibold text-gray-800 mb-4">Revenue Growth (7 days)</h3>
                    <canvas id="revenueChart"></canvas>
                </div>
            </section>

            <!-- Search & Filter Users -->
            <section class="bg-white rounded-xl shadow p-6 mb-8">
                <h3 class="text-xl font-semibold text-gray-800 mb-4">Search & Filter Users</h3>
                <form class="grid md:grid-cols-4 gap-4">
                    <input type="text" placeholder="Search by name or email" class="border rounded-lg p-2 text-sm">
                    <select class="border rounded-lg p-2 text-sm">
                        <option>Status</option>
                        <option>Active</option>
                        <option>Inactive</option>
                    </select>
                    <select class="border rounded-lg p-2 text-sm">
                        <option>Plan</option>
                        <option>Essential</option>
                        <option>Plus</option>
                        <option>Elite</option>
                    </select>
                    <button type="submit"
                        class="bg-gray-100 text-gray-800 px-4 py-2 rounded text-sm hover:bg-gray-200">Search / Apply
                        Filters</button>
                </form>
            </section>
            <livewire:last-login-actitvity />
            <!-- CRM Quick Panels -->
            <section class="grid md:grid-cols-3 gap-6 mb-8">
                <div class="bg-white p-6 rounded-xl shadow">
                    <h3 class="text-lg font-semibold text-gray-800 mb-2">📬 Recent Messages</h3>
                    <ul class="text-sm text-gray-700 space-y-2">
                        @foreach ($recentMessages as $rmsg)

                        <li><a href="#" class="hover:underline">{{ $rmsg->user->name }}: {{$rmsg->messages}}</a></li>
                        @endforeach
                    </ul>
                </div>

                <livewire:recent-activitiy />

               <livewire:quick-action />
            </section>
            <section class="bg-white rounded-xl shadow p-6 mb-8">
                <h3 class="text-xl font-semibold text-gray-800 mb-4">System Alerts</h3>
                <ul class="space-y-2">
                    <li class="text-yellow-600">⚠️ Payment Gateway Delay reported - 10 minutes ago</li>
                    <li class="text-red-600">🚨 User Login Failure Spike detected</li>
                    <li class="text-green-600">✅ Backup Completed Successfully - 1 hour ago</li>
                </ul>
            </section>

        </div>
    </main>
@endsection


@push('js')
    <script>
        const usersCtx = document.getElementById('usersChart').getContext('2d');
        const revenueCtx = document.getElementById('revenueChart').getContext('2d');
const labels = @json($labels);
    const data = @json($dataS);
const labelr = @json($labelr);
    const datar = @json($datar);
        new Chart(usersCtx, {
            type: 'line',
            data: {
                labels:labels,
                datasets: [{
                    label: 'New Users',
                    data: data,
                    backgroundColor: 'rgba(79, 70, 229, 0.2)',
                    borderColor: 'rgba(79, 70, 229, 1)',
                    borderWidth: 2
                }]
            }
        });

        new Chart(revenueCtx, {
            type: 'bar',
            data: {
                labels: labelr,
                datasets: [{
                    label: 'Revenue (£)',
                    data: datar,
                    backgroundColor: 'rgba(16, 185, 129, 0.7)',
                    borderColor: 'rgba(5, 150, 105, 1)',
                    borderWidth: 1
                }]
            }
        });
    </script>
@endpush
