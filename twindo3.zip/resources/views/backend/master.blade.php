<!-- Twindo Admin Dashboard (Enhanced Frontend UI/UX Match with Quick Actions, System Alerts, and Mini Charts) -->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Twindo Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tom-select @2.3.1/dist/css/tom-select.css" rel="stylesheet">

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    @stack('css')
    @livewireStyles
</head>

<body class="bg-gray-50 min-h-screen">

    @include('backend.partials.header')

    <div class="flex pt-20">

        <!-- Sidebar -->
        @include('backend.partials.sidebar')


        @yield('content')

    </div>

    <script src="https://cdn.jsdelivr.net/npm/tom-select @2.3.1/dist/js/tom-select.min.js"></script>

    @stack('js')

    @auth
        <script>
            let inactivityTimeout;

            function resetTimer() {
                clearTimeout(inactivityTimeout);
                inactivityTimeout = setTimeout(logout, 15 * 60 * 1000); // 15 minutes in milliseconds
            }

            function logout() {
                fetch('{{ route('admin.sessionlogout') }}', {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '{{ csrf_token() }}',
                        'Accept': 'application/json',
                    },
                }).then(response => {
                    if (response.ok) {
                        window.location.href = '/login';
                    }
                });
            }

            // Listen for user activity
            window.onload = resetTimer;
            ['mousemove', 'mousedown', 'keypress', 'scroll', 'touchstart'].forEach(event => {
                document.addEventListener(event, resetTimer);
            });
        </script>
    @endauth

    @livewireScripts
</body>

</html>
