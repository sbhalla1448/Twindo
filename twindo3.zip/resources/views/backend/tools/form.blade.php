@extends('backend.master')

@section('content')
<!-- Main Content -->
<main class="flex-1 overflow-auto">
    <div class="max-w-4xl mx-auto px-6 py-10">

        <!-- Breadcrumb & Hero -->
        <section class="mb-8">
            <nav class="text-sm text-gray-500">Home / Admin / Tools & Resources / Add New</nav>
            <h2 class="text-3xl font-bold text-gray-800">   {{ isset($toolResource) ? 'Edit':'Add New' }} Tool or Resource</h2>
        </section>

        <!-- Add Tool/Resource Form -->
        <section class="bg-white rounded-xl shadow p-8">
            <form  class="space-y-6"  action="{{ isset($toolResource) ? route('admin.toolResources.update', $toolResource->id) : route('admin.toolResources.store') }}" method="POST">
                @csrf
                @if (isset($toolResource))
                    @method('PUT')
                @endif
                <div>
                    <label class="block text-sm font-medium text-gray-700">Tool/Resource Title</label>
                    <input type="text" name="title" required
                        class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                        placeholder="Enter resource title"  value=" {{ old('title', $toolResource->title ?? '') }}">
                        @error('title') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
                    </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Resource URL</label>
                    <input type="url" name="url" required
                        class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500"
                        placeholder="https://"  value=" {{ old('url', $toolResource->url ?? '') }}">
                        @error('url') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
                    </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Category</label>
                    <select required name="category_id"
                        class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500">
                        <option value="">Select Category</option>
                        @foreach ($categories as $category)

                        <option value="{{ $category->id }}" @isset($toolResource)
                        {{ $toolResource->category_id == $category->id ? 'selected' : '' }}@endisset>{{$category->name}}</option>
                        @endforeach
                    </select>
                    @error('category_id') <span class="text-red-500 text-xs">{{ $message }}</span> @enderror
                </div>

                <div class="flex justify-end space-x-4">
                    <button type="button" onclick="window.history.back()"
                        class="px-6 py-2 rounded-lg bg-gray-200 hover:bg-gray-300">Cancel</button>
                    <button type="submit"
                        class="px-6 py-2 rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white">Save
                        Resource</button>
                </div>

            </form>
        </section>

    </div>
</main>
@endsection