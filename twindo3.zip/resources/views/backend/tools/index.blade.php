@extends('backend.master')

@section('content')
<livewire:tool-resource />
@endsection