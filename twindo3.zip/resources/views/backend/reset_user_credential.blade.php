@extends('backend.master')


@push('css')
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
@endpush


@section('content')
    <!-- Main Content -->
    <main class="flex-1 overflow-auto">
        <div class="max-w-7xl mx-auto px-6 py-10">

            <!-- Breadcrumb & Hero -->
            <section class="mb-8">
                <nav class="text-sm text-gray-500">Home / Admin / Dashboard/status</nav>
                <h2 class="text-3xl font-bold text-gray-800">Dashboard</h2>
            </section>


            <livewire:user.force-reset-credential/>



        </div>
    </main>
@endsection


@push('js')

@endpush
