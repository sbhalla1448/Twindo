@extends('backend.master')


@section('content')

<main class="flex-1 overflow-auto">
    <div class="max-w-2xl mx-auto px-6 py-10">

        <!-- Breadcrumb & Hero -->
        <section class="mb-8">
            <nav class="text-sm text-gray-500">Home / Admin / Users / Reactivate {{$user->name}}</nav>
            <h2 class="text-3xl font-bold text-gray-800">Reactivate User</h2>
        </section>

        <!-- Suspend User Confirmation Card -->
        <section class="bg-white rounded-xl shadow p-8 text-center">
            <div class="mb-6">
                <div
                            class="h-20 w-20 mx-auto bg-green-100 rounded-full flex items-center justify-center text-green-600 text-3xl mb-4">
                            ✅</div>
                <h3 class="text-xl font-semibold text-gray-800 mb-2">Are you sure you want to reactive {{$user->name}}?</h3>
                <p class="text-sm text-gray-500">This will immediately restore the user's full account access.</p>
            </div>
            <div class="flex justify-center space-x-4">
                @if($user->id == Auth::user()->id)
                <a href="{{ route('admin.users.index') }}">
                    <button
                    class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold px-6 py-3 rounded-xl">Cancel</button></a>
                @else
                <form action="{{ route('admin.user.status.change') }}"
                    method="POST" style="display: inline;">
                    @csrf()
                    <input type="hidden" name="userId" value="{{ $user->id }}">
                    <input type="hidden" name="status" value="1">
                <button  type="submit"
                    class="bg-green-500 hover:bg-green-600 text-white font-semibold px-6 py-3 rounded-xl">Confirm
                    Reactivate</button>
                </form>
                 <a href="{{ route('admin.users.index') }}">
                <button
                class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold px-6 py-3 rounded-xl">Cancel</button></a>
                @endif
            </div>
        </section>

    </div>
</main>

<!-- Main Content -->
{{-- <main class="flex-1 overflow-auto">
    <div class="max-w-2xl mx-auto px-6 py-10">

        <!-- Breadcrumb & Hero -->
        <section class="mb-8">
            <nav class="text-sm text-gray-500">Home / Admin / Users / Delete {{ $user->name }}</nav>
            <h2 class="text-3xl font-bold text-gray-800">Delete User</h2>
        </section>

        <!-- Delete User Confirmation Card -->
        <section class="bg-white rounded-xl shadow p-8 text-center">
            <div class="mb-6">
                <div
                    class="h-20 w-20 mx-auto bg-red-100 rounded-full flex items-center justify-center text-red-600 text-3xl mb-4">
                    🗑️</div>
                <h3 class="text-xl font-semibold text-gray-800 mb-2">Delete {{ $user->name }}?</h3>
                @if($user->id == Auth::user()->id)

                    <p class="text-sm text-gray-500">You are not allowed to self deleted.</p>
                @else

                <p class="text-sm text-gray-500">This action is irreversible. The user account and all
                    associated data will be permanently deleted.</p>
                @endif

            </div>
            <div class="flex justify-center space-x-4">
                @if($user->id == Auth::user()->id)
                <button
                class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold px-6 py-3 rounded-xl"><a href="{{ route('admin.users.index') }}">Cancel</a></button>
                @else

                <form action="{{ route('admin.users.destroy', $user->id) }}"
                    method="POST" style="display: inline;">
                    @csrf()
                    @method('DELETE')
                <button onclick="return confirm('Are your sure?')"
                    class="bg-red-600 hover:bg-red-700 text-white font-semibold px-6 py-3 rounded-xl">Confirm
                    Delete</button>



                </form>
                <a href="{{ route('admin.users.index') }}">
                <button
                class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold px-6 py-3 rounded-xl">Cancel</button></a>
                @endif
             </div>
        </section>

    </div>
</main> --}}
@endsection