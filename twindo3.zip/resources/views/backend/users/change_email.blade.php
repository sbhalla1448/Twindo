@extends('backend.master')


@section('content')
    <main class="flex-1 overflow-auto">
        <div class="max-w-2xl mx-auto px-6 py-10">

            <!-- Breadcrumb & Hero -->
            <section class="mb-8">
                <nav class="text-sm text-gray-500">Home / Admin / Users / Suspend John Smith</nav>
                <h2 class="text-3xl font-bold text-gray-800">Locked User</h2>
            </section>

            <section class="bg-white rounded-xl shadow p-8">
                <h2 class="text-2xl font-bold text-gray-800 mb-4">✉️ Change Admin Email</h2>
                <p class="text-sm text-gray-600 mb-6">Update the email address associated with your admin access. We'll
                    notify the old email of this change for security purposes.</p>

                <form class="space-y-6" action="{{ route('admin.change.email.update') }}" method="POST"">
                    @csrf
                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Current Admin Email</label>
                        <input type="email"
                            class="w-full border border-gray-300 rounded-lg p-2 text-sm shadow-sm bg-gray-100 text-gray-500"
                            value="{{ Auth::user()->email }}" disabled>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">New Email Address</label>
                        <input type="email" name="newEmail"
                            class="w-full border border-gray-300 rounded-lg p-2 text-sm shadow-sm"
                            placeholder="newadmin@twindo.co.uk" required>
                        @error('newEmail')
                            <p>{{ $message }}</p>
                        @enderror
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Confirm New Email</label>
                        <input type="email" name="confirmEmail"
                            class="w-full border border-gray-300 rounded-lg p-2 text-sm shadow-sm"
                            placeholder="Confirm new email" required>
                        @error('confirmEmail')
                            <p>{{ $message }}</p>
                        @enderror
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700 mb-1">Admin Password</label>
                        <input type="password" name="password"
                            class="w-full border border-gray-300 rounded-lg p-2 text-sm shadow-sm"
                            placeholder="Enter password to confirm" required>
                        @error('password')
                            <p>{{ $message }}</p>
                        @enderror
                    </div>

                    <div class="text-right">
                        <button type="submit"
                            class="bg-indigo-600 text-white px-5 py-2 rounded hover:bg-indigo-700 text-sm shadow">💾 Save
                            New Email</button>
                    </div>
                </form>
            </section>


        </div>
    </main>
@endsection
