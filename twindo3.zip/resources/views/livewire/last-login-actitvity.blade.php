<section class="bg-white rounded-xl shadow p-6 mb-8">
                <h3 class="text-xl font-semibold text-gray-800 mb-4">Last 6 Activities</h3>
                <table class="w-full text-left">
                    <thead>
                        <tr class="text-sm text-gray-400">
                            <th class="py-2">Name</th>
                            <th class="py-2">Email</th>
                            <th class="py-2">Plan</th>
                            <th class="py-2">Status</th>
                            <th class="py-2">Score</th>
                            <th class="py-2">Last Login</th>
                            <th class="py-2 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($userLastActivities as $userlast)


                        <tr class="border-t">
                            <td class="py-3">{{ $userlast->name }}</td>
                            <td class="py-3">{{ $userlast->email }}</td>
                            <td class="py-3">{{ $userlast->plan->name ?? '' }}</td>
                            <td class="py-3 text-green-600">{{ $userlast->status_label}}</td>
                            <td class="py-3">{{ $userlast->score->score ?? '' }}</td>
                            <td class="py-3">
                                @if(!empty($userlast->last_login_at))
                                {{ $userlast->last_login_at ?->format('d M Y')  }}
                                @else

                                @endif
                            </td>
                            <td class="py-3 text-right space-x-2">
                                <a style="cursor: pointer" wire:click="modalview({{ $userlast->id }})" class="text-indigo-600 hover:underline">View</a>
                                <a style="cursor: pointer" wire:click="viewMessage({{ $userlast->id }})"  class="text-blue-600 hover:underline">Message</a>
                                <a style="cursor: pointer" wire:click="viewActive({{ $userlast->id }})" class="text-red-600 hover:underline">Deactivate</a>
                            </td>
                        </tr>
                        @endforeach

                    </tbody>
                </table>
                <div class="flex justify-between items-center mt-4">
                    {{-- <button class="text-sm px-4 py-2 bg-gray-100 rounded hover:bg-gray-200">⬅ Previous</button>
                    <button class="text-sm px-4 py-2 bg-gray-100 rounded hover:bg-gray-200">Next ➡</button> --}}
                     {{ $userLastActivities->links('vendor.pagination.message-action-pagination') }}
                </div>

                @if($modalShow)
  <!-- View Log Modal -->
    <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-xl p-8 shadow-lg max-w-md w-full">
            <h2 class="text-2xl font-bold mb-4">Log Details</h2>
            <p><strong>User:</strong><span id="logTime">{{ $activitylog->user->name ??'' }}</span></p>
            <p><strong>Action:</strong> <span id="logTime">{{ $activitylog->action }}</span></p>
            <p><strong>IP Address:</strong> <span id="logIP">{{ $activitylog->ip_address }}</span></p>
            <p><strong>Timestamp:</strong> <span id="logTime">{{ $activitylog->created_at }}</span></p>
            <div class="text-right mt-6">
                <button wire:click="closeLogModal"
                    class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg">Close</button>
            </div>
        </div>
    </div>
    @endif

      @if($viewTools)
      {{-- <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div class="bg-white rounded-lg shadow-lg p-6 w-1/2">
          <h2 id="viewResourceTitle" class="text-2xl font-bold mb-4"></h2>
          <p class="text-gray-600">{{$currentSubscription->plan->name}}</p>



          <div class="text-right mt-6">
              <button wire:click="closeDialog"
                  class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg">Cancel</button>
              <button wire:click="cancelPlan"
                  class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg">Yes</button>
          </div>
      </div>
  </div> --}}
  <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
    <!-- Modal Container -->
    <div class="bg-white rounded-lg shadow-xl w-full max-w-md">
        <!-- Modal Header -->
        <div class="flex items-center justify-between p-6 border-b border-gray-200">
            <h2 class="text-lg font-semibold text-gray-900"> {{ $selectUser->name }} activity?</h2>
            <button wire:click="closeDialog" class="text-gray-400 hover:text-gray-600 transition-colors">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>

        <!-- Modal Body -->
        <div class="p-6 space-y-4">
            <!-- Warning Alert -->
            <div class="bg-red-50 border border-red-200 rounded-md p-4">
                <div class="flex items-start">
                    <div class="flex-shrink-0">
                        <svg class="w-5 h-5 text-red-400 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"></path>
                        </svg>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-red-800">
                            Are you sure that you want to Deactive "{{ $selectUser->name }}"?
                        </p>
                        {{-- <ul class="mt-2 text-sm text-red-700">
                            <li class="flex items-start">
                                <span class="inline-block w-1 h-1 bg-red-400 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                                Deleted activities cannot be restored.
                            </li>
                        </ul> --}}
                    </div>
                </div>
            </div>

            <!-- Checkbox -->
            {{-- <div class="flex items-start">
                <input
                    type="checkbox"
                    id="understand"
                    class="mt-1 h-4 w-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500"
                    checked
                >
                <label for="understand" class="ml-3 text-sm text-gray-700">
                    I understand that this action cannot be undone.
                </label>
            </div> --}}
        </div>

        <!-- Modal Footer -->
        <div class="flex justify-end space-x-3 px-6 py-4 border-t border-gray-200">
            <button wire:click="closeLogModal" class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition-colors">
                Cancel
            </button>
            <button wire:click="makeYes" class="px-4 py-2 text-sm font-medium text-white bg-teal-600 border border-transparent rounded-md hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition-colors">
                OK
            </button>
        </div>
    </div>
</div>
  @endif

  @if($viewToolmsg)
  <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-xl p-8 shadow-lg max-w-md w-full">

        <h2 class="text-2xl font-semibold mb-4 text-gray-800">{{$selectUser->name}}</h2>
        <form wire:submit="messageSave" class="space-y-4">
          <div>
            <label for="subject" class="block text-sm font-medium text-gray-700">Subject</label>
            <input type="text" id="subject" name="subject" wire:model="subject" required
              class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
            @error('subject')
                    <span>{{$message}}</span>
            @enderror
          </div>

          <div>
            <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
            <textarea wire:model="message" id="description" name="description" rows="4" required
              class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
              @error('message')
              <span>{{$message}}</span>
      @enderror
            </div>

          <div class="flex justify-between gap-4">
            <button type="submit"
              class="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition duration-200">
              Submit
            </button>

            <button type="button" wire:click="closeLogModal"
              class="flex-1 bg-gray-200 text-gray-800 py-2 px-4 rounded-lg hover:bg-gray-300 transition duration-200">
              Cancel
            </button>
          </div>
        </form>


    </div>
</div>
  @endif

</section>
