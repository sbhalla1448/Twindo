<div>
    <!-- Address Management -->
    <section class="bg-white rounded-xl shadow p-8">
        <h2 class="text-2xl font-bold text-gray-800 mb-4">🏡 Address Management</h2>
        <p class="text-sm text-gray-600 mb-6">Update or add your current address information for accurate
            credit reporting and verification.</p>

        <form wire:submit="addressSaveOrUpdate">
            <input type="hidden" wire:model ="addressId">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Street Address</label>
                    <input type="text" class="w-full border border-gray-300 rounded-lg p-2 text-sm shadow-sm"
                        placeholder="Flat 1, 20 High Street" wire:model="streetAddress" wire:model="addressType">
                    @error('addressType')
                        <span class="block sm:inline">{{ $message }}</span>
                    @enderror

                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">City</label>
                    <input type="text" class="w-full border border-gray-300 rounded-lg p-2 text-sm shadow-sm"
                        placeholder="London" wire:model="city">
                    @error('city')
                        <span class="block sm:inline">{{ $message }}</span>
                    @enderror
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Postcode</label>
                    <input type="text" class="w-full border border-gray-300 rounded-lg p-2 text-sm shadow-sm"
                        placeholder="SW1A 1AA" wire:model="postCode">
                    @error('postCode')
                        <span class="block sm:inline">{{ $message }}</span>
                    @enderror
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Country</label>
                    <select class="w-full border border-gray-300 rounded-lg p-2 text-sm shadow-sm"
                        wire:model="countryId">
                        <option value="" disabled selected>Select your country</option>
                        @foreach ($countries as $country)
                            <option value="{{ $country->id }}">{{ $country->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="md:col-span-2">
                    <label class="block text-sm font-medium text-gray-700 mb-1">Address Type</label>
                    <select class="w-full border border-gray-300 rounded-lg p-2 text-sm shadow-sm"
                        wire:model="addressType">
                        <option value="billing_address">Billing Address</option>
                        <option value="residential_address">Residential Address</option>
                        <option value="both">Both</option>
                    </select>
                </div>
            </div>

            <div class="mt-6 flex justify-between items-center">

                <label class="inline-flex items-center text-sm text-gray-700">
                    <input type="checkbox" @if ($defaultAddress == 1) checked @endif
                        class="form-checkbox text-indigo-600 mr-2" wire:model="defaultAddress">
                    Set as Default Address
                </label>
                <div wire:loading>

                    <svg aria-hidden="true"
                        class="inline w-8 h-8 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600"
                        viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                            fill="currentColor" />
                        <path
                            d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                            fill="currentFill" />
                    </svg>

                </div>
                <button
                    class="bg-indigo-600 text-white px-5 py-2 rounded hover:bg-indigo-700 text-sm shadow focus:outline-none focus:ring-2 focus:ring-indigo-500">💾
                    Save Address</button>
            </div>
        </form>
    </section>
    <!-- Spacer -->
    <section class="mt-8"></section>

    <!-- Saved Addresses Section -->
    <section class="bg-white rounded-xl shadow p-8">
        <h2 class="text-2xl font-bold text-gray-800 mb-4">📦 Saved Addresses</h2>
        <p class="text-sm text-gray-600 mb-6">Below are your previously saved addresses. You can edit or
            remove them at any time.</p>

        <div class="space-y-4">

            @foreach ($addresses as $ad)
                <div class="border rounded-lg p-4 shadow-sm">
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="font-semibold text-gray-800">{{ $ad->street_address }}</p>
                            <p class="text-sm text-gray-600">{{ $ad->city }}, {{ $ad->post_code }} ·
                                {{ $ad->country->name }}</p>
                            <span
                                class="inline-block mt-1 text-xs text-green-600 font-medium">{{ $ad->verify_address == 1 ? '✅ Verified' : '❌ Unverified' }}</span>
                        </div>
                        <div class="flex space-x-2">
                            <button class="text-sm text-indigo-600 hover:underline"
                                wire:click="editAddress({{ $ad->id }})">Edit</button>
                            <button class="text-sm text-red-600 hover:underline"
                                wire:click="deleteAddress({{ $ad->id }})">Delete</button>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </section>
</div>
