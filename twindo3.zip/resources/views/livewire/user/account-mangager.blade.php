<section class="mt-8 bg-white rounded-xl shadow p-6 mb-6">
    <h3 class="text-lg font-semibold text-gray-800 mb-4">👥 Account Manager</h3>
    <p class="text-sm text-gray-600 mb-2">Assigned Admin: <strong>{{ $user->assigner?->name }}</strong></p>
    <button wire:click="accountPreview"
        class="bg-indigo-100 text-indigo-700 px-4 py-2 rounded text-sm hover:bg-indigo-200">Change
        Manager</button>
    @if ($accountManager)
        <div class="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
            <div class="bg-white rounded-lg shadow-lg p-6 w-full max-w-2xl max-h-[80vh] overflow-y-auto">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-xl font-semibold">Change Asign Admin</h2>
                    <button wire:click="closeAccountPreview" class="text-gray-500 hover:text-gray-700">×</button>
                </div>
                <div class="prose">
                    <form wire:submit="assignUserUpdate">
                        <div class="mb-4">
                            <label for="templateSubject" class="block text-sm font-medium text-gray-700">Assigned
                                Admin</label>

                            <select wire:model="userId" class="w-full border rounded p-2 text-sm">
                                <option value="">Select Assign Admin</option>
                                @foreach ($users as $user)
                                    <option value="{{ $user->id }}">{{ $user->name }}</option>
                                @endforeach
                            </select>
                            @error('userId')
                                <span class="text-red-500 text-sm">{{ $message }}</span>
                            @enderror
                        </div>



                        <div class="flex justify-end">
                            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                                Submit
                            </button>
                        </div>
                    </form>



                </div>
            </div>
        </div>
    @endif
</section>
