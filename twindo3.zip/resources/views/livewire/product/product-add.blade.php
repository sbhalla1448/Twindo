<div class="max-w-6xl mx-auto px-6 py-12">
    <h1 class="text-3xl font-bold mb-8 text-indigo-700">➕ Add New Product</h1>
    <div class="grid md:grid-cols-2 gap-10">
      <form class="space-y-6" oninput="updatePreview()">

        <!-- Image Upload -->
        <div>
          <label class="block font-medium text-sm text-gray-700 mb-1">Product Image</label>
          <input type="file" accept="image/*" onchange="showImagePreview(event)" class="w-full border border-gray-300 rounded p-2">
        </div>

        <!-- Title -->
        <div>
          <label class="block font-medium text-sm text-gray-700 mb-1">Product Title</label>
          <input id="title" type="text" class="w-full border border-gray-300 rounded p-2" placeholder="Enter product name">
        </div>

        <!-- Pricing -->
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block font-medium text-sm text-gray-700 mb-1">Price per Month (£)</label>
            <input id="priceMonth" type="number" step="0.01" class="w-full border border-gray-300 rounded p-2">
          </div>
          <div>
            <label class="block font-medium text-sm text-gray-700 mb-1">Annual Price (£)</label>
            <input id="priceAnnual" type="number" step="0.01" class="w-full border border-gray-300 rounded p-2">
          </div>
        </div>

        <!-- Category -->
        <div>
          <label class="block font-medium text-sm text-gray-700 mb-1">Category</label>
          <select id="category" class="w-full border border-gray-300 rounded p-2">
            <option>Credit Services</option>
            <option>Debt Help</option>
            <option>Financial Tools</option>
          </select>
        </div>

        <!-- Product Status -->
        <div>
          <label class="block font-medium text-sm text-gray-700 mb-1">Product Status</label>
          <select id="status" class="w-full border border-gray-300 rounded p-2">
            <option>Featured</option>
            <option>Online Exclusive</option>
            <option>Popular</option>
            <option>Twindo Recommended</option>
            <option>Top Rated</option>
            <option>Trusted Choice</option>
          </select>
        </div>

        <!-- Tags -->
        <div>
          <label class="block font-medium text-sm text-gray-700 mb-1">Product Tags (comma separated)</label>
          <input id="tags" type="text" class="w-full border border-gray-300 rounded p-2" placeholder="tag1, tag2, tag3">
        </div>

        <!-- Rating -->
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block font-medium text-sm text-gray-700 mb-1">Rating (out of 5)</label>
            <input id="rating" type="number" step="0.1" max="5" min="0" class="w-full border border-gray-300 rounded p-2">
          </div>
          <div>
            <label class="block font-medium text-sm text-gray-700 mb-1">Number of Ratings</label>
            <input id="ratingCount" type="number" class="w-full border border-gray-300 rounded p-2">
          </div>
        </div>

        <!-- Website and Phone -->
        <div class="grid grid-cols-2 gap-4">
          <div>
            <label class="block font-medium text-sm text-gray-700 mb-1">Website Link</label>
            <input id="link" type="url" class="w-full border border-gray-300 rounded p-2" placeholder="https://example.com">
          </div>
          <div>
            <label class="block font-medium text-sm text-gray-700 mb-1">Phone Number</label>
            <input id="phone" type="text" class="w-full border border-gray-300 rounded p-2" placeholder="+44 123 456 7890">
          </div>
        </div>

        <!-- Description -->
        <div>
          <label class="block font-medium text-sm text-gray-700 mb-1">Product Description</label>
          <textarea id="description" rows="5" maxlength="300" oninput="document.getElementById('char-count').textContent = 300 - this.value.length" class="w-full border border-gray-300 rounded p-2"></textarea>
          <p class="text-xs text-gray-500 mt-1">Characters remaining: <span id="char-count">300</span></p>
        </div>

        <!-- SEO Notes -->
        <div>
          <label class="block font-medium text-sm text-gray-700 mb-1">SEO Notes or Internal Description</label>
          <textarea id="seoNotes" rows="3" class="w-full border border-gray-300 rounded p-2"></textarea>
        </div>

        <!-- Actions -->
        <div class="flex justify-between items-center">
          <button type="button" class="text-sm text-indigo-600 hover:underline">🔁 Duplicate from Existing</button>
          <div class="space-x-4">
            <button type="button" class="bg-yellow-500 hover:bg-yellow-600 text-white px-4 py-2 rounded">💾 Save as Draft</button>
            <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded">🚀 Create Product</button>
          </div>
        </div>
      </form>

      <!-- Live Preview -->
      <div class="bg-white rounded-xl shadow p-6">
        <h2 class="text-xl font-bold text-gray-800 mb-4">🔍 Live Product Preview</h2>
        <img id="preview-image" class="h-32 object-cover rounded mb-4" src="#" alt="Product Image Preview" style="display:none;">
        <p class="font-semibold text-lg text-gray-700 mb-1" id="preview-title">Product Title</p>
        <p class="text-sm text-gray-500 mb-2" id="preview-category">Category</p>
        <p class="text-sm text-gray-600" id="preview-price">£0.00 / month</p>
        <p class="text-sm text-gray-600 mb-2" id="preview-annual">£0.00 annually</p>
        <p class="text-sm text-gray-600 mb-1" id="preview-status">Status</p>
        <p class="text-sm text-yellow-600" id="preview-rating">0.0 ⭐</p>
        <p class="text-xs text-gray-500 mb-2" id="preview-rating-count">(0 reviews)</p>
        <p class="text-sm text-blue-600 mb-1" id="preview-link">https://</p>
        <p class="text-sm text-gray-700 mb-2" id="preview-phone">Phone</p>
        <p class="text-sm text-gray-600 mb-2" id="preview-description">Product description...</p>
        <p class="text-xs text-indigo-500 mb-2" id="preview-tags">#tags</p>
        <p class="text-xs text-gray-400" id="preview-seo">SEO Notes...</p>
      </div>
    </div>
  </div>

  @script
    @push('js')
    <script>
        function updatePreview() {
          document.getElementById('preview-title').textContent = document.getElementById('title').value;
          document.getElementById('preview-price').textContent = '£' + document.getElementById('priceMonth').value + ' / month';
          document.getElementById('preview-annual').textContent = '£' + document.getElementById('priceAnnual').value + ' annually';
          document.getElementById('preview-category').textContent = document.getElementById('category').value;
          document.getElementById('preview-status').textContent = document.getElementById('status').value;
          document.getElementById('preview-rating').textContent = document.getElementById('rating').value + ' ⭐';
          document.getElementById('preview-rating-count').textContent = '(' + document.getElementById('ratingCount').value + ' reviews)';
          document.getElementById('preview-link').textContent = document.getElementById('link').value;
          document.getElementById('preview-phone').textContent = document.getElementById('phone').value;
          document.getElementById('preview-description').textContent = document.getElementById('description').value;
          document.getElementById('preview-tags').textContent = document.getElementById('tags').value;
          document.getElementById('preview-seo').textContent = document.getElementById('seoNotes').value;
        }

        function showImagePreview(event) {
          const file = event.target.files[0];
          const preview = document.getElementById('preview-image');
          if (file) {
            preview.src = URL.createObjectURL(file);
            preview.style.display = 'block';
          } else {
            preview.style.display = 'none';
          }
        }
      </script>
    @endpush
  @endscript