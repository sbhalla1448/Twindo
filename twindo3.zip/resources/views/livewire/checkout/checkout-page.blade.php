<div>
    <header>
        <div class="logo">Twindo</div>
        <div class="tagline">Your journey to financial freedom starts here</div>
        <div class="secure-checkout">
            <i class="fas fa-lock"></i>
            <span>Secure Checkout</span>
        </div>

        <!-- Enhanced Progress Bar -->
        <div class="header-progress">
            <div class="progress-container-inner">
                <div class="progress-steps-inner">
                    <div class="progress-bar-inner" style="--progress-width: {{$progress}}%"></div>
                    <div class="step-inner {{ $progressAccount }}">
                        <i class="fas fa-user"></i>
                        <div class="step-label-inner">Account</div>
                    </div>

                    <div class="step-inner {{ $progressPayment }}">
                        <i class="fas fa-credit-card"></i>
                        <div class="step-label-inner ">Payment</div>
                    </div>
                    <div class="step-inner {{ $progressComplete }}">
                        <i class="fas fa-check-circle"></i>
                        <div class="step-label-inner">Confirmation</div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <div class="main-content">



        <!-- Stage 1: Account -->
        <div class="step-content {{ $geustUser }}" id="step1">
            <div class="stage1-container">
                @guest
                <div class="form-container">
                    <h2 class="section-title">
                        <i class="fas fa-user-circle"></i>
                        Account Information
                    </h2>

                    <div class="toggle-container">
                        <div class="toggle-option active" data-option="create">
                            <i class="fas fa-user-plus"></i>
                            <h3>Create Account</h3>
                            <p>New to Twindo? Create an account to manage your subscription.</p>
                        </div>
                        <div class="toggle-option" data-option="login">
                            <i class="fas fa-sign-in-alt"></i>
                            <h3>Sign In</h3>
                            <p>Already have an account? Sign in to continue.</p>
                        </div>
                    </div>

                    <div id="create-account-form">
                        <!-- Social signup buttons with Font Awesome icons -->
                        <div class="social-signup">

                            <button class="btn-social btn-google" id="google-signup">
                                <a href="{{ route('social.redirect', 'google') }}">
                                <i class="fab fa-google social-icon"></i>
                                Sign up with Google
                            </a>
                            </button>


                            <button class="btn-social btn-apple" id="apple-signup">

                        <a href="{{ route('social.redirect', 'apple') }}">
                                <i class="fab fa-apple social-icon"></i>
                                Sign up with Apple
                            </a>
                            </button>

                        </div>

                        <div class="or-divider">
                            <span>or</span>
                        </div>

                        <form wire:submit="userSignUp">
                            @if($errorMessage)
                            <div class="text-red-500 mb-4">{{ $errorMessage }}</div>
                        @endif
                        <div id="email-signup-form">
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="first-name">First Name</label>
                                    <input type="text" wire:model="first_name" id="first-name" class="form-control" placeholder="John">
                                    @error('first_name') <span style="color: red">{{ $message }}</span> @enderror
                                </div>
                                <div class="form-group">
                                    <label for="last-name">Last Name</label>
                                    <input type="text"  wire:model="last_name" id="last-name" class="form-control" placeholder="Doe">
                                    @error('last_name') <span style="color: red">{{ $message }}</span> @enderror
                                </div>
                            </div>

                            <!-- Email and Phone on same line -->
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="email">Email Address</label>
                                    <input type="email" wire:model="email" id="email" class="form-control" placeholder="john.doe@example.com">
                                    @error('email') <span style="color: red">{{ $message }}</span> @enderror
                                </div>
                                <div class="form-group">
                                    <label for="phone">Phone Number</label>
                                    <input type="tel" wire:model="phone" id="phone" class="form-control" placeholder="(123) 456-7890">
                                    @error('phone') <span style="color: red">{{ $message }}</span> @enderror
                                </div>
                            </div>

                            <!-- Address fields -->
                            <div class="form-group">
                                <label for="address">Street Address</label>
                                <input type="text" wire:model="street_address"  id="address" class="form-control" placeholder="123 Main St">
                                @error('street_address') <span style="color: red">{{ $message }}</span> @enderror
                            </div>

                            <div class="form-row">
                                <div class="form-group">
                                    <label for="city">City</label>
                                    <input type="text" wire:model="city"  id="city" class="form-control" placeholder="London">
                                    @error('city') <span style="color: red">{{ $message }}</span> @enderror
                                </div>
                                <div class="form-group">
                                    <label for="state">County</label>

                                    <input type="text" wire:model="county" id="state" class="form-control" placeholder="Greater London">
                                    @error('county') <span style="color: red">{{ $message }}</span> @enderror
                                </div>
                            </div>

                            <div class="form-row">
                                <div class="form-group">
                                    <label for="zip">Postal Code</label>
                                    <input type="text" wire:model="postal_code" id="zip" class="form-control" placeholder="SW1A 1AA">
                                    @error('postal_code') <span style="color: red">{{ $message }}</span> @enderror
                                </div>
                                <div class="form-group">
                                    <label for="country">Country</label>
                                    <select name="" id="" wire:model="countryId" class="form-control">
                                        <option value="">Select Country</option>
                                        @foreach ($countries as $country)
                                            <option value={{ $country->id }}>{{ $country->name }}</option>
                                        @endforeach
                                    </select>
                                    @error('countryId') <span style="color: red">{{ $message }}</span> @enderror
                                </div>
                            </div>

                            <!-- Password and Confirm Password on same line -->
                            <div class="form-row">
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <div class="password-container">
                                        <input wire:model="password" type="password" id="password" class="form-control" placeholder="Create a password">
                                        <button class="toggle-password">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        @error('password') <span style="color: red">{{ $message }}</span> @enderror
                                    </div>
                                    <!-- Password rules toggle -->
                                    <div class="password-toggle" id="password-toggle">
                                        <i class="fas fa-info-circle"></i>
                                        <span>Password requirements</span>
                                    </div>
                                    <div class="password-rules" id="password-rules">
                                        <p>Password must contain:</p>
                                        <ul>
                                            <li id="rule-length" class="invalid">At least 8 characters</li>
                                            <li id="rule-uppercase" class="invalid">At least one uppercase letter</li>
                                            <li id="rule-lowercase" class="invalid">At least one lowercase letter</li>
                                            <li id="rule-number" class="invalid">At least one number</li>
                                            <li id="rule-special" class="invalid">At least one special character</li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="confirm-password">Confirm Password</label>
                                    <div class="password-container">
                                        <input wire:model="confirm_password" type="password" id="confirm-password" class="form-control" placeholder="Confirm your password">
                                        <button class="toggle-password">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        @error('confirm_password') <span style="color: red">{{ $message }}</span> @enderror
                                    </div>
                                </div>
                            </div>

                            <!-- Updated newsletter text -->
                            <div class="checkbox-container">
                                <input type="checkbox" id="newsletter">
                                <label for="newsletter">Subscribe to our newsletter for tips and updates</label>
                            </div>

                            <div class="checkbox-container">
                                <input type="checkbox" id="terms">
                                <label for="terms">I agree to the <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a></label>
                            </div>

                            <button type="submit" class="btn" id="continue-to-payment">
                                <i class="fas fa-arrow-right"></i> Continue to Payment
                            </button>
                        </div>
                    </form>
                    </div>
                    <form wire:submit.prevent="userSignIn">
                    <div id="login-form" style="display: none;">

                        @if($errorMessage)
                        <div class="text-red-500 mb-4">{{ $errorMessage }}</div>
                    @endif
                        <div class="form-group">
                            <label for="login-email">Email Address</label>
                            <input type="email" wire:model="userEmail" id="login-email" class="form-control" placeholder="your.email@example.com">
                            @error('userEmail') <span style="color: red">{{ $message }}</span> @enderror
                        </div>

                        <div class="form-group">
                            <label for="login-password">Password</label>
                            <div class="password-container">
                                <input type="password" wire:model="userPassword" id="login-password" class="form-control" placeholder="Enter your password">
                                @error('userPassword') <span style="color: red">{{ $message }}</span> @enderror
                                <button class="toggle-password">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>

                        <div class="checkbox-container">
                            <input type="checkbox" id="remember">
                            <label for="remember">Remember me</label>
                        </div>

                        <button type="submit" class="btn" wire:loading.remove>

                            <i class="fas fa-sign-in-alt"></i> Sign In & Continue
                        </button>

                        <div style="text-align: center; margin-top: 20px;">
                            <a  href="{{ route('password.request') }}" style="color: #5CB46A; font-weight: 600;">Forgot your password?</a>
                        </div>

                    </div>
                </form>
                </div>

                @endguest

                <!-- Updated Order Summary for Stage 1 -->
                <div class="order-summary">
                    <h3 class="summary-title">Order Summary</h3>

                    <div class="plan-card">
                        <div class="plan-name">Twindo Plus</div>
                        <div class="plan-price">£{{$splan->monthly_price}}</div>
                        <div class="plan-period">per month</div>
                    </div>

                    <h4 style="font-size: 18px; margin-bottom: 15px; color: #033333;">Includes:</h4>
                    <ul class="features-list">
                        <!-- Added new bullet point -->
                        <li>Everything in the Essentials Package</li>
                        <li>Credit Report Review</li>
                        <li>Dedicated Credit Expert</li>
                        <li>Personalised Credit Plan</li>
                        <li>Debt Management Plan</li>
                        <li>Monthly Progress Updates</li>
                        <li>Priority Phone & Chat Support</li>

                    </ul>
                        {{-- <form wire:submit="applyCoupon">
                            <div class="coupon-section">
                                <!-- Changed to Discount Code -->
                                <input wire:model="couponCode" type="text"  class="form-control coupon-input" placeholder="Discount code">
                                @error('couponCode') <span style="color: red">{{ $message }}</span> @enderror

                                <button type="submit" class="apply-btn">Apply</button>
                            </div>
                        </form> --}}

                    <div class="summary-row">
                        <span>Subtotal</span>
                        <span>£{{$splan->monthly_price}}</span>
                    </div>
                    <div class="summary-row total">
                        <span>Total</span>
                        <span>£{{$splan->monthly_price}}</span>
                    </div>

                    <div class="trust-badges">
                        <div class="trust-badge">
                            <i class="fas fa-shield-alt"></i>
                            <span>256-bit SSL Security</span>
                        </div>
                        <div class="trust-badge">
                            <i class="fas fa-lock"></i>
                            <span>PCI DSS Compliant</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <!-- Stage 2: Payment -->
        <div class="step-content {{ $logedInStatus }}" >
            <div class="stage2-container">
                <div class="form-container">
                    <h2 class="section-title">
                        <i class="fas fa-credit-card"></i>
                        Payment Information
                    </h2>

                    <!-- NEW PAYMENT METHOD SELECTOR -->
                    {{-- <div class="payment-selector">
                        <div class="payment-selector-title">Select Payment Method</div>
                        <div class="payment-methods-grid">
                            <div class="payment-method-card active" data-method="card">
                                <div class="payment-method-icon">
                                    <i class="far fa-credit-card"></i>
                                </div>
                                <div class="payment-method-name">Card</div>
                            </div>
                            <div class="payment-method-card" data-method="apple">
                                <div class="payment-method-icon">
                                    <i class="fab fa-apple"></i>
                                </div>
                                <div class="payment-method-name">Apple Pay</div>
                            </div>
                            <div class="payment-method-card" data-method="klarna">
                                <div class="payment-method-icon">
                                    <i class="fas fa-shopping-bag"></i>
                                </div>
                                <div class="payment-method-name">Klarna</div>
                            </div>
                        </div>
                    </div> --}}

                    <!-- PAYMENT PLAN TOGGLE -->
                    <div class="payment-plan-toggle">
                        <div class="payment-plan-option {{ $selectedPlan === 'monthly' ? 'active' : '' }}"  wire:click="setPaymentPlan('monthly')">
                            <div class="payment-plan-name">Monthly</div>
                            <div class="payment-plan-price">£{{$splan->monthly_price}}/mo</div>
                        </div>
                        <div class="payment-plan-option {{ $selectedPlan === 'annual' ? 'active' : '' }}"  wire:click="setPaymentPlan('annual')">
                            <div class="payment-plan-name">Annual</div>
                            <div class="payment-plan-price">£{{$splan->yearly_price}}/yr</div>
                            <div class="payment-plan-savings">Save 15%</div>
                        </div>
                    </div>

                <form id="payment-form">
                    <input type="hidden" name="selected_plan" value="{{ $selectedPlan }}">
                    <!-- PAYMENT METHOD CONTENT -->
                    <div class="payment-method-content">
                        <!-- Card Payment Method -->
                        <div class="payment-method-section active" >

                            <div id="payment-element" wire:ignore></div>
                            <div>
                                <button class="btn btn-outline" id="back-to-account">
                                    <i class="fas fa-arrow-left"></i> Back to Account
                                </button>
                                <button type="submit" class="btn" >
                                    <i class="fas fa-lock"></i> Complete Purchase
                                </button>
                            </div>
                        </div>

                    </div>
                    <div id="payment-message" class="hidden">

                </div>
            </form>

                <!-- Updated Order Summary for Stage 2 -->
                <div class="order-summary">
                    <h3 class="summary-title">Order Summary</h3>

                    <div class="plan-card">
                        <div class="plan-name">{{$splan->name}}</div>
                        <div class="plan-price" id="plan-price-display">£{{$subtotal}}</div>
                        <div class="plan-period" id="plan-period-display">per {{ $selectedPlan === 'monthly' ? 'Month' : 'Year' }}</div>
                    </div>

                    <h4 style="font-size: 18px; margin-bottom: 15px; color: #033333;">Includes:</h4>
                    <ul class="features-list">
                        <!-- Added new bullet point -->
                        <li>Everything in the Essentials Package</li>
                        <li>Credit Report Review</li>
                        <li>Dedicated Credit Expert</li>
                        <li>Personalised Credit Plan</li>
                        <li>Debt Management Plan</li>
                        <li>Monthly Progress Updates</li>
                        <li>Priority Phone & Chat Support</li>
                    </ul>
                    <div>Client Secret: {{ $clientSecret }}</div>
                    <div>NewPayment : {{ $paymentIntentId }}</div>
                    <form wire:submit.prevent="applyCoupon">
                            <div class="coupon-section">
                                <!-- Changed to Discount Code -->
                                <input name="couponCode" wire:model="couponCode" type="text"  class="form-control coupon-input" placeholder="Discount code">
                                @error('couponCode') <span style="color: red">{{ $message }}</span> @enderror


                                <button type="submit" class="apply-btn">Apply</button>
                            </div>
                        </form>

                    <div class="summary-row">
                        <span>Subtotal</span>
                        <span id="subtotal-display">£{{$subtotal}}</span>
                    </div>
                    @if($discount > 0)
                    <div class="summary-row">
                        <span>Discount</span>
                        <span id="subtotal-display">£{{$discount}}</span>
                    </div>
                    @endif
                    <div class="summary-row total">
                        <span>Total</span>
                        <span id="total-display">£{{$total}}</span>
                    </div>

                    <div class="trust-badges">
                        <div class="trust-badge">
                            <i class="fas fa-shield-alt"></i>
                            <span>256-bit SSL Security</span>
                        </div>
                        <div class="trust-badge">
                            <i class="fas fa-lock"></i>
                            <span>PCI DSS Compliant</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stage 3: Confirmation -->
        <div class="step-content" id="step3">
            <div class="confirmation-container">
                <div class="confirmation-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h1 class="confirmation-title">Thank You for Your Purchase!</h1>
                <p class="confirmation-subtitle">
                    Your Twindo Plus subscription is now active. We've sent a confirmation email with all the details.
                    You can now access your dashboard and start on your credit improvement journey.
                </p>

                <div class="order-details">
                    <h3 style="font-size: 20px; margin-bottom: 20px; text-align: center; color: #033333;">Order Details</h3>
                    <div class="detail-row">
                        <span class="detail-label">Order Number:</span>
                        <span class="detail-value">TW-20250606-931323</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Subscription Plan:</span>
                        <span class="detail-value">Twindo Plus</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Billing Cycle:</span>
                        <span class="detail-value">Monthly</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Next Payment:</span>
                        <span class="detail-value">July 6, 2025</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Total Paid:</span>
                        <span class="detail-value">£59.99</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Payment Method:</span>
                        <span class="detail-value">Visa ending in 3456</span>
                    </div>
                </div>

                <div class="confirmation-buttons">
                    <button class="btn" id="go-to-dashboard">
                        <i class="fas fa-tachometer-alt"></i> Go to Dashboard
                    </button>
                    <button class="btn btn-outline" id="back-to-home">
                        <i class="fas fa-home"></i> Back to Home
                    </button>
                </div>
            </div>
        </div>


    </div>
</div>

{{--
@push('js')
<script src="https://js.stripe.com/v3/"></script>

<script>
    document.addEventListener("DOMContentLoaded", function(event) {
        const stripe = Stripe("{{ config('stripe.stripe_pk') }}", { apiVersion: '2023-10-16' });
        const elements = stripe.elements({ clientSecret: "{{ $clientSecret }}" });

        const paymentElement = elements.create("payment", { layout: "tabs" });
        paymentElement.mount("#payment-element");

        document.querySelector("#payment-form").addEventListener("submit", handleSubmit);

        async function handleSubmit(e) {
            e.preventDefault();
            setLoading(true);

            const { error } = await stripe.confirmPayment({
                elements,
                confirmParams: {
                    return_url: "{{ route('checkout.success') }}",
                    receipt_email: "{{ Auth::user()->email }}",
                },
            });

            if (error) {
                showMessage(error.message);
            } else {
                showMessage("An unexpected error occurred.");
            }

            setLoading(false);
        }

        function showMessage(messageText) {
            const messageContainer = document.querySelector("#payment-message");
            messageContainer.classList.remove("hidden");
            messageContainer.textContent = messageText;

            setTimeout(function () {
                messageContainer.classList.add("hidden");
                messageContainer.textContent = "";
            }, 4000);
        }

        function setLoading(isLoading) {
            const submitBtn = document.querySelector("#complete-purchase");
            if (isLoading) {
                submitBtn.disabled = true;
            } else {
                submitBtn.disabled = false;
            }
        }
    });
</script>

@endpush --}}

{{-- @push('js')
<script src="https://js.stripe.com/v3/"></script>

<script>
    let stripe;
    let elements;
    let paymentElement;

    function mountStripe(clientSecret) {
        stripe = Stripe("{{ config('stripe.stripe_pk') }}", { apiVersion: '2023-10-16' });
        elements = stripe.elements({ clientSecret });

        if (paymentElement) {
            paymentElement.unmount();
        }

        paymentElement = elements.create("payment", { layout: "tabs" });
        paymentElement.mount("#payment-element");

        const form = document.querySelector("#payment-form");
        if (form) {
            form.removeEventListener("submit", handleSubmit); // prevent duplicate
            form.addEventListener("submit", handleSubmit);
        }
    }

    async function handleSubmit(e) {
        e.preventDefault();
        setLoading(true);

        const { error } = await stripe.confirmPayment({
            elements,
            confirmParams: {
                return_url: "{{ route('checkout.success') }}",
                receipt_email: "{{ Auth::user()->email }}",
            },
        });

        if (error) {
            showMessage(error.message);
        } else {
            showMessage("An unexpected error occurred.");
        }

        setLoading(false);
    }

    function showMessage(messageText) {
        const messageContainer = document.querySelector("#payment-message");
        if (!messageContainer) return;
        messageContainer.classList.remove("hidden");
        messageContainer.textContent = messageText;

        setTimeout(() => {
            messageContainer.classList.add("hidden");
            messageContainer.textContent = "";
        }, 4000);
    }

    function setLoading(isLoading) {
        const submitBtn = document.querySelector("#complete-purchase");
        if (!submitBtn) return;
        submitBtn.disabled = isLoading;
    }

    document.addEventListener("DOMContentLoaded", () => {
        const initialSecret = @json($clientSecret ?? null);
        if (initialSecret) {
            mountStripe(initialSecret);
        }
    });


Livewire.on('stripe-updated', ({ clientSecret }) => {
    elements = stripe.elements({ clientSecret });
    cardElement = elements.create('card');
    cardElement.mount('#card-element');
});

</script>



@endpush --}}

{{-- @script
 @push('js')
<script src="https://js.stripe.com/v3/"></script>
<script>
    let stripe;
    let elements;
    let paymentElement;

    function mountStripe(clientSecret) {
        // Clean up existing elements before reinitializing
        if (paymentElement) {
            paymentElement.unmount();
            paymentElement = null;
        }

        stripe = Stripe("{{ config('stripe.stripe_pk') }}", { apiVersion: '2023-10-16' });
        elements = stripe.elements({ clientSecret });

        paymentElement = elements.create("payment", { layout: "tabs" });
        paymentElement.mount("#payment-element");

        const form = document.querySelector("#payment-form");
        if (form) {
            form.removeEventListener("submit", handleSubmit); // prevent duplicate
            form.addEventListener("submit", handleSubmit);
        }
    }

    async function handleSubmit(e) {
        e.preventDefault();
        setLoading(true);

        const { error } = await stripe.confirmPayment({
            elements,
            confirmParams: {
                return_url: "{{ route('checkout.success') }}",
                receipt_email: "{{ Auth::user()->email }}",
            },
        });

        if (error) {
            showMessage(error.message);
        } else {
            showMessage("An unexpected error occurred.");
        }

        setLoading(false);
    }

    function showMessage(messageText) {
        const messageContainer = document.querySelector("#payment-message");
        if (!messageContainer) return;
        messageContainer.classList.remove("hidden");
        messageContainer.textContent = messageText;

        setTimeout(() => {
            messageContainer.classList.add("hidden");
            messageContainer.textContent = "";
        }, 4000);
    }

    function setLoading(isLoading) {
        const submitBtn = document.querySelector("#complete-purchase");
        if (!submitBtn) return;
        submitBtn.disabled = isLoading;
    }

    document.addEventListener("DOMContentLoaded", () => {
        const initialSecret = @json($clientSecret ?? null);
        if (initialSecret) {
            mountStripe(initialSecret);
        }
    });


    Livewire.on('stripe-updated', ({ clientSecret, paymentIntentId }) => {

    if (clientSecret) {
        mountStripe(clientSecret);

        const newUrl = new URL(window.location.href);
        newUrl.searchParams.set('payment_intent', paymentIntentId);
        newUrl.searchParams.set('payment_intent_client_secret', clientSecret);
        window.history.replaceState(null, '', newUrl.toString());
    }
});
</script>
@endpush

@endscript --}}

 @script
@push('js')
<script src="https://js.stripe.com/v3/"></script>
<script>
    // Use 'livewire:navigated' to ensure this runs on initial load and after any Livewire navigation.
    document.addEventListener('livewire:navigated', () => {
        const useremail = @json($useremail ?? null);
        let stripe;
        let elements;
        let paymentElement;
        const form = document.getElementById('payment-form');

        // This function handles both the initial setup and the re-initialization
        function setupStripe(clientSecret) {
            if (!clientSecret) {
                return;
            }

            stripe = Stripe("{{ config('stripe.stripe_pk') }}", { apiVersion: '2023-10-16' });
            elements = stripe.elements({ clientSecret });

            const paymentElementContainer = document.getElementById('payment-element');

            // This is the key to re-initialization: clear the container before mounting again.
            if (paymentElementContainer) {
                paymentElementContainer.innerHTML = '';
            }

            paymentElement = elements.create("payment", { layout: "tabs" });
            paymentElement.mount("#payment-element");
        }

        async function handleSubmit(e) {
            e.preventDefault();
            setLoading(true);

            // Use the most up-to-date stripe and elements instances
            const { error } = await stripe.confirmPayment({
                elements,
                confirmParams: {
                    return_url: "{{ route('checkout.success') }}",

                    receipt_email: useremail,
                },
            });

            if (error) {
                showMessage(error.message);
            } else {
                showMessage("An unexpected error occurred.");
            }

            setLoading(false);
        }

        // --- Event Listeners & Initial Setup ---

        if (form) {
            form.addEventListener('submit', handleSubmit);
        }

        // Initial setup when the page first loads
        const initialSecret = @json($clientSecret ?? null);
        setupStripe(initialSecret);

        // Listen for the event from Livewire to re-initialize the form

    //         Livewire.on('stripe-updated', ({ clientSecret, paymentIntentId }) => {
    //     console.log('Stripe updated:', { clientSecret, paymentIntentId }); // Debug log
    //     if (clientSecret) {
    //         setupStripe(clientSecret);

    //         const newUrl = new URL(window.location.href);
    //         newUrl.searchParams.set('payment_intent', paymentIntentId);
    //         newUrl.searchParams.set('payment_intent_client_secret', clientSecret);
    //         window.history.replaceState(null, '', newUrl.toString());
    //     }
    // });

    Livewire.on('stripe-updated', (data) => {
    console.log('Stripe updated event data:', data);
    const eventData = data[0] || {}; // Access the first object in the array, fallback to empty object
    const { clientSecret, paymentIntentId } = eventData;
    // console.log('Extracted:', { clientSecret, paymentIntentId });
    if (clientSecret && paymentIntentId) {
        // mountStripe(clientSecr/et);
         setupStripe(clientSecret);
        console.log('Extracted:', { clientSecret, paymentIntentId });
        const newUrl = new URL(window.location.href);
        newUrl.searchParams.set('payment_intent', paymentIntentId);
        newUrl.searchParams.set('payment_intent_client_secret', clientSecret);
        window.history.replaceState(null, '', newUrl.toString());
    } else {
        console.error('Missing clientSecret or paymentIntentId:', { clientSecret, paymentIntentId });
    }
});


Livewire.on('reloadPage', () => {
        window.location.reload(); // Full page reload
    });

        // --- Helper Functions ---
        function showMessage(messageText) {
            const messageContainer = document.querySelector("#payment-message");
            messageContainer.classList.remove("hidden");
            messageContainer.textContent = messageText;
            setTimeout(() => { messageContainer.classList.add("hidden"); messageContainer.textContent = ""; }, 5000);
        }

        function setLoading(isLoading) {
            const submitBtn = document.querySelector('button[type="submit"]');
            if (!submitBtn) return;

            if (isLoading) {
                submitBtn.disabled = true;
                submitBtn.innerHTML = 'Processing...';
            } else {
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<i class="fas fa-lock"></i> Complete Purchase';
            }
        }
    });
</script>

@endpush
@endscript

{{-- @script
@push('js')
<script src="https://js.stripe.com/v3/"></script>
<script>
    let stripe;
    let elements;
    let paymentElement;
    let currentClientSecret;

    function mountStripe(clientSecret) {
        // Clean up existing elements
        if (paymentElement) {
            paymentElement.destroy(); // Use destroy() to fully remove
            paymentElement = null;
        }
        if (elements) {
            elements = null;
        }

        stripe = Stripe("{{ config('stripe.stripe_pk') }}", { apiVersion: '2023-10-16' });
        elements = stripe.elements({ clientSecret });
        currentClientSecret = clientSecret;

        paymentElement = elements.create("payment", { layout: "tabs" });
        paymentElement.mount("#payment-element");

        const form = document.querySelector("#payment-form");
        if (form) {
            form.removeEventListener("submit", handleSubmit); // Prevent duplicate listeners
            form.addEventListener("submit", handleSubmit);
        }
    }

    // async function handleSubmit(e) {
    //     e.preventDefault();
    //     setLoading(true);

    //     const { error } = await stripe.confirmPayment({
    //         elements,
    //         confirmParams: {
    //             return_url: "{{ route('checkout.success') }}",
    //             receipt_email: "{{ Auth::user()->email }}",
    //         },
    //     });

    //     if (error) {
    //         showMessage(error.message);
    //     } else {
    //         showMessage("An unexpected error occurred.");
    //     }

    //     setLoading(false);
    // }

    async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);

    // Wait for elements to be ready
    await new Promise(resolve => setTimeout(resolve, 500)); // 500ms delay

    const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
            return_url: "{{ route('checkout.success') }}",
            receipt_email: "{{ Auth::user()->email }}",
        },
    });

    if (error) {
        showMessage(error.message);
    } else {
        showMessage("An unexpected error occurred.");
    }

    setLoading(false);
}

    function showMessage(messageText) {
        const messageContainer = document.querySelector("#payment-message");
        if (!messageContainer) return;
        messageContainer.classList.remove("hidden");
        messageContainer.textContent = messageText;

        setTimeout(() => {
            messageContainer.classList.add("hidden");
            messageContainer.textContent = "";
        }, 4000);
    }

    function setLoading(isLoading) {
        const submitBtn = document.querySelector("#payment-form button[type='submit']");
        if (!submitBtn) return;
        submitBtn.disabled = isLoading;
    }

    document.addEventListener("DOMContentLoaded", () => {
        const initialSecret = @json($clientSecret ?? null);
        if (initialSecret) {
            mountStripe(initialSecret);
        }
    });

    // Livewire.on('stripe-updated', ({ clientSecret, paymentIntentId }) => {
    //     if (clientSecret) {
    //         mountStripe(clientSecret);

    //         // Update URL parameters
    //         const newUrl = new URL(window.location.href);
    //         newUrl.searchParams.set('payment_intent', paymentIntentId);
    //         newUrl.searchParams.set('payment_intent_client_secret', clientSecret);
    //         window.history.replaceState(null, '', newUrl.toString());
    //     }
    // });
    Livewire.on('stripe-updated', ({ clientSecret, paymentIntentId }) => {
    if (clientSecret) {
        console.log('Stripe updated:', { clientSecret, paymentIntentId }); // Debug log
        mountStripe(clientSecret);

        const newUrl = new URL(window.location.href);
        newUrl.searchParams.set('payment_intent', paymentIntentId);
        newUrl.searchParams.set('payment_intent_client_secret', clientSecret);
        window.history.replaceState(null, '', newUrl.toString());
    }
});
</script>
@endpush
@endscript --}}

{{-- @script
@push('js')
<script src="https://js.stripe.com/v3/"></script>
<script>
    console.log('Livewire and Stripe JS initialized'); // Debug log

    let stripe;
    let elements;
    let paymentElement;
    let currentClientSecret;

    function mountStripe(clientSecret) {
        if (paymentElement) {
            paymentElement.destroy();
            paymentElement = null;
        }
        if (elements) {
            elements = null;
        }

        stripe = Stripe("{{ config('stripe.stripe_pk') }}", { apiVersion: '2023-10-16' });
        elements = stripe.elements({ clientSecret });
        currentClientSecret = clientSecret;

        paymentElement = elements.create("payment", { layout: "tabs" });
        paymentElement.mount("#payment-element");

        const form = document.querySelector("#payment-form");
        if (form) {
            form.removeEventListener("submit", handleSubmit);
            form.addEventListener("submit", handleSubmit);
        }
    }

    async function handleSubmit(e) {
        e.preventDefault();
        setLoading(true);

        await new Promise(resolve => setTimeout(resolve, 500)); // Delay for readiness

        const { error } = await stripe.confirmPayment({
            elements,
            confirmParams: {
                return_url: "{{ route('checkout.success') }}",
                receipt_email: "{{ Auth::user()->email }}",
            },
        });

        if (error) {
            showMessage(error.message);
        } else {
            showMessage("An unexpected error occurred.");
        }

        setLoading(false);
    }

    function showMessage(messageText) {
        const messageContainer = document.querySelector("#payment-message");
        if (!messageContainer) return;
        messageContainer.classList.remove("hidden");
        messageContainer.textContent = messageText;

        setTimeout(() => {
            messageContainer.classList.add("hidden");
            messageContainer.textContent = "";
        }, 4000);
    }

    function setLoading(isLoading) {
        const submitBtn = document.querySelector("#payment-form button[type='submit']");
        if (!submitBtn) return;
        submitBtn.disabled = isLoading;
    }

    document.addEventListener("DOMContentLoaded", () => {
        const initialSecret = @json($clientSecret ?? null);
        if (initialSecret) {
            mountStripe(initialSecret);
        }
    });

    Livewire.on('stripe-updated', ({ clientSecret, paymentIntentId }) => {
        console.log('Stripe updated:', { clientSecret, paymentIntentId }); // Debug log
        if (clientSecret) {
            mountStripe(clientSecret);

            const newUrl = new URL(window.location.href);
            newUrl.searchParams.set('payment_intent', paymentIntentId);
            newUrl.searchParams.set('payment_intent_client_secret', clientSecret);
            window.history.replaceState(null, '', newUrl.toString());
        }
    });
</script>
@endpush
@endscript --}}