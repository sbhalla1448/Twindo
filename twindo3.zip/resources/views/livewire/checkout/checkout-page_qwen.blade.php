<div>
    <div>
        @if (session()->has('error'))
            <div class="alert alert-danger">{{ session('error') }}</div>
        @endif

        <form id="payment-form">
            <input type="hidden" name="payment_method" value="card">
            <div id="card-element"></div>
            <button id="submit">Pay Now</button>
            <div id="error-message"></div>
        </form>


    </div>


    @push('js')
        <script src="https://js.stripe.com/v3/"></script>
        <script>
            const stripe = Stripe('{{ config('stripe.stripe_pk') }}');
            const clientSecret = "{{ $clientSecret }}";

            const appearance = {
                theme: 'flat',
            };
            const elements = stripe.elements({ appearance, clientSecret });

            const card = elements.create('card');
            card.mount('#card-element');

            const form = document.getElementById('payment-form');
            form.addEventListener('submit', async (event) => {
                event.preventDefault();

                const { paymentIntent, error } = await stripe.confirmCardPayment(clientSecret, {
                    payment_method: {
                        card: card,
                        billing_details: {
                            name: '{{ Auth::user()?->name }}',
                        },
                    },
                });

                if (error) {
                    document.getElementById('error-message').textContent = error.message;
                } else if (paymentIntent?.status === 'succeeded') {
                    window.location.href = "{{ route('checkout.success') }}";
                }
            });
        </script>
        @endpush