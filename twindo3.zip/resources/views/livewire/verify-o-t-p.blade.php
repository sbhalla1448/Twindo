<div class="bg-white rounded-xl shadow-xl p-8 w-full max-w-md">

    <h2 class="text-2xl font-bold text-gray-800 mb-6 text-center">Verify OTP</h2>

        @if (session('error'))
        <h2 class="text-2xl font-bold text-gray-800 mb-6 text-center">
        {{ session('error') }}
            </h2>
        @endif


    <div class="space-y-6">

        <div class="text-center">
            <p class="text-gray-600 mb-4">Enter OTP for google 2fa</p>

        </div>
<form wire:submit="verifyOTP">
        <div>
            <label class="block text-sm font-medium text-gray-700">Enter 6-digit Code</label>
            <input type="text" wire:model="otp" placeholder="123456" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
            @error('otp') <span class="error">{{ $message }}</span> @enderror
        </div>

        <div class="flex justify-end space-x-4">
            {{-- <button class="bg-gray-300 text-gray-700 px-5 py-2 rounded-lg hover:bg-gray-400">Logout</button> --}}
            <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700">Verify </button>
        </div>
    </form>

    </div>

</div>