  <main class="flex-1 overflow-auto">
      <div class="max-w-7xl mx-auto px-6 py-10">

          <!-- Breadcrumb & Hero -->
          <section class="mb-8">
              <nav class="text-sm text-gray-500">Home / Admin / Messages & Actions</nav>
              <h2 class="text-3xl font-bold text-gray-800">Messages & Actions</h2>
          </section>

          <!-- Search, Filters, and Actions -->
          <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-6 space-y-4 md:space-y-0">


              <div class="flex space-x-4">
                  <input type="search" placeholder="Search Messages..." class="border px-4 py-2 rounded-lg w-64" wire:model.live="search">
                  <select class="border px-4 py-2 rounded-lg" wire:model.change="filter">
                      <option value="">Filter by Status</option>
                      <option value="0">Pending</option>
                      <option value="1">Completed</option>
                      <option value="deleted">Deleted</option>
                  </select>
                  @error('bulk')
                      <p>
                          {{ $message }}
                      </p>
                  @enderror
                  @if (session('message'))
                      <p>
                          {{ session('message') }}
                      </p>
                  @endif
              </div>
              <div class="flex flex-wrap gap-2 items-center">
                  <span id="selectedCountBadge" class="text-sm text-gray-600">{{ count($bulkSelect) }} Selected</span>
                  <button wire:click="applyBulkAction('markAsDone')"
                      class="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600">✔️ Mark Done</button>
                  <button wire:click="applyBulkAction('delete')"
                      class="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600">🗑️ Delete</button>
                  <button class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700"><a
                          href="{{ route('admin.messageActions.create') }}">➕ Compose</a></button>
              </div>
          </div>

          <!-- Messages List -->
          <section class="bg-white rounded-xl shadow p-6">
              <table class="w-full text-left">
                  <thead>
                      <tr class="text-sm text-gray-400">
                          <th class="py-2"><input type="checkbox"
                                  wire:click="$set('bulkSelect', @js($messages->pluck('id')))"></th>
                          <th class="py-2">From</th>
                          <th class="py-2">Subject</th>
                          <th class="py-2">Received/Created</th>
                          <th class="py-2">Status</th>
                          <th class="py-2">Actions</th>
                          <th class="py-2">Notification</th>
                      </tr>
                  </thead>
                  <tbody>

                      @foreach ($messages as $message)
                          <tr class="border-t hover:bg-gray-50">
                              <td class="py-3"><input type="checkbox" wire:model="bulkSelect"
                                      value="{{ $message->id }}">
                              </td>
                              <td class="py-3">{{ $message->user->name }}</td>
                              <td class="py-3">{{ $message->subject }}</td>
                              <td class="py-3">{{ $message->created_at->format('d M Y') }}</td>
                              <td class="py-3 text-yellow-500">
                                @if($message->draft_status == 1 )
                                    Draft
                                @else
                                {{ $message->status == 0 ? 'Pending' : 'Completed' }}
                                @endif
                              </td>
                              <td class="py-3 flex space-x-2">
                                  <button  class="text-indigo-600"
                                  wire:click="viewMessage({{$message->id}})" style="cursor: pointer;">View</button>
                                  @if ($message->done_status == 0)
                                      <a href="#" class="text-green-600">Mark Done</a>
                                  @endif
                                  @if ($message->deleted_at != null)
                                      <a href="#" class="text-red-500"
                                          wire:click="restoreMessage({{ $message->id }})">Restore</a>
                                  @else
                                      <a href="#" class="text-red-500"
                                          wire:click="deleteMessage({{ $message->id }})">Delete</a>
                                  @endif
                              </td>
                              <td class="py-3 flex space-x-2">
                                <td class="py-3">
                                    {{-- {{ $message?->latestMessage->is_seen_admin == 1 ? '🔴 Unseen':'✅ Seen' }} --}}
                                    {{ $message?->latestMessage }}
                                    {{-- @if ($message->unseen_admin)
                                        <span class="inline-flex items-center px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-700">
                                            🔴 Unseen
                                        </span>
                                    @else
                                        <span class="inline-flex items-center px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-700">
                                            ✅ Seen
                                        </span>
                                    @endif --}}
                                </td>
                              </td>
                          </tr>
                      @endforeach

                  </tbody>
              </table>
          </section>

          <!-- Pagination -->
          {{-- <div class="flex justify-between items-center mt-6">
              <span class="text-sm text-gray-600">Showing 1-20 of 84 messages</span>
              <div class="flex space-x-2">
                  <button class="px-3 py-1 border rounded-md hover:bg-gray-100">Previous</button>
                  <button class="px-3 py-1 border rounded-md hover:bg-gray-100">Next</button>
              </div>
          </div> --}}

          {{ $messages->links('vendor.pagination.message-action-admin-pagination') }}

      </div>

      @if($viewmsg == true)
      <!-- Message Thread -->
      <div class="bg-white p-6 rounded-xl shadow space-y-6">
        <h3 class="text-2xl font-bold text-indigo-700 mb-2">Message Thread</h3>
        <div class="space-y-4">
          @foreach ($usermessages as $msg)
          <div class="p-4 bg-gray-50 border rounded-lg text-sm">
              @if($msg->admin_id != null)
              <strong class="text-indigo-700">Twindo Team</strong> <span class="text-gray-400 text-xs">({{ $msg->created_at->format('d M Y') }} - {{ $msg->created_at->format('h:i A') }})</span>
              @else
              <strong class="text-indigo-700">{{ $msg->user->name }}</strong> <span class="text-gray-400 text-xs">({{ $msg->created_at->format('d M Y') }} - {{ $msg->created_at->format('h:i A') }})</span>
              @endif
              <p class="mt-1 text-gray-700">{{$msg->message}}</p>
            </div>
          @endforeach

          {{-- <div class="p-4 bg-green-50 border-green-200 border rounded-lg text-sm">
            <strong class="text-green-700">You</strong> <span class="text-gray-400 text-xs">(31 Mar 2025 - 12:45pm)</span>
            <p class="mt-1 text-gray-700">Hi, I’ve uploaded my latest council tax bill. Let me know if it’s acceptable.</p>
          </div> --}}
          {{-- <div class="p-4 bg-gray-50 border rounded-lg text-sm">
            <strong class="text-indigo-700">Twindo Team</strong> <span class="text-gray-400 text-xs">(1 Apr 2025 - 9:15am)</span>
            <p class="mt-1 text-gray-700">Thanks! We have received your upload and will review it within 48 hours.</p>
          </div> --}}
        </div>
        <div class="flex justify-between mt-4">
              {{ $usermessages->links('vendor.pagination.message-action-pagination') }}
        </div>
        <form class="space-y-4 mt-6" wire:submit="replyMessageSubmit">

          <label for="reply" class="text-gray-700 text-sm font-semibold">✏️ Write a Reply</label>
          <textarea wire:model="replyMessage" id="reply" class="w-full border-2 border-gray-300 rounded-lg p-3 text-sm bg-gray-50" rows="3" placeholder="Write your reply here..."></textarea>
              @error('replyMessage')
                  <span>{{$message}}</span>
              @enderror
          <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center bg-white" style="position: relative;">
            <p class="text-gray-500">Drag & drop a file here or click to upload</p>
            <input type="file" class="opacity-0 absolute inset-0 cursor-pointer" wire:model="uploadFile">
          </div>
          <div class="flex justify-end">
            <button type="submit"  class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-2 rounded-lg">Post Reply</button>
          </div>
        </form>
      </div>
  @endif



  </main>
