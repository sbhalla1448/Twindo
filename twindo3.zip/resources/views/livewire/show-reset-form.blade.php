<div class="max-w-5xl mx-auto px-6 py-10 space-y-10">
    {{-- <h2>Reset Password</h2>
    @if (session('status'))
    <div class="alert alert-success" role="alert">
        {{ session('status') }}
    </div>
@endif

<form method="POST" action="{{ route('password.update') }}">
    @csrf

    <input type="hidden" name="token" value="{{ $token }}" wire:model="token">
      <div class="form-group">
        <label for="email">Email Address</label>
        <input readonly id="email" type="email" wire:model="email"  @error('email') is-invalid @enderror" name="email" value="{{ $email ?? old('email') }}" required autocomplete="email" autofocus>

        @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
        @enderror
      </div>
      <div class="form-group">
        <label for="email">Password</label>
        <input id="password" type="password"  @error('password') is-invalid @enderror" name="password" required autocomplete="new-password">

        @error('password')
            <span class="invalid-feedback" role="alert">
                <strong>{{ $message }}</strong>
            </span>
        @enderror
      </div>
      <div class="form-group">
        <label for="password-confirm">Confirm Password</label>

        <div class="col-md-6">
            <input id="password-confirm" type="password"  name="password_confirmation" required autocomplete="new-password">
        </div>
      </div>


      <button type="submit">Reset Password</button>
    </form>
    <div class="back-link">
      <p><a href="{{ route('login') }}">Back to login</a></p>
    </div> --}}
    <section class="bg-white rounded-xl shadow p-8 mb-8">

        <form wire:submit="updatePassword">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                @error('email')
                    <span class="text-red-500 text-xs">{{ $message }}</span>
                @enderror


                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">New Password</label>
                    <input type="password" wire:model.live="newPassword"
                        class="w-full border border-gray-300 rounded-lg p-2 text-sm shadow-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                        placeholder="Enter new password">
                    @error('newPassword')
                        <span class="text-red-500 text-xs">{{ $message }}</span>
                    @enderror
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Confirm New Password</label>
                    <input type="password" wire:model="confirmPassword"
                        class="w-full border border-gray-300 rounded-lg p-2 text-sm shadow-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                        placeholder="Confirm new password">
                    @error('confirmPassword')
                        <span class="text-red-500 text-xs">{{ $message }}</span>
                    @enderror
                </div>


                <!-- Password Strength Meter -->
                <div class="mt-4 text-sm text-gray-600 w-full">
                    <span class="block mb-1 font-medium">Password Strength:</span>
                    <div class="w-full bg-gray-200 rounded-full h-2">
                        <div class="bg-green-500 h-2 rounded-full" style="width: {{ $passwordStrength }}%">
                        </div>
                    </div>
                    <p class="text-xs text-gray-500 mt-1">Include uppercase, lowercase, number, and symbol for a
                        stronger password. {{ $passwordStrength }}</p>
                </div>
            </div>
            <div class="mt-6 text-right">
                <div wire:loading>

                    <svg aria-hidden="true"
                        class="inline w-8 h-8 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600"
                        viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                            fill="currentColor" />
                        <path
                            d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                            fill="currentFill" />
                    </svg>

                </div>
                @if($passwordStrength == 100)
                <button type="submit"
                    class="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-lg text-sm font-medium shadow transition duration-150">
                    🔒 Update Password
                </button>
                @else
                <button type="button"
                class="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-lg text-sm font-medium shadow transition duration-150 cursor-not-allowed" disabled>
                🔒 Update Password
            </button>
                @endif
            </div>

        </form>

    </section>
    {{-- <h2 class="text-2xl font-bold text-gray-800 mb-4">🔐 Change Admin Password</h2>
        <p class="text-sm text-gray-600 mb-6">Update your password to keep your administrator account secure. Use a strong, unique password.</p>

        <form class="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div class="md:col-span-2">
            <label class="block text-sm font-medium text-gray-700 mb-1">Current Password</label>
            <input type="password" class="w-full border border-gray-300 rounded-lg p-2 text-sm shadow-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none" placeholder="Enter current password">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">New Password</label>
            <input type="password" class="w-full border border-gray-300 rounded-lg p-2 text-sm shadow-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none" placeholder="Enter new password">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Confirm New Password</label>
            <input type="password" class="w-full border border-gray-300 rounded-lg p-2 text-sm shadow-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none" placeholder="Confirm new password">
          </div>
        </form>

        <!-- Password Strength Meter -->
        <div class="mt-4 text-sm text-gray-600">
          <span class="block mb-1 font-medium">Password Strength:</span>
          <div class="w-full bg-gray-200 rounded-full h-2">
            <div class="bg-green-500 h-2 rounded-full" style="width: 75%"></div>
          </div>
          <p class="text-xs text-gray-500 mt-1">Include uppercase, lowercase, number, and symbol for a stronger password.</p>
        </div>

        <div class="mt-6 text-right">
          <button class="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-lg text-sm font-medium shadow transition duration-150">🔒 Update Password</button>
        </div>

        <p class="mt-4 text-xs text-gray-500">Last changed on: 03 March 2025 at 14:32</p> --}}


</div>
