 <!-- Main Content -->
 <main class="flex-1 overflow-auto">
     <div class="max-w-7xl mx-auto px-6 py-10 space-y-10">

         <!-- Breadcrumb & Hero -->
         <section>
             <nav class="text-sm text-gray-500">Home / Admin / Manage Documents</nav>
             <h2 class="text-3xl font-bold text-gray-800">Manage Uploaded Documents</h2>
         </section>

         <!-- Action Buttons -->
         <div class="flex justify-between items-center">
             <button wire:click="togleFilter"
                 class="flex items-center bg-gray-100 text-gray-800 px-4 py-2 rounded-lg hover:bg-gray-200">
                 🔍 <span class="ml-2">Filters</span>
             </button>
             <button class="flex items-center bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700"> <a
                     href="{{ route('admin.documents.archive.index') }}">
                     📁<span class="ml-2">Archive Documents</span> </a>
             </button>
             <button class="flex items-center bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700"> <a
                     href="{{ route('admin.documents.create') }}">
                     ➕ <span class="ml-2">Upload Document</span> </a>
             </button>
         </div>

         <!-- Filters Drawer Collapsed by Default -->
         @if ($drawarShow)
             {{-- <div id="filterDrawer" class="bg-white rounded-lg shadow p-6 hidden"> --}}
             <div id="filterDrawer" class="bg-white rounded-lg shadow p-6">
                 @if (session()->has('delete_documents'))
                     <div class="mb-4 text-green-600 text-sm font-medium">
                         {{ session('message') }}
                     </div>
                 @endif
                 <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                     <div>
                         <label class="block text-sm font-medium text-gray-700">Document Type</label>
                         <select class="mt-1 block w-full border-gray-300 rounded-md shadow-sm"
                             wire:model.change="types">


                             <option value="">All Types</option>
                             @foreach (\App\Enums\DocumentType::options() as $status)
                                 <option value="{{ $status->value }}">
                                     {{ $status->label() }}
                                 </option>
                             @endforeach
                         </select>
                     </div>
                     <div>
                         <label class="block text-sm font-medium text-gray-700">Uploaded Date (From)</label>
                         <input type="date" wire:model.live="fromDate"
                             class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                     </div>
                     <div>
                         <label class="block text-sm font-medium text-gray-700">Uploaded Date (To)</label>
                         <input type="date" wire:model.live="toDate"
                             class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                     </div>
                 </div>
                 <div class="mt-6 flex justify-end space-x-4">
                     <button wire:click="resetFilter"
                         class="bg-gray-100 hover:bg-gray-200 text-gray-800 px-6 py-2 rounded-lg">Reset</button>
                     <button class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg">Apply
                         Filters</button>
                 </div>
             </div>
         @endif

         <!-- Search & Bulk Actions -->
         <div class="flex justify-between items-center">
             <input type="search" placeholder="Search by User or Document Name..."
                 class="border px-4 py-2 rounded-lg w-1/3" wire:model.live="search">
             @error('bulk')
                 <p>{{ $message }}</p>
             @enderror
             @if (session()->has('message'))
                 <div class="bg-green-100 text-green-800 p-4 mb-4 rounded">
                     {{ session('message') }}
                 </div>
             @endif
             <select wire:model.change="bulkAction" class="border px-4 py-2 rounded-lg">
                 <option value="">Bulk Actions</option>
                 <option value="deleted">Delete Selected</option>
                 <option value="approved">Approve Selected</option>
             </select>
         </div>

         <!-- Documents Table -->
         <section class="bg-white rounded-xl shadow p-6">
             <div id="emptyState" class="hidden text-center py-16">
                 <h3 class="text-xl font-semibold text-gray-700 mb-2">No Documents Found</h3>
                 <p class="text-gray-500 mb-6">Try adjusting your filters or upload a new document.</p>
                 <button class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-lg">➕ Upload
                     Document</button>
             </div>

             <table class="w-full text-left">
                 <thead>
                     <tr class="text-sm text-gray-400">
                         <th class="py-2"><input type="checkbox"
                                 wire:click="$set('bulkSelect', @js($documents->pluck('id')))"></th>
                         <th class="py-2">User</th>
                         <th class="py-2">Document Name</th>
                         <th class="py-2">Type</th>
                         <th class="py-2">Uploaded On</th>
                         <th class="py-2">Actions</th>
                     </tr>
                 </thead>
                 <tbody>
                     @foreach ($documents as $doc)
                         <tr class="border-t hover:bg-gray-50">
                             <td class="py-3"><input type="checkbox" wire:model="bulkSelect"
                                     value="{{ $doc?->id }}"></td>
                             <td class="py-3">{{ $doc?->user->name }}</td>
                             <td class="py-3">{{ $doc?->document_name }}</td>
                             <td class="py-3">{{ $doc?->document_type }}</td>
                             <td class="py-3">{{ $doc?->created_at->format('d M Y') }}</td>
                             <td class="py-3 space-x-2">
                                 <a href="#" class="text-indigo-600">View</a>
                                 <a href="{{ route('admin.documents.edit', \Illuminate\Support\Facades\Crypt::encryptString($doc->id)) }}"
                                     class="text-blue-600">Edit</a>
                                 <a href="{{ route('admin.documents.document.archived', \Illuminate\Support\Facades\Crypt::encryptString($doc->id)) }}"
                                     class="text-yellow-600">Archive</a>
                                 <a href="{{ route('admin.documents.document.delete', \Illuminate\Support\Facades\Crypt::encryptString($doc->id)) }}"
                                     class="text-red-500">Delete</a>
                             </td>
                         </tr>
                     @endforeach
                     {{-- <tr class="border-t hover:bg-gray-50">
                         <td class="py-3"><input type="checkbox"></td>
                         <td class="py-3">Jane Doe</td>
                         <td class="py-3">Address Verification</td>
                         <td class="py-3">Address</td>
                         <td class="py-3">08 Apr 2025</td>
                         <td class="py-3 space-x-2">
                             <a href="#" class="text-indigo-600">View</a>
                             <a href="#" class="text-blue-600">Edit</a>
                             <a href="#" onclick="return confirmArchive();" class="text-yellow-600">Archive</a>
                             <a href="#" onclick="return confirmDelete();" class="text-red-500">Delete</a>
                         </td>
                     </tr> --}}
                 </tbody>
             </table>
     </div>
     <!-- Email Template Trigger -->
     <section class="max-w-7xl mx-auto px-6 pb-10">
         <div class="bg-white p-6 rounded-xl shadow">
             <h3 class="text-lg font-semibold text-gray-800 mb-4">📧 Send Email to User</h3>
             @if (session()->has('message'))
                 <div class="mb-4 text-green-600 text-sm font-medium">
                     {{ session('message') }}
                 </div>
             @endif

             @if (session()->has('error'))
                 <div class="mb-4 text-green-600 text-sm font-medium">
                     {{ session('message') }}
                 </div>
             @endif
             <form wire:submit="sendEmail" class="space-y-4" enctype="multipart/form-data">
                 <div>
                     <label class="block text-sm font-medium text-gray-700 mb-1">Select Customer</label>
                     <select wire:model.live="user" class="w-full border rounded p-2 text-sm">
                         <option value="">Choose Customer</option>
                         @foreach ($users as $user)
                             <option value="{{ $user->id }}">{{ $user->name }}</option>
                         @endforeach
                     </select>
                     {{-- <p>{{ $uname }}</p> --}}
                 </div>

                 <div>
                     <label class="block text-sm font-medium text-gray-700 mb-1">Select Template</label>
                     <select wire:model.live="templateId" class="w-full border rounded p-2 text-sm">
                         <option value="">Choose an email template</option>
                         @foreach ($emailTemplates as $temp)
                             <option value="{{ $temp->id }}">{{ $temp->email_subject }}</option>
                         @endforeach
                     </select>
                 </div>
                 <div class="grid md:grid-cols-2 gap-4">
                     <div>
                         <label class="block text-sm font-medium text-gray-700 mb-1">CC</label>
                         <input type="email" wire:model="cc" class="w-full border rounded p-2 text-sm"
                             placeholder="cc@example.com">
                     </div>
                     <div>
                         <label class="block text-sm font-medium text-gray-700 mb-1">BCC</label>
                         <input type="email" wire:model="bcc" class="w-full border rounded p-2 text-sm"
                             placeholder="bcc@example.com">
                     </div>
                 </div>
                 <div>
                     <label class="block text-sm font-medium text-gray-700 mb-1">Attachments</label>
                     <input type="file" wire:model="attachment"
                         class="block w-full text-sm text-gray-700 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
                 </div>
                 <div>
                     <label class="block text-sm font-medium text-gray-700 mb-1">Message Preview</label>
                     <textarea wire:model="mailBody" rows="6" class="w-full border rounded p-2 text-sm"
                         placeholder="Message preview...">



</textarea>
                     <p class="mt-1 text-xs text-gray-500 italic">You can preview the final version of this email
                         before sending.</p>
                 </div>
                 <div class="text-right">
                     @if (session()->has('error'))
                         <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
                             {{ session('error') }}
                         </div>
                     @endif
                     @if (session()->has('template_message'))
                         <div class="bg-blue-100 border border-blue-400 text-blue-700 px-4 py-3 rounded mb-4">
                             {{ session('template_message') }}
                         </div>
                     @endif
                     <button wire:click="manageTemplate" type="button"
                         class="text-sm text-gray-600 hover:underline mr-4">🛠️ Manage Templates</button>
                     <button wire:click="previewEmail" type="button"
                         class="text-sm text-indigo-600 hover:underline mr-4">👁️ Preview
                         Email</button>
                     <div wire:loading>

                         <svg aria-hidden="true"
                             class="inline w-8 h-8 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600"
                             viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                             <path
                                 d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                                 fill="currentColor" />
                             <path
                                 d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                                 fill="currentFill" />
                         </svg>

                     </div>
                     <button type="submit"
                         class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm">📤
                         Send Email</button>
                 </div>
             </form>

             @if ($showPreview)
                 <div class="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
                     <div class="bg-white rounded-lg shadow-lg p-6 w-full max-w-2xl max-h-[80vh] overflow-y-auto">
                         <div class="flex justify-between items-center mb-4">
                             <h2 class="text-xl font-semibold">Email Preview</h2>
                             <button wire:click="closePreview"
                                 class="text-gray-500 hover:text-gray-700">&times;</button>
                         </div>
                         <div class="prose">
                             {!! $previewContent !!}
                         </div>
                     </div>
                 </div>
             @endif

             @if ($manageTemplatePreview)
                 <div class="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
                     <div class="bg-white rounded-lg shadow-lg p-6 w-full max-w-2xl max-h-[80vh] overflow-y-auto">
                         <div class="flex justify-between items-center mb-4">
                             <h2 class="text-xl font-semibold">
                                 {{ $editingTemplateId ? 'Edit Template' : 'Create Template' }}</h2>
                             <button wire:click="closeManagePreview"
                                 class="text-gray-500 hover:text-gray-700">×</button>
                         </div>
                         <div class="prose">
                             <form wire:submit.prevent="saveTemplate">
                                 <div class="mb-4">
                                     <label for="templateSubject"
                                         class="block text-sm font-medium text-gray-700">Email
                                         Subject</label>
                                     <input type="text" class="w-full border rounded p-2 text-sm"
                                         id="templateSubject" wire:model="templateSubject">
                                     @error('templateSubject')
                                         <span class="text-red-500 text-sm">{{ $message }}</span>
                                     @enderror
                                 </div>

                                 <div class="mb-4">
                                     <label for="templateBody" class="block text-sm font-medium text-gray-700">Email
                                         Body</label>
                                     <textarea rows="6" class="w-full border rounded p-2 text-sm" id="templateBody" wire:model="templateBody"
                                         placeholder="Enter email body..."></textarea>
                                     @error('templateBody')
                                         <span class="text-red-500 text-sm">{{ $message }}</span>
                                     @enderror
                                 </div>

                                 <div class="flex justify-end">
                                     <button type="submit"
                                         class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                                         {{ $editingTemplateId ? 'Update Template' : 'Save Template' }}
                                     </button>
                                 </div>
                             </form>

                             <h3 class="text-lg font-semibold mt-6">Template List</h3>
                             @if ($emailTemplates->isEmpty())
                                 <p class="text-gray-500">No templates found.</p>
                             @else
                                 <table class="w-full mt-4 border-collapse">
                                     <thead>
                                         <tr class="bg-gray-100">
                                             <th class="border p-2 text-left">Subject</th>
                                             <th class="border p-2 text-left">Body</th>
                                             <th class="border p-2 text-left">Actions</th>
                                         </tr>
                                     </thead>
                                     <tbody>
                                         @foreach ($emailTemplates as $template)
                                             <tr>
                                                 <td class "border p-2">{{ $template->email_subject }}</td>
                                                 <td class="border p-2">{{ Str::limit($template->email_body, 50) }}
                                                 </td>
                                                 <td class="border p-2">
                                                     <button wire:click="editTemplate({{ $template->id }})"
                                                         class="bg-yellow-500 text-white px-2 py-1 rounded hover:bg-yellow-600">Edit</button>
                                                     <button wire:click="deleteTemplate({{ $template->id }})"
                                                         class="bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600"
                                                         onclick="return confirm('Are you sure you want to delete this template?')">Delete</button>
                                                 </td>
                                             </tr>
                                         @endforeach
                                     </tbody>
                                 </table>
                             @endif
                         </div>
                     </div>
                 </div>
             @endif
         </div>
     </section>

 </main>


 {{-- @script
     @push('js')
         <script>
             function confirmDelete() {
                 return confirm('Are you sure you want to delete this document?');
             }

             function confirmBulkAction() {
                 return confirm('Are you sure you want to apply the selected bulk action to the selected documents?');
             }

             function toggleFilters() {
                 document.getElementById('filterDrawer').classList.toggle('hidden');
             }

             function checkEmptyState() {
                 const tableBody = document.querySelector('tbody');
                 const emptyState = document.getElementById('emptyState');
                 if (tableBody.children.length === 0) {
                     emptyState.classList.remove('hidden');
                 } else {
                     emptyState.classList.add('hidden');
                 }
             }

             function toggleSelectAll(source) {
                 const checkboxes = document.querySelectorAll('tbody input[type="checkbox"]');
                 checkboxes.forEach(checkbox => checkbox.checked = source.checked);
             }

             function confirmArchive() {
                 return confirm('Are you sure you want to archive this document?');
             }

             window.onload = checkEmptyState;
         </script>
     @endpush
 @endscript --}}
