<main class="flex-1 p-8 space-y-10">

    <!-- Hero -->
    <div class="bg-white p-8 rounded-xl shadow">
      <h1 class="text-3xl font-bold text-indigo-700 mb-2">Messages & Actions</h1>
      <p class="text-gray-600">This page keeps a complete log of communication, documents and required actions for your credit repair journey. You’ll find updates from Twindo, your uploads, and all tracked steps.</p>
    </div>

    <!-- Latest Updates -->
    <div class="bg-white p-8 rounded-xl shadow">
      <h2 class="text-2xl font-bold text-indigo-700 mb-4">Latest Updates</h2>
      <div class="overflow-x-auto">
        <table class="min-w-full text-sm">
          <thead class="bg-gray-100 text-gray-700">
            <tr>
              <th class="py-3 px-4 text-left">Date</th>
              <th class="py-3 px-4 text-left">From</th>
              <th class="py-3 px-4 text-left">Subject</th>
              <th class="py-3 px-4 text-left">Status</th>
              <th class="py-3 px-4 text-left">Action</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-gray-200">
            @foreach ($messages as $mes)


            <tr class="hover:bg-gray-50" wire:click="viewMessage({{$mes->id}})" style="cursor: pointer;">
              <td class="py-3 px-4">{{$mes->created_at->format('d M Y')}}</td>
              <td class="py-3 px-4">{{$mes->user_id== Auth::user()->id ? 'you':'Twindo Team'}}</td>
              <td class="py-3 px-4">{{$mes->subject}}</td>
              <td class="py-3 px-4 text-orange-500 font-semibold">⚠️ In Progress</td>
              <td class="py-3 px-4">
                <a href="#" class="text-indigo-600 font-bold hover:underline">View</a></td>
            </tr>
            @endforeach

          </tbody>
        </table>
        <div class="flex justify-between mt-4">
            {{ $messages->links('vendor.pagination.message-action-pagination') }}
      </div>
      </div>
    </div>

    @if($viewmsg == true)
    <!-- Message Thread -->
    <div class="bg-white p-6 rounded-xl shadow space-y-6">
      <h3 class="text-2xl font-bold text-indigo-700 mb-2">Message Thread</h3>
      <div class="space-y-4">
        @foreach ($usermessages as $msg)
        <div class="p-4 bg-gray-50 border rounded-lg text-sm">
            @if($msg->admin_id != null)
            <strong class="text-indigo-700">Twindo Team</strong> <span class="text-gray-400 text-xs">({{ $msg->created_at->format('d M Y') }} - {{ $msg->created_at->format('h:i A') }})</span>
            @else
            <strong class="text-indigo-700">You</strong> <span class="text-gray-400 text-xs">({{ $msg->created_at->format('d M Y') }} - {{ $msg->created_at->format('h:i A') }})</span>
            @endif
            <p class="mt-1 text-gray-700">{{$msg->message}}</p>
          </div>
        @endforeach

        {{-- <div class="p-4 bg-green-50 border-green-200 border rounded-lg text-sm">
          <strong class="text-green-700">You</strong> <span class="text-gray-400 text-xs">(31 Mar 2025 - 12:45pm)</span>
          <p class="mt-1 text-gray-700">Hi, I’ve uploaded my latest council tax bill. Let me know if it’s acceptable.</p>
        </div> --}}
        {{-- <div class="p-4 bg-gray-50 border rounded-lg text-sm">
          <strong class="text-indigo-700">Twindo Team</strong> <span class="text-gray-400 text-xs">(1 Apr 2025 - 9:15am)</span>
          <p class="mt-1 text-gray-700">Thanks! We have received your upload and will review it within 48 hours.</p>
        </div> --}}
      </div>
      <div class="flex justify-between mt-4">
            {{ $usermessages->links('vendor.pagination.message-action-pagination') }}
      </div>
      <form class="space-y-4 mt-6" wire:submit="replyMessageSubmit">
        <label for="reply" class="text-gray-700 text-sm font-semibold">✏️ Write a Reply</label>
        <textarea wire:model="replyMessage" id="reply" class="w-full border-2 border-gray-300 rounded-lg p-3 text-sm bg-gray-50" rows="3" placeholder="Write your reply here..."></textarea>
            @error('replyMessage')
                <span>{{$message}}</span>
            @enderror
        <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center bg-white" style="position: relative;">
          <p class="text-gray-500">Drag & drop a file here or click to upload</p>
          <input type="file" class="opacity-0 absolute inset-0 cursor-pointer" wire:model="uploadFile">
        </div>
        <div class="flex justify-end">
          <button type="submit"  class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-2 rounded-lg">Post Reply</button>
        </div>
      </form>
    </div>
@endif
    <!-- Upcoming Tasks -->
    <div class="bg-white p-8 rounded-xl shadow">
      <h3 class="text-2xl font-bold text-indigo-700 mb-4">Upcoming Tasks 🔔 (3)</h3>
      <div class="overflow-x-auto">
        <table class="min-w-full text-sm">
          <thead class="bg-gray-100 text-gray-700">
            <tr>
              <th class="py-3 px-4 text-left">Task</th>
              <th class="py-3 px-4 text-left">Assigned By</th>
              <th class="py-3 px-4 text-left">Deadline</th>
              <th class="py-3 px-4 text-left">Status</th>
              <th class="py-3 px-4 text-left">Action</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-gray-200">
            <tr>
              <td class="py-3 px-4">Upload March 2025 Council Tax Bill</td>
              <td class="py-3 px-4">Twindo Team</td>
              <td class="py-3 px-4">03 Apr 2025</td>
              <td class="py-3 px-4 text-orange-500">⚠️ In Progress</td>
              <td class="py-3 px-4"><a href="#" class="text-indigo-600 hover:underline">View</a></td>
            </tr>
            <tr>
              <td class="py-3 px-4">Add New Debit Card (ending 8821)</td>
              <td class="py-3 px-4">Twindo Team</td>
              <td class="py-3 px-4">10 Apr 2025</td>
              <td class="py-3 px-4 text-blue-500">🔵 Pending</td>
              <td class="py-3 px-4"><a href="#" class="text-indigo-600 hover:underline">View</a></td>
            </tr>
            <tr>
              <td class="py-3 px-4">Review Loan Options (Credit Builder)</td>
              <td class="py-3 px-4">Twindo Advisor</td>
              <td class="py-3 px-4">15 Apr 2025</td>
              <td class="py-3 px-4 text-gray-600">❗ Not Started</td>
              <td class="py-3 px-4"><a href="#" class="text-indigo-600 hover:underline">View</a></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <form action="{{ route('store.note') }}" method="POST">
        @csrf
    <!-- Quick Note -->
    <div class="bg-white p-8 rounded-xl shadow">
      <h3 class="text-2xl font-bold text-indigo-700 mb-4">Quick Note</h3>
      <label for="note" class="text-gray-700 text-sm font-semibold">📝 Save a Private Note</label>
      <textarea id="note" name="description" rows="4" placeholder="Reminder: Follow up on Experian credit report next week.&#10;Upload new proof of address by Thursday!&#10;Research debt consolidation options before April." class="w-full border-2 border-gray-300 rounded-lg p-4 text-sm bg-gray-50">{{$note->description ?? ''}}</textarea>
      <div class="flex justify-end mt-4">
        <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-2 rounded-lg">Save Note</button>
      </div>
      <p class="text-gray-400 text-xs mt-2">Last updated: {{$note->updated_at->format('d M Y')}}</p>
    </div>
</form>
  </main><!-- Main Content -->
