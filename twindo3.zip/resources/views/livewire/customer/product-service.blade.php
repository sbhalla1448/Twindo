<main class="flex-1 p-8 space-y-12">
    <div class="max-w-7xl mx-auto space-y-12">

      <div class="bg-white rounded-xl shadow p-8">
        <h1 class="text-3xl font-bold text-indigo-700 mb-2">Products & Services</h1>
        <p class="text-gray-600">This section gives you a complete overview of all the services, financial products, and support tools included with your Twindo plan. You can manage your current plan, explore upgrade options, add powerful extras, and access helpful resources to assist in your financial journey.</p>
      </div>

      <div class="bg-white rounded-xl shadow p-8">
        <h2 class="text-2xl font-bold text-indigo-700 mb-6">Your Current Plan</h2>
        <div class="p-6 bg-green-50 rounded-lg border border-green-300">
          <ul class="space-y-2 text-gray-700">
            <li><strong>Plan:</strong> {{ $currentSubscription->plan->name }}</li>
            <li><strong>Signed Up:</strong> {{$currentSubscription->created_at->format('d M Y')}}</li>
            <li><strong>Status:</strong> {{$currentSubscription->status}}</li>
          </ul>
          <div class="mt-6 flex gap-4">
            <button class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-4 py-2 rounded">Manage Plan</button>
            <button class="bg-yellow-500 hover:bg-yellow-600 text-white font-semibold px-4 py-2 rounded" wire:click="planActivity('Paused')">Pause Plan</button>
            <button class="bg-red-500 hover:bg-red-600 text-white font-semibold px-4 py-2 rounded" wire:click="planActivity('Cancelled')">Cancel Plan</button>
          </div>
        </div>
      </div>

      @if($viewTools)
      {{-- <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div class="bg-white rounded-lg shadow-lg p-6 w-1/2">
          <h2 id="viewResourceTitle" class="text-2xl font-bold mb-4"></h2>
          <p class="text-gray-600">{{$currentSubscription->plan->name}}</p>



          <div class="text-right mt-6">
              <button wire:click="closeDialog"
                  class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg">Cancel</button>
              <button wire:click="cancelPlan"
                  class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg">Yes</button>
          </div>
      </div>
  </div> --}}
  <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
    <!-- Modal Container -->
    <div class="bg-white rounded-lg shadow-xl w-full max-w-md">
        <!-- Modal Header -->
        <div class="flex items-center justify-between p-6 border-b border-gray-200">
            <h2 class="text-lg font-semibold text-gray-900"> {{ $title }} activity?</h2>
            <button wire:click="closeDialog" class="text-gray-400 hover:text-gray-600 transition-colors">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>

        <!-- Modal Body -->
        <div class="p-6 space-y-4">
            <!-- Warning Alert -->
            <div class="bg-red-50 border border-red-200 rounded-md p-4">
                <div class="flex items-start">
                    <div class="flex-shrink-0">
                        <svg class="w-5 h-5 text-red-400 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"></path>
                        </svg>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-red-800">
                            Are you sure that you want to {{ $title }} "{{ $currentSubscription->plan->name }}"?
                        </p>
                        {{-- <ul class="mt-2 text-sm text-red-700">
                            <li class="flex items-start">
                                <span class="inline-block w-1 h-1 bg-red-400 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                                Deleted activities cannot be restored.
                            </li>
                        </ul> --}}
                    </div>
                </div>
            </div>

            <!-- Checkbox -->
            {{-- <div class="flex items-start">
                <input
                    type="checkbox"
                    id="understand"
                    class="mt-1 h-4 w-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500"
                    checked
                >
                <label for="understand" class="ml-3 text-sm text-gray-700">
                    I understand that this action cannot be undone.
                </label>
            </div> --}}
        </div>

        <!-- Modal Footer -->
        <div class="flex justify-end space-x-3 px-6 py-4 border-t border-gray-200">
            <button wire:click="closeDialog" class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition-colors">
                Cancel
            </button>
            <button wire:click="makeYes" class="px-4 py-2 text-sm font-medium text-white bg-teal-600 border border-transparent rounded-md hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition-colors">
                OK
            </button>
        </div>
    </div>
</div>
  @endif

      <div class="bg-white rounded-xl shadow p-8">
        <h2 class="text-2xl font-bold text-indigo-700 mb-6">Upgrade Options</h2>
        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div class="flex flex-col border border-gray-200 rounded-xl p-6 bg-gray-50 hover:shadow-lg">
            <h4 class="text-lg font-semibold text-indigo-700 mb-2">Essential Plan</h4>
            <p class="text-gray-600 text-sm mb-4">Basic credit repair and debt advice, budgeting support.</p>
            <button class="mt-auto bg-green-600 hover:bg-green-700 text-white font-semibold px-4 py-2 rounded"><a  href="{{ route('checkout.page','essential_plan') }}">  Upgrade Now (£29.99/mo) </a></button>
            <p class="text-xs text-gray-400 mt-2">🛡️ Secure Checkout</p>
          </div>
          <div class="flex flex-col border border-gray-200 rounded-xl p-6 bg-gray-50 hover:shadow-lg">
            <h4 class="text-lg font-semibold text-indigo-700 mb-2">Plus Plan</h4>
            <p class="text-gray-600 text-sm mb-4">Credit improvement, debt negotiation support, insolvency guidance.</p>
            <button class="mt-auto bg-green-600 hover:bg-green-700 text-white font-semibold px-4 py-2 rounded"><a  href="{{ route('checkout.page','plus_plan') }}"> Upgrade Now (£59.99/mo) </a></button>
            <p class="text-xs text-gray-400 mt-2">🛡️ Secure Checkout</p>
          </div>
          <div class="flex flex-col border border-gray-200 rounded-xl p-6 bg-gray-50 hover:shadow-lg">
            <h4 class="text-lg font-semibold text-indigo-700 mb-2">Elite Plan</h4>
            <p class="text-gray-600 text-sm mb-4">Legal help, full dispute management, financial coaching access.</p>
            <button class="mt-auto bg-green-600 hover:bg-green-700 text-white font-semibold px-4 py-2 rounded"> <a  href="{{ route('checkout.page','elite_plan') }}"> Upgrade Now (£99.99/mo) </a></button>
            <p class="text-xs text-gray-400 mt-2">🛡️ Secure Checkout</p>
          </div>
          <div class="flex flex-col border border-gray-200 rounded-xl p-6 bg-gray-50 hover:shadow-lg">
            <h4 class="text-lg font-semibold text-indigo-700 mb-2">Platinum Plan</h4>
            <p class="text-gray-600 text-sm mb-4">Full rebuild strategy, VIP support, premium finance products.</p>
            <button class="mt-auto bg-green-600 hover:bg-green-700 text-white font-semibold px-4 py-2 rounded"><a  href="{{ route('checkout.page','platinum _plan') }}"> Upgrade Now (£2,500 One-Off) </a></button>
            <p class="text-xs text-gray-400 mt-2">🛡️ Secure Checkout</p>
          </div>
          <div class="flex flex-col border border-gray-200 rounded-xl p-6 bg-gray-50 hover:shadow-lg">
            <h4 class="text-lg font-semibold text-indigo-700 mb-2">Guaranteed Essentials</h4>
            <p class="text-gray-600 text-sm mb-4">Guaranteed mobile, bank account, credit access options.</p>
            <button class="mt-auto bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded"><a  href="{{ route('checkout.page','guaranteed_essentials') }}"> Add to Plan (£100)</a></button>
            <p class="text-xs text-gray-400 mt-2">🛡️ Secure Checkout</p>
          </div>
          <div class="flex flex-col border border-gray-200 rounded-xl p-6 bg-gray-50 hover:shadow-lg">
            <h4 class="text-lg font-semibold text-indigo-700 mb-2">Guaranteed Mobility</h4>
            <p class="text-gray-600 text-sm mb-4">Car or van finance guaranteed, no credit check required.</p>
            <button class="mt-auto bg-blue-600 hover:bg-blue-700 text-white font-semibold px-4 py-2 rounded"><a  href="{{ route('checkout.page','guaranteed_mobility') }}"> Add to Plan (£100)</a></button>
            <p class="text-xs text-gray-400 mt-2">🛡️ Secure Checkout</p>
          </div>
        </div>
      </div>

      <div class="bg-white rounded-xl shadow p-8">
        <h2 class="text-2xl font-bold text-indigo-700 mb-6">Helpful Resources</h2>
        <p class="text-gray-600 mb-8">These expert resources are available to support your credit repair and financial journey.</p>
        <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div class="flex flex-col border border-gray-200 rounded-xl p-6 bg-gray-50 hover:shadow-lg items-start">
            <h4 class="text-lg font-semibold text-indigo-700 mb-2">📜 What's Included in Each Plan</h4>
            <p class="text-gray-600 text-sm mb-4">Quick breakdown of all package features across plans.</p>
            <button class="mt-auto bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-4 py-2 rounded">View</button>
          </div>
          <div class="flex flex-col border border-gray-200 rounded-xl p-6 bg-gray-50 hover:shadow-lg items-start">
            <h4 class="text-lg font-semibold text-indigo-700 mb-2">❓ FAQs About Twindo Packages</h4>
            <p class="text-gray-600 text-sm mb-4">Find answers to all common questions about Twindo services.</p>
            <button class="mt-auto bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-4 py-2 rounded">View</button>
          </div>
          <div class="flex flex-col border border-gray-200 rounded-xl p-6 bg-gray-50 hover:shadow-lg items-start">
            <h4 class="text-lg font-semibold text-indigo-700 mb-2">📞 Speak to a Twindo Advisor</h4>
            <p class="text-gray-600 text-sm mb-4">Schedule a call with our advisors for tailored support.</p>
            <button class="mt-auto bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-4 py-2 rounded">View</button>
          </div>
          <div class="flex flex-col border border-gray-200 rounded-xl p-6 bg-gray-50 hover:shadow-lg items-start">
            <h4 class="text-lg font-semibold text-indigo-700 mb-2">🌟 See Success Stories</h4>
            <p class="text-gray-600 text-sm mb-4">Real examples of clients rebuilding credit successfully.</p>
            <button class="mt-auto bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-4 py-2 rounded">View</button>
          </div>
        </div>
      </div>

    </div>
  </main>