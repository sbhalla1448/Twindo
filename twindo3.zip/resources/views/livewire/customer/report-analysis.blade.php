<div>
    {!! $templateReport->html_content!!}
</div>
