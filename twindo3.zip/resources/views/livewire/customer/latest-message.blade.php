

    <section class="bg-white rounded-xl shadow p-6 mb-8">
        <h3 class="text-lg font-semibold text-gray-700 mb-4">📩 Latest Messages</h3>
        <table class="min-w-full text-sm text-left text-gray-700">
            <thead class="text-xs text-gray-500 uppercase">
                <tr>
                    <th scope="col" class="px-4 py-2">Subject</th>
                    <th scope="col" class="px-4 py-2">Status</th>
                    <th scope="col" class="px-4 py-2">Action</th>
                </tr>
            </thead>
            <tbody>

                @foreach ($messages as $msg)


                <tr class="border-t hover:bg-gray-50">
                    <td class="px-4 py-3">{{$msg->subject}}</td>
                    <td class="px-4 py-3 text-red-500 font-semibold">{{$msg->read_status_user == 1 ? 'Read':'Unread'}}</td>
                    <td class="px-4 py-3">
                        <a style="cursor: pointer" wire:click="readMessage({{ $msg->id }})" class="text-indigo-600 hover:underline">View</a> /
                        <a style="cursor: pointer" wire:click="readMessage({{ $msg->id }})" class="text-indigo-600 hover:underline">Respond</a>
                    </td>
                </tr>
                @endforeach
                {{-- <tr class="border-t hover:bg-gray-50">
                    <td class="px-4 py-3">Important changes to your subscription</td>
                    <td class="px-4 py-3 text-green-600 font-semibold">Read</td>
                    <td class="px-4 py-3">
                        <a href="#" class="text-indigo-600 hover:underline">View</a>
                    </td>
                </tr>
                <tr class="border-t hover:bg-gray-50">
                    <td class="px-4 py-3">New Resources Available!</td>
                    <td class="px-4 py-3 text-green-600 font-semibold">Read</td>
                    <td class="px-4 py-3">
                        <a href="#" class="text-indigo-600 hover:underline">View</a>
                    </td>
                </tr> --}}
            </tbody>
        </table>

        @if($viewTools)
        <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-40">
           <div class="bg-white rounded-lg shadow-lg p-6 w-1/2">
               <div class="bg-white p-6 rounded-xl shadow space-y-6">
                   <h3 class="text-2xl font-bold text-indigo-700 mb-2">Message Thread</h3>
                   <div class="space-y-4">
                     @foreach ($usermessages as $msg)
                     <div class="p-4 bg-gray-50 border rounded-lg text-sm">
                         @if($msg->admin_id != null)
                         <strong class="text-indigo-700">Twindo Team</strong> <span class="text-gray-400 text-xs">({{ $msg->created_at->format('d M Y') }} - {{ $msg->created_at->format('h:i A') }})</span>
                         @else
                         <strong class="text-indigo-700">You</strong> <span class="text-gray-400 text-xs">({{ $msg->created_at->format('d M Y') }} - {{ $msg->created_at->format('h:i A') }})</span>
                         @endif
                         <p class="mt-1 text-gray-700">{{$msg->message}}</p>
                       </div>
                     @endforeach

                     {{-- <div class="p-4 bg-green-50 border-green-200 border rounded-lg text-sm">
                       <strong class="text-green-700">You</strong> <span class="text-gray-400 text-xs">(31 Mar 2025 - 12:45pm)</span>
                       <p class="mt-1 text-gray-700">Hi, I’ve uploaded my latest council tax bill. Let me know if it’s acceptable.</p>
                     </div> --}}
                     {{-- <div class="p-4 bg-gray-50 border rounded-lg text-sm">
                       <strong class="text-indigo-700">Twindo Team</strong> <span class="text-gray-400 text-xs">(1 Apr 2025 - 9:15am)</span>
                       <p class="mt-1 text-gray-700">Thanks! We have received your upload and will review it within 48 hours.</p>
                     </div> --}}
                   </div>
                   <div class="flex justify-between mt-4">
                         {{ $usermessages->links('vendor.pagination.message-action-pagination') }}
                   </div>
                   <form class="space-y-4 mt-6" wire:submit="replyMessageSubmit">
                     <label for="reply" class="text-gray-700 text-sm font-semibold">✏️ Write a Reply</label>
                     <textarea wire:model="replyMessage" id="reply" class="w-full border-2 border-gray-300 rounded-lg p-3 text-sm bg-gray-50" rows="3" placeholder="Write your reply here..."></textarea>
                         @error('replyMessage')
                             <span>{{$message}}</span>
                         @enderror
                     <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center bg-white" style="position: relative;">
                       <p class="text-gray-500">Drag & drop a file here or click to upload</p>
                       <input type="file" class="opacity-0 absolute inset-0 cursor-pointer" wire:model="uploadFile">
                     </div>
                     <div class="flex justify-end">
                        <button wire:click="closeDialog"
                        class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg">Cancel</button>
                       <button type="submit"  class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-2 rounded-lg">Post Reply</button>
                     </div>
                   </form>
                 </div>




           </div>
       </div>
       @endif

    </section>




