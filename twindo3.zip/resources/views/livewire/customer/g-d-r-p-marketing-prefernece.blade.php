   <section class="bg-white rounded-xl shadow p-8">
                <h2 class="text-2xl font-bold text-gray-800 mb-4">🛡️ GDPR & Marketing Preferences</h2>
                <p class="text-sm text-gray-600 mb-6">Control how Twindo contacts you and how your data is handled.</p>

                <div class="space-y-6">
                     @if (session()->has('message'))
        <div style="color: green;">{{ session('message') }}</div>
    @endif
                    <div>
                        <h3 class="text-sm font-semibold text-gray-800 mb-2">Marketing Preferences</h3>
                        <label class="flex items-center space-x-3">
                            <input type="checkbox" class="form-checkbox h-5 w-5 text-indigo-600" wire:model.live="emailUpdates">
                            <span class="text-sm text-gray-700">Email updates about new features and offers</span>
                        </label>
                        <label class="flex items-center space-x-3 mt-2">
                            <input type="checkbox"  wire:model.live="smsAlerts" class="form-checkbox h-5 w-5 text-indigo-600">
                            <span class="text-sm text-gray-700">SMS alerts for account activity</span>
                        </label>
                    </div>

                    <div>
                        <h3 class="text-sm font-semibold text-gray-800 mb-2">Data Usage & GDPR Rights</h3>
                        <p class="text-sm text-gray-600 mb-2">You can request to download your data or ask for it to be
                            removed at any time.</p>
                        <div class="flex flex-col sm:flex-row sm:space-x-4 space-y-2 sm:space-y-0">
                            <button class="text-sm bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700"
                                onclick="openModal('exportModal')">📥 Request Data Export</button>
                            <button class="text-sm bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700"
                                onclick="openModal('deleteModal')">🗑️ Request Data Deletion</button>
                        </div>
                    </div>
                </div>
                <div id="exportModal" class="fixed inset-0 hidden bg-black bg-opacity-30 flex items-center justify-center z-50">
                    <div class="bg-white p-6 rounded-xl shadow-xl max-w-sm w-full">
                      <h3 class="text-lg font-semibold text-gray-800 mb-3">Download Data Export</h3>
                      <p class="text-sm text-gray-600 mb-4">Are you sure you want to request a download of your personal data?</p>
                      <div class="flex justify-end space-x-3">
                        <button class="text-sm text-gray-600 hover:underline" onclick="closeModal('exportModal')">Cancel</button>
                        <button wire:click="dataExport" class="bg-indigo-600 text-white text-sm px-4 py-2 rounded hover:bg-indigo-700">Confirm</button>
                      </div>
                    </div>
                  </div>

                  <!-- Delete Confirmation Modal -->
                  <div id="deleteModal" class="fixed inset-0 hidden bg-black bg-opacity-30 flex items-center justify-center z-50">
                    <div class="bg-white p-6 rounded-xl shadow-xl max-w-sm w-full">
                      <h3 class="text-lg font-semibold text-red-600 mb-3">Confirm Data Deletion</h3>
                      <p class="text-sm text-gray-600 mb-4">This will permanently erase all your personal data from Twindo systems. This cannot be undone.</p>
                      <div class="flex justify-end space-x-3">
                        <button class="text-sm text-gray-600 hover:underline" onclick="closeModal('deleteModal')">Cancel</button>
                        <button wire:click="dataDeletion" class="bg-red-600 text-white text-sm px-4 py-2 rounded hover:bg-red-700">Delete</button>
                      </div>
                    </div>
                  </div>
            </section>


@script
@push('js')
<script>
    function openModal(id) {
        document.getElementById(id).classList.remove('hidden');
    }

    function closeModal(id) {
        document.getElementById(id).classList.add('hidden');
    }

    function showToast() {
        const toast = document.getElementById('successToast');
        toast.classList.remove('hidden');
        setTimeout(() => toast.classList.add('hidden'), 3000);
    }
    // Example bindings for Confirm buttons
    document.querySelectorAll('button').forEach(btn => {
        if (btn.textContent.includes('Confirm') || btn.textContent.includes('Delete')) {
            btn.addEventListener('click', showToast);
        }
    });
</script>

<script>
function openModal(id) {
document.getElementById(id).classList.remove('hidden');
}
function closeModal(id) {
document.getElementById(id).classList.add('hidden');
}
</script>

@endpush
@endscript