<div>
     <header>
        <h1>Compare Credit Repair & Financial Products</h1>
        <p>Browse and filter trusted services across banking, loans, credit cards, and more.</p>
        <div class="search-box" style="position: relative;">
            <input type="search" wire:model.live="search" placeholder="Search for product, company or category...">
            <svg style="position: absolute; right: 12px; top: 50%; transform: translateY(-50%); width: 20px; height: 20px; fill: #888;"
                xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                <path
                    d="M10 2a8 8 0 105.293 14.707l4.147 4.147 1.414-1.414-4.147-4.147A8 8 0 0010 2zm0 2a6 6 0 110 12 6 6 0 010-12z" />
            </svg>
        </div>
    </header>
    <main>
        <section class="filters">
            <h2>Filter Your Results</h2>
            <div class="filter-controls">
                <label>Sort by
                    <select wire:model.live="sortBy">
                        <option value="">Best Match</option>
                        <option value="low_rate">Lowest Cost</option>
                        <option value="top_rate">Highest Rated</option>
                        <option value="newest">Newest</option>
                    </select>
                </label>
                <label>Category
                    <select  wire:model.live="categoryId">
                        <option value="">All</option>
                        
                         @foreach ($categories as $category)
            <option value="{{ $category->id }}">{{$category->name}}</option>
            @endforeach
                    </select>
                </label>
                <label>Product or Service
                    <select  wire:model.live="productId">
                        <option>All</option>
                       @foreach ($productsFilter as $pro)
                           <option value="{{ $pro->id }}">{{ $pro->title }}</option>
                       @endforeach
                    </select>
                </label>
            </div>
            <div class="reset-link">
                <a href="#" wire:click="reseetFilters">Reset Filters</a>
            </div>
        </section>
            @foreach ($products as $product)
                
           
        <section class="card featured">
            <div class="tag">{{ $product->product_status }}</div>
            <h3 style="width: 40%;">{{ $product->category->name }}</h3>
            {{ $product->title }}
            </p>
            <div class="stars"><span style="color:#064d38; font-weight: 600;">⭐⭐⭐⭐⭐</span> <span
                    style="color:#0e3b29; font-weight: 600;">{{ $product->rating }}</span> <span style="color:#666">({{ $product->rating_count }} reviews)</span>
            </div>
            <div class="phone">📞 {{ $product->phone }}</div>
            <div class="price-box">
                <div style="position: absolute; right: 20px; bottom: 80px; text-align: right;">
                    <div class="price">£{{ $product->price_per_month }}/mo</div>
                    <div class="total">Total Cost: £{{ $product->price_annual }}</div>
                </div>
                <div class="cta-buttons">
                    <button class="visit">Visit Now</button>
                </div>
            </div>
        </section>
         @endforeach

        {{-- <section class="card">
            <div class="tag">Online Exclusive</div>
            <h3 style="width: 40%;">Wollit</h3>
            <p
                style="width: 60%; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                Turn subscriptions into credit activity. Trusted by 100,000+ users in the UK. Free trial available.
                Reports to Experian.</p>
            <div class="stars"><span style="color:#0e3b29; font-weight: 600;">⭐⭐⭐⭐⯪</span> <span
                    style="color:#0e3b29; font-weight: 600;">4.5</span> <span style="color:#666">(1,783 reviews)</span>
            </div>
            <div class="phone">📞 0800 765 4321</div>
            <div class="price-box">
                <div style="position: absolute; right: 20px; bottom: 80px; text-align: right;">
                    <div class="price">£9.99/mo</div>
                    <div class="total">Total Cost: £119.88/year</div>
                </div>
                <div class="cta-buttons">
                    <button class="visit">Visit Now</button>
                </div>
            </div>
        </section>

        <section class="card">
            <div class="tag">Popular</div>
            <h3 style="width: 40%;">CreditLadder</h3>
            <p
                style="width: 60%; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                Report your rent to credit reference agencies to boost your score. No credit check. FCA regulated
                service.</p>
            <div class="stars"><span style="color:#0e3b29; font-weight: 600;">⭐⭐⭐⭐⭐</span> <span
                    style="color:#0e3b29; font-weight: 600;">4.6</span> <span style="color:#666">(2,012 reviews)</span>
            </div>
            <div class="phone">📞 0800 654 3210</div>
            <div class="price-box">
                <div style="position: absolute; right: 20px; bottom: 80px; text-align: right;">
                    <div class="price">£5.99/mo</div>
                    <div class="total">Total Cost: £71.88/year</div>
                </div>
                <div class="cta-buttons">
                    <button class="visit">Visit Now</button>
                </div>
            </div>
        </section>
        <section class="card">
            <div class="tag">Top Rated</div>
            <h3 style="width: 40%;">Salad Money</h3>
            <p
                style="width: 60%; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                Affordable loans for NHS and public sector workers. No credit score required. Regulated by the FCA.</p>
            <div class="stars"><span style="color:#0e3b29; font-weight: 600;">⭐⭐⭐⭐⭐</span> <span
                    style="color:#0e3b29; font-weight: 600;">4.7</span> <span style="color:#666">(1,529 reviews)</span>
            </div>
            <div class="phone">📞 0800 321 9876</div>
            <div class="price-box">
                <div style="position: absolute; right: 20px; bottom: 80px; text-align: right;">
                    <div class="price">£15.00/mo</div>
                    <div class="total">Total Cost: £180.00/year</div>
                </div>
                <div class="cta-buttons">
                    <button class="visit">Visit Now</button>
                </div>
            </div>
        </section>

        <section class="card">
            <div class="tag">Trusted Choice</div>
            <h3 style="width: 40%;">Ocean Credit Card</h3>
            <p
                style="width: 60%; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                Credit card designed for rebuilding your credit history. QuickCheck eligibility checker available.</p>
            <div class="stars"><span style="color:#0e3b29; font-weight: 600;">⭐⭐⭐⭐</span> <span
                    style="color:#0e3b29; font-weight: 600;">4.2</span> <span style="color:#666">(3,210 reviews)</span>
            </div>
            <div class="phone">📞 0800 456 7890</div>
            <div class="price-box">
                <div style="position: absolute; right: 20px; bottom: 80px; text-align: right;">
                    <div class="price">£3.00/mo</div>
                    <div class="total">Total Cost: £36.00/year</div>
                </div>
                <div class="cta-buttons">
                    <button class="visit">Visit Now</button>
                </div>
            </div>
        </section> --}}
        {{-- <div class="pagination">
            <button class="pagination-btn">«</button>
            <button class="pagination-btn active">1</button>
            <button class="pagination-btn">2</button>
            <button class="pagination-btn">3</button>
            <button class="pagination-btn">»</button>
        </div> --}}
            {{ $products->links('vendor.pagination.comparison') }}

            @if($products->hasMorePages())
              <div class="load-more">
       
         <button wire:click="loadMore" class="load-more-btn">Load More</button>
         </div>
    @endif
      
           
       
    </main>
</div>
