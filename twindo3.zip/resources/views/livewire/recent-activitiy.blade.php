<div class="bg-white p-6 rounded-xl shadow">
    <h3 class="text-lg font-semibold text-gray-800 mb-2">📅 Recent Activity</h3>
    <ul class="text-sm text-gray-700 space-y-2">

        @foreach ($recentActivtities as $activity)
        <li>{{ $activity->user->name ?? '' }} {{$activity->descriptions}}</li>
        @endforeach


    </ul>
    <div class="flex justify-between items-center mt-4">
       {{  $recentActivtities->links('vendor.pagination.message-action-pagination')}}

    </div>
</div>