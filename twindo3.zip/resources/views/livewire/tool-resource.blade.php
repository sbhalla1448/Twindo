<main class="flex-1 overflow-auto">
    <div class="max-w-7xl mx-auto px-6 py-10">

        <section class="mb-8 flex items-center justify-between">
            <div>
                <nav class="text-sm text-gray-500">Home / Admin / Tools & Resources</nav>
                <h2 class="text-3xl font-bold text-gray-800">Manage Tools & Resources</h2>
                <p class="text-gray-600 mt-2">Upload member-only tools, resources, blogs, how-to guides,
                    calculators, templates and more.</p>
            </div>
            <div>
                <button class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg"><a href="{{ route('admin.toolResources.create') }}">➕ Add New
                    Resource</a></button>
            </div>
        </section>

        <div class="flex mb-6 space-x-4">
            <input type="search" placeholder="🔎 Search Resources..."
                class="border px-6 py-3 rounded-lg w-full text-lg" wire:model.live="search">
            <select  wire:model.change="categoryId"
                class="border px-6 py-3 rounded-lg text-gray-600">
                <option value="">All Categories</option>
                @foreach ($cats as $cat)
                <option value={{ $cat->id }} > {{ $cat->name }}</option>
                @endforeach
            </select>
        </div>

        <!-- Resource Tables -->
        <section class="bg-white rounded-xl shadow p-6 space-y-10">

            <!-- Credit Repair Resources -->
            <div>
                @foreach ($categories as $category)
                <h3 class="text-2xl font-semibold text-indigo-700 mb-4">{{$category->name}}</h3>
                <table class="w-full">
                    <tbody>

                        @foreach ($category->tools as $tool)

                        <tr class="resource-item border-t hover:bg-gray-50" data-category="credit">
                            <td class="py-3">{{$tool->title}}</td>
                            <td class="py-3 text-right space-x-2">
                                <button wire:click="view({{ $tool->id }})"class="text-green-600 hover:underline">View</button>
                                <button class="text-blue-600 hover:underline"><a href="{{ route('admin.toolResources.edit',$tool->id) }}"> Edit </a></button>
                                <button wire:click="deleteTool({{ $tool->id }})" return wire:confirm="Are You Sure?"
                                    class="text-red-600 hover:underline">Delete</button>
                            </td>
                        </tr>
                        @endforeach

                    </tbody>
                </table>
                @endforeach
            </div>



        </section>

    </div>

     <!-- View Resource Modal -->
     @if($viewTools)
     <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
     <div class="bg-white rounded-lg shadow-lg p-6 w-1/2">
         <h2 id="viewResourceTitle" class="text-2xl font-bold mb-4"></h2>
         <p class="text-gray-600">{{$title}}</p>
         {{-- <iframe src="{{ $url }}" style="width:100%; height:800px; border:none;"></iframe> --}}
         <iframe src="{{ $url }}" class="w-full aspect-video"></iframe>
         {{-- {!! $content !!} --}}
         <div class="text-right mt-6">
             <button wire:click="closeDialog"
                 class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg">Close</button>
         </div>
     </div>
 </div>
 @endif
</main>