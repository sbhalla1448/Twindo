<main class="flex-1 overflow-auto">
    <div class="max-w-7xl mx-auto px-6 py-10 space-y-10">

      <!-- Filtering & Sorting -->
      <section class="bg-white p-6 rounded-xl shadow">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">🔎 Filter & Sort Uploads</h3>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          <select class="border rounded p-2 w-full text-sm" wire:model.change="status">
            <option value="">All</option>
            <option value="highToLow">Sort by Score (High to Low)</option>
            <option value="lowToHigh">Sort by Score (Low to High)</option>
            <option value="Approve">Sort by Approve</option>
            <option value="Pending">Sort by Pending</option>
            <option value="Reject">Sort by Reject</option>

          </select>
          <input type="date" wire:model.live="date" class="border rounded p-2 w-full text-sm" placeholder="Filter by Date">
          <input type="search" wire:model.live="search" class="border rounded p-2 w-full text-sm" placeholder="Search by User Email">
          <button wire:click="reseFilter" class="bg-indigo-600 text-white px-4 py-2 rounded text-sm hover:bg-indigo-700 transition">Reset</button>
        </div>
      </section>

      <!-- Credit Score Upload Management Table with Bulk Actions -->
      <section class="bg-white p-6 rounded-xl shadow">
        <div class="flex justify-between items-center mb-4">
          <h2 class="text-xl font-semibold text-gray-800">📤 User Credit Score Uploads</h2>
               @if (session()->has('message'))
            <div class="bg-green-100 text-green-800 p-4 mb-4 rounded">
                {{ session('message') }}
            </div>
        @endif
        @error('bulk')
            <div class="bg-green-100 text-green-800 p-4 mb-4 rounded">
                {{ $message }}
            </div>
        @enderror
   <div wire:loading>

                    <svg aria-hidden="true"
                        class="inline w-8 h-8 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600"
                        viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                            fill="currentColor" />
                        <path
                            d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                            fill="currentFill" />
                    </svg>

                </div>
          <button class="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-indigo-700 transition" wire:click="applyBulkAction" >
          
            
            ⬇️ Download CSV</button>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-sm text-left">
            <thead class="text-gray-600 border-b">
              <tr>
                <th class="py-2"><input type="checkbox" class="form-checkbox" wire:click="$set('bulkSelect', @js($creditScores->pluck('id')))"></th>
                <th>User</th>
                <th>Upload Date</th>
                <th>Score</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>

                @foreach ($creditScores as $cscore)


              <tr class="border-t hover:bg-gray-50"  wire:click="selectedUser({{ $cscore->user_id }}, '{{ $cscore->id }}')" @isset($selectedScore)
                
              @if($selectedScore->id === $cscore->id) style="background-color: #f0f4ff;" @endif @endisset>
                {{-- <td><input type="checkbox" class="form-checkbox" wire:click="selectedUser({{ $cscore->user_id }})"></td> --}}
                <td><input type="checkbox" class="form-checkbox" wire:model="bulkSelect" value="{{ $cscore->id }}" >
                
                
                </td>
                {{-- <td><input type="checkbox" class="form-checkbox"
       wire:model="selected.{{ $cscore->id }}"
       wire:change="selectedUser({{ $cscore->user_id }}, selected['{{ $cscore->id }}'] ?? null)"></td> --}}
                <td class="py-3">{{ $cscore->user->name }}<br><span class="text-xs text-gray-500">{{$cscore->user->email}}</span></td>
                <td>{{ $cscore->created_at->format('d M Y') }}</td>
                <td>{{ $cscore->score }}</td>
                <td><span class="bg-yellow-100 text-yellow-700 px-2 py-1 rounded text-xs">{{ $cscore->score_status }}</span></td>
                <td class="space-x-2">
                  <button class="text-green-600 hover:underline" wire:click="approve({{ $cscore->id }})">✅ Approve</button>
                  <button class="text-red-600 hover:underline" wire:click="reject({{ $cscore->id }})">❌ Reject</button>
                  <button   onclick="focusCommentTextarea()"  class="text-indigo-600 hover:underline">🗨️ Comment</button>
                </td>
              </tr>
              @endforeach
              <!-- More rows... -->
            </tbody>
          </table>
        </div>
      </section>

      <!-- Email Template Trigger -->
      {{-- <section class="bg-white p-6 rounded-xl shadow">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">📧 Send Email to User</h3>
        <form class="space-y-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Select Template</label>
            <select class="w-full border rounded p-2 text-sm">
              <option>Choose an email template</option>
              <option value="approved">✅ Score Approved Notification</option>
              <option value="rejected">❌ Score Rejected Notification</option>
              <option value="info">📝 Request for More Info</option>
            </select>
          </div>
          <div class="grid md:grid-cols-2 gap-4">
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">CC</label>
              <input type="email" class="w-full border rounded p-2 text-sm" placeholder="cc@example.com">
            </div>
            <div>
              <label class="block text-sm font-medium text-gray-700 mb-1">BCC</label>
              <input type="email" class="w-full border rounded p-2 text-sm" placeholder="bcc@example.com">
            </div>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Attachments</label>
            <input type="file" class="block w-full text-sm text-gray-700 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Message Preview</label>
            <textarea rows="6" class="w-full border rounded p-2 text-sm" placeholder="Message preview...">Hi Jane,

Your latest credit score submission has been approved. Great job!

Regards,
The Twindo Team</textarea>
            <p class="mt-1 text-xs text-gray-500 italic">You can preview the final version of this email before sending.</p>
          </div>
          <div class="text-right">
            <button type="button" onclick="toggleTemplateManager()" class="text-sm text-gray-600 hover:underline mr-4">🛠️ Manage Templates</button>
            <button type="button" class="text-sm text-indigo-600 hover:underline mr-4">👁️ Preview Email</button>
            <button type="submit" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm">📤 Send Email</button>
          </div>
        </form>
      </section> --}}
      <section class="bg-white p-6 rounded-xl shadow">
    <h3 class="text-lg font-semibold text-gray-800 mb-4">📧 Send Email to User</h3>
    @if (session()->has('message'))
    <div class="mb-4 text-green-600 text-sm font-medium">
        {{ session('message') }}
    </div>
@endif
    @if (session()->has('error'))
    <div class="mb-4 text-green-600 text-sm font-medium">
        {{ session('message') }}
    </div>
@endif
    <form  wire:submit="sendEmail" class="space-y-4" enctype="multipart/form-data">
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Select Template</label>
            <select wire:model.live="templateId" class="w-full border rounded p-2 text-sm">
                <option value="">Choose an email template</option>
                @foreach ($emailTemplates as $temp)
                    <option value="{{ $temp->id }}">{{ $temp->email_subject }}</option>
                @endforeach
            </select>
        </div>
        <div class="grid md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">CC</label>
                <input type="email" wire:model="cc" class="w-full border rounded p-2 text-sm" placeholder="cc@example.com">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">BCC</label>
                <input type="email"  wire:model="bcc"  class="w-full border rounded p-2 text-sm" placeholder="bcc@example.com">
            </div>
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Attachments</label>
            <input type="file" wire:model="attachment"
                class="block w-full text-sm text-gray-700 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Message Preview</label>
            <textarea wire:model="mailBody"  rows="6" class="w-full border rounded p-2 text-sm" placeholder="Message preview...">

                {{-- Hi {{ $user->name }},

            {{ $selectedTemplate->email_body ?? '' }}

Regards,
The Twindo Team --}}

</textarea>
            <p class="mt-1 text-xs text-gray-500 italic">You can preview the final version of this email
                before sending.</p>
        </div>
        <div class="text-right">
            @if (session()->has('error'))
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            {{ session('error') }}
        </div>
    @endif
    @if (session()->has('template_message'))
        <div class="bg-blue-100 border border-blue-400 text-blue-700 px-4 py-3 rounded mb-4">
            {{ session('template_message') }}
        </div>
    @endif
            <button wire:click="manageTemplate" type="button"
                class="text-sm text-gray-600 hover:underline mr-4">🛠️ Manage Templates</button>
            <button wire:click="previewEmail" type="button" class="text-sm text-indigo-600 hover:underline mr-4">👁️ Preview
                Email</button>
                <div wire:loading>

                    <svg aria-hidden="true"
                        class="inline w-8 h-8 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600"
                        viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                            fill="currentColor" />
                        <path
                            d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                            fill="currentFill" />
                    </svg>

                </div>
            <button type="submit"
                class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm">📤
                Send Email</button>
        </div>
    </form>

    @if ($showPreview)
        <div class="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
            <div class="bg-white rounded-lg shadow-lg p-6 w-full max-w-2xl max-h-[80vh] overflow-y-auto">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-xl font-semibold">Email Preview</h2>
                    <button wire:click="closePreview" class="text-gray-500 hover:text-gray-700">&times;</button>
                </div>
                <div class="prose">
                    {!! $previewContent !!}
                </div>
            </div>
        </div>
    @endif

    @if ($manageTemplatePreview)
        <div class="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
            <div class="bg-white rounded-lg shadow-lg p-6 w-full max-w-2xl max-h-[80vh] overflow-y-auto">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-xl font-semibold">{{ $editingTemplateId ? 'Edit Template' : 'Create Template' }}</h2>
                    <button wire:click="closeManagePreview" class="text-gray-500 hover:text-gray-700">×</button>
                </div>
                <div class="prose">
                    <form wire:submit.prevent="saveTemplate">
                        <div class="mb-4">
                            <label for="templateSubject" class="block text-sm font-medium text-gray-700">Email Subject</label>
                            <input type="text" class="w-full border rounded p-2 text-sm" id="templateSubject" wire:model="templateSubject">
                            @error('templateSubject') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
                        </div>

                        <div class="mb-4">
                            <label for="templateBody" class="block text-sm font-medium text-gray-700">Email Body</label>
                            <textarea rows="6" class="w-full border rounded p-2 text-sm" id="templateBody" wire:model="templateBody" placeholder="Enter email body..."></textarea>
                            @error('templateBody') <span class="text-red-500 text-sm">{{ $message }}</span> @enderror
                        </div>

                        <div class="flex justify-end">
                            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                                {{ $editingTemplateId ? 'Update Template' : 'Save Template' }}
                            </button>
                        </div>
                    </form>

                    <h3 class="text-lg font-semibold mt-6">Template List</h3>
                    @if ($emailTemplates->isEmpty())
                        <p class="text-gray-500">No templates found.</p>
                    @else
                        <table class="w-full mt-4 border-collapse">
                            <thead>
                                <tr class="bg-gray-100">
                                    <th class="border p-2 text-left">Subject</th>
                                    <th class="border p-2 text-left">Body</th>
                                    <th class="border p-2 text-left">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($emailTemplates as $template)
                                    <tr>
                                        <td class "border p-2">{{ $template->email_subject }}</td>
                                        <td class="border p-2">{{ Str::limit($template->email_body, 50) }}</td>
                                        <td class="border p-2">
                                            <button wire:click="editTemplate({{ $template->id }})" class="bg-yellow-500 text-white px-2 py-1 rounded hover:bg-yellow-600">Edit</button>
                                            <button wire:click="deleteTemplate({{ $template->id }})" class="bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600" onclick="return confirm('Are you sure you want to delete this template?')">Delete</button>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    @endif
                </div>
            </div>
        </div>
    @endif

</section>

<form wire:submit="saveComment" class="space-y-6">
       <section class="bg-white p-6 rounded-xl shadow">
        <h3 class="text-lg font-semibold text-gray-800 mb-2">🔍 Document Preview & Comment {{ $selectedScore->score ?? '' }}  {{$selectedScore->image ?? ''}} </h3>
        <div class="grid md:grid-cols-2 gap-6">
          <div class="border rounded p-4 bg-gray-100 text-center text-sm text-gray-500">
            <img src="{{ asset('storage/uploads/' . ($selectedScore->image ?? 'default.jpg')) }}" alt="Score Image">
          </div>
          <div>
            <textarea  id="commentTextarea" wire:model='comment' class="w-full border rounded p-2 text-sm mb-2" rows="4" placeholder="Add a comment for the user..."></textarea>
            <div class="flex flex-row flex-wrap gap-3">
              <button type="button" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm" wire:click="setComment('✅ Approve')" >✅ Approve</button>
              <button type="button" class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm" wire:click="setComment('❌ Reject')">❌ Reject</button>
              <button type="button" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm" wire:click="setComment('🏷️ Tag as Highest')">🏷️ Tag as Highest</button>
              <button type="button" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg text-sm" wire:click="setComment('🏷️ Tag as Lowest')">🏷️ Tag as Lowest</button>
              
            </div>
          </div>
        </div>
      </section> 

  




      <!-- Comment History Log -->
      <section class="bg-white p-6 rounded-xl shadow">
        <div class="flex justify-between items-center mb-4">
          <h3 class="text-lg font-semibold text-gray-800">🗨️ Admin Comments</h3>
              <div wire:loading>

                    <svg aria-hidden="true"
                        class="inline w-8 h-8 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600"
                        viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                            fill="currentColor" />
                        <path
                            d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                            fill="currentFill" />
                    </svg>

                </div>
           @isset($selectedScore) 
          <button type="submit" class="text-sm text-indigo-600 hover:underline">➕ Add Comment</button>
          @endisset
        </div></h3>
        <ul class="text-sm text-gray-700 space-y-2">
 @isset($selectedScore) 
        @foreach ($selectedScore->comments as  $comment)
           <li><strong>{{ $comment->user->name }}</strong> on <em>{{ $comment->created_at->format('d M Y') }}</em>: {{ $comment->body }}</li>
        @endforeach
         @endisset
        
          {{-- <li><strong>Admin B</strong> on <em>15 Apr 2025</em>: "Score looked suspicious. Follow-up required. ⛔"</li> --}}
          <!-- More comment logs... -->
        </ul>
      </section>
    </form>

      <!-- Real-Time Status Sync Note -->
      <section class="bg-white p-4 rounded-xl shadow text-sm text-gray-600">
        <p>ℹ️ All score status changes are synced live with the user's dashboard. Updates reflect in real time across both panels.</p>
      </section>


      <section class="bg-white p-6 rounded-xl shadow">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">🕒 User Timeline</h3>
        <ul class="text-sm text-gray-700 space-y-2">
           @isset($selectedScore) 
          <li>📤 User uploaded score on <strong>{{ $selectedScore->created_at->format('d M Y') }}</strong></li>
                @if(!empty($selectedScore->approved_by) )
          <li>{{ $selectedScore->score_status }} by {{ $selectedScore?->approved->name }}on <strong>{{ $selectedScore?->updated_at->format('d M Y') }}</strong></li>
          @endif  
          @endisset
          <!-- More logs... -->
        </ul>
      </section>

    </div>




</main>


@script
@push('js')
<script>
  function focusCommentTextarea() {
    const textarea = document.getElementById('commentTextarea');
    if (textarea) {
      textarea.focus();
    }
  }
</script>
  
@endpush
@endscript