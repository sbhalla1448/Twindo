<main class="flex-1 overflow-auto">
    <div class="max-w-7xl mx-auto px-6 py-10">

        <!-- Breadcrumb & Hero -->
        <section class="mb-8">
            <nav class="text-sm text-gray-500">Home / Admin / Users</nav>
            <h2 class="text-3xl font-bold text-gray-800">Users</h2>
        </section>

        <!-- Filters and Search -->
        <section class="bg-white rounded-xl shadow p-6 mb-6">
            <div class="flex flex-wrap gap-4 items-center mb-4">
                <select class="border border-gray-300 rounded-md px-3 py-2" wire:model.change="status">
                    <option value="">All Statuses</option>
                    <option value="1">Active</option>
                    <option value="2">Suspended</option>
                    <option value="3">lock</option>
                    <option value="4">Reset</option>
                </select>
                <select class="border border-gray-300 rounded-md px-3 py-2">
                    <option>All Subscriptions</option>
                    <option>Essential</option>
                    <option>Plus</option>
                    <option>Elite</option>
                </select>
                <input type="search" placeholder="Search users..."
                    class="border border-gray-300 rounded-md px-3 py-2 flex-1" wire:model.live="search">
            </div>
        </section>
        @if (session()->has('message'))
            <div class="bg-green-100 text-green-800 p-4 mb-4 rounded">
                {{ session('message') }}
            </div>
        @endif
        @error('bulk')
            <div class="bg-green-100 text-green-800 p-4 mb-4 rounded">
                {{ $message }}
            </div>
        @enderror



        <!-- User Table with Bulk Actions -->
        <section class="bg-white rounded-xl shadow p-6">
            <div class="mb-4 flex justify-between items-center">
                <div class="flex items-center space-x-2">
                    <select wire:model="bulkAction" class="border border-gray-300 rounded-md px-3 py-2">
                        <option value="">Bulk Actions</option>
                        <option value="suspend">Suspend Selected</option>
                        <option value="delete">Delete Selected</option>
                    </select>
                    <button wire:click="applyBulkAction"
                        class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md">
                        Apply
                    </button>
                </div>
            </div>

            <table class="w-full text-left">
                <thead>
                    <tr class="text-sm text-gray-400">
                        <th class="py-2">
                            <input type="checkbox" wire:click="$set('bulkSelect', @js($users->pluck('id')))">
                        </th>
                        <th class="py-2">Name</th>
                        <th class="py-2">Email</th>
                        <th class="py-2">Status</th>
                        <th class="py-2">Subscription</th>
                        <th class="py-2">Joined</th>
                        <th class="py-2">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($users as $user)
                        <tr class="border-t">
                            <td class="py-3">
                                <input type="checkbox" wire:model="bulkSelect" value="{{ $user->id }}">
                            </td>
                            <td class="py-3">{{ $user->name }}</td>
                            <td class="py-3">{{ $user->email }}</td>
                            <td class="py-3 text-green-500">
                                @if ($user->status == 2)
                                    Suspend
                                @elseif($user->status == 3)
                                    locked
                                @elseif ($user->status == 4)
                                    Force To reset
                                @else
                                    Active
                                @endif
                            </td>
                            <td class="py-3">Elite</td>
                            <td class="py-3">{{ $user->created_at->format('d M Y') }}</td>
                            <td class="py-3">
                                <a href="{{ route('admin.users.show', \Illuminate\Support\Facades\Crypt::encryptString($user->id)) }}"
                                    class="text-indigo-600">Manage</a>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </section>

    </div>
</main>
