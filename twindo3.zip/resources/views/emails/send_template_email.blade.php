<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Template</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        .container {
            width: 100%;
            max-width: 600px;
            margin: 20px auto;
            background: #ffffff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2);
            padding: 20px;
        }
        .header {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border-radius: 8px 8px 0 0;
        }
        .content {
            margin: 20px 0;
            font-size: 16px;
            line-height: 1.5;
        }
        .footer {
            margin-top: 20px;
            font-size: 14px;
            color: gray;
        }
        .thank-you {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>{{$data['subject']}}</h2>
        </div>
        <div class="content">
            {{-- <p>Dear <strong>{{$data['user']}}</strong>,</p> --}}
            <p>{!! nl2br(e($data['body'])) !!}</p>
            {{-- <p class="thank-you">Thank you for your attention to this matter.</p> --}}
            @if ($filePath)
        <p>Please find the attached file.</p>
            @endif
        </div>
        <div class="footer">
            <p>Best regards,</p>
            <p>Twindo Team</p>
            {{-- <p>[Your Position]</p>
            <p>[Your Company]</p>
            <p>[Your Contact Information]</p> --}}
        </div>
    </div>
</body>
</html>