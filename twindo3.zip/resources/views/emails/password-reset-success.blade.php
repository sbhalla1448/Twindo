
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Reset Confirmation | Twindo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background: linear-gradient(135deg, #f0f8ff 0%, #e6f7ff 100%);
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .email-container {
            max-width: 845px;
            background-color: #ffffff;
            border-radius: 20px;
            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.15);
            overflow: hidden;
        }

        .email-header {
            background: linear-gradient(135deg, #033333 0%, #0a4a4a 100%);
            padding: 35px 30px 30px;
            text-align: center;
            color: white;
            position: relative;
            overflow: hidden;
        }

        .email-header::before {
            content: "";
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(92, 180, 106, 0.15) 0%, transparent 70%);
            transform: rotate(15deg);
        }

        .logo {
            font-size: 38px;
            font-weight: 800;
            letter-spacing: -0.5px;
            margin-bottom: 8px;
            color: #EEFCFC;
            position: relative;
            z-index: 2;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .tagline {
            font-weight: 300;
            font-size: 18px;
            opacity: 0.85;
            margin-bottom: 15px;
            color: #5CB46A;
            position: relative;
            z-index: 2;
            font-style: italic;
        }

        h1 {
            font-weight: 600;
            font-size: 28px;
            padding: 12px 0;
            border-top: 1px solid rgba(92, 180, 106, 0.3);
            border-bottom: 1px solid rgba(92, 180, 106, 0.3);
            margin: 0 auto;
            max-width: 80%;
            color: #EEFCFC;
            position: relative;
            z-index: 2;
        }

        .email-content {
            padding: 35px 45px;
            color: #033333;
            line-height: 1.6;
            font-size: 15px;
        }

        .greeting {
            font-size: 24px;
            margin-bottom: 20px;
            color: #033333;
            position: relative;
        }

        .greeting::after {
            content: "";
            display: block;
            width: 60px;
            height: 4px;
            background: linear-gradient(90deg, #5CB46A, #033333);
            border-radius: 2px;
            margin-top: 10px;
        }

        .highlight {
            color: #5CB46A;
            font-weight: 600;
        }

        .cta-button {
            display: inline-block;
            background: linear-gradient(135deg, #5CB46A 0%, #4CA05A 100%);
            color: white !important;
            text-decoration: none;
            padding: 16px 36px;
            border-radius: 50px;
            font-weight: 700;
            font-size: 17px;
            margin: 25px 0;
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: 0 6px 20px rgba(92, 180, 106, 0.35);
            border: none;
            cursor: pointer;
            width: 100%;
            max-width: 320px;
            position: relative;
            overflow: hidden;
        }

        .cta-button::before {
            content: "";
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: 0.6s;
        }

        .cta-button:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 25px rgba(92, 180, 106, 0.5);
            background: linear-gradient(135deg, #4CA05A 0%, #3e8e4c 100%);
        }

        .cta-button:hover::before {
            left: 100%;
        }

        .section {
            margin: 25px 0;
            padding: 24px;
            border-radius: 16px;
            background-color: #f8fdfd;
            border: 1px solid #e0f0f0;
        }

        .section-title {
            display: flex;
            align-items: center;
            font-size: 18px;
            margin-bottom: 12px;
            color: #033333;
        }

        .section-title .icon {
            margin-right: 12px;
            font-size: 22px;
            color: #5CB46A;
        }

        .security-note {
            background-color: #f0faf0;
            padding: 16px 20px;
            border-radius: 12px;
            margin: 25px 0;
            text-align: center;
            border-left: 4px solid #5CB46A;
            font-size: 15px;
        }

        .email-footer {
            background-color: #f0fafa;
            padding: 25px 20px;
            text-align: center;
            border-top: 1px solid #d9f0f0;
            font-size: 14px;
            color: #033333;
        }

        .social-links {
            display: flex;
            justify-content: center;
            margin: 15px 0;
            gap: 15px;
        }

        .social-icon {
            display: inline-flex;
            width: 44px;
            height: 44px;
            background-color: #e0f5f5;
            border-radius: 50%;
            align-items: center;
            justify-content: center;
            color: #5CB46A;
            text-decoration: none;
            font-weight: bold;
            transition: all 0.3s ease;
            font-size: 18px;
        }

        .social-icon:hover {
            background-color: #5CB46A;
            color: white;
            transform: translateY(-4px) scale(1.1);
        }

        .social-icon.tiktok:hover {
            background: linear-gradient(135deg, #000, #25F4EE, #FE2C55);
            color: white;
        }

        .footer-links {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 20px;
            gap: 15px;
        }

        .footer-links a {
            color: #5CB46A;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.2s ease;
            padding: 5px 10px;
            border-radius: 6px;
        }

        .footer-links a:hover {
            color: #033333;
            background-color: rgba(92, 180, 106, 0.1);
            text-decoration: none;
        }

        .security-badge {
            display: inline-flex;
            align-items: center;
            background: linear-gradient(135deg, #e0f5f5 0%, #d0f0f0 100%);
            padding: 10px 20px;
            border-radius: 30px;
            margin-top: 15px;
            font-size: 14px;
            color: #033333;
        }

        .security-badge .icon {
            color: #5CB46A;
            margin-right: 8px;
            font-size: 16px;
        }

        .legal-disclaimer {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7f7;
            padding: 20px 22px;
            text-align: center;
            border-top: 1px solid #e0e0e0;
            border-bottom: 1px solid #e0e0e0;
            border-left: 1px solid #e0e0e0;
            border-right: 1px solid #e0e0e0;
            border-radius: 0 0 16px 16px;
            margin-top: -1px;
        }

        .legal-section {
            margin-bottom: 15px;
            position: relative;
        }

        .legal-section::after {
            content: "";
            display: block;
            width: 120px;
            height: 1px;
            background: linear-gradient(90deg, transparent, #c0d0d0, transparent);
            margin: 15px auto 12px;
        }

        .legal-section:last-child::after {
            display: none;
        }

        .legal-title {
            display: flex;
            align-items: center;
            justify-content: center;
            color: #5a6a6a;
            margin-bottom: 10px;
            font-weight: 700;
            font-size: 12px;
            letter-spacing: 0.5px;
        }

        .legal-content {
            font-size: 11px;
            color: #6c757d;
            max-width: 580px;
            margin: 0 auto;
            line-height: 1.5;
        }

        .legal-content a {
            color: #5CB46A;
            text-decoration: underline;
            transition: all 0.2s;
        }

        .legal-content a:hover {
            color: #033333;
            text-decoration: none;
        }

        .legal-content ul {
            padding-left: 0;
            margin: 5px 0;
            text-align: center;
            list-style: none;
        }

        .legal-content li {
            margin-bottom: 3px;
            position: relative;
            padding-left: 0;
            text-align: center;
        }

        .key-rights-section .legal-content {
            margin-top: 3px;
        }

        .key-rights-section .legal-content ul {
            margin-top: 3px;
            margin-bottom: 3px;
        }

        .compliance-row {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 6px;
        }

        .compliance-item {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 11px;
        }

        .compliance-item .icon {
            color: #8ca9a9;
            font-size: 11px;
        }

        @media (max-width: 845px) {
            .email-container {
                max-width: 95%;
            }

            .email-content {
                padding: 30px;
            }

            .email-header {
                padding: 30px 20px 25px;
            }

            .logo {
                font-size: 34px;
            }

            h1 {
                font-size: 24px;
                max-width: 90%;
            }

            .greeting {
                font-size: 22px;
            }

            .cta-button {
                padding: 14px 28px;
                font-size: 16px;
            }

            .section {
                padding: 20px;
            }

            .social-links {
                gap: 10px;
            }

            .social-icon {
                width: 40px;
                height: 40px;
                font-size: 16px;
            }

            .footer-links {
                gap: 12px;
            }

            .legal-disclaimer {
                padding: 18px;
            }

            .compliance-row {
                gap: 10px;
            }
        }

        @media (max-width: 480px) {
            .email-header {
                padding: 25px 15px 20px;
            }

            .email-content {
                padding: 25px 20px;
            }

            .footer-links {
                flex-direction: column;
                gap: 8px;
            }

            .compliance-row {
                flex-direction: column;
                gap: 8px;
            }
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="email-header">
            <div class="logo">Twindo</div>
            <div class="tagline">Your journey to financial freedom starts here</div>
            <h1>Password Reset Confirmation</h1>
        </div>

        <div class="email-content">
            <h2 class="greeting">Hello {{ $user->name }},</h2>

            <p>We're confirming that your Twindo password has been successfully reset. You're now ready to securely access your account.</p>

            <div style="text-align: center;">
                <a href="https://app.twindo.co.uk/login" class="cta-button">Login to Your Account</a>
            </div>

            <div class="security-note">
                <p><strong>Important:</strong> For your security, all active sessions have been terminated. You'll need to use your new password for all future logins.</p>
            </div>

            <div class="section">
                <h3 class="section-title">
                    <span class="icon">🔒</span> Security Information
                </h3>
                <p>This password reset was initiated on <span class="highlight">{{ \Carbon\Carbon::parse($timestamp)->setTimezone('GMT')->format('F j, Y \a\t H:i') }} GMT</span> from:</p>
                <ul style="padding-left: 24px; margin-top: 10px;">
                    <li style="margin-bottom: 8px;"><strong>Device:</strong> {{$user_device}}</li>
                    <li style="margin-bottom: 8px;"><strong>Location:</strong> {{$location}}</li>
                    <li><strong>IP Address:</strong> {{$user_ip}}</li>
                </ul>
            </div>

            <div class="section">
                <h3 class="section-title">
                    <span class="icon">❓</span> Didn't make this change?
                </h3>
                <p>If you didn't reset your password, your account may have been compromised. Please take immediate action:</p>
                <ol style="padding-left: 24px; margin-top: 10px;">
                    <li style="margin-bottom: 8px;"><a href="https://app.twindo.co.uk/reset-password" style="color: #5CB46A; font-weight: 600;">Reset your password</a> again immediately</li>
                    <li style="margin-bottom: 8px;">Review your <a href="https://app.twindo.co.uk/security" style="color: #5CB46A; font-weight: 600;">account security settings</a></li>
                    <li><a href="https://www.twindo.co.uk/help" style="color: #5CB46A; font-weight: 600;">Contact our security team</a> for assistance</li>
                </ol>
            </div>
        </div>

        <div class="email-footer">
            <div class="social-links">
                <a href="#" class="social-icon"><i class="fab fa-facebook-f"></i></a>
                <a href="#" class="social-icon"><i class="fab fa-linkedin-in"></i></a>
                <a href="#" class="social-icon"><i class="fab fa-instagram"></i></a>
                <a href="#" class="social-icon tiktok"><i class="fab fa-tiktok"></i></a>
            </div>

            <p>You received this email because you recently reset your Twindo password.</p>

            <div class="footer-links">
                <a href="#">Help Center</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Terms of Service</a>
                <a href="#">Unsubscribe</a>
            </div>

            <div class="security-badge">
                <span class="icon">🔒</span> Secure and Encrypted
            </div>

            <p style="margin-top: 15px;">© 2025 Twindo t/a EDPLX Limited. All rights reserved.<br>
            124 City Road London, EC1V 2NX, UK</p>
        </div>

        <div class="legal-disclaimer">
            <div class="legal-section">
                <div class="legal-title">
                    CONFIDENTIALITY & GDPR NOTICE
                </div>
                <div class="legal-content">
                    This email and attachments are confidential and intended solely for the named recipient(s). Unauthorised disclosure, copying, or distribution is prohibited. If received in error, notify us immediately at <a href="mailto:data-privacy@twindo.co.uk">data-privacy@twindo.co.uk</a> and permanently delete all copies. We comply with UK GDPR and Data Protection Act 2018.
                </div>
            </div>

            <div class="legal-section key-rights-section">
                <div class="legal-title">
                    CREDIT REPAIR DISCLOSURES
                </div>
                <div class="legal-content">
                    Twindo (trading as EDPLX Limited) is not a Credit Reference Agency (CRA), lender, or government body. We do not guarantee specific credit score improvements or removal of accurate information.
                </div>
                <div class="legal-content">
                    <strong>Your key rights:</strong>
                    <ul>
                        <li>Dispute inaccuracies directly with CRAs at no cost</li>
                        <li>Adverse information remains for <strong>6 years</strong> (including bankruptcies)</li>
                        <li><strong>14-day cooling-off period</strong> to cancel services</li>
                        <li>Full <a href="https://www.twindo.co.uk/t-cs" target="_blank">Terms & Conditions</a></li>
                    </ul>
                </div>
            </div>

            <div class="legal-section">
                <div class="legal-title">
                    REGULATORY COMPLIANCE
                </div>
                <div class="legal-content">
                    <div class="compliance-row">
                        <div class="compliance-item">
                            <span class="icon"><i class="fas fa-id-card"></i></span> ICO Registration: ZB553399
                        </div>
                        <div class="compliance-item">
                            <span class="icon"><i class="fas fa-building"></i></span> Registered in England & Wales: 15398152
                        </div>
                        <div class="compliance-item">
                            <span class="icon"><i class="fas fa-file-alt"></i></span> <a href="https://www.twindo.co.uk/privacy-policy" target="_blank">Privacy Policy</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>