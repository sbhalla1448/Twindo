<?php

use App\Http\Middleware\AdminMiddleware;
use App\Http\Middleware\AuthGates;
use App\Http\Middleware\CheckUserStatus;
use App\Http\Middleware\IsCustomerMiddleware;
use App\Http\Middleware\TwoFactorMiddlewar;
use App\Http\Middleware\UserSuspendMiddleware;
use App\Http\Middleware\UserTemporaryLockMiddleware;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__ . '/../routes/web.php',
        commands: __DIR__ . '/../routes/console.php',
        health: '/up',
        then: function () {
            Route::middleware(['auth','web','userStatus','gate','isAdmin'])->name('admin.')->prefix('admin')
                ->group(__DIR__ . '/../routes/backend.php');
            Route::middleware(['auth','web','userStatus', 'isCustomer',])->prefix('account')
                ->group(__DIR__ . '/../routes/customer.php');
        }
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->alias([
            'userStatus' => CheckUserStatus::class,
            'isAdmin' => AdminMiddleware::class,
            'gate' => AuthGates::class,
            '2fa' => TwoFactorMiddlewar::class,
            'isCustomer' => IsCustomerMiddleware::class,
            'userLock' => UserTemporaryLockMiddleware::class,
            'userSuspend' => UserSuspendMiddleware::class,

        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        //
    })->create();
