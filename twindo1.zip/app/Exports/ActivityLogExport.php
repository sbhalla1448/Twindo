<?php

namespace App\Exports;

use App\Models\ActivityLog;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Illuminate\Support\Collection;

class ActivityLogExport implements FromCollection, WithHeadings
{
    public function collection()
    {
        $logs = ActivityLog::with('user')
            ->whereHas('user', function ($query) {
                $query->where('role_id', '!=', 2);
            })
            ->get();

        // Map the data with user_id and user_name
        return $logs->map(function ($log) {
            return [
                'User ID'      => $log->user_id,
                'User Name'    => optional($log->user)->name,
                'IP Address'   => $log->ip_address,
                'User Agent'   => $log->user_agent,
                'Action'       => $log->action,
                'URL'          => $log->url,
                'Method'       => $log->method,
                'Descriptions' => $log->descriptions,
                'Icon'         => $log->icon,
            ];
        });
    }

    public function headings(): array
    {
        return [
            'User ID',
            'User Name',
            'IP Address',
            'User Agent',
            'Action',
            'URL',
            'Method',
            'Descriptions',
            'Icon',
        ];
    }
}
