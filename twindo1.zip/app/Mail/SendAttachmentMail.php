<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;
use Illuminate\Mail\Mailables\Attachment;

class SendAttachmentMail extends Mailable
{
    use Queueable, SerializesModels;
    public $mailData;
    public $filePath;

    /**
     * Create a new message instance.
     */
    public function __construct($mailData, $filePath)
    {
        $this->mailData = $mailData;
        $this->filePath = $filePath;
    }

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
        return new Envelope(
            subject: $this->mailData['subject'],
            cc: $this->mailData['cc'],
            bcc: $this->mailData['bcc'],
        );
    }

    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        return new Content(
            view: 'emails.send_template_email',
            with: ['data' => $this->mailData]
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        // return [
        //     Attachment::fromPath($this->filePath)
        //         ->as(basename($this->filePath))
        //         ->withMime(mime_content_type($this->filePath)),
        // ];

        if ($this->filePath && file_exists($this->filePath)) {
            return [
                Attachment::fromPath($this->filePath)
                    ->as(basename($this->filePath))
                    ->withMime(mime_content_type($this->filePath)),
            ];
        }
        return [];
    }
}
