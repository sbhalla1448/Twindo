<?php

use App\Models\VisibilityRule;

function user_can_view($section)
{
    $user = auth()->user();

    if (!$user || !$user->role) {
        return false;
    }

    $rule = VisibilityRule::where('section', $section)->first();

    return $rule &&
        $user->role->visibilityRules()
        ->where('visibility_rule_id', $rule->id)
        ->wherePivot('can_view', true)
        ->exists();
}


function creditScoreDescription($score)
{

    if ($score >= 0 && $score <= 560) {
        return 'Very Poor (0–560)';
    } elseif ($score <= 720) {
        return 'Poor (561–720)';
    } elseif ($score <= 880) {
        return 'Fair (721–880)';
    } elseif ($score <= 960) {
        return 'Good (881–960)';
    } elseif ($score <= 999) {
        return 'Excellent (961–999)';
    }
}

