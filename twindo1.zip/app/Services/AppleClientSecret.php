<?php

namespace App\Services;

use Firebase\JWT\JWT;

class AppleClientSecret
{
    public static function generate()
    {
        $privateKey = str_replace('\n', "\n", env('APPLE_PRIVATE_KEY'));

        $payload = [
            'iss' => env('APPLE_TEAM_ID'),
            'iat' => time(),
            'exp' => time() + 86400 * 180, // valid for 6 months
            'aud' => 'https://appleid.apple.com',
            'sub' => env('APPLE_CLIENT_ID'),
        ];

        return JWT::encode($payload, $privateKey, 'ES256', env('APPLE_KEY_ID'));
    }
}
