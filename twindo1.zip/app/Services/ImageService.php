<?php



namespace App\Services;

use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;

class ImageService
{
    public function processUserImage($image, string $directory = 'users'): string
    {
        $manager = new ImageManager(new Driver());
        $filename = uniqid('avatar_', true) . '.webp';


        $image = $manager->read($image->getRealPath())
            ->cover(870, 493)
            ->toWebp(100);

        $imagePath = public_path('images/' . $filename);
        file_put_contents($imagePath, (string) $image);

        return $filename;
    }
}
