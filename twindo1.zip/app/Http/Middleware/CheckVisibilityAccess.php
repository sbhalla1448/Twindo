<?php

namespace App\Http\Middleware;

use App\Models\VisibilityRule;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class CheckVisibilityAccess
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $user = Auth::user();

        if (!$user || !$user->role) {
            abort(403, 'Unauthorized');
        }

        $rule = VisibilityRule::where('section', $section)->first();

        if (!$rule || !$user->role->visibilityRules()
            ->where('visibility_rule_id', $rule->id)
            ->wherePivot('can_view', true)->exists()) {
            abort(403, 'Access Denied');
        }

        return $next($request);
    }
}
