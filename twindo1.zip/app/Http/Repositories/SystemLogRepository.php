<?php
namespace App\Http\Repositories;

use App\Models\ActivityLog;
use App\Models\User;

class SystemLogRepository
{
    public function gets()
    {
       return ActivityLog::with('user')->get();
    }





}
