<?php

namespace App\Http\Repositories;


use App\Models\User;
use Illuminate\Support\Facades\Auth;

class ProfileUpdateRepository
{
    public function update($request)
    {
        return User::where('id', Auth::user()->id)->update([
            'name' => request('name'),
            'email' => request('email'),
            'phone' => request('phone'),
        ]);
    }
}
