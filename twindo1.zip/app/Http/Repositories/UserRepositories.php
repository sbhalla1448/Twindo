<?php
namespace App\Http\Repositories;

use App\Models\User;

class UserRepositories
{
    public function gets()
    {
       return User::with('role')->get();
    }

    public function get($id)
    {

    }

    public function store($request)
    {
        try {
            $user = User::create($request->validated());
            if ($request->hasFile('image')) {
                $user->addMedia($request->file('image'))->toMediaCollection('profile');
            }
            return to_route('admin.users.index')->with('message', 'User Successfully Created');
        } catch (Exception $e) {
            return serverError($e);
        }
    }

    public function update($request, $id)
    {

    }

    public function destroy($user)
    {

        try {
            $user = User::findOrFail($user->id);
            $user->delete();
            return to_route('admin.users.index')->with('message', 'User Successfully Deleted');
        } catch (Exception $e) {
            return serverError($e);
        }
    }


    public function statusChange($userId, $status)
    {
        $user = User::findOrFail($userId);
        return $user->update(['status' => $status]);
    }

}
