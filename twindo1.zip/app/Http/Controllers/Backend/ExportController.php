<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Exports\ActivityLogExport;
use Maatwebsite\Excel\Facades\Excel;

class ExportController extends Controller
{
    public function activityLog()
    {
        return Excel::download(new ActivityLogExport, 'activity_logs.xlsx');
    }
}
