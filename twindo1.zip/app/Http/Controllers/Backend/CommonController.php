<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CommonController extends Controller
{
    public function index()
    {
        return view('backend.twofa.index');
    }
    public function accountStatusSuspendOrLock()
    {
        return view('backend.suspen_bashboard');
    }
    public function resetUserCredential()
    {
        return view('backend.reset_user_credential');
    }



    public function sessionLogout(Request $request)
    {
        if (Auth::user()->session_timeout == 1) {
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
            return redirect('/login');
        }
    }
}
