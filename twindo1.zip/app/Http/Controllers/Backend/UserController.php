<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Http\Repositories\UserRepositories;
use App\Http\Requests\StoreUserRequest;
use App\Models\ActivityLog;
use App\Models\Role;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Image;
use Intervention\Image\Drivers\Gd\Driver;
use Intervention\Image\ImageManager;

class UserController extends Controller
{

    public function __construct(private readonly UserRepositories $repository) {}


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // Gate::authorize('user_list_access');
        $users = $this->repository->gets();
        return view('backend.users.index', compact('users'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // return "ok";
        // Gate::authorize('user_create');
        $roles = Role::all();

        return view('backend.users.add_user', compact('roles'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(StoreUserRequest $request)
    {

        // Gate::authorize('user_edit');

        // return $request->all();

        $user = User::create([
            'role_id' => $request->role_id,
            'name' => $request->name,
            'email' => $request->email,
            'password' => Hash::make($request->password),

        ]);


        // $manager = new ImageManager(new Driver());

        // if ($request->hasFile('avatar')) {
        //     $photo_upload = $request->file('avatar');
        //     $imageName = time() . '.webp';

        //     $image = $manager->read($photo_upload);
        //     $image->resize(400, 400)
        //         ->toWebp()
        //         ->save(public_path('images/' . $imageName));

        //     User::find($user->id)->update([
        //         'avatar' => $imageName
        //     ]);
        // }
        flash('User Successfully Added.');

        return redirect()->route('admin.users.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function show($encrypted_id)
    {
        // Gate::authorize('user_list_access');

        try {
            $id = Crypt::decryptString($encrypted_id);
            $user = User::findOrFail($id);
            return view('backend.users.manage_user', compact('user'));
        } catch (\Exception $e) {
            abort(404, 'Invalid or tampered ID');
        }
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function edit(User $user)
    {
        // Gate::authorize('user_edit');
        $roles = Role::all();
        return view('backend.users.form', compact('user', 'roles'));
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, User $user)
    {
        // Gate::authorize('user_edit');
        $manager = new ImageManager(new Driver());
        $this->validate($request, [
            'name' => 'required|string|max:255',
            'email' => 'required|string|max:255|email|unique:users,email,' . $user->id,
            'role_id' => 'required',
            'password' => 'nullable|confirmed|string|min:8',
            'avatar' => 'nullable|image'
        ]);

        $user->update([
            'role_id' => $request->role_id,
            // 'role' => $request->role,
            'name' => $request->name,
            'email' => $request->email,
            'password' => isset($request->password) ? Hash::make($request->password) : $user->password,
            'status' => $request->filled('status'),
        ]);


        // upload images

        if ($request->hasfile('avatar')) {

            $deleteoldphoto = $user->avatar;
            if ($deleteoldphoto) {
                $path = public_path('images/backend/') . $deleteoldphoto;
                if (file_exists($path)) {
                    unlink($path);
                }
            }
        }

        if ($request->hasFile('avatar')) {
            $photo_upload = $request->file('avatar');
            $imageName = time() . '.webp';

            $image = $manager->read($photo_upload);
            $image->resize(400, 400)
                ->toWebp()
                ->save(public_path('images/' . $imageName));

            User::find($user->id)->update([
                'avatar' => $imageName
            ]);
        }
        flash('User Successfully Updated.');
        return redirect()->route('admin.users.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\User  $user
     * @return \Illuminate\Http\Response
     */
    public function destroy(User $user)
    {
        $users = $this->repository->destroy($user);
    }


    public function delete($encrypted_id)
    {
        // Gate::authorize('user_list_access');

        try {
            $id = Crypt::decryptString($encrypted_id);
            $user = User::findOrFail($id);
            return view('backend.users.delete_user', compact('user'));
        } catch (\Exception $e) {
            abort(404, 'Invalid or tampered ID');
        }
    }
    public function reactiveUser($encrypted_id)
    {
        // Gate::authorize('user_list_access');

        try {
            $id = Crypt::decryptString($encrypted_id);
            $user = User::findOrFail($id);
            return view('backend.users.reactive_user', compact('user'));
        } catch (\Exception $e) {
            abort(404, 'Invalid or tampered ID');
        }
    }
    public function suspendUser($encrypted_id)
    {
        // Gate::authorize('user_list_access');

        try {
            $id = Crypt::decryptString($encrypted_id);
            $user = User::findOrFail($id);
            return view('backend.users.suspend_user', compact('user'));
        } catch (\Exception $e) {
            abort(404, 'Invalid or tampered ID');
        }
    }
    public function lockedUser($encrypted_id)
    {
        // Gate::authorize('user_list_access');

        try {
            $id = Crypt::decryptString($encrypted_id);
            $user = User::findOrFail($id);
            return view('backend.users.locked_user', compact('user'));
        } catch (\Exception $e) {
            abort(404, 'Invalid or tampered ID');
        }
    }
    public function resetUserCredentials($encrypted_id)
    {
        // Gate::authorize('user_list_access');

        try {
            $id = Crypt::decryptString($encrypted_id);
            $user = User::findOrFail($id);
            return view('backend.users.force_reset_user_password', compact('user'));
        } catch (\Exception $e) {
            abort(404, 'Invalid or tampered ID');
        }
    }


    public function userStatusChange(Request $request)
    {
        $request->validate([
            'userId' => 'required|exists:users,id',
            'status' => 'required',
        ]);

        try {
            $success = $this->repository->statusChange($request->userId, $request->status);

            if ($success) {
                return to_route('admin.users.index')->with('message', 'User Status Changed Successfully');
            }

            return to_route('admin.users.index')->with('error', 'Failed to change user status.');
        } catch (\Exception $e) {
            return to_route('admin.users.index')->with('error', 'An error occurred: ' . $e->getMessage());
        }
    }

    public function changeEmail()
    {
        return view('backend.users.change_email');
    }

    public function changeEmailUpdate(Request $request)
    {
        $request->validate([
            'newEmail' => ['required', 'email', 'unique:users,email'],
            'confirmEmail' => ['required', 'same:newEmail'],
            'password' => ['required'],
        ]);

        $user = Auth::user();

        // Check if password matches
        if (!Hash::check($request->password, $user->password)) {
            return back()->withErrors(['password' => 'The password is incorrect.'])->withInput();
        }
        $user->email = $request->newEmail;
        $user->save();
        Auth::logout();
        return redirect()->route('login')->with('status', 'Email updated successfully. Please log in again.');
    }

    public function userLoginHistory($id)
    {
        $loginHistory = ActivityLog::where('user_id', $id)->where('action', 'login')->paginate(10);


        return view('backend.users.login_history', compact('loginHistory'));
    }
}
