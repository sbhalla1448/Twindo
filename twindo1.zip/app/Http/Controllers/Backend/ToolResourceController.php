<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\ToolResource;
use App\Http\Requests\StoreToolResourceRequest;
use App\Http\Requests\UpdateToolResourceRequest;
use App\Models\Category;

class ToolResourceController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('backend.tools.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $categories = Category::all();
        return view('backend.tools.form',compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreToolResourceRequest $request)
    {


        $store = ToolResource::create($request->validated());
        flash('Tools & Resources Created Successfully.');
        return to_route('admin.toolResources.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(ToolResource $toolResource)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(ToolResource $toolResource)
    {
        $categories = Category::all();
        return view('backend.tools.form',compact('categories','toolResource'));

    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateToolResourceRequest $request, ToolResource $toolResource)
    {
        $toolResource->update($request->validated());
        return to_route('admin.toolResources.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(ToolResource $toolResource)
    {
        $toolResource->delete();
        return to_route('admin.toolResources.index');
    }
}
