<?php

namespace App\Http\Controllers\Backend;

use App\Models\Product;
use App\Models\Category;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Gate;
use Intervention\Image\ImageManager;
use Intervention\Image\Drivers\Gd\Driver;
use App\Http\Requests\StoreProductRequest;
use App\Http\Requests\UpdateProductRequest;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('backend.products.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $categories = Category::get(['id','name']);
        return view('backend.products.form',compact('categories'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreProductRequest $request)
    {

        // return $request->all();
        $submitType = $request->input('submit_type');

        $store = Product::create($request->validated() + ['status'=>$submitType]);

        $manager = new ImageManager(new Driver());

        if ($request->hasFile('image')) {
            $photo_upload = $request->file('image');
            $imageName = time() . '.webp';

            $image = $manager->read($photo_upload);
            $image->resize(600, 600)
                ->toWebp()
                ->save(public_path('images/' . $imageName));

            Product::find($store->id)->update([
                'image' => $imageName
            ]);
        }
        flash('Product Created Successfully.');
        return to_route('admin.products.index');
    }



    /**
     * Display the specified resource.
     */
    public function show(Product $product)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Product $product)
    {
        $categories = Category::get(['id','name']);
        return view('backend.products.edit_product',compact('categories','product'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateProductRequest $request, Product $product)
    {
        $submitType = $request->input('submit_type');
        $manager = new ImageManager(new Driver());
        $product->update($request->validated() + ['status'=>$submitType]);
        if ($request->hasFile('image')) {
            $deleteoldphoto = $product->image;
            if ($deleteoldphoto) {
                $path = ('images/') . $deleteoldphoto;
                if (file_exists($path)) {
                    unlink($path);
                }
            }
            $photo_upload = $request->file('image');
            $imageName = time() . '.webp';

            $image = $manager->read($photo_upload);
            $image->resize(60, 60)
                ->toWebp()
                ->save(public_path('images/' . $imageName));

            $product->update([
                'image' => $imageName
            ]);
        }
        flash('Product Updated Successfully.');
        return to_route('admin.products.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Product $product)
    {
        if ($product->image) {
            $path = ('images/') . $product->image;
            if (file_exists($path)) {
                unlink($path);
            }
        }
        $product->delete();
        flash('Product Deleted Successfully.');
        return to_route('admin.products.index');
    }

    public function duplicate(Product $product)
    {
        $categories = Category::all();
        return view('backend.products.duplicate', compact('product', 'categories'));
    }
}
