<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\DocumentUpload;
use App\Models\MessageAction;
use App\Models\MessageThread;
use App\Models\Payment;
use App\Models\Product;
use App\Models\Subscription;
use App\Models\ToolResource;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Gate;

class DashboardControler extends Controller
{
    public function index()
    {
        // Gate::authorize('dashboard_access');

        $data['userCount'] =User::count();
        $activeSubscriptions = Subscription::where('status', 1)
            ->select('user_id')
            ->groupBy('user_id')
            ->get();
        $data['subscriptions'] = $activeSubscriptions->count();
        $data['currentMonthTotal'] = Payment::whereMonth('created_at', Carbon::now()->month)
            ->whereYear('created_at', Carbon::now()->year)
            ->sum('amount');

        // Last month total
        $data['lastMonthTotal'] = Payment::whereMonth('created_at', Carbon::now()->subMonth()->month)
            ->whereYear('created_at', Carbon::now()->subMonth()->year)
            ->sum('amount');
            $data['unseenmsg'] = MessageThread::where('is_seen_admin',0)->count();
            $data['uploadCount'] = DocumentUpload::count();
            $data['productAccount'] = Product::count();
            $data['toolsCount'] = ToolResource::count();
        // Get start of this week (Monday)
            $startOfWeek = Carbon::now()->startOfWeek();
            $endOfWeek = Carbon::now()->endOfWeek();

            // Query users created this week and group by day name
          $startOfWeek = Carbon::now()->startOfWeek();
        $endOfWeek = Carbon::now()->endOfWeek();

// Get raw data grouped by day name
        $rawData = User::whereBetween('created_at', [$startOfWeek, $endOfWeek])
            ->select(DB::raw('DAYNAME(created_at) as day'), DB::raw('COUNT(*) as total'))
            ->groupBy('day')
            ->get()
            ->pluck('total', 'day')
            ->toArray();

        // Define all 7 days in correct order
        $weekDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

        $labels = [];
        $dataS = [];

        foreach ($weekDays as $day) {
            $labels[] = Carbon::parse($day)->format('D'); // e.g., "Mon", "Tue"
            $dataS[] = $rawData[$day] ?? 0; // Use 0 if no users on that day
        }
        $data['labels'] = $labels;
        $data['dataS'] = $dataS;

 $rawDataR = Payment::whereBetween('created_at', [$startOfWeek, $endOfWeek])
    ->where('status', 1) // optional: only include successful payments
    ->select(DB::raw('DAYNAME(created_at) as day'), DB::raw('SUM(amount) as total'))
    ->groupBy('day')
    ->get()
    ->pluck('total', 'day')
    ->toArray();


        $labels = [];
        $dataS = [];

        foreach ($weekDays as $dayr) {
            $labelr[] = Carbon::parse($dayr)->format('D'); // e.g. "Mon"
            $datar[] = $rawData[$dayr] ?? 0;
        }

     $data['labelr'] = $labelr;
        $data['datar'] = $datar;

       $data['recentMessages'] = MessageAction::latest()->take(8)->get();
        return view('backend.dashboard', $data);
    }
}
