<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\UserNotification;
use App\Http\Requests\StoreUserNotificationRequest;
use App\Http\Requests\UpdateUserNotificationRequest;

class UserNotificationController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $preferences = auth()->user()->notificationPreferences ?? new UserNotification();
        return view('backend.settings.manage_notification', compact('preferences'));
    }


    public function updateNotification(UpdateUserNotificationRequest $request)
    {

        // return $request->all();
        auth()->user()->notificationPreferences()->delete();

        auth()->user()->notificationPreferences()->updateOrCreate(

            $request->validated()
        );


        // $user->notificationPreferences()->updateOrCreate([], $request->validated());

    return back()->with('success', 'Preferences saved successfully.');
    }


}
