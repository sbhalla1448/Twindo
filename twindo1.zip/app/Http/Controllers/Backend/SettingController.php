<?php

namespace App\Http\Controllers\Backend;

use Image;
use App\Models\Setting;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Repositories\ProfileUpdateRepository;
use App\Http\Requests\UpdateProfileRequest;
use Intervention\Image\ImageManager;
use Illuminate\Support\Facades\Gate;
use Intervention\Image\Drivers\Gd\Driver;

class SettingController extends Controller
{

    public function __construct(private readonly ProfileUpdateRepository $repository) {}


    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        // Gate::authorize('setting_access');
        $setting = Setting::where('id', 1)->first();
        return view('backend.settings.index', compact('setting'));
    }


    public function userSetting()
    {


        return view('backend.profile.user_profile');
    }


    public function profileUpdate(UpdateProfileRequest $request)
    {
        $this->repository->update($request);

        return to_route('admin.settings.user');
    }


    public function securitySetting()
    {

        return view('backend.profile.security_settings');
    }




    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Setting  $setting
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Setting $setting)
    {

        Gate::authorize('setting_view');
        $this->validate($request, [

            'site_name' => 'string|nullable',
            'site_url' => 'url|string|nullable',

            'copyright' => 'string|nullable',
            'slogan' => 'string|nullable',
            'meta_description' => 'string|nullable',
            'meta_keywords' => 'string|nullable',
            'about_site' => 'string|nullable',
            'facebook' => 'string|nullable',
            'google' => 'string|nullable',
            'linkdin' => 'string|nullable',
            'twiter' => 'string|nullable',
            'contact' => 'string|nullable',
            'fax' => 'string|nullable',
            'hotline' => 'string|nullable',
            'email' => 'string|nullable',
            'address' => 'string|nullable',

        ]);

        $setting = Setting::where('id', 1)->update([
            'site_name' => $request->site_name,
            'site_url' => $request->site_url,
            'copyright' => $request->copyright,
            'slogan' => $request->slogan,
            'meta_title' => $request->meta_title,
            'meta_description' => $request->meta_description,
            'meta_keywords' => $request->meta_keywords,
            'about_site' => $request->about_site,
            'facebook' => $request->facebook,
            'google' => $request->google,
            'linkdin' => $request->linkdin,
            'twiter' => $request->twiter,
            'youtube' => $request->youtube,
            'instagram' => $request->instagram,
            'contact' => $request->contact,
            'fax' => $request->fax,
            'hotline' => $request->hotline,
            'email' => $request->email,
            'webmail' => $request->webmail,
            'address' => $request->address,
        ]);


        flash('User Successfully Updated.');
        return redirect()->route('admin.settings.index');
    }

    public function sitelogo(Request $request)
    {
        Gate::authorize('setting_access');
        $manager = new ImageManager(new Driver());

        if ($request->hasfile('site_logo')) {

            $sitelogo = Setting::find(1);
            $deleteoldphoto = Setting::find($sitelogo->site_logo);
            if ($deleteoldphoto) {
                $path = public_path('images/') . $deleteoldphoto;
                if (file_exists($path)) {
                    unlink($path);
                }
            }
        }

        if ($request->hasFile('site_logo')) {
            $photo_upload = $request->file('site_logo');
            $imageName = time() . '.webp';

            $image = $manager->read($photo_upload);
            $image->resize(90, 73)
                ->toWebp()
                ->save(public_path('images/' . $imageName));

            $setting = Setting::find(1);

            $setting->update([
                'site_logo' => $imageName

            ]);
        }
        flash('User Successfully Updated.');

        return redirect()->route('admin.settings.index');
    }
}
