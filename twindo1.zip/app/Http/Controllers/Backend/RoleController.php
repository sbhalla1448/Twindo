<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\Module;
use App\Models\Permission;
use App\Models\PermissionRole;
use App\Models\Role;
use App\Models\User;
use App\Models\VisibilityRule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Str;


class RoleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // Gate::authorize('role_list_access');
        $roles = Role::all();
        return view('backend.roles.index', compact('roles'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        // Gate::authorize('role_permission_create');
        $modules = Module::all();
        return view('backend.roles.create', compact('modules'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // Gate::authorize('role_permission_create');

        $this->validate($request, [
            'name' => 'required|unique:roles',
            'description' => 'required',

        ]);
        $slug = Str::slug($request->name);
        Role::create([
            'name' => $request->name,
            'slug' => $slug,
            'description' => $request->description,
        ]);

        return back();
        // $this->validate($request, [
        //     'name' => 'required|unique:roles',
        //     'permissions' => 'required|array',
        //     'permissions.*' => 'integer',
        // ]);

        // return $request->all();
        $slug = Str::slug($request->name);
        $checkStoreRole = Role::where('slug', $slug)->first();
        if ($checkStoreRole != null) {
            return redirect()->route('roles.index')->with('error', 'Your Already define this role');
        } else {
            Role::create([
                'name' => $request->name,
                'slug' => $slug,
                'store_id' => Auth::user()->store,
            ])->permissions()->sync($request->input('permissions', []));

            return redirect()->route('admin.roles.index')->with('success', 'Role Successfully Added');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Role  $role
     * @return \Illuminate\Http\Response
     */
    public function show(Role $role)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Role  $role
     * @return \Illuminate\Http\Response
     */
    public function edit(Role $role)
    {

        // Gate::authorize('role_permission_edit');
        $modules = Module::where('status', 0)->get();
        $roles = Role::all();
        return view('backend.roles.permission_control', compact('modules', 'roles', 'role'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Role  $role
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Role $role)
    {
        // Gate::authorize('role_permission_edit');

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
        ]);

        $role->update($validated);
        return back();

        // $role->update([
        //     'name' => $request->name,
        //     'slug' => Str::slug($request->name),
        // ]);
        // $role->permissions()->sync($request->input('permissions', []));

        return redirect()->route('admin.roles.index')->with('success', 'Role Successfully Updated');;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Role  $role
     * @return \Illuminate\Http\Response
     */
    public function destroy(Role $role)
    {


        // Gate::authorize('role_permission_delete');

        $user = User::where('role_id', $role->id)->first();


        if ($user == null) {
            if ($role->deletable) {
                $role->delete();

                return back()->with('success', 'Role Successfully Deleted');
            } else {

                return back()->with('error', 'You can\'t delete system role');
            }
        } else {


            return back()->with('error', 'This user role can not be deleted');
        }
        return back();
    }

    public function roleBasedVisibility()
    {
        $sections = VisibilityRule::with('roles')->get();
        $roles = Role::all();
        return view('backend.roles.role_based_visibility', compact('sections', 'roles'));
    }
    public function roleBasedVisibilityUpdate(Request $request)
    {
        $roles = Role::all();
        $rules = VisibilityRule::all();

        foreach ($rules as $rule) {
            foreach ($roles as $role) {
                $key = "visibility.{$rule->id}.{$role->id}";
                $canView = data_get($request, $key, false);

                $rule->roles()->syncWithoutDetaching([
                    $role->id => ['can_view' => $canView ? true : false]
                ]);
            }
        }
        // $roles = Role::all();
        // $visibility = $request->input('visibility', []);

        // foreach ($roles as $role) {
        //     $syncData = [];

        //     foreach ($visibility as $sectionId => $roleData) {
        //         if (isset($roleData[$role->id])) {
        //             $syncData[$sectionId] = ['can_view' => true];
        //         }
        //     }

        //     // Get all section IDs, even those not included in current syncData
        //     $allSectionIds = \App\Models\VisibilityRule::pluck('id')->toArray();
        //     foreach ($allSectionIds as $id) {
        //         if (!isset($syncData[$id])) {
        //             $syncData[$id] = ['can_view' => false];
        //         }
        //     }

        //     $role->visibilityRules()->sync($syncData);
        // }

        return back();
    }
    public function permissionControll()
    {
        $modules = Module::where('status', 0)->get();
        $roles = Role::all();
        return view('backend.roles.permission_control', compact('modules', 'roles'));
    }

    public function getPermissions($id)
    {
        $role = Role::with('permissions')->findOrFail($id);
        return response()->json($role->permissions->pluck('id'));
    }

    public function permissionControllStore(Request $request)
    {
        // return $request->all();
        $validated = $request->validate([
            'role_id' => 'required',

        ]);

        $role = Role::findorfail($request->role_id);

        $role->permissions()->sync($request->input('permissions', []));
        return back();
    }



    public function per()
    {

        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'Role-Based Visibility']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Users',
        //     'slug' => 'users',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Payment Methods',
        //     'slug' => 'payment_methods',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Subscription Management',
        //     'slug' => 'subscription_management',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Product Management',
        //     'slug' => 'product_management',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Documents',
        //     'slug' => 'documents',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Messages & Actions',
        //     'slug' => 'messages_&_actions',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Tools & Resources',
        //     'slug' => 'tools_&_resources',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'System Logs',
        //     'slug' => 'system_logs',
        // ]);



        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'User Setup']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'User List Access',
        //     'slug' => 'user_list_access',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'User Create',
        //     'slug' => 'user_create',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'User Edit',
        //     'slug' => 'user_edit',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'User Delete',
        //     'slug' => 'user_delete',
        // ]);


        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'Role Permission']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Role List Access',
        //     'slug' => 'role_list_access',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Role & Permission Create',
        //     'slug' => 'role_permission_create',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Role & Permission Edit',
        //     'slug' => 'role_permission_edit',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Role & Permission Delete',
        //     'slug' => 'role_permission_delete',
        // ]);

        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'Dashboard']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Dashboard',
        //     'slug' => 'dashboard_access',
        // ]);
        $moduleAppDashboard = Module::updateOrCreate(['name' => 'System Logs']);
        Permission::updateOrCreate([
            'module_id' => $moduleAppDashboard->id,
            'name' => 'System Log Access',
            'slug' => 'system_log_access',
        ]);




        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'Settings']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Setting Access',
        //     'slug' => 'setting_access',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'General Settings',
        //     'slug' => 'setting_view',
        // ]);


        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'Documents']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Document List Access',
        //     'slug' => 'documents_access',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Document Create',
        //     'slug' => 'documents_create',
        // ]);

        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Document Edit',
        //     'slug' => 'documents_edit',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Document Destroy',
        //     'slug' => 'documents_delete',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Document Archive Access',
        //     'slug' => 'documents_arichive_access',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Document Archive Create',
        //     'slug' => 'documents_arichive',
        // ]);

        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'Page Panel']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Page List Access',
        //     'slug' => 'page_access',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Page Create',
        //     'slug' => 'page_create',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Page View',
        //     'slug' => 'page_view',
        // ]);

        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Page Edit',
        //     'slug' => 'page_edit',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Page Destroy',
        //     'slug' => 'page_delete',
        // ]);




        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'Faq Panel']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Faq List Access',
        //     'slug' => 'faq_access',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Faq Create',
        //     'slug' => 'faq_create',
        // ]);

        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Faq Edit',
        //     'slug' => 'faq_edit',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Faq Destroy',
        //     'slug' => 'faq_delete',
        // ]);

        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'Lead Banner']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'lead Banner Access',
        //     'slug' => 'lead_banner_access',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Lead Banner Create',
        //     'slug' => 'lead_banner_create',
        // ]);

        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'lead_banner Edit',
        //     'slug' => 'lead_banner_edit',
        // ]);



        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'Service Panel']);
        //         Permission::updateOrCreate([
        //             'module_id' => $moduleAppDashboard->id,
        //             'name' => 'Service List Access',
        //             'slug' => 'service_access',
        //         ]);
        //         Permission::updateOrCreate([
        //             'module_id' => $moduleAppDashboard->id,
        //             'name' => 'Service Create',
        //             'slug' => 'service_create',
        //         ]);

        //         Permission::updateOrCreate([
        //             'module_id' => $moduleAppDashboard->id,
        //             'name' => 'Service Edit',
        //             'slug' => 'service_edit',
        //         ]);
        //         Permission::updateOrCreate([
        //             'module_id' => $moduleAppDashboard->id,
        //             'name' => 'Service Destroy',
        //             'slug' => 'service_delete',
        //         ]);

        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'Event Panel']);
        //         Permission::updateOrCreate([
        //             'module_id' => $moduleAppDashboard->id,
        //             'name' => 'Event List Access',
        //             'slug' => 'event_access',
        //         ]);
        //         Permission::updateOrCreate([
        //             'module_id' => $moduleAppDashboard->id,
        //             'name' => 'Event Create',
        //             'slug' => 'event_create',
        //         ]);

        //         Permission::updateOrCreate([
        //             'module_id' => $moduleAppDashboard->id,
        //             'name' => 'Event Edit',
        //             'slug' => 'event_edit',
        //         ]);
        //         Permission::updateOrCreate([
        //             'module_id' => $moduleAppDashboard->id,
        //             'name' => 'Event Destroy',
        //             'slug' => 'event_delete',
        //         ]);


        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'Gallery Panel']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Gallery List Access',
        //     'slug' => 'gallery_access',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Gallery Create',
        //     'slug' => 'gallery_create',
        // ]);

        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Gallery Edit',
        //     'slug' => 'gallery_edit',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Gallery Destroy',
        //     'slug' => 'gallery_delete',
        // ]);


        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'Member Panel']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Member List Access',
        //     'slug' => 'member_access',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Member Create',
        //     'slug' => 'member_create',
        // ]);

        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Member Edit',
        //     'slug' => 'member_edit',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Member Destroy',
        //     'slug' => 'member_delete',
        // ]);

        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'EC Member Panel']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'EC Member List Access',
        //     'slug' => 'ec_member_access',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'EC Member Create',
        //     'slug' => 'ec_member_create',
        // ]);

        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'EC Member Edit',
        //     'slug' => 'ec_member_edit',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'EC Member Destroy',
        //     'slug' => 'ec_member_delete',
        // ]);

        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'Parnter Panel']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Partner List Access',
        //     'slug' => 'partner_access',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Partner Create',
        //     'slug' => 'partner_create',
        // ]);

        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Partner Edit',
        //     'slug' => 'partner_edit',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Partner Destroy',
        //     'slug' => 'partner_delete',
        // ]);
        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'Tradw Show Panel']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Trade Show List Access',
        //     'slug' => 'trade_show_access',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Trade Show Create',
        //     'slug' => 'trade_show_create',
        // ]);

        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Trade Show Edit',
        //     'slug' => 'trade_show_edit',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Trade Show Destroy',
        //     'slug' => 'trade_show_delete',
        // ]);
        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'Tradw Show Details Panel']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Trade Show Details List Access',
        //     'slug' => 'trade_show_details_access',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Trade Show Details Create',
        //     'slug' => 'trade_show_details_create',
        // ]);

        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Trade Show Details Edit',
        //     'slug' => 'trade_show_details_edit',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Trade Show Details Destroy',
        //     'slug' => 'trade_show_details_delete',
        // ]);
        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'Crs Panel']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Crs List Access',
        //     'slug' => 'crs_access',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Crs Create',
        //     'slug' => 'crs_create',
        // ]);

        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Crs Edit',
        //     'slug' => 'crs_edit',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Crs Destroy',
        //     'slug' => 'crs_delete',
        // ]);
        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'Category Panel']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Category List Access',
        //     'slug' => 'category_access',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Category Create',
        //     'slug' => 'category_create',
        // ]);

        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Category Edit',
        //     'slug' => 'category_edit',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Category Destroy',
        //     'slug' => 'category_delete',
        // ]);
        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'Club History Panel']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Club History List Access',
        //     'slug' => 'club_history_access',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Club History Create',
        //     'slug' => 'club_history_create',
        // ]);

        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Club History Edit',
        //     'slug' => 'club_history_edit',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Club History Destroy',
        //     'slug' => 'club_history_delete',
        // ]);

        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'About Us Panel']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'About Us List Access',
        //     'slug' => 'aboutus_access',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'About Us Create',
        //     'slug' => 'aboutus_create',
        // ]);

        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'About Us Edit',
        //     'slug' => 'aboutus_edit',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'About Us Destroy',
        //     'slug' => 'aboutus_delete',
        // ]);
        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'Notice Panel']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Notice List Access',
        //     'slug' => 'notice_access',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Notice Create',
        //     'slug' => 'notice_create',
        // ]);

        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Notice Edit',
        //     'slug' => 'notice_edit',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Notice Destroy',
        //     'slug' => 'notice_delete',
        // ]);

        // $moduleAppDashboard = Module::updateOrCreate(['name' => 'CLub Panel']);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Club List Access',
        //     'slug' => 'club_access',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Club Create',
        //     'slug' => 'club_create',
        // ]);

        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Club Edit',
        //     'slug' => 'club_edit',
        // ]);
        // Permission::updateOrCreate([
        //     'module_id' => $moduleAppDashboard->id,
        //     'name' => 'Club Destroy',
        //     'slug' => 'club_delete',
        // ]);






        return $moduleAppDashboard;
    }
}
