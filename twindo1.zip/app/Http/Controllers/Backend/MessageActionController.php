<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\MessageAction;
use App\Http\Requests\StoreMessageActionRequest;
use App\Http\Requests\UpdateMessageActionRequest;

class MessageActionController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('backend.message_actions.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view('backend.message_actions.compose');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreMessageActionRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(MessageAction $messageAction)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(MessageAction $messageAction)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateMessageActionRequest $request, MessageAction $messageAction)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(MessageAction $messageAction)
    {
        //
    }
}
