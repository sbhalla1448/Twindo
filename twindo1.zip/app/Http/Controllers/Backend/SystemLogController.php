<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Http\Repositories\SystemLogRepository;
use Illuminate\Http\Request;

class SystemLogController extends Controller
{
    public function __construct(private readonly SystemLogRepository $repository)
    {}

    public function index()
    {
        // Gate::authorize('user_list_access');
        // $systemLogs = $this->repository->gets();
        // return view('backend.system_logs.index', compact('systemLogs'));
        return view('backend.system_logs.index');
    }
}
