<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Models\CreditScore;
use Illuminate\Http\Request;

class CreditHistoryController extends Controller
{
    public function index()
    {
        return view('backend.credit.index');
    }
        public function downloadCSV()
        {
            $selectedIds = session('selected_credit_scores', []);

            if (empty($selectedIds)) {
                return redirect()->back()->with('error', 'No credit scores selected.');
            }

            $fileName = 'selected_credit_scores.csv';
            $headers = [
                'Content-Type' => 'text/csv',
                'Content-Disposition' => "attachment; filename=\"$fileName\"",
            ];

            $callback = function () use ($selectedIds) {
                $handle = fopen('php://output', 'w');
                fputcsv($handle, ['ID', 'User Name', 'Score', 'Score Date']);

                CreditScore::with('user')
                    ->whereIn('id', $selectedIds)
                    ->each(function ($score) use ($handle) {
                        fputcsv($handle, [
                            $score->id,
                            $score->user->name ?? '',
                            $score->score,
                            $score->score_date,
                        ]);
                    });

                fclose($handle);
            };

            return response()->stream($callback, 200, $headers);

            
        }
}
