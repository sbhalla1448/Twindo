<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreDocumentRequest;
use App\Http\Requests\UpdateDocumentRequest;
use App\Models\Document;
use App\Models\DocumentUpload;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Gate;
use Intervention\Image\Drivers\Gd\Driver;
use Intervention\Image\ImageManager;
use Illuminate\Support\Facades\Storage;

class DocumentController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('backend.documents.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $users = User::where('role_id', 2)->get(['id', 'name']);
        return view('backend.documents.create', compact('users'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreDocumentRequest $request)
    {

        $storeDocument = Document::create($request->validated());

        if (!empty($request->file_names)) {
            foreach ($request->file_names as $file) {
                $extension = $file->getClientOriginalExtension();
                $filename = uniqid() . '_' . time() . '.' . $extension;
                $path = $file->storeAs('uploads', $filename, 'public');

                DocumentUpload::create([
                    'document_id' => $storeDocument->id,
                    'file_type' => $extension,
                    'file_name' => $filename
                ]);
            }
        }

        flash('Document Uploaded Successfully');

        return redirect()->route('admin.documents.index');
    }

    /**
     * Display the specified resource.
     */
    public function show(Document $document)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit($encrypted_id)
    {
        try {
            $id = Crypt::decryptString($encrypted_id);
            $doc = Document::findOrFail($id);
            $users = User::where('role_id', 2)->get(['id', 'name']);
            return view('backend.documents.edit', compact('doc', 'users'));
        } catch (\Exception $e) {
            abort(404, 'Invalid or tampered ID');
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateDocumentRequest $request, Document $document)
    {

        // return $request->all();
        $document->update($request->validated());
        if (!empty($request->file_names)) {
            foreach ($request->file_names as $file) {
                $extension = $file->getClientOriginalExtension();
                $filename = uniqid() . '_' . time() . '.' . $extension;
                $path = $file->storeAs('uploads', $filename, 'public');

                DocumentUpload::create([
                    'document_id' => $document->id,
                    'file_type' => $extension,
                    'file_name' => $filename
                ]);
            }
        }

        flash('Document Uploaded Successfully');

        return redirect()->route('admin.documents.index');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Document $document)
    {
        //
    }

    public function documentDelete(Request $request, $encrypted_id)
    {
        try {
            $id = Crypt::decryptString($encrypted_id);
            $doc = Document::findOrFail($id);
            if ($request->pdelete == 'yes') {

                $files = DocumentUpload::where('document_id', $id)->get();
                foreach ($files as $file) {
                    $filePath = 'uploads/' . $file->file_name;
                    if (Storage::disk('public')->exists($filePath)) {
                        Storage::disk('public')->delete($filePath);
                    } else {
                        session()->flash('error', 'File not found.');
                    }
                }
                Document::findorfail($id)->delete();
                return to_route('admin.documents.index');
            } else {
                return view('backend.documents.delete_document', compact('doc'));
            }
        } catch (\Exception $e) {
            abort(404, 'Invalid or tampered ID');
        }

        // try {
        //     $id = Crypt::decryptString($encrypted_id);
        //     $doc = Document::findOrFail($id);
        //     return view('backend.documents.delete_document', compact('doc'));
        // } catch (\Exception $e) {
        //     abort(404, 'Invalid or tampered ID');
        // }
    }
    public function documentArchived(Request $request, $encrypted_id)
    {
        try {
            $id = Crypt::decryptString($encrypted_id);
            $doc = Document::findOrFail($id);
            if ($request->archived == 'yes') {


                $doc->update(['archive_status' => 1]);
                return to_route('admin.documents.index');
            } else {
                return view('backend.documents.archive_document', compact('doc'));
            }
        } catch (\Exception $e) {
            abort(404, 'Invalid or tampered ID');
        }
    }
    public function documentArchivedRestore($encrypted_id)
    {
        try {
            $id = Crypt::decryptString($encrypted_id);
            $doc = Document::findOrFail($id);
            $doc->update(['archive_status' => 0]);
            return to_route('admin.documents.index');
        } catch (\Exception $e) {
            abort(404, 'Invalid or tampered ID');
        }
    }
    public function documentArchivedIndex()
    {
        $documents = Document::with('user')->where('archive_status', 1)->get();
        return view('backend.documents.archived_index', compact('documents'));
    }


    public function deleteFile($id)
    {
        $file = DocumentUpload::findOrFail($id);
        $filePath = 'uploads/' . $file->file_name;
        // Optionally delete the physical file too
        if (Storage::disk('public')->exists($filePath)) {
            Storage::disk('public')->delete($filePath);
        } else {
            session()->flash('error', 'File not found.');
        }

        $file->delete();

        return back()->with('success', 'File deleted successfully.');
    }
}
