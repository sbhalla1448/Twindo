<?php

namespace App\Http\Controllers\Backend;

use App\Models\User;
use App\Models\TemplateReport;
use App\Http\Controllers\Controller;
use App\Http\Requests\StoreTemplateReportRequest;
use App\Http\Requests\UpdateTemplateReportRequest;

class TemplateReportController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return view('backend.report_analysis.index');
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $users = User::where('role_id',2)->get(['id','name']);
        return view('backend.report_analysis.form',compact('users'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreTemplateReportRequest $request)
    {
        $store = TemplateReport::create($request->validated());
        return redirect()->route('admin.tempateReports.index')->with('success','Report Store Successfully');
    }

    /**
     * Display the specified resource.
     */
    public function show(TemplateReport $templateReport, $id)
    {

        $templateReport = TemplateReport::findOrFail($id);

        $users = User::where('role_id',2)->get(['id','name']);
        return view('backend.report_analysis.show',compact('users','templateReport'));

    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(TemplateReport $templateReport, $id)
    {


       $templateReport = TemplateReport::findOrFail($id);
        $users = User::where('role_id',2)->get(['id','name']);
        return view('backend.report_analysis.form',compact('users','templateReport'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateTemplateReportRequest $request, TemplateReport $templateReport)
    {
       $templateReport->update($request->validated());
       return redirect()->route('admin.tempateReports.index')->with('success','Report Update Successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(TemplateReport $templateReport)
    {
        //
    }
}
