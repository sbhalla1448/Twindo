<?php

namespace App\Http\Controllers\Frontend;
use App\Http\Controllers\Controller;

use App\Models\Coupon;
use App\Models\Payment;
use App\Models\Subscription;
use App\Models\SubscriptionPlan;
use App\Notifications\PackageRegistration;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Stripe\PaymentIntent;
use Stripe\Stripe;

class CheckoutSuccessController extends Controller
{
    public function __invoke(Request $request)
    {
        // Set Stripe Secret Key
        Stripe::setApiKey(config('stripe.stripe_sk'));

        $paymentIntentId  = $request->query('payment_intent');


        if (!$paymentIntentId) {
            return view('customer.payment.failed', [
                'message' => 'Missing payment intent ID.',
            ]);
        }

        try {
            // Retrieve the PaymentIntent from Stripe
            $intent = PaymentIntent::retrieve($paymentIntentId);



            // Check if payment succeeded
            if ($intent->status === 'succeeded') {
                // Save payment to database if needed
                $user = Auth::user();
                $planId = $intent->metadata->plan_id;
                $subscriptionPlan = SubscriptionPlan::findorfail($planId);
                $checkPayment = Payment::where('transaction_id',$intent->id)->first();
                $oneItmeJob = $intent->metadata->plan_id;
               if(!$checkPayment)
               {
                if($subscriptionPlan->status==0)
                {
                     $currentSubscription = Subscription::where('user_id',  $user->id)->latest()->take(1)->first();
                       if(Carbon::parse($currentSubscription->end_date)->isPast())
                       {

                           $subscription=  Subscription::create([
                                    'user_id' => $user->id,
                                    'subscription_plan_id' => $planId,
                                    'subcription_type' => $intent->metadata->duration === 'monthly'
                                        ? 'Monthly'
                                        : 'Yearly',
                                    'start_date' => now(),
                                    'end_date' => $intent->metadata->duration === 'monthly'
                                        ? now()->addMonths(1)
                                        : now()->addYears(1),
                                    'status' => 'Active',
                                    'extra_plan' => $subscriptionPlan->name ? [$subscriptionPlan->name] : []

                                ]);

                            $orderCreate = Payment::create([
                                'user_id' =>  $user->id,
                                'subscription_id' =>  $subscription->id,
                                'transaction_id' => $intent->id,
                                'amount' => $intent->amount / 100,
                                'currency' => $intent->currency,
                                'subscription_plan_id' => $planId,
                                'status' => $intent->status,
                                'payment_gateway' => 'Stripe',

                            ]);

                        if($intent->metadata->discount > 0 )
                        {
                            $coupon = Coupon::where('code', $intent->metadata->couponCode)->first();
                            $coupon->increment('used_count');
                        }

                       }else{
                        $features = $currentSubscription->extra_plan ?? [];
                        $features[] = $subscriptionPlan->name;
                        $currentSubscription->extra_plan = array_unique($features);
                        $currentSubscription->save();
                          $orderCreate = Payment::create([
                                'user_id' =>  $user->id,
                                'subscription_id' =>  $currentSubscription->id,
                                'transaction_id' => $intent->id,
                                'amount' =>$intent->amount / 100,
                                'currency' => $intent->currency,
                                'subscription_plan_id' => $planId,
                                'status' => $intent->status,
                                'payment_gateway' => 'Stripe',
                                'metadata' => $intent->metadata,

                            ]);
                            if($intent->metadata->discount > 0 )
                            {
                                $coupon = Coupon::where('code', $intent->metadata->couponCode)->first();
                                $coupon->increment('used_count');
                            }
                       }

                }else{
                $subscription=  Subscription::create([
                        'user_id' => $user->id,
                        'subscription_plan_id' => $planId,
                        'subcription_type' =>$intent->metadata->duration === 'monthly'
                            ? 'Monthly'
                            : 'Yearly',
                        'start_date' => now(),
                        'end_date' =>$intent->metadata->duration === 'monthly'
                            ? now()->addMonths(1)
                            : now()->addYears(1),
                        'status' => 'Active',
                    ]);

                $orderCreate = Payment::create([
                    'user_id' =>  $user->id,
                    'subscription_id' =>  $subscription->id,
                    'transaction_id' => $intent->id,
                    'amount' => $intent->amount / 100,
                    'currency' => $intent->currency,
                    'subscription_plan_id' => $planId,
                    'status' => $intent->status,
                    'metadata' => $intent->metadata,
                    'payment_method_types' => $intent->payment_method_types[0] ?? 'unknown',
                    'payment_gateway' => 'Stripe',

                ]);
                if($intent->metadata->discount > 0 )
                {
                    $coupon = Coupon::where('code', $intent->metadata->couponCode)->first();
                    $coupon->increment('used_count');
                }
            }


            }
            $user = auth()->user();
            $currentSubscriptionPlan = Subscription::where('user_id',  $user->id)->latest()->take(1)->first();
            $user->notify(new PackageRegistration($currentSubscriptionPlan));
            
                // Perform any subscription or user role activation logic here
                session()->forget('checkout_' . auth()->id());
                return view('customer.payment.success', [
                    'intent' => $intent,
                    'currentPlan' => $currentSubscriptionPlan,
                ]);

            }
            session()->forget('checkout_' . auth()->id());
            // Payment not succeeded
            return view('customer.payment.failed', [
                'message' => 'Payment not completed. Status: ' . $intent->status,
            ]);

        } catch (\Exception $e) {
            // Handle Stripe or API errors
            session()->forget('checkout_' . auth()->id());
            return view('customer.payment.failed', [
                'message' => 'Stripe Error: ' . $e->getMessage(),
            ]);
        }
    }
}
