<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\SubscriptionPlan;
use Illuminate\Http\Request;

class FrontendController extends Controller
{
    public function index()
    {
        return view('frontend.plan');
    }
    public function comparison()
    {
        return view('frontend.comparison');
    }
    public function signUp()
    {
        return view('frontend.sign_up');
    }

    public function frontendCheckout($slug)
    {

      $splan = SubscriptionPlan::where('slug', $slug)->first();

        return view('customer.payment.checkout', compact('splan'));
    }


}
