<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Services\AppleClientSecret;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Laravel\Socialite\Facades\Socialite;

class SocialLoginController extends Controller
{
    public function redirect($provider)
    {
        return Socialite::driver($provider)->redirect();
    }

    public function callback($provider)
    {
        try {
            $socialUser = Socialite::driver($provider)->user();


            // Check if the user exists
            $user = User::where('email', $socialUser->getEmail())->first();

            if (!$user) {
                // Create a new user
                $user = User::create([
                    'role_id' => 2,
                    'status' => true,
                    'name' => $socialUser->getName(),
                    'email' => $socialUser->getEmail(),
                    'provider' => $provider,
                    'provider_id' => $socialUser->getId(),
                    'image' => $socialUser->getAvatar(),
                ]);
            }

            // $user = User::updateOrCreate([
            //     'provider_id' => $socialUser->id,
            // ], [
            //     'name' => $socialUser->name,
            //     'email' => $socialUser->email,
            //     'provider' => $provider,
            //     'image' => $socialUser->getAvatar(),
            //     // 'github_refresh_token' => $socialUser->refreshToken,
            // ]);

            // Log the user in
            Auth::login($user);


            return to_route('home');
        } catch (\Exception $e) {
            return redirect('/login')->withErrors(['error' => 'Unable to login, please try again.']);
        }
    }


    public function redirectToApple()
    {
        $clientSecret = AppleClientSecret::generate();

        config(['services.apple.client_secret' => $clientSecret]);

        return Socialite::driver('apple')->redirect();
    }

    public function handleAppleCallback()
    {
        $clientSecret = AppleClientSecret::generate();
        config(['services.apple.client_secret' => $clientSecret]);

        $appleUser = Socialite::driver('apple')->user();

        $user = User::updateOrCreate([
            'email' => $appleUser->getEmail(),
        ], [
            'name' => $appleUser->getName() ?? 'Apple User',
            'apple_id' => $appleUser->getId(),
        ]);

        Auth::login($user);

        return redirect()->intended('/');
    }
}
