<?php

namespace App\Http\Controllers\Auth;

use Carbon\Carbon;
use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/home';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
        $this->middleware('auth')->only('logout');
    }

    function authenticated(Request $request, $user)
    {
        if($user->status == 0)
        {
            Auth::logout();
            return to_route('login')->with('error', 'Your account is deactive. Please contact support.');
        }

        $user->update([
            'last_login_at' => Carbon::now()->toDateTimeString(),
            'active_status' => 1,
        ]);
    }

    public function logout(Request $request)
    {
        $user = User::findorfail(Auth::user()->id);
        $user->update(['active_status' => 0, 'last_logout_at' => Carbon::now()->toDateTimeString()]);
        $this->guard()->logout();

        $request->session()->invalidate();

        return redirect('/');
    }
}
