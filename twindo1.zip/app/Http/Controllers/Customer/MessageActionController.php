<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\MessageAction;
use App\Models\Note;
use Illuminate\Http\Request;

class MessageActionController extends Controller
{
    public function index()
    {
        $data['note'] = Note::where('user_id', auth()->user()->id)->first();
        $data['messages'] = MessageAction::where('user_id', auth()->user()->id)->get();
        return view('customer.message_action',$data);
    }

    public function storeNote(Request $request)
    {
        $request->validate([
            'description' => 'required|string',
        ]);

        $store = Note::updateOrCreate(
            ['user_id' => auth()->user()->id],
         [

            'description' => $request->description,
        ]);

        return redirect()->back()->with('success', 'Note saved successfully.');
    }

}
