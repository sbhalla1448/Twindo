<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Models\Subscription;
use Illuminate\Http\Request;

class SubscriptionController extends Controller
{
    public function mySubscription()
    {
        $data['subscription'] = Subscription::where('user_id', auth()->id())->latest()->take(1)->first();
        $data['payments'] = Payment::where('user_id', auth()->id())->latest()->get();
        return view('customer.my_subscription',$data);
    }

    public function cancelMySubscription()
    {
        $subscription = Subscription::where('user_id', auth()->id())->latest()->take(1)->first();
        if ($subscription) {
            $subscription->update(['status' => 'Cancelled']);
            return redirect()->route('subscription')->with('success', 'Subscription cancelled successfully.');
        }
        return redirect()->route('subscription')->with('error', 'No active subscription found.');
    }
}
