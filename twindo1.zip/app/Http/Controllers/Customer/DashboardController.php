<?php

namespace App\Http\Controllers\Customer;

use Carbon\Carbon;
use App\Models\CreditScore;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Document;
use App\Models\DocumentUpload;
use App\Models\MessageAction;
use App\Models\Subscription;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function index(Request $request)
    {

        $data['user'] = Auth::user();
        $data['filter'] = $request->input('filter', 'all'); // default is 'all'
        $filter = $request->input('filter', 'all'); // default is 'all'
        $query = CreditScore::where('user_id', auth()->id())->where('score_status','Approve');


        if ($filter === '3m') {
            $query->where('score_date', '>=', Carbon::now()->subMonths(3));
        } elseif ($filter === '6m') {
            $query->where('score_date', '>=', Carbon::now()->subMonths(6));
        } elseif ($filter === '12m') {
            $query->where('score_date', '>=', Carbon::now()->subMonths(12));
        }
        // $scores = CreditScore::where('user_id', auth()->id())
        //     ->orderBy('score_date') // or 'created_at' if you track dates there
        //     ->get();
        $scores = $query->orderBy('score_date')->get();
        $data['allScores'] = CreditScore::where('user_id', operator: auth()->id())->where('score_status','Approve')->latest()->get();
        $data['allScoresWithStatus'] = CreditScore::with(relations: 'latestComment')->where('user_id', auth()->id())->latest()->get();
        $data['highestScore'] = $data['allScores']->max('score');
        $data['lowestScore'] = $data['allScores']->min('score');



        $data['currentScore'] = CreditScore::where('user_id', auth()->id())->where('score_status','Approve')->latest()->first();
        $data['currentSubscription'] = Subscription::where('user_id', auth()->id())->where('status','Active')->latest()->first();
        $data['current2ndScore'] = CreditScore::where('user_id', auth()->id())->where('score_status','Approve')->latest()->skip(1)->first();

        $data['labels'] = $scores->pluck('score_date')->map(fn($d) => \Carbon\Carbon::parse($d)->format('M Y'))->toArray();
        $data['dataS'] = $scores->pluck('score')->toArray();
        $data['unreadMsg'] = MessageAction::where('user_id', auth()->id())->where('read_status_user',0)->count();
        $data['uploadDocument'] = Document::withCount('files')->where('user_id', auth()->id())->get()->sum('files_count');
        // return  $data['uploadDocument'];
        return view('customer.dashboard', $data);
    }

    public function toolResource()
    {
        return view('customer.tools_resource');
    }
}
