<?php

namespace App\Http\Controllers\Customer;

use Carbon\Carbon;
use App\Models\CreditScore;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Intervention\Image\ImageManager;
use App\Http\Requests\StoreCreditScore;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\Drivers\Gd\Driver;

class CreditScoreController extends Controller
{
    public function index(Request $request)
    {
        $data['filter'] = $request->input('filter', 'all'); // default is 'all'
        $filter = $request->input('filter', 'all'); // default is 'all'
        $query = CreditScore::where('user_id', auth()->id())->where('score_status','Approve');


        if ($filter === '3m') {
            $query->where('score_date', '>=', Carbon::now()->subMonths(3));
        } elseif ($filter === '6m') {
            $query->where('score_date', '>=', Carbon::now()->subMonths(6));
        } elseif ($filter === '12m') {
            $query->where('score_date', '>=', Carbon::now()->subMonths(12));
        }
        // $scores = CreditScore::where('user_id', auth()->id())
        //     ->orderBy('score_date') // or 'created_at' if you track dates there
        //     ->get();
        $scores = $query->orderBy('score_date')->get();
        $data['allScores'] = CreditScore::where('user_id', operator: auth()->id())->where('score_status','Approve')->latest()->get();
        $data['allScoresWithStatus'] = CreditScore::with(relations: 'latestComment')->where('user_id', auth()->id())->latest()->get();
        $data['highestScore'] = $data['allScores']->max('score');
        $data['lowestScore'] = $data['allScores']->min('score');



        $data['currentScore'] = CreditScore::where('user_id', auth()->id())->where('score_status','Approve')->latest()->first();
        $data['current2ndScore'] = CreditScore::where('user_id', auth()->id())->where('score_status','Approve')->latest()->skip(1)->first();

        $data['labels'] = $scores->pluck('score_date')->map(fn($d) => \Carbon\Carbon::parse($d)->format('M Y'))->toArray();
        $data['dataS'] = $scores->pluck('score')->toArray();
        return view('customer.credit_score_history',$data);
    }
    // public function index(Request $request)
    // {
    //     $data['filter'] = $request->input('filter', 'all'); // default is 'all'
    //     $filter = $request->input('filter', 'all'); // default is 'all'
    //     $query = CreditScore::where('user_id', auth()->id())->where('score_status','Approve');


    //     if ($filter === '3m') {
    //         $query->where('score_date', '>=', Carbon::now()->subMonths(3));
    //     } elseif ($filter === '6m') {
    //         $query->where('score_date', '>=', Carbon::now()->subMonths(6));
    //     } elseif ($filter === '12m') {
    //         $query->where('score_date', '>=', Carbon::now()->subMonths(12));
    //     }
    //     // $scores = CreditScore::where('user_id', auth()->id())
    //     //     ->orderBy('score_date') // or 'created_at' if you track dates there
    //     //     ->get();
    //     $scores = $query->orderBy('score_date')->get();
    //     $data['allScores'] = CreditScore::where('user_id', auth()->id())->where('score_status','Approve')->latest()->get();
    //     $data['allScoresreject'] = CreditScore::where('user_id', auth()->id())->latest()->get();
    //     $data['highestScore'] = $data['allScores']->max('score');
    //     $data['lowestScore'] = $data['allScores']->min('score');



    //     $data['currentScore'] = CreditScore::where('user_id', auth()->id())->where('score_status','Approve')->latest()->first();
    //     $data['current2ndScore'] = CreditScore::where('user_id', auth()->id())->where('score_status','Approve')->latest()->skip(1)->first();

    //     $data['labels'] = $scores->pluck('score_date')->map(fn($d) => \Carbon\Carbon::parse($d)->format('M Y'))->toArray();
    //     $data['dataS'] = $scores->pluck('score')->toArray();
    //     return view('customer.credit_score_history',$data);
    // }
    public function createUploadScore()
    {
        return view('customer.upload_credit_score');
    }

    public function store(StoreCreditScore $request)
    {

        $store = CreditScore::create($request->validated() + ['user_id' => auth()->id()]);


        if ($request->hasFile('image')) {
            $manager = new ImageManager(new Driver());
            $photo_upload = $request->file('image');
            $imageName = time() . '.webp';
                $image = $manager->read($photo_upload->getRealPath())
                    // ->cover(870, 493)
                    ->toWebp(90);
                Storage::disk('public')->put('uploads/' . $imageName, (string) $image);
                $store->update([
                    'image' => $imageName
                ]);
        }



        return redirect()->route('credit.history')->with('success', 'Credit score uploaded successfully.');
    }
}
