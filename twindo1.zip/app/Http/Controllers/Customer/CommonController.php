<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use App\Models\TemplateReport;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CommonController extends Controller
{
    public function index()
    {
        return view('customer.twofa');
    }
    public function accountStatusSuspendOrLock()
    {
        return view('backend.suspen_bashboard');
    }
    public function resetUserCredential()
    {
        return view('backend.reset_user_credential');
    }



    public function sessionLogout(Request $request)
    {
        if (Auth::user()->session_timeout == 1) {
            Auth::logout();
            $request->session()->invalidate();
            $request->session()->regenerateToken();
            return redirect('/login');
        }
    }

        public function comparison()
    {
        return view('customer.comparison');
    }


    public function productService()
    {
        return view('customer.product_service');
    }
    public function analysisReport()
    {
        $reports = TemplateReport::where('user_id', Auth::user()->id)->get();
        return view('customer.analysis_report.analysis_report',compact('reports'));
    }
    public function analysisReportShow($id)
    {

      $templateReport = TemplateReport::where('id',$id)->where('user_id', Auth::user()->id)->first();



      return view('customer.analysis_report.analysis_report_show',compact('templateReport'));
    }

}
