<?php

namespace App\Http\Controllers\Customer;

use App\Models\Document;
use Illuminate\Http\Request;
use App\Models\DocumentUpload;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use App\Http\Requests\StoreCustomerDocumentRequest;

class DocumentController extends Controller
{
    public function index()
    {
        $documents = Document::with('files')->where('user_id', auth()->user()->id)->get();
        return view('customer.my_document',compact('documents'));
    }

    public function getFiles($id)
{


    $document = Document::with('files')->findOrFail($id);


    return response()->json($document->files);
}

public function uploadDocuments(StoreCustomerDocumentRequest $request)
{
    $storeDocument = Document::create($request->validated()+ ['user_id'=> Auth::user()->id]);

    if (!empty($request->file_names)) {
        foreach ($request->file_names as $file) {
            $extension = $file->getClientOriginalExtension();
            $filename = uniqid() . '_' . time() . '.' . $extension;
            $path = $file->storeAs('uploads', $filename, 'public');

            DocumentUpload::create([
                'document_id' => $storeDocument->id,
                'file_type' => $extension,
                'file_name' => $filename
            ]);
        }
    }

    flash('Document Uploaded Successfully');
    return back()->with('success', 'Document Uploaded Successfully');
}

}
