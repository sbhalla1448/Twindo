<?php


namespace App\Http\Controllers\Customer;
use Carbon\Carbon;

use Stripe\Stripe;
use App\Models\User;
use Stripe\Customer;
use App\Models\Payment;
use Stripe\PaymentIntent;
use App\Models\Subscription;
use Illuminate\Http\Request;
use App\Mail\FailedPaymentEmail;
use App\Mail\PaymentSuccessMail;
use App\Models\SubscriptionPlan;
use Illuminate\Support\Facades\Log;
use Stripe\Exception\CardException;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Validator;
use Stripe\Exception\ApiErrorException;

class PaymentController extends Controller
{
    public function __construct()
    {
        Stripe::setApiKey(config('stripe.stripe_sk'));
    }

    public function checkout(Request $request)
    {
        // return $request->all();

        $plan = SubscriptionPlan::findorfail($request->plan_id);
        $amount = $request->amount;
        session()->put('plan_id', $request->plan_id);
        session()->put('duration', $request->duration);
        session()->put('job_id', $request->job_id);
        session()->put('plan_name', $request->plan_name);

        if ($request->payment_method === 'stripe') {

            \Stripe\Stripe::setApiKey(config('stripe.stripe_sk'));
            // $stripe = new \Stripe\StripeClient(config('stripe.stripe_sk'));

            $lineItems = [];




            $lineItems[] = [
                'price_data' => [
                    'currency' => 'usd',
                    'product_data' => [
                        'name' => $plan->name,
                        'description' => 'sdfasdf',
                    ],
                    'unit_amount' => $amount * 100,
                ],
                'quantity' => 1,
            ];



            // $response = $stripe->checkout->sessions->create([
            $response =  \Stripe\Checkout\Session::create([

                'line_items' => $lineItems,
                'mode' => 'payment',
                'success_url' => route('stripe.success') . '?session_id={CHECKOUT_SESSION_ID}',
                'cancel_url' => route('stripe.cancel'),
            ]);

            return redirect($response->url);
        } elseif ($request->payment_method === 'paypal') {
            $provider = new PayPalClient;
            $provider->setApiCredentials(config('paypal'));
            $paypalToken = $provider->getAccessToken();
            $response = $provider->createOrder([
                "intent" => "CAPTURE",
                "application_context" => [
                    "return_url" => route('paypal.success'),
                    "cancel_url" => route('paypal.cancel')
                ],
                "purchase_units" => [
                    [
                        "amount" => [
                            "currency_code" => "USD",
                            "value" => $total,
                        ]
                    ]
                ]
            ]);

            if (isset($response['id']) && $response['id'] != null) {
                foreach ($response['links'] as $link) {
                    if ($link['rel'] === 'approve') {
                        // session()->put('product_name', $request->product_name);
                        // session()->put('quantity', $request->quantity);
                        return redirect()->away($link['href']);
                    }
                }
                // Mail::to($user->email)->send(new FailedPaymentEmail($plan));
                return redirect()

                    ->route('cancel.payment')

                    ->with('error', 'Something went wrong.');
            } else {

                return redirect()

                    ->route('create.payment')

                    ->with('error', $response['message'] ?? 'Something went wrong.');
            }
        } else {
            return "casho on delivery";
        }
    }

    public function cancelStripe()

    {

        return redirect()

            ->route('subscription');
    }

    public function paymentSuccessPaypal(Request $request)

    {

        $provider = new PayPalClient;

        $provider->setApiCredentials(config('paypal'));

        $provider->getAccessToken();

        $response = $provider->capturePaymentOrder($request['token']);

        $user = Auth::user();
        $planId = session()->get('plan_id');
        $duration = session()->get('duration');
        $job = session()->get('job_id');
        $planName = session()->get('plan_name');
        $plan = SubscriptionPlan::findorfail($planId);

        if (isset($response['status']) && $response['status'] == 'COMPLETED') {



            // $user->update([
            //     'spotlight' => $user->spotlight + $plan->spotlight,
            // ]);

            // $subscriptions = Subscription::where('user_id',  $user->id)->first();

            // if ($subscriptions) {
            //     $subscriptions->update([
            //         'subscription_plan_id' => $plan->id,
            //         'end_date' => $duration === 'monthly'
            //             ? \Carbon\Carbon::parse($subscriptions->end_date)->addMonths($plan->duration)
            //             : \Carbon\Carbon::parse($subscriptions->end_date)->addYears($plan->duration),
            //         // 'end_date' => \Carbon\Carbon::parse($subscriptions->end_date)->addMonths($plan->duration),
            //     ]);
            // } else {
            //     Subscription::create([
            //         'user_id' => $user->id,
            //         'subscription_plan_id' => $plan->id,
            //         'start_date' => now(),
            //         'end_date' => $duration === 'monthly'
            //             ? now()->addDays($plan->duration)
            //             : now()->addMonths($plan->duration),
            //     ]);
            // }

            if($job==1)
            {
                 $currentSubscription = Subscription::where('user_id',  $user->id)->latest()->take(1)->first();
                   if(Carbon::parse($currentSubscription->end_date)->isPast())
                   {

                    $currentSubscription->update(['guaranteed_essentials'=> $planName === 'Guaranteed Essentials' ? 1:0, 'guaranteed_mobility'=> $planName === 'Guaranteed Mobility' ? 1:0,]);
                      $orderCreate = Payment::create([
                            'user_id' =>  $user->id,
                            'subscription_id' =>  $currentSubscription->id,
                            'transaction_id' => $response->id,
                            'amount' => $plan->price,
                            'currency' => $response->currency,
                            'subscription_plan_id' => session()->get('plan_id'),
                            'status' => $response->status,
                            'payment_gateway' => 'Paypal',

                        ]);
                   }else{
                        $subscription=  Subscription::create([
                                'user_id' => $user->id,
                                'subscription_plan_id' => $plan->id,
                                'subcription_type' => $duration === 'monthly'
                                    ? 'Monthly'
                                    : 'Yearly',
                                'start_date' => now(),
                                'end_date' => $duration === 'monthly'
                                    ? now()->addMonths(1)
                                    : now()->addYears(1),
                                'status' => 'Active',
                                'guaranteed_essentials'=> $planName === 'Guaranteed Essentials' ? 1:'',
                                'guaranteed_mobility'=> $planName === 'Guaranteed Mobility' ? 1:'',

                            ]);

                        $orderCreate = Payment::create([
                            'user_id' =>  $user->id,
                            'subscription_id' =>  $subscription->id,
                            'transaction_id' => $response->id,
                            'amount' => $plan->price,
                            'currency' => $response->currency,
                            'subscription_plan_id' => session()->get('plan_id'),
                            'status' => $response->status,
                            'payment_gateway' => 'Paypal',

                        ]);
                   }

            }else{
            $subscription=  Subscription::create([
                    'user_id' => $user->id,
                    'subscription_plan_id' => $plan->id,
                    'subcription_type' => $duration === 'monthly'
                        ? 'Monthly'
                        : 'Yearly',
                    'start_date' => now(),
                    'end_date' => $duration === 'monthly'
                        ? now()->addMonths(1)
                        : now()->addYears(1),
                    'status' => 'Active',
                ]);

            $orderCreate = Payment::create([
                'user_id' =>  $user->id,
                'subscription_id' =>  $subscription->id,
                'transaction_id' => $response->id,
                'amount' => $plan->price,
                'currency' => $response->currency,
                'subscription_plan_id' => session()->get('plan_id'),
                'status' => $response->status,
                'payment_gateway' => 'Paypal',

            ]);
            }




            // Mail::to($user->email)->send(new PaymentSuccessMail($plan));
             session()->forget('plan_id');
            session()->forget('duration');
            session()->forget('job_id');
            session()->forget('plan_name');
            return redirect()

                ->route('paypal')

                ->with('success', 'Transaction complete.');
        } else {
            Mail::to($user->email)->send(new FailedPaymentEmail($plan));
            return redirect()

                ->route('paypal')

                ->with('error', $response['message'] ?? 'Something went wrong.');
        }
    }

    public function successStripe(Request $request)
    {
        $user = Auth::user();
        $planId = session()->get('plan_id');
        $plan = SubscriptionPlan::findorfail($planId);
        $duration = session()->get('duration');
        $job = session()->get('job_id');
        $planName = session()->get('plan_name');

        if (isset($request->session_id)) {

            $stripe = new \Stripe\StripeClient(config('stripe.stripe_sk'));
            $response = $stripe->checkout->sessions->retrieve($request->session_id);
            //dd($response);

            // $orderCreate = Payment::create([
            //     'user_id' =>  $user->id,
            //     'transaction_id' => $response->id,
            //     'amount' => $plan->price,
            //     'currency' => $response->currency,
            //     'subscription_plan_id' => session()->get('plan_id'),
            //     'status' => $response->status,
            //     'payment_gateway' => 'Stripe',

            // ]);

            // $user->update([
            //     'spotlight' => $user->spotlight + $plan->spotlight,
            // ]);

            // $subscriptions = Subscription::where('user_id',  $user->id)->first();

            // if ($subscriptions) {
            //     $subscriptions->update([
            //         'subscription_plan_id' => $plan->id,
            //         'end_date' => \Carbon\Carbon::parse($subscriptions->end_date)->addMonths($plan->duration),
            //     ]);
            // } else {
            //     Subscription::create([
            //         'user_id' => $user->id,
            //         'subscription_plan_id' => $plan->id,
            //         'start_date' => now(),
            //         'end_date' => now()->addMonths($plan->duration),
            //     ]);
            // }

            // if ($subscriptions) {
            //     $subscriptions->update([
            //         'subscription_plan_id' => $plan->id,
            //         'end_date' => $plan->duration_type === 'day'
            //             ? \Carbon\Carbon::parse($subscriptions->end_date)->addDays($plan->duration)
            //             : \Carbon\Carbon::parse($subscriptions->end_date)->addMonths($plan->duration),
            //         // 'end_date' => \Carbon\Carbon::parse($subscriptions->end_date)->addMonths($plan->duration),
            //     ]);
            // } else {
            //     Subscription::create([
            //         'user_id' => $user->id,
            //         'subscription_plan_id' => $plan->id,
            //         'start_date' => now(),
            //         'end_date' => $plan->type === 'day'
            //             ? now()->addDays($plan->duration)
            //             : now()->addMonths($plan->duration),
            //     ]);
            // }

            // done code

            //    $subscription=  Subscription::create([
            //         'user_id' => $user->id,
            //         'subscription_plan_id' => $plan->id,
            //         'subcription_type' => $duration === 'monthly'
            //             ? 'Monthly'
            //             : 'Yearly',
            //         'start_date' => now(),
            //         'end_date' => $duration === 'monthly'
            //             ? now()->addMonths(1)
            //             : now()->addYears(1),
            //         'status' => 'Active',
            //     ]);

            // $orderCreate = Payment::create([
            //     'user_id' =>  $user->id,
            //     'subscription_id' =>  $subscription->id,
            //     'transaction_id' => $response->id,
            //     'amount' => $plan->price,
            //     'currency' => $response->currency,
            //     'subscription_plan_id' => session()->get('plan_id'),
            //     'status' => $response->status,
            //     'payment_gateway' => 'Stripe',

            // ]);

                if($job==1)
            {
                 $currentSubscription = Subscription::where('user_id',  $user->id)->latest()->take(1)->first();
                   if(Carbon::parse($currentSubscription->end_date)->isPast())
                   {

                       $subscription=  Subscription::create([
                                'user_id' => $user->id,
                                'subscription_plan_id' => $plan->id,
                                'subcription_type' => $duration === 'monthly'
                                    ? 'Monthly'
                                    : 'Yearly',
                                'start_date' => now(),
                                'end_date' => $duration === 'monthly'
                                    ? now()->addMonths(1)
                                    : now()->addYears(1),
                                'status' => 'Active',
                                'extra_plan' => $planName ? [$planName] : []

                            ]);

                        $orderCreate = Payment::create([
                            'user_id' =>  $user->id,
                            'subscription_id' =>  $subscription->id,
                            'transaction_id' => $response->id,
                            'amount' => $plan->price,
                            'currency' => $response->currency,
                            'subscription_plan_id' => session()->get('plan_id'),
                            'status' => $response->status,
                            'payment_gateway' => 'Stripe',

                        ]);

                   }else{
                    $features = $currentSubscription->extra_plan ?? [];
                    $features[] = $planName;
                    $currentSubscription->extra_plan = array_unique($features);
                    $currentSubscription->save();
                      $orderCreate = Payment::create([
                            'user_id' =>  $user->id,
                            'subscription_id' =>  $currentSubscription->id,
                            'transaction_id' => $response->id,
                            'amount' => $plan->price,
                            'currency' => $response->currency,
                            'subscription_plan_id' => session()->get('plan_id'),
                            'status' => $response->status,
                            'payment_gateway' => 'Stripe',

                        ]);
                   }

            }else{
            $subscription=  Subscription::create([
                    'user_id' => $user->id,
                    'subscription_plan_id' => $plan->id,
                    'subcription_type' => $duration === 'monthly'
                        ? 'Monthly'
                        : 'Yearly',
                    'start_date' => now(),
                    'end_date' => $duration === 'monthly'
                        ? now()->addMonths(1)
                        : now()->addYears(1),
                    'status' => 'Active',
                ]);

            $orderCreate = Payment::create([
                'user_id' =>  $user->id,
                'subscription_id' =>  $subscription->id,
                'transaction_id' => $response->id,
                'amount' => $plan->price,
                'currency' => $response->currency,
                'subscription_plan_id' => session()->get('plan_id'),
                'status' => $response->status,
                'payment_gateway' => 'Stripe',

            ]);
            }


            // Mail::to($user->email)->send(new PaymentSuccessMail($plan));
            // $recipients = [session()->get('customer_email'), 'ordertracking@sunharbor.co'];

            // Mail::to($recipients)->queue(new OrderConfirmMail($orders, $orderCreate));
          session()->forget('plan_id');
            session()->forget('duration');
            session()->forget('job_id');
            session()->forget('plan_name');


            // return to_route('f.dashboard');
            return to_route('subscription');
        } else {
            // Mail::to($user->email)->send(new FailedPaymentEmail($plan));
            return redirect()->route('stripe.cancel');
        }
    }


    public function checkoutPage()
    {
        $plans = SubscriptionPlan::where('status', 'active')->get();
        return view('customer.checkout', compact('plans'));
    }

    public function createPaymentIntent222(Request $request)
    {
        Stripe::setApiKey(config('stripe.stripe_sk'));

        $amount = $request->input('amount', 1000); // default $10 in cents

        $intent = PaymentIntent::create([
            'amount' => $amount,
            'currency' => 'usd',
            'automatic_payment_methods' => ['enabled' => true],
        ]);

        return response()->json([
            'clientSecret' => $intent->client_secret,
            'paymentIntentId' => $intent->id,
        ]);
    }


    public function confirmPayment(Request $request)
    {
        Payment::create([
            'payment_intent_id' => $request->input('intent_id'),
            'status' => $request->input('status'),
            'amount' => $request->input('amount'),
            'currency' => $request->input('currency'),
        ]);

        return redirect()->route('payment.success');
    }

    public function success()
    {
        return view('customer.success');
    }

    public function error()
    {
        return view('customer.error');
    }


    public function showPaymentForm()
    {
        return view('customer.payment.form', [
            'stripe_public_key' => config('stripe.stripe_pk')
        ]);
    }
    public function createPaymentIntent(Request $request)
    {
        try {
            // Ensure we're returning JSON response
            $request->headers->set('Accept', 'application/json');

            $validator = Validator::make($request->all(), [
                'amount' => 'required|numeric|min:1',
                'currency' => 'required|string|max:3',
                'customer_email' => 'required|email',
                'customer_name' => 'required|string|max:255',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'error' => 'Validation failed',
                    'details' => $validator->errors()
                ], 400);
            }

            $amount = $request->amount;
            $currency = strtolower($request->currency);
            $customerEmail = $request->customer_email;
            $customerName = $request->customer_name;

            // Create or retrieve Stripe customer
            $stripeCustomer = $this->createOrRetrieveCustomer($customerEmail, $customerName);

            // Create payment intent
            $paymentIntent = PaymentIntent::create([
                'amount' => $amount * 100, // Convert to cents
                'currency' => $currency,
                'customer' => $stripeCustomer->id,
                'automatic_payment_methods' => [
                    'enabled' => true,
                ],
                'metadata' => [
                    'customer_email' => $customerEmail,
                    'customer_name' => $customerName,
                    'product' => 'ADEX Unit Prep - Periodontal-scaling',
                    'order_date' => now()->toDateTimeString(),
                ],
                'description' => 'ADEX Unit Prep - Periodontal-scaling Course',
                'receipt_email' => $customerEmail,
            ]);

            // Store payment intent in session for later reference
            session(['payment_intent_id' => $paymentIntent->id]);

            return response()->json([
                'client_secret' => $paymentIntent->client_secret,
                'payment_intent_id' => $paymentIntent->id,
                'customer_id' => $stripeCustomer->id
            ]);

        } catch (ApiErrorException $e) {
            Log::error('Stripe API Error: ' . $e->getMessage(), [
                'request_data' => $request->all()
            ]);

            return response()->json([
                'error' => 'Payment processing error: ' . $e->getMessage()
            ], 400);

        } catch (\Exception $e) {
            Log::error('Payment Intent Creation Error: ' . $e->getMessage(), [
                'request_data' => $request->all()
            ]);

            return response()->json([
                'error' => 'An unexpected error occurred. Please try again.'
            ], 500);
        }
    }

    public function processPayment(Request $request)
    {
        try {
            $request->headers->set('Accept', 'application/json');

            $validator = Validator::make($request->all(), [
                'payment_intent_id' => 'required|string',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'error' => 'Invalid payment intent ID'
                ], 400);
            }

            // Retrieve payment intent from Stripe
            $paymentIntent = PaymentIntent::retrieve($request->payment_intent_id);

            if ($paymentIntent->status === 'succeeded') {
                // Handle successful payment
                $this->handleSuccessfulPayment($paymentIntent);

                return response()->json([
                    'success' => true,
                    'message' => 'Payment processed successfully!',
                    'payment_intent_id' => $paymentIntent->id
                ]);
            } else {
                return response()->json([
                    'success' => false,
                    'message' => 'Payment not completed. Status: ' . $paymentIntent->status
                ], 400);
            }

        } catch (CardException $e) {
            Log::error('Card Error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => $e->getError()->message
            ], 400);

        } catch (ApiErrorException $e) {
            Log::error('Stripe API Error in processing: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Payment processing error: ' . $e->getMessage()
            ], 400);

        } catch (\Exception $e) {
            Log::error('Payment Processing Error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while processing payment'
            ], 500);
        }
    }

    /**
     * Handle successful payment
     */
    private function handleSuccessfulPayment($paymentIntent)
    {
        try {
            $metadata = $paymentIntent->metadata;

            // Create or get user
            $user = User::firstOrCreate(
                ['email' => $metadata['customer_email']],
                [
                    'name' => $metadata['customer_name'],
                    'email' => $metadata['customer_email'],
                    'password' => Hash::make('temporary_password_' . uniqid()),
                    'email_verified_at' => now(),
                ]
            );

            // Create order record
            // $order = Order::create([
            //     'user_id' => $user->id,
            //     'product_name' => $metadata['product'],
            //     'amount' => $paymentIntent->amount / 100, // Convert back to dollars
            //     'currency' => $paymentIntent->currency,
            //     'status' => 'completed',
            //     'stripe_payment_intent_id' => $paymentIntent->id,
            //     'metadata' => json_encode($metadata->toArray()),
            // ]);

            // Create payment record
            Payment::create([
                'user_id' => $user->id,
                'order_id' => $order->id,
                'stripe_payment_intent_id' => $paymentIntent->id,
                'amount' => $paymentIntent->amount / 100,
                'currency' => $paymentIntent->currency,
                'status' => 'succeeded',
                'payment_method' => 'card',
                'metadata' => json_encode($paymentIntent->toArray()),
            ]);

            // Send confirmation email (implement as needed)
            // Mail::to($user->email)->send(new PaymentConfirmationMail($order));

            Log::info('Payment processed successfully', [
                'payment_intent_id' => $paymentIntent->id,
                'user_id' => $user->id,
                'order_id' => $order->id,
                'amount' => $paymentIntent->amount / 100,
            ]);

        } catch (\Exception $e) {
            Log::error('Error handling successful payment: ' . $e->getMessage(), [
                'payment_intent_id' => $paymentIntent->id,
                'error' => $e->getTraceAsString()
            ]);
            throw $e;
        }
    }

    /**
     * Apply coupon code
     */
    public function applyCoupon(Request $request)
    {
        try {
            $request->headers->set('Accept', 'application/json');

            $validator = Validator::make($request->all(), [
                'coupon_code' => 'required|string|max:50',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'error' => 'Invalid coupon code'
                ], 400);
            }

            $couponCode = strtoupper($request->coupon_code);

            // Define available coupons (you can move this to database)
            $coupons = [
                'SAVE20' => ['discount' => 20, 'type' => 'percentage'],
                'WELCOME50' => ['discount' => 50, 'type' => 'fixed'],
                'STUDENT15' => ['discount' => 15, 'type' => 'percentage'],
            ];

            if (!isset($coupons[$couponCode])) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid coupon code'
                ], 400);
            }

            $coupon = $coupons[$couponCode];
            $originalAmount = 647;

            if ($coupon['type'] === 'percentage') {
                $discountAmount = ($originalAmount * $coupon['discount']) / 100;
                $newAmount = $originalAmount - $discountAmount;
            } else {
                $discountAmount = $coupon['discount'];
                $newAmount = max($originalAmount - $discountAmount, 0);
            }

            return response()->json([
                'success' => true,
                'coupon_code' => $couponCode,
                'discount_amount' => $discountAmount,
                'new_amount' => $newAmount,
                'original_amount' => $originalAmount,
                'discount_type' => $coupon['type']
            ]);

        } catch (\Exception $e) {
            Log::error('Coupon application error: ' . $e->getMessage());
            return response()->json([
                'success' => false,
                'message' => 'Error applying coupon'
            ], 500);
        }
    }
}
