<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateUserNotificationRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
        'email_weekly_summary' => 'nullable',
        'email_account_changes' => 'nullable',
        'email_new_user' => 'nullable',
        'sms_login_alerts' => 'nullable',
        'sms_critical_alerts' => 'nullable',
        'email_frequency' => 'string',
        ];
    }
}
