<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateDocumentRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'user_id' => 'required|integer',
            'document_type' => 'required',
            'document_name' => 'required|string|max:255',
            'remarks' => 'sometimes',
            'file_names' => 'sometimes|array',
            'file_names.*' => 'file|mimes:png,jpg,webp,gif,pdf|max:10248',
            'approve_status' => 'nullable',
            'archive_status' => 'nullable',
        ];
    }
}
