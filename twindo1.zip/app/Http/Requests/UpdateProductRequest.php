<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class UpdateProductRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'image' => 'nullable|image|mimes:png,jpg,jpeg,gif,webp|max:2048',
            'title' => 'required|string|max:255|unique:products,title,' .$this->product->id,
            'price_per_month' => 'nullable|numeric',
            'price_annual' => 'nullable|numeric',
            'category_id' => 'required|integer|exists:categories,id',
            'product_status' => 'required|string|max:255',
            'tags' => 'nullable|string|max:255',
            'rating' => 'nullable|numeric|between:0,5',
            'rating_count' => 'nullable|integer|min:0',
            'website_link' => 'nullable|url',
            'phone' => 'nullable|string|max:20',
            'description' => 'required|string|max:300',
            'seo_notes' => 'nullable|string',
            'status' => 'nullable|string|max:50',
        ];

    }

    public function messages()
{
    return [
        'image.image' => 'The uploaded file must be an image.',
        'image.mimes' => 'The image must be a file of type: png, jpg, jpeg, gif, or webp.',
        'image.max' => 'The image must not be larger than 2MB.',

        'title.required' => 'The product title is required & Unique',
        'title.max' => 'The product title may not be greater than 255 characters.',

        'price_per_month.numeric' => 'The monthly price must be a valid number.',
        'price_annual.numeric' => 'The annual price must be a valid number.',

        'category_id.required' => 'Please select a category.',
        'category_id.exists' => 'The selected category does not exist.',

        'product_status.required' => 'Please choose a product status.',

        'tags.max' => 'Tags may not be longer than 255 characters.',

        'rating.numeric' => 'Rating must be a number.',
        'rating.between' => 'Rating must be between 0 and 5.',

        'rating_count.integer' => 'Rating count must be an integer.',
        'rating_count.min' => 'Rating count cannot be negative.',

        'website_link.url' => 'Please provide a valid URL.',

        'phone.max' => 'Phone number is too long.',

        'description.required' => 'Please enter a description.',
        'description.max' => 'Description must not exceed 300 characters.',

        'seo_notes.string' => 'SEO notes must be text.',

        'status.string' => 'Status must be text.',
    ];
}

}


