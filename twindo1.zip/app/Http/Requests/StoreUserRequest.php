<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreUserRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|min:6|confirmed',
            'role_id' => 'required',
        ];
    }
}


// $this->validate($request, [
//             'name' => 'required|string|max:255',
//             'email' => 'required|string|max:255|email|unique:users',
//             'role_id' => 'required',
//             'password' => 'required|confirmed|string|min:8',
//             'avatar' => 'image|mimes:jpeg,png,jpg,gif,webp|max:2048'
//         ]);