<?php

namespace App\Models;

use App\Models\CreditScoreComment;
use Illuminate\Database\Eloquent\Model;

class CreditScore extends Model
{
    protected $fillable = [
        'user_id',
        'credit_ref_agency',
        'score',
        'score_date',
        'score_description',
        'image',
        'tagable',
        'score_status',
        'approved_by',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
    public function approved()
    {
        return $this->belongsTo(User::class,'approved_by');
    }


    public function comments()
    {
        return $this->hasMany(CreditScoreComment::class)->whereNull('parent_id');
    }

    public function latestComment()
    {
        return $this->hasOne(CreditScoreComment::class)
            ->whereNull('parent_id')
            ->latest();
    }
}
