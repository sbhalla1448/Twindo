<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Mattiverse\Userstamps\Traits\Userstamps;

class Document extends Model
{
    use Userstamps;
    protected $fillable = [
        'user_id',
        'document_type',
        'document_name',
        'remarks',
        'file_type',
        'file_name',
        'approve_status',
        'archive_status',
        'created_by',
        'updated_by',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
    public function files()
    {
        return $this->hasMany(DocumentUpload::class, 'document_id', 'id');
    }
}
