<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RoleVisibilityRule extends Model
{
    protected $fillable = [
        'role_id',
        'visibility_rule_id',
        'can_view',
    ];
}
