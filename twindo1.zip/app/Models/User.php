<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use App\Observers\UserObserver;
use Illuminate\Database\Eloquent\Attributes\ObservedBy;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Action;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Crypt;
use Mattiverse\Userstamps\Traits\Userstamps;
use App\Notifications\CustomResetPassword;

#[ObservedBy([UserObserver::class])]
class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasFactory, Notifiable;
    use Userstamps;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'role_id',
        'image',
        'status',
        'google2fa_secret',
        'session_timeout',
        'suspicious_login_alert',
        'last_login_at',
        'last_logout_at',
        'provider',
        'provider_id',
        'phone',
        'created_by',
        'password_change_at',
        'assigned_user',
        'created_by',
        'updated_by',
        'stripe_customer_id',
        'flaged_account',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'password_chage_at' => 'datetime',
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'last_login_at'=> 'datetime'
        ];
    }

    public function role()
    {
        return $this->belongsTo(Role::class, 'role_id', 'id');
    }
    public function assigner()
    {
        return $this->belongsTo(User::class, 'assigned_user', 'id');
    }
    public function activityLogs()
    {
        return $this->hasMany(ActivityLog::class, 'user_id', 'id');
    }
    public function addresses()
    {
        return $this->hasMany(UserAddress::class, 'user_id', 'id');
    }

    public function hasPermission($permission): bool
    {
        return $this->role->permissions()->where('slug', $permission)->first() ? true : false;
    }

    public function loginHistories()
    {
        return $this->hasMany(LoginHistory::class);
    }

    public function notificationPreferences()
    {
        return $this->hasOne(UserNotification::class);
    }

    public function getStatusLabelAttribute()
    {
        return match ($this->status) {
            0 => 'Deactive',
            2 => 'Suspend',
            3 => 'Locked',
            4 => 'Force To Reset',
            default => 'Active',
        };
    }

//     public function sendPasswordResetNotification($token)
// {
//     $this->notify(new CustomResetPassword($token));
// }

public function sendPasswordResetNotification($token)
{
    $ip = request()->ip();
    $device = request()->header('User-Agent');
    $timestamp = now()->format('Y-m-d H:i:s');

    $this->notify(new CustomResetPassword($token, $ip, $device, $timestamp));
}

    public function subscription()
    {
        return $this->hasOne(Subscription::class);
    }
    public function score()
    {
        return $this->hasOne(CreditScore::class);
    }
    protected array $auditExclude = [
        'password',
        'remember_token',
        'email_verified_at',
    ];

}
