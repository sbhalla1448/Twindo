<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class MessageAction extends Model
{
    use SoftDeletes;
    protected $fillable = [
        'user_id',
        'recipient',
        'subject',
        'messages',
        'status',
        'done_status',
        'draft_status',
        'read_status_user',
        'read_status_admin',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function threads()
    {
        return $this->hasMany(MessageThread::class, 'message_id');
    }
    public function scopeUnseen($query, $userId)
    {
        return $query->whereHas('threads', function ($q) use ($userId) {
            $q->where('receiver_id', $userId)->where('is_seen_user', false);
        });
    }
    public function scopeUnseenadmin($query, $userId)
    {
        return $query->whereHas('threads', function ($q) use ($userId) {
            $q->where('is_seen_user', false);
        });
    }
    public function scopeSeen($query, $userId)
    {
        return $query->whereHas('threads', function ($q) use ($userId) {
            $q->where('receiver_id', $userId)->where('is_seen_user', true);
        });
    }

    public function latestMessage()
    {
        return $this->hasOne(MessageThread::class,'message_id')->latest();
    }
}
