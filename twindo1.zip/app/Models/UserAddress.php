<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserAddress extends Model
{
    protected $fillable = [
        'user_id',
        'street_address',
        'city',
        'post_code',
        'state',
        'country_code',
        'address_type',
        'verify_address',
        'default_address_status',
    ];

    public function country()
    {
        return $this->belongsTo(Country::class, 'country_code', 'id');
    }
}
