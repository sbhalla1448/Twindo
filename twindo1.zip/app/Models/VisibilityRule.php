<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class VisibilityRule extends Model
{
    protected $fillable = ['section'];

    public function roles()
    {
        return $this->belongsToMany(Role::class, 'role_visibility_rule')
            ->withPivot('can_view')
            ->withTimestamps();
    }
}
