<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DocumentUpload extends Model
{
    protected $fillable=[
        'document_id',
        'file_type',
        'file_name',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
