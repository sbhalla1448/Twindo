<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CreditScoreComment extends Model
{
    protected $fillable = [
        'user_id',
        'credit_score_id',
        'parent_id',
        'body',
    ];
    
    public function user()
    {
        return $this->belongsTo(User::class);
    }
    public function creditScore()
    {
        return $this->belongsTo(CreditScore::class);
    }
    public function replies()

    {

        return $this->hasMany(CreditScore::class, 'parent_id');
    }
}
