<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MessageThread extends Model
{
    protected $fillable = [
        'message_id',
        'message',
        'user_id',
        'receiver_id',
        'admin_id',
        'subject',
        'file',
        'is_seen_user',
        'is_seen_admin',
    ];


    public function message()
    {
        return $this->belongsTo(MessageAction::class,'id','message_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function receiver()
    {
        return $this->belongsTo(User::class, 'receiver_id');
    }

    public function admin()
    {
        return $this->belongsTo(User::class, 'admin_id');
    }
    public function scopeUnseen($query, $userId)
    {
        return $query->where('receiver_id', $userId)->where('is_seen', false);
    }

}
