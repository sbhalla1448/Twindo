<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TemplateReport extends Model
{
    protected $fillable = [
        'user_id',
        'title',
        'date',
        'description',
        'html_content',
        'status',
    ];

    protected function casts(): array
    {
        return [
            'date' => 'date',

        ];
    }
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
