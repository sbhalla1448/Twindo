<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Coupon extends Model
{
    protected $fillable = [
        'code', 'type', 'value', 'min_spend', 'valid_from', 'valid_to',
        'usage_limit', 'used_count', 'active'
    ];

    // public function isValid()
    // {
    //     if (!$this->active) return false;

    //     if ($this->valid_from && now()->lessThan($this->valid_from)) return false;

    //     if ($this->valid_to && now()->greaterThan($this->valid_to)) return false;

    //     if ($this->used_count >= $this->usage_limit) return false;

    //     return true;
    // }


    public function isValid($subtotal = null)
    {
        // Check if coupon is active
        if (!$this->active) {
            return ['valid' => false, 'message' => 'Coupon is not active'];
        }

        // Check date validity
        $now = now();
        if ($this->valid_from && $now->lessThan($this->valid_from)) {
            return ['valid' => false, 'message' => 'Coupon is not yet valid'];
        }

        if ($this->valid_to && $now->greaterThan($this->valid_to)) {
            return ['valid' => false, 'message' => 'Coupon has expired'];
        }

        // Check usage limit
        if ($this->used_count >= $this->usage_limit) {
            return ['valid' => false, 'message' => 'Coupon usage limit exceeded'];
        }

        // Check minimum spend if provided
        if ($subtotal !== null && $this->min_spend && $subtotal < $this->min_spend) {
            return ['valid' => false, 'message' => 'Minimum spend requirement not met'];
        }

        return ['valid' => true, 'message' => 'Coupon is valid'];
    }

    public function calculateDiscount($subtotal)
    {
        return $this->type === 'fixed'
            ? min($this->value, $subtotal) // Prevent negative totals
            : ($this->value / 100) * $subtotal;
    }

    // Safely increment usage count with database constraint
    public function incrementUsage()
    {
        return $this->where('id', $this->id)
                   ->where('used_count', '<', 'usage_limit')
                   ->increment('used_count');
    }

     /**
     * Boot the model and attach event listeners.
     */
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($coupon) {
            if (!$coupon->code) {
                $coupon->code = $coupon->generateUniqueCode();
            }
        });
    }

    /**
     * Generate a unique coupon code.
     *
     * @return string
     */
    private function generateUniqueCode()
    {
        do {
            // Customize the format as needed
            $code = strtoupper(uniqid() . rand(100, 999));
            // Example format: "COUPON-" . substr(md5(rand()), 0, 8);
        } while (self::where('code', $code)->exists());

        return $code;
    }

}
