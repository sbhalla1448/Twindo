<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Mattiverse\Userstamps\Traits\Userstamps;
use Illuminate\Support\Facades\Log;

class Product extends Model
{

    use Userstamps;

    protected $fillable = [
        'image',
        'title',
        'price_per_month',
        'price_annual',
        'category_id',
        'product_status',
        'tags',
        'rating',
        'rating_count',
        'website_link',
        'phone',
        'description',
        'seo_notes',
        'status',
        'created_by',
        'updated_by',
    ];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    protected static function boot()
    {
        parent::boot();

        static::deleting(function ($product) {
            \Log::info('Deleting product ID: ' . $product->id);

            $imagePath = public_path('images/' . $product->image);

            if (file_exists($imagePath)) {
                unlink($imagePath);
                \Log::info('Deleted image: ' . $imagePath);
            } else {
                \Log::warning('Image not found at: ' . $imagePath);
            }
        });
    }
}
