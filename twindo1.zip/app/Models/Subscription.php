<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use iamfarhad\LaravelAuditLog\Traits\Auditable;

class Subscription extends Model
{
    use Auditable;
    protected $fillable = [
        'user_id',
        'subscription_plan_id',
        'start_date',
        'end_date',
        'subcription_type',
        'status',
        'guaranteed_essentials',
        'guaranteed_mobility',
        'extra_plan',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
    public function plan()
    {
        return $this->belongsTo(SubscriptionPlan::class, 'subscription_plan_id', 'id');
    }

   public function payment()
    {
            return $this->hasOne(Payment::class,'subscription_id','id');
    }


    protected $casts = [
    'start_date' => 'date',
    'end_date' => 'date',
    'extra_plan' => 'array',
];
}
