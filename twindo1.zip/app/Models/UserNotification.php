<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class UserNotification extends Model
{
    protected $fillable = [
        'user_id',
        'email_weekly_summary',
        'email_account_changes',
        'email_new_user',
        'sms_login_alerts',
        'sms_critical_alerts',
        'email_frequency',
        'new_feature_offer',
        'sms_alert_account_activity',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
