<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ActivityLog extends Model
{
    protected $fillable = [
        'user_id',
        'ip_address',
        'user_agent',
        'action',
        'url',
        'method',
        'descriptions',
        'icon',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }
    // public function getUserAgentAttribute($value)
    // {
    //     return json_decode($value);
    // }

    // protected $casts = [
    //     'user_agent' => 'string', // ✅ ensure it's string
    // ];
}
