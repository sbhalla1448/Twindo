<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ToolResource extends Model
{
    protected $fillable =[
        'category_id',
        'title',
        'url',
        'status',
    ];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }
}
