<?php

namespace App\Livewire\Credit;

use App\Mail\SendAttachmentMail;
use App\Models\CreditScore;
use App\Models\CreditScoreComment;
use App\Models\EmailTemplate;
use App\Models\User;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Livewire\Component;
use Livewire\WithFileUploads;

class CreditSocreHistory extends Component
{
    use WithFileUploads;

    public $templateId;
    public $selectedTemplate;
    public $cc;
    public $bcc;
    public $attachment;
    public $user;
    public $emailTemplates = [];
    public $mailBody;
    public $showPreview = false;

    public $previewContent;
    public $subject = '';
    public $manageTemplatePreview = false;
    public $templateSubject = '';
    public $templateBody = '';
    public $editingTemplateId = null;
    public $search = '';
    public $status = '';
    public $date = '';
    public $selectedScore;
    public $comment;

      public $bulkSelect = [];
       public $bulkAction = '';


           public function applyBulkAction()
    {
        if (count($this->bulkSelect) === 0) {
                        return $this->addError('bulk', 'No Upload Document selected.');
        }

     
        session(['selected_credit_scores' => $this->bulkSelect]); // Pass to session

        return redirect()->route('admin.download.csv');
        // $this->mount();
        // $this->bulkSelect = [];
    }

    // Mount method accepts optional $id
    public function mount($id = null, $cid = null)
    {
        if ($id) {
            $this->loadUser($id);
            $this->loadCscore($cid);
        }



        $this->emailTemplates = EmailTemplate::all();
    }

    public function reseFilter()
    {
       
        $this->search = '';
        $this->status = '';
        $this->date = '';
        
    }

    protected function loadUser($id)
    {
        $this->user = User::findOrFail($id);
    }
    protected function loadCscore($cid)
    {
         $this->selectedScore = CreditScore::findOrFail($cid);
    }

    public function selectedUser($id, $cid)
    {
       if (is_null($id)) {
        return $this->redirectRoute('admin.credit.history');
       }    


        $this->loadUser($id);
        $this->loadCscore($cid);
 
       
    }
 
    

    public function updatedTemplateId($value)
    {
        $this->selectedTemplate = EmailTemplate::find($value);

        if ($this->user && $this->selectedTemplate) {
            $userName = $this->user->name;
            $templateBody = $this->selectedTemplate->email_body;
            $this->mailBody = "Hi {$userName},\n\n{$templateBody}\n\nRegards,\nThe Twindo Team";
            $this->subject = $this->selectedTemplate->email_subject;
        }
    }

    public function previewEmail()
    {
        $filePath = null;
        if ($this->attachment) {
            $filePath = $this->attachment->getClientOriginalName();
        }

        $mailData = [
            'subject' => $this->subject,
            'body' => $this->mailBody,
        ];

        $this->previewContent = Blade::render('emails.send_template_email', [
            'data' => $mailData,
            'filePath' => $filePath,
        ]);

        $this->showPreview = true;
    }

    public function closePreview()
    {
        $this->showPreview = false;
        $this->previewContent = null;
    }

    public function sendEmail()
    {
        $this->validate([
            'templateId' => 'required|exists:email_templates,id',
            'cc' => 'nullable|email',
            'bcc' => 'nullable|email',
            'mailBody' => 'nullable|string',
            'attachment' => 'nullable|file|max:2048',
        ]);

        $filePath = null;
        if ($this->attachment) {
            $stored = $this->attachment->store('temp', 'public');
            $filePath = storage_path('app/public/' . $stored);
        }

        $mailData = [
            'subject' => $this->subject,
            'user' => $this->user->name ?? 'User',
            'body' => $this->mailBody,
            'cc' => $this->cc,
            'bcc' => $this->bcc,
        ];

        try {
            Mail::to($this->user->email)->send(new SendAttachmentMail($mailData, $filePath));

            if ($filePath) {
                Storage::disk('public')->delete(str_replace(storage_path('app/public/'), '', $filePath));
            }

            $this->mailBody = "";
            session()->flash('message', 'Email sent successfully!');
        } catch (\Exception $e) {
            session()->flash('error', 'Failed to send email: ' . $e->getMessage());

            if ($filePath) {
                Storage::disk('public')->delete(str_replace(storage_path('app/public/'), '', $filePath));
            }
        }
    }

    public function manageTemplate()
    {
        $this->manageTemplatePreview = true;
        $this->templateSubject = '';
        $this->templateBody = '';
        $this->editingTemplateId = null;
    }

    public function closeManagePreview()
    {
        $this->manageTemplatePreview = false;
        $this->templateSubject = '';
        $this->templateBody = '';
        $this->editingTemplateId = null;
    }

    public function saveTemplate()
    {
        $this->validate([
            'templateSubject' => 'required|string|max:255',
            'templateBody' => 'required|string',
        ]);

        if ($this->editingTemplateId) {
            EmailTemplate::find($this->editingTemplateId)->update([
                'email_subject' => $this->templateSubject,
                'email_body' => $this->templateBody,
            ]);
            session()->flash('template_message', 'Template updated successfully!');
        } else {
            EmailTemplate::create([
                'email_subject' => $this->templateSubject,
                'email_body' => $this->templateBody,
            ]);
            session()->flash('template_message', 'Template created successfully!');
        }

        // Don't call mount(), just reload the templates
        $this->emailTemplates = EmailTemplate::all();
        $this->closeManagePreview();
    }

    public function editTemplate($id)
    {
        $template = EmailTemplate::findOrFail($id);
        $this->editingTemplateId = $id;
        $this->templateSubject = $template->email_subject;
        $this->templateBody = $template->email_body;
        $this->manageTemplatePreview = true;
    }

    public function deleteTemplate($id)
    {
        EmailTemplate::findOrFail($id)->delete();
        session()->flash('template_message', 'Template deleted successfully!');
        $this->emailTemplates = EmailTemplate::all();
        $this->closeManagePreview();
    }

    public function approve($id)
    {
        $creditScore = CreditScore::findOrFail($id);
        $creditScore->update(['score_status' => 'Approve','approved_by' => auth()->id()]);
        session()->flash('message', 'Credit score approved successfully!');

    }
    public function reject($id)
    {
        $creditScore = CreditScore::findOrFail($id);
        $creditScore->update(['score_status' => 'Reject','approved_by' => auth()->id()]);
        session()->flash('message', 'Credit score rejected successfully!');
    }
public function setComment($text)
{
    $this->comment = $text;
}
    public function saveComment()
    {
        
        $this->validate([            
            'comment' => 'required|string|max:500',
        ]);

        if (!$this->selectedScore) {
            session()->flash('error', 'No credit score selected.');
            return;
        }
        CreditScoreComment::create([
            'user_id' => auth()->id(),
            'credit_score_id' => $this->selectedScore->id,
            'body' => $this->comment,
        ]);

        $this->comment = '';
        session()->flash('message', 'Comment added successfully!');
    }
    public function render()
    {
        $creditScores = CreditScore::with('user')
            ->when($this->search, fn($query) =>
                $query->where(function ($q) {
                    $q->where('score', 'like', '%' . $this->search . '%')
                      ->orWhereHas('user', fn($q2) =>
                          $q2->where('name', 'like', "%{$this->search}%")
                             ->orWhere('email', 'like', "%{$this->search}%")
                      );
                })
            )
            ->when($this->date, fn($query) => $query->whereDate('score_date', $this->date))
            ->when($this->status, function ($query) {
                if (in_array($this->status, ['highToLow', 'lowToHigh'])) {
                    $direction = $this->status === 'highToLow' ? 'DESC' : 'ASC';
                    $query->orderBy('score', $direction);
                } else {
                    $query->where('score_status', $this->status);
                }
            })
            ->latest()->paginate(10);

        return view('livewire.credit.credit-socre-history', [
            'creditScores' => $creditScores,
        ]);
    }
}
