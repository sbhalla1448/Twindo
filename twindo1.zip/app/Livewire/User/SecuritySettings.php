<?php

namespace App\Livewire\User;

use Livewire\Component;
use Illuminate\Support\Facades\Hash;

class SecuritySettings extends Component
{
    public $user;
    public $passwordchange = false;


    public $password;
    public $password_confirmation;
    public $passwordStrength = 0;


    public function mount($user)
    {
        $this->user = $user;
    }

    public function passwordUp()
    {
        $this->passwordchange = true;
    }
    public function closePasswordModal()
    {
        $this->passwordchange = false;
    }



    // Real-time password strength calculation
    public function updatedPassword($value)
    {
        $this->passwordStrength = $this->calculatePasswordStrength($value);
    }

    // Calculate password strength based on criteria
    private function calculatePasswordStrength($password)
    {
        $strength = 0;

        // Length (at least 8 characters)
        if (strlen($password) >= 8) {
            $strength += 25;
        }

        // Uppercase letters
        if (preg_match('/[A-Z]/', $password)) {
            $strength += 25;
        }

        // Lowercase letters
        if (preg_match('/[a-z]/', $password)) {
            $strength += 25;
        }

        // Numbers or symbols
        if (preg_match('/[0-9\W]/', $password)) {
            $strength += 25;
        }

        return min($strength, 100); // Cap at 100%
    }

    public function updateUserPassword()
    {

        $this->validate([
            'password' => 'required|min:6|confirmed',
        ]);


        $this->user->update([
            'password' => Hash::make($this->password),
            'password_change_at' => now(),
        ]);
        $this->passwordchange = false;
        $this->reset('password', 'password_confirmation');
    }
    public function render()
    {
        return view('livewire.user.security-settings');
    }
}
