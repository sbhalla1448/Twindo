<?php

namespace App\Livewire\User;

use App\Models\EmailTemplate;
use Livewire\Component;
use Livewire\WithFileUploads;
use Illuminate\Support\Facades\Mail;
use App\Mail\SendAttachmentMail;
use Illuminate\Support\Facades\Blade;

class SendEmailToUser extends Component
{

    use WithFileUploads;

    public $templateId;
    public $selectedTemplate;
    public $cc;
    public $bcc;
    public $attachment;
    public $user;
    public $emailTemplates;
    public $mailBody;
    public $showPreview = false;

    public $previewContent;
    public $subject = '';
    public $manageTemplatePreview = false;
    public $templateSubject = '';
    public $templateBody = '';
    public $editingTemplateId = null;


    public function mount($user)
    {
        $this->user = $user;
        // $this->emailTemplates = EmailTemplate::pluck('email_subject', 'id');
        $this->emailTemplates = EmailTemplate::all();
    }

    public function updatedTemplateId($value)
    {

        $this->selectedTemplate = EmailTemplate::find($value);
        $userName = $this->user->name;
        $templateBody = $this->selectedTemplate->email_body ;
        $this->mailBody = "Hi {$userName},\n\n{$templateBody}\n\nRegards,\nThe Twindo Team";
        $this->subject = $this->selectedTemplate->email_subject;
    }

    public function previewEmail()
    {

        $mailData = [
            'subject' => $this->subject,
            'body' => $this->mailBody,
        ];

        $filePath = null;
        if ($this->attachment) {
            $filePath = $this->attachment->getClientOriginalName();
        }

        $this->previewContent = Blade::render('emails.send_template_email', [
            'data' => $mailData,
            'filePath' => $filePath,
        ]);

        $this->showPreview = true;
    }

    public function closePreview()
    {
        $this->showPreview = false;
        $this->previewContent = null;
    }

        public function sendEmail()
{
            $this->validate([
                'templateId' => 'required|exists:email_templates,id',
                'cc' => 'nullable|email',
                'bcc' => 'nullable|email',
                'mailBody' => 'nullable|string',
                'attachment' => 'nullable|file|max:2048',
            ]);
            $filePath = null;
            if ($this->attachment) {
                $filePath = $this->attachment->store('temp', 'public');
                $filePath = storage_path('app/public/' . $filePath);
            }


    $template = EmailTemplate::find($this->templateId);

    $mailData = [
        'subject' => $this->selectedTemplate->email_subject,
        'user' => $this->user->name,
        'body' => $this->mailBody,
        'cc' => $this->cc,
        'bcc' => $this->bcc,
    ];

    try {

        Mail::to($this->user->email)->send(new SendAttachmentMail($mailData, $filePath));

        if ($filePath) {
            \Storage::disk('public')->delete(str_replace(storage_path('app/public/'), '', $filePath));
        }


        $this->mailBody = "";

        session()->flash('message', 'Email sent successfully!');
    } catch (\Exception $e) {
        session()->flash('error', 'Failed to send email: ' . $e->getMessage());
        if ($filePath) {
            \Storage::disk('public')->delete(str_replace(storage_path('app/public/'), '', $filePath));
        }
    }
    session()->flash('message', 'Email sent successfully!');
    }


    public function manageTemplate()
    {
        $this->manageTemplatePreview = true;
        $this->templateSubject = '';
        $this->templateBody = '';
        $this->editingTemplateId = null;
    }
    public function closeManagePreview()
    {
        $this->manageTemplatePreview = false;
        $this->templateSubject = '';
        $this->templateBody = '';
        $this->editingTemplateId = null;
    }

    public function saveTemplate()
    {
        $this->validate([
            'templateSubject' => 'required|string|max:255',
            'templateBody' => 'required|string',
        ]);

        if ($this->editingTemplateId) {
            EmailTemplate::find($this->editingTemplateId)->update([
                'email_subject' => $this->templateSubject,
                'email_body' => $this->templateBody,
            ]);
            session()->flash('template_message', 'Template updated successfully!');
        } else {
            EmailTemplate::create([
                'email_subject' => $this->templateSubject,
                'email_body' => $this->templateBody,
            ]);
            session()->flash('template_message', 'Template created successfully!');
        }
        $this->mount($this->user, $this->emailTemplates);
        $this->closeManagePreview();
    }

    public function editTemplate($id)
    {
        $template = EmailTemplate::findOrFail($id);
        $this->editingTemplateId = $id;
        $this->templateSubject = $template->email_subject;
        $this->templateBody = $template->email_body;
        $this->manageTemplatePreview = true;
    }

    public function deleteTemplate($id)
    {
        EmailTemplate::findOrFail($id)->delete();
        $this->closeManagePreview();
        session()->flash('template_message', 'Template deleted successfully!');
        $this->mount($this->user, $this->emailTemplates);
    }

    public function render()
    {

        return view('livewire.user.send-email-to-user');
    }
}
