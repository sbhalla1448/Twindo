<?php

namespace App\Livewire\User;

use App\Models\User;
use Livewire\Component;

class AccountMangager extends Component
{
    public $users, $user, $userId;
    public $accountManager = false;

    public function mount($user)
    {
        $this->user = $user;
    }

    public function accountPreview()
    {
        $this->users = User::whereNot('role_id', 2)->get(['id', 'name']);
        $this->accountManager = true;
    }

    public function assignUserUpdate()
    {
        $this->validate([
            'userId' => 'required',
        ]);
        // dd($this->userId);
        $this->user->update([
            'assigned_user' => $this->userId,
        ]);

        $this->accountManager = false;
        $this->mount($this->user);
    }
    public function closeAccountPreview()
    {
        $this->accountManager = false;
    }
    public function render()
    {
        return view('livewire.user.account-mangager');
    }
}
