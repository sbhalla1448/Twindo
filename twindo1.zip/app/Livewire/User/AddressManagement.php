<?php

namespace App\Livewire\User;

use App\Models\Country;
use App\Models\UserAddress;
use Livewire\Component;

class AddressManagement extends Component
{
    public $addresses, $addressId, $user, $streetAddress, $countries, $postCode, $city, $countryId, $addressType, $defaultAddress, $default;
    public $editButton = false;

    public function mount($user)
    {
        $this->user = $user;
        $this->defaultAddress = 0;
    }

    public function editAddress($id)
    {
        $this->editButton = true;
        $address = UserAddress::findorfail($id);
        $this->streetAddress = $address->street_address;
        $this->city = $address->city;
        $this->postCode = $address->post_code;
        $this->countryId = $address->country_code;
        $this->addressType = $address->address_type;
        $this->defaultAddress = $address->default_address_status;
        $this->addressId = $id;
    }
    public function deleteAddress($id)
    {
        $address = UserAddress::findorfail($id);
        $address->delete();
    }

    public function addressSaveOrUpdate()
    {
        $this->validate([
            'streetAddress' => 'required',
            'postCode' => 'required',
            'countryId' => 'required',
            'city' => 'required',
            'addressType' => 'required',

        ]);

        $data = [
            'street_address' => $this->streetAddress,
            'city' => $this->city,
            'post_code' => $this->postCode,
            'country_code' => $this->countryId,
            'address_type' => $this->addressType,
            'default_address_status' => $this->defaultAddress,
        ];

        if ($this->addressId) {
            // Update existing address
            $address = UserAddress::find($this->addressId);
            $address->update($data);
            $this->reset(['streetAddress', 'city', 'postCode', 'countryId', 'addressType', 'defaultAddress']);
        } else {
            // Create new address
            $this->user->addresses()->create($data);
            $this->reset(['streetAddress', 'city', 'postCode', 'countryId', 'addressType', 'defaultAddress']);
        }

        // $this->user->addresses()->create([
        //     'street_address' => $this->streetAddress,
        //     'city' => $this->city,
        //     'post_code' => $this->postCode,
        //     'country_code' => $this->countryId,
        //     'address_type' => $this->addressType,
        //     'default_address_status' => $this->defaultAddress,
        // ]);

    }
    public function render()
    {
        $this->countries = Country::get(['id', 'name']);
        $this->addresses = UserAddress::where('user_id',$this->user->id)->latest()->get();
        return view('livewire.user.address-management');
    }
}
