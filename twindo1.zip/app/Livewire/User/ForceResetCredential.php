<?php

namespace App\Livewire\User;

use Livewire\Component;
use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Validate;
use Illuminate\Support\Facades\Hash;

class ForceResetCredential extends Component
{

    public $errorPass;
    public $currentPassword;
    public $newPassword;
    public $confirmPassword;
    public $passwordStrength = 0;

    protected $rules = [
        'currentPassword' => 'required',
        'newPassword' => 'required|min:6',
        'confirmPassword' => 'required|same:newPassword',
    ];

 // Real-time password strength calculation
 public function updatedNewPassword($value)
 {
     $this->passwordStrength = $this->calculatePasswordStrength($value);
 }

 // Calculate password strength based on criteria
 private function calculatePasswordStrength($password)
 {
     $strength = 0;

     // Length (at least 8 characters)
     if (strlen($password) >= 8) {
         $strength += 25;
     }

     // Uppercase letters
     if (preg_match('/[A-Z]/', $password)) {
         $strength += 25;
     }

     // Lowercase letters
     if (preg_match('/[a-z]/', $password)) {
         $strength += 25;
     }

     // Numbers or symbols
     if (preg_match('/[0-9\W]/', $password)) {
         $strength += 25;
     }

     return min($strength, 100); // Cap at 100%
 }

 public function updatePassword()
 {
     $this->validate();



     if (!Hash::check($this->currentPassword, Auth::user()->password)) {
         $this->addError('currentPassword', 'The current password is incorrect.');
         return;
     }
     Auth::user()->update([
         'password' => Hash::make($this->newPassword),
         'password_change_at' => now(),
         'status' => 1,
     ]);
     Auth::logout();
     return redirect()->route('login');
 }

    public function render()
    {
        return view('livewire.user.force-reset-credential');
    }
}
