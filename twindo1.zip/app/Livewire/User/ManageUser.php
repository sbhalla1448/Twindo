<?php

namespace App\Livewire\User;

use Livewire\Component;
use Livewire\WithFileUploads;
use Intervention\Image\Drivers\Gd\Driver;
use Intervention\Image\ImageManager;
use Illuminate\Support\Facades\File;
use App\Services\ImageService;

class ManageUser extends Component
{
    use WithFileUploads;
    public $user, $name, $email, $phone, $image;

    public function mount($user)
    {
        $this->user = $user;
        $this->name = $user->name;
        $this->email = $user->email;
        $this->phone = $user->phone;
    }

    public function updateUser()
    {


        $this->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|max:255|email|unique:users,email,' . $this->user->id,
            'phone' => 'required|unique:users,phone,' . $this->user->id,
            'image' => 'nullable|image|mimes:jpeg,png,jpg,gif|max:2048', // 2MB max
        ]);

        $updateData = [
            'name' => $this->name,
            'email' => $this->email,
            'phone' => $this->phone,
        ];


        if ($this->image) {
            $updateData['image'] = $this->processImage($this->image);
        }
        // $updateData['image'] = app(ImageService::class)->processUserImage($this->image, 'image');
        // if ($this->image) {
        //     $updateData['image'] = $this->processImage($this->image);
        // }

        $this->user->update($updateData);
        $this->image = null;
    }

    public function render()
    {
        return view('livewire.user.manage-user');
    }





    protected function processImage($image): string
    {
        try {
            $manager = new ImageManager(new Driver());
            $filename = uniqid('avatar_', true) . '.webp';

            $image = $manager->read($image->getRealPath())
                // ->cover(870, 493)
                ->toWebp(100);

            $imagePath = public_path('images/' . $filename);
            file_put_contents($imagePath, (string) $image);

            if ($this->user->image) {
                File::delete(public_path('images/' . $this->user->image));
            }
            return $filename;
        } catch (\Exception $e) {
            $this->addError('image', 'Failed to process the image.');
            return $this->user->image ?? '';
        }
    }
}
