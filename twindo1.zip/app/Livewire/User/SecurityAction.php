<?php

namespace App\Livewire\User;

use Livewire\Component;

class SecurityAction extends Component
{
    public function render()
    {
        return view('livewire.user.security-action');
    }
}
