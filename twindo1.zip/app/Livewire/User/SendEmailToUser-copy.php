<?php

namespace App\Livewire\User;

use App\Models\EmailTemplate;
use Livewire\Component;
use Livewire\WithFileUploads;
use Illuminate\Support\Facades\Mail;

class SendEmailToUser extends Component
{

    use WithFileUploads;

    public $templateId;
    public $selectedTemplate;
    public $cc;
    public $bcc;
    public $attachment;
    public $user;
    public $emailTemplates;

    public function mount($user)
    {
        $this->user = $user;
        // $this->emailTemplates = EmailTemplate::pluck('email_subject', 'id');
        $this->emailTemplates = EmailTemplate::all();
    }

    public function updatedTemplateId($value)
    {

        $this->selectedTemplate = EmailTemplate::find($value);
    }


        public function sendEmail()
{
    $this->validate([
        'templateId' => 'required|exists:email_templates,id',
        'cc' => 'nullable|email',
        'bcc' => 'nullable|email',
        'attachment' => 'nullable|file|max:2048',
    ]);

    $template = EmailTemplate::find($this->templateId);

    Mail::send([], [], function ($message) use ($template) {
        $message->to('recipient@example.com') // Replace with real user
                ->subject($template->email_subject)
                ->html($template->email_body);

        if ($this->cc) {
            $message->cc($this->cc);
        }

        if ($this->bcc) {
            $message->bcc($this->bcc);
        }

        if ($this->attachment) {
            $message->attach($this->attachment->getRealPath(), [
                'as' => $this->attachment->getClientOriginalName(),
                'mime' => $this->attachment->getMimeType(),
            ]);
        }
    });


        session()->flash('message', 'Email sent successfully!');
    }

    public function render()
    {

        return view('livewire.user.send-email-to-user');
    }
}
