<?php

namespace App\Livewire\ReportAnalysis;

use App\Models\User;
use Livewire\Component;
use App\Models\TemplateReport;

class ReportAnalysis extends Component
{
public $userId = '';

public $search = '';
public $report;
    public $viewTools = false;
public function showModel($id)
{

    $this->viewTools = true;
    $this->report = TemplateReport::find($id);

}
public function closeDialog()
{
    $this->viewTools = false;
}
public function makeYes()
{
    $this->report->delete();
    $this->viewTools = false;
}
    public function render()
    {
        $reports =TemplateReport::with('user')

        ->when($this->userId !== '', function ($query) {
              $query->where('user_id', $this->userId);
          })

->when($this->search, function ($query) {
              $query->where(function ($q) {
                  $q->where('title', 'like', '%' . $this->search . '%')
                      ->orWhere('description', 'like', '%' . $this->search . '%')
                      ->orWhere('date', 'like', '%' . $this->search . '%')

                      ->orWhereHas('user', fn($userQ) => $userQ->where('name', 'like', "%{$this->search}%"));
              });
          })
          ->get();
        return view('livewire.report-analysis.report-analysis',[
            'reports' => $reports,
            'customers' => User::where('role_id',2)->get(['id','name']),
        ]);
    }
}
