<?php

namespace App\Livewire\Message;

use Livewire\Component;
use App\Models\MessageAction;
use App\Models\MessageThread;
use Illuminate\Support\Facades\Auth;
use Livewire\WithFileUploads;
use Livewire\Attributes\Validate;
use Livewire\WithPagination;


class MessageIndex extends Component
{
    use WithFileUploads;
    use WithPagination;
    public $search = '';
    public $filter = '';
    public $bulkSelect = [];
    public $bulkAction = '';
    public $modalView = false;
    public $user,$subject,$body;


    public $viewmsg = false;
    public $messageId,$replyMessage,$uploadFile,$userId;

    public function mount() {}
    public function applyBulkAction($data)
    {
        // dd($this->bulkSelect);

        if (count($this->bulkSelect) === 0) {

            // dd('sdfasdf');
            return $this->addError('bulk', 'No messages selected.');
        }
        // dd($this->bulkSelect);
        switch ($data) {
            case 'markAsDone':
                MessageAction::whereIn('id', $this->bulkSelect)->update(['done_status' => 1]);
                session()->flash('message', 'Selected messages mark as done.');
                break;

            case 'delete':
                MessageAction::whereIn('id', $this->bulkSelect)->delete();
                session()->flash('message', 'Selected messages deleted.');
                break;

            default:
                $this->addError('bulk', 'Invalid action selected.');
                break;
        }

        // Refresh data
        $this->mount();
        $this->bulkSelect = [];
    }

    public function deleteMessage($id)
    {
        MessageAction::findorfail($id)->delete();
        session()->flash('message', 'Messages deleted.');
    }
    public function restoreMessage($id)
    {
        // dd($id);
        MessageAction::withTrashed()->where('id', $id)->restore();
        session()->flash('message', 'Messages Restore Successfully.');
    }

    public function viewMessage($id)
    {
        $message = MessageAction::findOrFail($id);

        $this->userId = $message->user_id;
        $this->messageId = $id;
        $this->viewmsg = true;
        $threds = MessageThread::where('message_id', $id)->update(['is_seen_admin'=> 1]);


    }

    public function replyMessageSubmit()
    {

        $this->validate([
            'replyMessage' => 'required|string',
            'uploadFile' => 'nullable|file|mimes:png,jpg,webp,gif,jpeg,pdf,doc,docx|max:5048'
        ]);

        $name = null;

        if ($this->uploadFile) {
            $name = uniqid() . '.' . $this->uploadFile->getClientOriginalExtension();
            $this->uploadFile->storeAs('uploads', $name);
        }

        MessageThread::create([
            'message_id' => $this->messageId,
            'message' => $this->replyMessage,
            'user_id' => $this->userId,
            'admin_id' => Auth::user()->id,
            'file' => $name,
        ]);

        $this->replyMessage = '';
        $this->uploadFile = null;

    }

    public function render()
    {

        $messages = MessageAction::with(['user','latestMessage'])

                ->when($this->filter !== '', function ($query) {

                    if($this->filter == 'deleted')
                    {
                        $query->onlyTrashed();
                    }else{
                        $query->where('status', $this->filter);
                    }
                })
                ->when($this->search, function ($query) {
                    $query->where(function ($q) {
                        $q->where('subject', 'like', '%' . $this->search . '%')
                            ->orWhere('messages', 'like', '%' . $this->search . '%')
                            ->orWhereHas('user', fn($qr) => $qr->where('name', 'like', '%' . $this->search . '%'));
                    });
                })
                ->paginate(5);

                $usermessages = $this->messageId
                ? MessageThread::where('message_id', $this->messageId)

                    ->latest()
                    ->paginate(2)
                : [];
        return view('livewire.message.message-index', [
            'messages' => $messages,
            'usermessages' => $usermessages,
        ]);
    }
}
