<?php

namespace App\Livewire\Message;

use App\Models\User;
use App\Mail\SendMail;
use Livewire\Component;
use App\Models\MessageAction;
use Livewire\Attributes\Validate;
use Illuminate\Support\Facades\Mail;

class MessageCompose extends Component
{
    #[Validate('required')]
    public $userId;

    #[Validate('required')]
    public $subject;

    #[Validate('required')]
    public $messageBody;





    public function draftMessage()
    {


        $this->validate();

        MessageAction::create([
            'user_id' => $this->userId,
            'subject' => $this->subject,
            'messages' => $this->messageBody,
            'draft_status' => 1,
        ]);

        $this->reset();
        session()->flash('status', 'Message save in draft.');
    }
    public function sendMessage()
    {
        $this->validate();

        MessageAction::create([
            'user_id' => $this->userId,
            'subject' => $this->subject,
            'messages' => $this->messageBody,
        ]);

        // $data = [
        //     'email' => $this->email,
        //     'subject' => $this->subject,
        //     'body' => $this->messageBody,
        // ];

        // Mail::to($this->email)->send(new SendMail($data));

        $this->reset();
        session()->flash('status', 'Message send successfully.');
    }

    public function tempateData($data)
    {
        $this->messageBody = $data;
    }

    public function render()
    {
        $users = User::all();
        return view('livewire.message.message-compose',[
            'users' => $users,
        ]);
    }
}
