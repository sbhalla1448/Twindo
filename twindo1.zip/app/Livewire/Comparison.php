<?php

namespace App\Livewire;

use App\Models\Category;
use App\Models\Product;
use Livewire\Component;

class Comparison extends Component
{
    
    public $categoryId = '';
    public $productId = '';
    public $search = '';
    public $sortBy  = '';
    public $perPage = 2;


    public function reseetFilters()
    {
        $this->categoryId = '';
        $this->productId = '';
        $this->search = '';
        $this->sortBy = '';
        $this->perPage=2;
    }


public function loadMore()
{
    $this->perPage += 2;
}

    public function render()
    {
        $products = Product::with('category')
              ->when($this->categoryId !== '', function ($query) {
            $query->where('category_id', $this->categoryId);
        })
              ->when($this->productId !== '', function ($query) {
            $query->where('id', $this->productId);
        })

        ->when($this->search, function ($query) {
            $query->where(function ($q) {
                $q->where('title', 'like', '%' . $this->search . '%')
                   
                    ->orWhereHas('category', fn($userQ) => $userQ->where('name', 'like', "%{$this->search}%"));
            });
        })

           ->when($this->sortBy === 'newest', function ($query) {
        $query->orderBy('created_at', 'desc');
    })
    ->when($this->sortBy === 'top_rate', function ($query) {
        $query->orderBy('price_per_month', 'desc'); 
    })
    ->when($this->sortBy === 'low_rate', function ($query) {
        $query->orderBy('price_per_month', 'asc');
    })

          ->paginate($this->perPage);
          $productsFilter = Product::get(['id','title']);
          $categories = Category::get(['id', 'name']);
        return view('livewire.comparison',[
            'products'=> $products,
            'categories'=> $categories,
            'productsFilter'=> $productsFilter,
        ]);
    }
}
