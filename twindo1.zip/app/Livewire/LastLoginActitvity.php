<?php

namespace App\Livewire;

use App\Models\ActivityLog;
use App\Models\MessageAction;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;
use Livewire\WithPagination;
use Livewire\Attributes\Validate;

class LastLoginActitvity extends Component
{

     use WithPagination;
     public $modalShow = false;
      public $viewTools = false;
      public $viewToolmsg = false;

     public $activitylog,$selectUser;

     #[Validate('required')]
     public $subject = '';

    #[Validate('required')]
    public $message = '';



     public function modalview($id)
     {
       $this->modalShow = true;
        $this->activitylog = ActivityLog::where('user_id',Auth::user()->id)->latest()->take(1)->first();

     }

     public function viewMessage($id)
     {
        $this->viewToolmsg = true;
        $this->selectUser = User::findorfail($id);
     }

     public function messageSave()
     {
        $this->validate();

        MessageAction::create([
            'user_id' => $this->selectUser->id,
            'subject' => $this->subject,
            'messages' => $this->message,
        ]);
        $this->subject ='';
        $this->message ='';
        $this->viewToolmsg = false;
     }

     public function closeLogModal()
     {
        $this->modalShow = false;
        $this->viewTools = false;
        $this->viewToolmsg = false;
     }
 public function viewActive($id)
    {

        $this->viewTools = true;
      $this->selectUser = User::findorfail($id);

    }


       public function makeYes()
    {
        $this->selectUser->update(['status'=>0]);
        $this->viewTools = false;
    }
    public function render()
    {
         $userLastActivities= User::orderBy('last_login_at','DESC')->paginate(3);
        return view('livewire.last-login-actitvity',[
            'userLastActivities' => $userLastActivities,
        ]);
    }
}
