<?php

namespace App\Livewire;

use App\Models\User;
use Livewire\Component;
use Livewire\WithPagination;
use App\Models\EmailTemplate;
use Livewire\WithFileUploads;
use Illuminate\Support\Facades\Mail;
use App\Mail\SendAttachmentMailBlast;
use Illuminate\Support\Facades\Blade;

class QuickAction extends Component
{
    use WithPagination;
    use WithFileUploads;
    public $modalShow = false;
    public $modalBlashShow = false;



    public $templateId;
    public $selectedTemplate;
    public $cc;
    public $bcc;
    public $attachment;
    public $user;
    public $emailTemplates;
    public $mailBody;
    public $showPreview = false;

    public $previewContent;
    public $subject = '';
    public $userID = '';



    public function viewModal()
    {
        $this->resetPage();
        $this->modalShow = true;
    }
    public function toggleFlag($userId)
    {
        $user = User::findOrFail($userId);
        $user->flaged_account = !$user->flaged_account;
        $user->save();

        // $this->users = User::select('id', 'name', 'email', 'last_login_at', 'flaged_account')->get();
    }
    public function render()
    {
        $users = User::where('role_id', 2)
            ->select('id', 'role_id', 'name', 'email', 'last_login_at', 'flaged_account')
            ->orderByDesc('id')
            ->paginate(3);

        $useremails = User::where('role_id', 2)
            ->select('id', 'name')
            ->orderBy('name') // Optional: better UX if selecting by name
            ->get();

        return view('livewire.quick-action', compact('users', 'useremails'));
    }

    public function viewEmailBlast()
    {

        $this->modalBlashShow = true;
    }
    public function viewEmailBlastClose()
    {

        $this->modalBlashShow = false;
    }


    public function previewEmail()
    {

        $mailData = [
            'subject' => $this->subject,
            'body' => $this->mailBody,
        ];

        $filePath = null;
        if ($this->attachment) {
            $filePath = $this->attachment->getClientOriginalName();
        }

        $this->previewContent = Blade::render('emails.send_template_email', [
            'data' => $mailData,
            'filePath' => $filePath,
        ]);

        $this->showPreview = true;
    }

    public function closePreview()
    {
        $this->showPreview = false;
        $this->previewContent = null;
    }

//         public function sendEmail()
// {
//             $this->validate([
//                 'subject' => 'required',
//                 'cc' => 'nullable|email',
//                 'bcc' => 'nullable|email',
//                 'mailBody' => 'required|string',
//                 'attachment' => 'nullable|file|max:2048',
//             ]);


//             $filePath = null;
//             if ($this->attachment) {
//                 $filePath = $this->attachment->store('temp', 'public');
//                 $filePath = storage_path('app/public/' . $filePath);
//             }


//     $mailData = [
//         'subject' => $this->subject,
//         'user' => $this->user->name,
//         'body' => $this->mailBody,
//         'cc' => $this->cc,
//         'bcc' => $this->bcc,
//     ];

//     try {
//         if($this->userID == null || $this->userID== 'all')
//         {
//             $users = User::where('role_id',2)->get(['id','email']);

//             forach($users as $user)
//             {
//                 Mail::to($user->email)->send(new SendAttachmentMail($mailData, $filePath));

//                 if ($filePath) {
//                     \Storage::disk('public')->delete(str_replace(storage_path('app/public/'), '', $filePath));
//                 }
//             }

//             $this->mailBody = "";

//             session()->flash('message', 'Email sent successfully!');
//         }else{
//             $user = User::findorfail($this->userID);
//             Mail::to($user->email)->send(new SendAttachmentMail($mailData, $filePath));

//             if ($filePath) {
//                 \Storage::disk('public')->delete(str_replace(storage_path('app/public/'), '', $filePath));
//             }


//             $this->mailBody = "";

//             session()->flash('message', 'Email sent successfully!');
//         }



//     } catch (\Exception $e) {
//         session()->flash('error', 'Failed to send email: ' . $e->getMessage());
//         if ($filePath) {
//             \Storage::disk('public')->delete(str_replace(storage_path('app/public/'), '', $filePath));
//         }
//     }
//     session()->flash('message', 'Email sent successfully!');
//     }



public function sendEmail()
{
    $this->validate([
        'subject' => 'required',
        'cc' => 'nullable|email',
        'bcc' => 'nullable|email',
        'mailBody' => 'required|string',
        'attachment' => 'nullable|file|max:2048',
    ]);

    $filePath = null;

    if ($this->attachment) {
        $filePath = $this->attachment->store('temp', 'public');
        $filePath = storage_path('app/public/' . $filePath);
    }

    $mailData = [
        'subject' => $this->subject,
        'user' => $this->user->name ?? 'Admin',
        'body' => $this->mailBody,
        'cc' => $this->cc,
        'bcc' => $this->bcc,
    ];

    try {
        if ($this->userID === null || $this->userID === 'all') {
            $users = User::where('role_id', 2)->get(['id', 'email']);

            foreach ($users as $user) {
                Mail::to($user->email)->queue(new SendAttachmentMailBlast($mailData, $filePath));
            }
        } else {
            $user = User::findOrFail($this->userID);
            Mail::to($user->email)->queue(new SendAttachmentMailBlast($mailData, $filePath));
        }

        // Cleanup the uploaded file once all queued
        if ($filePath) {
            \Storage::disk('public')->delete(str_replace(storage_path('app/public/'), '', $filePath));
        }

        $this->subject = "";
        $this->mailBody = "";
        session()->flash('message', 'Email queued successfully!');
        $this->modalBlashShow = false;
    } catch (\Exception $e) {
        if ($filePath) {
            \Storage::disk('public')->delete(str_replace(storage_path('app/public/'), '', $filePath));
        }
        session()->flash('error', 'Failed to queue email: ' . $e->getMessage());
    }
}

}
