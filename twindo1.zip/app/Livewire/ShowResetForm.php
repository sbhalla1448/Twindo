<?php

namespace App\Livewire;

use App\Models\User;
use Livewire\Component;
use Jenssegers\Agent\Agent;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Password;
use App\Notifications\PasswordResetSuccess;
use Illuminate\Support\Facades\Http;


class ShowResetForm extends Component
{
 public $token, $email;
 public $newPassword;
 public $confirmPassword;
 public $passwordStrength = 0;

 protected $rules = [
    'newPassword' => 'required|min:6',
    'confirmPassword' => 'required|same:newPassword',
];
    public function mount($token, $email)
    {
        $this->token = $token;
        $this->email = $email;
    }

  public function updatedNewPassword($value)
    {
        $this->passwordStrength = $this->calculatePasswordStrength($value);
    }

 private function calculatePasswordStrength($password)
 {
     $strength = 0;


     if (strlen($password) >= 8) {
         $strength += 25;
     }


     if (preg_match('/[A-Z]/', $password)) {
         $strength += 25;
     }


     if (preg_match('/[a-z]/', $password)) {
         $strength += 25;
     }


     if (preg_match('/[0-9\W]/', $password)) {
         $strength += 25;
     }

     return min($strength, 100);
 }

 public function updatePassword()
 {

     $this->validate();
     $password = $this->newPassword;

    //  $agent = new Agent();
    //  $browser = $agent->browser();
    //  $platform = $agent->platform();
    //  $deviceInfo = "{$browser} on {$platform}";

    //  $ip = request()->ip();

    //  $locationData = Http::get("https://ipapi.co/{$ip}/json/")->json();
    //  $location = $locationData['city'] ?? 'Unknown City';
    //  $region = $locationData['region'] ?? 'Unknown Region';
    //  $country = $locationData['country_name'] ?? 'Unknown Country';
    //  $fullLocation = "{$location}, {$region}, {$country}";
    //  $timestamp = now()->format('Y-m-d H:i:s');

    //  $status = Password::reset(
    //      [
    //          'email' => $this->email,
    //          'password' => $this->newPassword,
    //          'password_confirmation' => $this->confirmPassword,
    //          'token' => $this->token,
    //      ],
    //      function (User $user, string $password) {
    //          $user->forceFill([
    //              'password' => Hash::make($password),
    //              'password_change_at' => now(),
    //          ])->save();
    //          $user->notify(new PasswordResetSuccess($deviceInfo, $ip, $fullLocation, $timestamp));
    //      }
    //  );

    $agent = new Agent();
    $browser = $agent->browser();
    $platform = $agent->platform();
    $deviceInfo = "{$browser} on {$platform}";

    $ip = request()->ip();

    $locationData = Http::get("https://ipapi.co/{$ip}/json/")->json();
    $location = $locationData['city'] ?? 'Unknown City';
    $region = $locationData['region'] ?? 'Unknown Region';
    $country = $locationData['country_name'] ?? 'Unknown Country';
    $fullLocation = "{$location}, {$region}, {$country}";
    $timestamp = now()->format('Y-m-d H:i:s');

    $status = Password::reset(
        [
            'email' => $this->email,
            'password' => $this->newPassword,
            'password_confirmation' => $this->confirmPassword,
            'token' => $this->token,
        ],
        function (User $user, string $password) use ($deviceInfo, $ip, $fullLocation, $timestamp) {
            $user->forceFill([
                'password' => Hash::make($password),
                'password_change_at' => now(),
            ])->save();

            $user->notify(new PasswordResetSuccess($deviceInfo, $ip, $fullLocation, $timestamp));
        }
    );



     if ($status === Password::PASSWORD_RESET) {

         session()->flash('message', 'Password reset successfully.');


         return redirect()->route('login');
     } else {
         $this->addError('email', __($status));
     }
 }


    public function render()
    {
        return view('livewire.show-reset-form');
    }
}
