<?php

namespace App\Livewire;

use App\Models\ActivityLog;
use Livewire\Component;
use Livewire\WithPagination;

class RecentActivitiy extends Component
{

    use WithPagination;
    public function render()
    {
        $recentActivtities = ActivityLog::latest()->paginate(8);
        return view('livewire.recent-activitiy',[
            'recentActivtities' =>$recentActivtities,
        ]);
    }
}
