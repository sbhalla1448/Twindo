<?php

namespace App\Livewire;

use Livewire\Component;
use Illuminate\Support\Facades\Auth;

class VerifyOTP extends Component
{
    public $otp;
    public function verifyOTP()
    {
        $this->validate([
            'otp' => 'required',
        ]);

        $google2fa = app('pragmarx.google2fa');


        $isValid = $google2fa->verifyKey(Auth::user()->google2fa_secret, $this->otp);
        if($isValid)
        {
            session(['google2fa_verified'=>true]);
            if(Auth::user()->role_id == 2 )
            {
                return redirect()->route('dashboard');
            }else{
                return redirect()->route('admin.dashboard');
            }
            
        }else{
            session()->flash('error','Invalid OTP');
        }

    }

    public function render()
    {
        return view('livewire.verify-o-t-p');
    }
}
