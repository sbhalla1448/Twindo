<?php

namespace App\Livewire\Subscription;

use App\Models\Subscription;
use App\Models\SubscriptionPlan;
use Livewire\Component;

class Index extends Component
{

    public $search = '';
    public $status = '';
    public $plan = '';

    public $bulkSelect = [];
    public $bulkAction = '';
    public $selectSubscription = '';
    public $viewTools = false;


    public function closeModal()
    {

       $this->viewTools = false;
    }
    public function viewModal($id)
    {

       $this->viewTools = true;
       $this->selectSubscription = Subscription::findOrFail($id);
    }
public function changeSubscriptionActitvity($id, $data)
   {


        $subscription = Subscription::findOrFail($id);
        $subscription->update(['status' => $data]);
        $this->viewTools = false;
   }

    public function render()
    {

        $subscriptions = Subscription::with(['user','plan'])

          ->when($this->status !== '', function ($query) {
                $query->where('status', $this->status);
            })
          ->when($this->plan !== '', function ($query) {
                $query->where('subscription_plan_id', $this->plan);
            })
  ->when($this->search, function ($query) {
                $query->where(function ($q) {
                    $q->where('subcription_type', 'like', '%' . $this->search . '%')
                        ->orWhere('status', 'like', '%' . $this->search . '%')
                        ->orWhereHas('plan', fn($userQ) => $userQ->where('name', 'like', "%{$this->search}%"))
                        ->orWhereHas('user', fn($userQ) => $userQ->where('name', 'like', "%{$this->search}%"));
                });
            })
            ->get();
        return view('livewire.subscription.index',[
            'subscriptions' => $subscriptions,
            'subplans' => SubscriptionPlan::where('status', 1)->get(['id', 'name']),

        ]);
    }

}