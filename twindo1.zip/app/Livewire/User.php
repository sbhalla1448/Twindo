<?php

namespace App\Livewire;

use App\Models\User as ModelUser;
use Livewire\Component;

class User extends Component
{

    public $search = '';
    public $status = '';

    public $bulkSelect = [];
    public $bulkAction = '';

    public function mount() {}
    public function applyBulkAction()
    {
        if (count($this->bulkSelect) === 0) {
            return $this->addError('bulk', 'No users selected.');
        }

        switch ($this->bulkAction) {
            case 'suspend':
                ModelUser::whereIn('id', $this->bulkSelect)->update(['status' => 2]);
                session()->flash('message', 'Selected users suspended.');
                break;

            case 'delete':
                ModelUser::whereIn('id', $this->bulkSelect)->delete();
                session()->flash('message', 'Selected users deleted.');
                break;

            default:
                $this->addError('bulk', 'Invalid action selected.');
                break;
        }

        // Refresh data
        $this->mount();
        $this->bulkSelect = [];
    }


    public function render()
    {
        $users = ModelUser::with('role')
            ->when($this->status !== '', function ($query) {
                $query->where('status', $this->status);
            })
            ->when($this->search, function ($query) {
                $query->where(function ($q) {
                    $q->where('name', 'like', '%' . $this->search . '%')
                        ->orWhere('email', 'like', '%' . $this->search . '%');
                });
            })
            // ->when($this->someOtherTrigger, function ($query) {
            //     $query->where('some_column', $this->someValue);
            // })
            ->get(['id', 'name', 'email', 'status', 'created_at']);

        return view('livewire.user', ['users' => $users]);
    }
}
  