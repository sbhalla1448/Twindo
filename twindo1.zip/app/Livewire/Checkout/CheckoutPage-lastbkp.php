<?php

namespace App\Livewire\Checkout;

use Stripe\Stripe;
use App\Models\User;
use App\Models\Coupon;
use App\Models\Country;
use Livewire\Component;
use Stripe\PaymentIntent;
use App\Models\UserAddress;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Stripe\Customer;
use Stripe\StripeClient;

class CheckoutPage extends Component
{
    public $selectedPlan = 'monthly';
    public $progress = 0;
    public $progressAccount = 'active';
    public $logedInStatus;

    public $plan_id = 1;
    public $geustUser;
    public $progressPayment;
    public $couponCode;
    public $splan;
    public $newTotal = 0;
    public $subtotal;
    public $discount;
    public $total = 0;
    public $progressComplete;
    public $first_name, $last_name, $email, $phone, $street_address, $city, $county, $postal_code, $country, $password, $confirm_password,$countryId;
    public $payment_method = 'card';
    public $card_number, $expiry_date, $cvc, $name_on_card, $billing_postal_code;
    public $plan = 'monthly';
    public $clientSecret;
    // public $checkoutKey;
    public $errorMessage;

    protected StripeClient $stripe;
    protected ?string $checkoutKey = null;


    public function __construct()
    {
        $this->stripe = New StripeClient(config('stripe.stripe_sk'));
    }

    protected $rules = [
        'first_name' => 'required|string|max:255',
        'last_name' => 'required|string|max:255',
        'email' => 'required|email|unique:users,email',
        'phone' => 'required|string|max:20',
        'street_address' => 'required|string|max:255',
        'city' => 'required|string|max:255',
        'county' => 'required|string|max:255',
        'postal_code' => 'required|string|max:20',
        'countryId' => 'required|string|max:255',
        'password' => 'required|string|min:8|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/',
        'confirm_password' => 'required|same:password',
    ];

    public function mount($splan)
    {

        $this->splan = $splan;
        $this->checkoutKey = "checkout_". $splan->id;
        $this->geustUser = Auth::check() ? '' : 'active';
        $this->logedInStatus = Auth::check() ? 'active' : '';
        $this->progress = Auth::check() ? '50' : '0';
        $this->progressPayment = Auth::check() ? 'active' : '0';
        $this->subtotal = $splan->monthly_price;
        $this->total = $this->subtotal; // Default monthly plan price
        // dd($this->total);
        if (Auth::check()) {
            $this->clientSecret = $this->getClientSecret();
        }

    }


// public function setPaymentPlan($plan)
// {
//     $this->selectedPlan = $plan;
//     $this->subtotal = $plan == 'monthly' ? $this->splan->monthly_price:$this->splan->yearly_price;
//     if (Auth::check()) {
//         // ensure checkoutKey is always set before using it
//         if (!$this->checkoutKey) {
//             $this->checkoutKey = 'checkout_' . auth()->id();
//         }

//         $this->clientSecret = $this->getClientSecret();
//         $this->dispatch('stripe-updated', [
//             'clientSecret' => $this->clientSecret
//         ]);
//     }
// }
public function setPaymentPlan($plan)
{

    $this->selectedPlan = $plan;
    $this->subtotal = $plan === 'monthly' ? $this->splan->monthly_price : $this->splan->yearly_price;

    if (Auth::check()) {
        // Make sure the key is initialized
        if (!$this->checkoutKey) {
            $this->checkoutKey = "checkout_". $this->splan->id;
        }

        $this->clientSecret = $this->getClientSecret();

        $this->dispatch('stripe-updated', [
            'clientSecret' => $this->clientSecret
        ]);
    }
}

    public function userSignUp()
    {

        $this->validate();

        $user = User::create([
            'name' => $this->first_name . ' ' . $this->last_name,
            'email' => $this->email,
            'password' => Hash::make($this->password),
            'phone' => $this->phone,
            'role_id' => 2,
            'status' => 1,
        ]);
        Auth::login($user);
        if($user)
        {
            UserAddress::create([
            'user_id' => $user->id,
            'street_address' =>  $this->street_address,
            'city' => $this->city,
            'post_code' =>  $this->postal_code,
            'country_code' => $this->countryId,
            // 'address_type' => $this->addressType,
            // 'default_address_status' => $this->defaultAddress,
            ]);

        }
        $this->reset([
            'first_name', 'last_name', 'email', 'phone', 'street_address', 'city', 'county', 'postal_code', 'countryId',
            'password', 'confirm_password'
        ]);
        $this->progress = 50;
        $this->progressPayment = 'active';


    }

    public function userSignIn()
    {
        $this->validate([
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        if (Auth::attempt(['email' => $this->email, 'password' => $this->password])) {
            // Authentication passed
            $user = Auth::user();
            if ($user->status=== 0) {
                Auth::logout();
                $this->errorMessage = 'Your account is not active. Please contact support.';
                return;
            }
        } else {
            $this->errorMessage = 'Invalid email or password.';
        }
    }

        // Apply Coupon
        public function applyCoupon()
        {
            $this->validate([
                'couponCode' => 'required|string',
            ]);

            // $coupon = Coupon::where('code', $this->couponCode)->first();


            // if (!$coupon || !$coupon->isValid()) {
            //     $this->addError('couponCode', 'Invalid or expired coupon.');
            //     return;
            // }

            // if ($coupon->min_spend && $this->subtotal < $coupon->min_spend) {
            //     $this->addError('couponCode', 'Minimum spend not met.');
            //     return;
            // }

            // $this->discount = $coupon->type === 'fixed'
            //     ? $coupon->value
            //     : ($coupon->value / 100) * $this->subtotal;

            // $this->couponCode = $coupon->code;
            // $coupon->increment('used_count');

            // $this->total = $this->subtotal - $this->discount;

            // // 💡 Stripe's minimum is 50 cents (USD)
            // if ($this->total < 0.5) {
            //     $this->addError('couponCode', 'Total after discount must be at least $0.50');
            //     return;
            // }

            // // ♻️ Regenerate payment intent with new amount
            // if (Auth::check()) {
            //     $this->clientSecret = $this->getClientSecret();

            //     $this->dispatch('stripe-updated', [
            //         'clientSecret' => $this->clientSecret
            //     ]);
            // }

            $coupon = Coupon::where('code', $this->couponCode)
            ->where('active', true)
            ->lockForUpdate()
            ->first();

            if (!$coupon) {
                $this->addError('couponCode', 'Invalid coupon code.');
                return;
            }
            $validation = $coupon->isValid($this->subtotal);
            if (!$validation['valid']) {
                $this->addError('couponCode', $validation['message']);
                return;
            }

            $this->discount = $coupon->calculateDiscount($this->subtotal);
             $this->total = max($this->subtotal - $this->discount, 0.50);
             if ($this->total < 0.50) {
                $this->addError('couponCode', 'Total after discount must be at least $0.50');
                return;
            }

                 // Store coupon info but don't increment usage yet
                // $this->appliedCoupon = $coupon;
                $this->couponCode = $coupon->code;

                // if (Auth::check()) {
                //     $this->clientSecret = $this->getClientSecret();
                //     $this->dispatch('stripe-updated', [
                //         'clientSecret' => $this->clientSecret
                //     ]);
                // }

                if (Auth::check()) {
                    // Make sure the key is initialized
                    if (!$this->checkoutKey) {
                        $this->checkoutKey = "checkout_". $this->splan->id;
                    }

                    $this->clientSecret = $this->getClientSecret();

                    $this->dispatch('stripe-updated', [
                        'clientSecret' => $this->clientSecret
                    ]);
                }
        }



        protected function getClientSecret()
        {
            $user = Auth::user();

            $customer = $this->getStripeCustomer($user);

            $paymentIntent = $this->getPaymentIntent($customer);

            // Ensure checkoutKey is initialized
            if (!$this->checkoutKey) {
                $this->checkoutKey = 'checkout_' . auth()->id();
            }

            // Save PaymentIntent ID in session for later use
            session([$this->checkoutKey => $paymentIntent->id]);

            return $paymentIntent->client_secret;
        }


protected function getStripeCustomer(User $user):Customer
{

    if($user->stripe_customer_id !==null){
        return $this->stripe->customers->retrieve($user->stripe_customer_id);
    }

    $customer = $this->stripe->customers->create([
        'email' => $user->email,
        'name' => $user->name,
    ]);
    $user->update(['stripe_customer_id' => $customer->id]);
    // session(['stripe_customer_id' => $customer->id]);
    return $customer;
}

protected function getPaymentIntent(Customer $customer):PaymentIntent
{
    $paymentIntentId =  session($this->checkoutKey);
    // $paymentIntentId =  trim((string) session($this->checkoutKey, ''));
    if($paymentIntentId ===null)
    {
        return $this->createNewPaymentIntent($customer);
    }
    $paymentIntent = $this->stripe->paymentIntents->retrieve($paymentIntentId);
    if($paymentIntent->status !== 'requires_payment_method')
    {
        return $this->createNewPaymentIntent($customer);
    }

    return $paymentIntent;
}

protected function createNewPaymentIntent(Customer $customer): PaymentIntent
{
    $paymentIntent = $this->stripe->paymentIntents->create([
        'customer' => $customer->id,
        'setup_future_usage' => 'off_session',
        'amount' => intval($this->total * 100),
        'currency' => config('stripe.currency'),
        'metadata' => [
            'user_id' => Auth::user()->id,
            'plan_id' => $this->plan_id,
            'duration' => $this->selectedPlan,
        ],
    ]);

    session([$this->checkoutKey => $paymentIntent->id]);


    return $paymentIntent;
}



    public function render()
    {

        if (!$this->discount) {
            $this->total = $this->subtotal;
        } else {
            $this->total = $this->subtotal - $this->discount;
        }

        $countries = Country::all();
        return view('livewire.checkout.checkout-page', [
            'countries' => $countries,
        ]);
        // return view('livewire.checkout.checkout-page');
    }
}
