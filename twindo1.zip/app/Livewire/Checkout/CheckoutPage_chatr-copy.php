<?php

namespace App\Livewire\Checkout;

use Stripe\Stripe;
use App\Models\User;
use App\Models\Coupon;
use App\Models\Country;
use Livewire\Component;
use Stripe\PaymentIntent;
use App\Models\UserAddress;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Stripe\Customer;
use Stripe\StripeClient;

class CheckoutPage extends Component
{
    public $selectedPlan = 'monthly';
    public $progress = 0;
    public $progressAccount = 'active';
    public $logedInStatus;

    public $plan_id = 1;
    public $geustUser;
    public $progressPayment;
    public $couponCode;
    public $splan;
    public $newTotal = 0;
    public $subtotal;
    public $discount;
    public $total = 0;
    public $progressComplete;
    public $first_name, $last_name, $email, $phone, $street_address, $city, $county, $postal_code, $country, $password, $confirm_password,$countryId;
    public $payment_method = 'card';
    public $card_number, $expiry_date, $cvc, $name_on_card, $billing_postal_code;
    public $plan = 'monthly';
    public $clientSecret;
    // public $checkoutKey;
    public $errorMessage;

    protected StripeClient $stripe;
    protected ?string $checkoutKey = null;


    public function __construct()
    {
        $this->stripe = New StripeClient(config('stripe.stripe_sk'));
    }


    public function mount($splan)
    {

        $this->splan = $splan;
        $this->checkoutKey = "checkout_". $splan->id;
        $this->geustUser = Auth::check() ? '' : 'active';
        $this->logedInStatus = Auth::check() ? 'active' : '';
        $this->progress = Auth::check() ? '50' : '0';
        $this->progressPayment = Auth::check() ? 'active' : '0';
        $this->subtotal = $splan->monthly_price;
        $this->total = $this->subtotal; // Default monthly plan price
        if (Auth::check()) {
            $this->clientSecret = $this->createOrUpdatePaymentIntent(true);
        }

    }
    public function setPaymentPlan($plan)
    {
        $this->selectedPlan = $plan;
        $this->subtotal = $plan === 'monthly' ? $this->splan->monthly_price : $this->splan->yearly_price;
        $this->recalculateTotal();

        if (Auth::check()) {
            $this->clientSecret = $this->createOrUpdatePaymentIntent(true);
            $this->dispatch('stripe-updated', ['clientSecret' => $this->clientSecret]);
        }
    }

        // Apply Coupon
        public function applyCoupon()
        {
            $this->couponCode = is_array($this->couponCode) ? '' : (string) $this->couponCode;



            $this->validate([
                'couponCode' => 'required|string',
            ]);

            $coupon = Coupon::where('code', $this->couponCode)
                ->where('active', true)
                ->lockForUpdate()
                ->first();

            if (!$coupon) {
                $this->addError('couponCode', 'Invalid coupon code.');
                return;
            }

            $validation = $coupon->isValid($this->subtotal);
            if (!$validation['valid']) {
                $this->addError('couponCode', $validation['message']);
                return;
            }

            $this->discount = $coupon->calculateDiscount($this->subtotal);
            $this->couponCode = $coupon->code; // Make sure it stays a string
            $this->recalculateTotal();

            if (Auth::check()) {
                $this->clientSecret = $this->createOrUpdatePaymentIntent(true);
                $this->dispatch('stripe-updated', ['clientSecret' => $this->clientSecret]);
            }
        }


        private function recalculateTotal()
        {
            $this->total = max(0, $this->subtotal - $this->discount);
        }




        // protected function getClientSecret()
        // {
        //     $user = Auth::user();

        //     $customer = $this->getStripeCustomer($user);

        //     $paymentIntent = $this->getPaymentIntent($customer);

        //     // Ensure checkoutKey is initialized
        //     if (!$this->checkoutKey) {
        //         $this->checkoutKey = 'checkout_' . auth()->id();
        //     }

        //     // Save PaymentIntent ID in session for later use
        //     session([$this->checkoutKey => $paymentIntent->id]);

        //     return $paymentIntent->client_secret;
        // }

        protected function getStripeCustomer(User $user): Customer
        {
            if ($user->stripe_customer_id) {
                return $this->stripe->customers->retrieve($user->stripe_customer_id);
            }

            $customer = $this->stripe->customers->create([
                'email' => $user->email,
                'name' => $user->name,
            ]);

            $user->update(['stripe_customer_id' => $customer->id]);

            return $customer;
        }
        // protected function getPaymentIntent(Customer $customer): ?PaymentIntent
        // {
        //     $paymentIntentId = session()->get($this->checkoutKey);

        //     if (!$paymentIntentId) {
        //         return null;
        //     }

        //     try {
        //         return $this->stripe->paymentIntents->retrieve($paymentIntentId);
        //     } catch (\Exception $e) {
        //         return null;
        //     }
        // }

        protected function getPaymentIntent(Customer $customer): ?PaymentIntent
{
    $paymentIntentData = session()->get($this->checkoutKey);

    // If it's an array, extract the ID
    $paymentIntentId = is_array($paymentIntentData) ? ($paymentIntentData['id'] ?? null) : $paymentIntentData;

    if (!$paymentIntentId || !is_string($paymentIntentId)) {
        return null;
    }

    try {
        return $this->stripe->paymentIntents->retrieve($paymentIntentId);
    } catch (\Exception $e) {
        return null;
    }
}

        protected function createOrUpdatePaymentIntent($forceCreate = false): string
        {
            $user = Auth::user();
            $customer = $this->getStripeCustomer($user);

            $paymentIntent = $this->getPaymentIntent($customer);

            $amount = intval($this->total * 100);

            if ($paymentIntent && !$forceCreate) {
                return $paymentIntent->client_secret;
            }

            if ($paymentIntent && $paymentIntent->status === 'requires_payment_method') {
                $updated = $this->stripe->paymentIntents->update($paymentIntent->id, [
                    'amount' => $amount,
                    'metadata' => [
                        'user_id' => $user->id,
                        'plan_id' => $this->plan_id,
                        'duration' => $this->selectedPlan,
                    ],
                ]);

                return $updated->client_secret;
            }

            $newIntent = $this->stripe->paymentIntents->create([
                'customer' => $customer->id,
                'setup_future_usage' => 'off_session',
                'amount' => $amount,
                'currency' => config('stripe.currency'),
                'metadata' => [
                    'user_id' => $user->id,
                    'plan_id' => $this->plan_id,
                    'duration' => $this->selectedPlan,
                ],
            ]);

            // 🔥 PUT this, not GET
            session()->put($this->checkoutKey, $newIntent->id);

            return $newIntent->client_secret;
        }



    public function render()
    {

        if (!$this->discount) {
            $this->total = $this->subtotal;
        } else {
            $this->total = $this->subtotal - $this->discount;
        }

        $countries = Country::all();
        return view('livewire.checkout.checkout-page', [
            'countries' => $countries,
        ]);
        // return view('livewire.checkout.checkout-page');
    }
}
