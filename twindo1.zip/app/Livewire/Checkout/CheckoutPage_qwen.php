<?php

namespace App\Livewire\Checkout;

use Stripe\Stripe;
use App\Models\User;
use App\Models\Coupon;
use App\Models\Country;
use Livewire\Component;
use Stripe\Customer;
use Stripe\PaymentIntent;
use App\Models\UserAddress;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Stripe\StripeClient;

class CheckoutPage extends Component
{
    public $selectedPlan = 'monthly';
    public $progress = 0;
    public $logedInStatus;
    public $planId = 1;
    public $plan_id = 1;
    public $geustUser;
    public $couponCode;
    public $newTotal = 0;
    public $subtotal;
    public $discount = 0;
    public $total = 0;
    public $first_name;
    public $last_name;
    public $email;
    public $phone;
    public $street_address;
    public $city;
    public $county;
    public $postal_code;
    public $country;
    public $countryId;
    public $password;
    public $confirm_password;
    public $payment_method = 'card';
    public $clientSecret;
    public $errorMessage;

    protected StripeClient $stripe;
    protected string $checkoutKey;

    protected $rules = [
        'first_name' => 'required|string|max:255',
        'last_name' => 'required|string|max:255',
        'email' => 'required|email',
        'phone' => 'required|string|max:20',
        'street_address' => 'required|string|max:255',
        'city' => 'required|string|max:255',
        'county' => 'required|string|max:255',
        'postal_code' => 'required|string|max:20',
        'countryId' => 'required|string|max:255',
        'password' => 'nullable|min:8|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/',
        'confirm_password' => 'nullable|same:password',
    ];

    public function __construct()
    {
        $this->stripe = new StripeClient(config('stripe.stripe_sk'));
    }

    public function mount()
    {
        $this->checkoutKey = "checkout.{$this->planId}";
        $this->logedInStatus = Auth::check() ? 'active' : '';
        $this->geustUser = Auth::check() ? '' : 'active';
        $this->progress = Auth::check() ? 50 : 0;

        // Default monthly plan price
        $this->subtotal = $this->selectedPlan === 'monthly' ? 59.99 : 599.99;
        $this->total = $this->subtotal;

        if (Auth::check()) {
            $this->clientSecret = $this->getClientSecret();
        }
    }

    public function setPaymentPlan($plan)
    {
        $this->selectedPlan = $plan;
        $this->subtotal = $plan === 'monthly' ? 59.99 : 599.99;
        $this->total = $this->subtotal - $this->discount;

        if (Auth::check()) {
            $this->clientSecret = $this->getClientSecret();
        }
    }

    public function userSignUp()
    {
        $this->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'phone' => 'required|string|max:20',
            'street_address' => 'required|string|max:255',
            'city' => 'required|string|max:255',
            'county' => 'required|string|max:255',
            'postal_code' => 'required|string|max:20',
            'countryId' => 'required|string|max:255',
            'password' => 'required|string|min:8|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/',
            'confirm_password' => 'required|same:password',
        ]);

        $user = User::create([
            'name' => $this->first_name . ' ' . $this->last_name,
            'email' => $this->email,
            'password' => Hash::make($this->password),
            'phone' => $this->phone,
            'role_id' => 2,
            'status' => 1,
        ]);

        Auth::login($user);

        UserAddress::create([
            'user_id' => $user->id,
            'street_address' => $this->street_address,
            'city' => $this->city,
            'post_code' => $this->postal_code,
            'country_code' => $this->countryId,
        ]);

        $this->reset(['password', 'confirm_password']);
        $this->progress = 50;
        $this->clientSecret = $this->getClientSecret();
    }

    public function userSignIn()
    {
        $this->validate([
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        if (Auth::attempt(['email' => $this->email, 'password' => $this->password])) {
            $user = Auth::user();
            if ($user->status === 0) {
                Auth::logout();
                $this->errorMessage = 'Your account is not active. Please contact support.';
                return;
            }

            $this->progress = 50;
            $this->clientSecret = $this->getClientSecret();
        } else {
            $this->errorMessage = 'Invalid email or password.';
        }
    }

    public function applyCoupon()
    {
        $this->validate(['couponCode' => 'required|string']);

        $coupon = Coupon::where('code', $this->couponCode)->first();

        if (!$coupon || !$coupon->isValid()) {
            return $this->addError('couponCode', 'Invalid or expired coupon.');
        }

        if ($coupon->min_spend && $this->subtotal < $coupon->min_spend) {
            return $this->addError('couponCode', 'Minimum spend not met.');
        }

        $this->discount = $coupon->type === 'fixed'
            ? $coupon->value
            : ($coupon->value / 100) * $this->subtotal;

        $this->total = max(0, $this->subtotal - $this->discount);
        $coupon->increment('used_count');
    }

    protected function getClientSecret(): string
    {
        $user = Auth::user();

        // Get or create Stripe Customer
        $customer = $this->getStripeCustomer($user);

        // Create or retrieve Payment Intent
        $paymentIntent = $this->getPaymentIntent($customer);

        return $paymentIntent->client_secret;
    }

    protected function getStripeCustomer(User $user): Customer
    {
        if ($user->stripe_customer_id) {
            return $this->stripe->customers->retrieve($user->stripe_customer_id);
        }

        $customer = $this->stripe->customers->create([
            'email' => $user->email,
            'name' => $user->name,
        ]);

        $user->update(['stripe_customer_id' => $customer->id]);
        return $customer;
    }

    protected function getPaymentIntent(Customer $customer): PaymentIntent
    {
        $amount = $this->getStripeAmount($this->total);

        $existingIntentId = session($this->checkoutKey);

        if ($existingIntentId) {
            try {
                $intent = $this->stripe->paymentIntents->retrieve($existingIntentId);
                if ($intent->status === 'requires_payment_method') {
                    $intent = $this->stripe->paymentIntents->update($existingIntentId, [
                        'amount' => $amount,
                        'currency' => 'usd',
                        'customer' => $customer->id,
                    ]);
                }
                return $intent;
            } catch (\Exception $e) {
                // Invalid intent found; discard it and create a new one
            }
        }

        return $this->createNewPaymentIntent($customer, $amount);
    }

    protected function createNewPaymentIntent(Customer $customer, int $amount): PaymentIntent
    {
        $intent = $this->stripe->paymentIntents->create([
            'amount' => $amount,
            'currency' => 'usd',
            'customer' => $customer->id,
            'automatic_payment_methods' => ['enabled' => true],
            'metadata' => [
                'user_id' => Auth::id(),
                'plan_id' => $this->plan_id,
                'type' => $this->selectedPlan,
            ],
        ]);

        session([$this->checkoutKey => $intent->id]);
        return $intent;
    }

    protected function getStripeAmount(float $total): int
    {
        $amountCents = (int) round($total * 100);
        if ($amountCents < 50) {
            throw new \Exception("Minimum payment amount is \$0.50");
        }
        return $amountCents;
    }

    public function render()
    {
        $countries = Country::all();
        return view('livewire.checkout.checkout-page', compact('countries'));
    }
}