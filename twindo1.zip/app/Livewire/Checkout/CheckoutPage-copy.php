<?php

namespace App\Livewire\Checkout;

use Stripe\Stripe;
use Stripe\PaymentIntent;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Livewire\Component;

class CheckoutPage extends Component
{
    public $step = 1;
    public $first_name, $last_name, $email, $phone, $street_address, $city, $county, $postal_code, $country, $password, $confirm_password;
    public $payment_method = 'card';
    public $card_number, $expiry_date, $cvc, $name_on_card, $billing_postal_code;
    public $plan = 'monthly';
    public $clientSecret;
    public $errorMessage;

    protected $rules = [
        'first_name' => 'required|string|max:255',
        'last_name' => 'required|string|max:255',
        'email' => 'required|email|unique:users,email',
        'phone' => 'required|string|max:20',
        'street_address' => 'required|string|max:255',
        'city' => 'required|string|max:255',
        'county' => 'required|string|max:255',
        'postal_code' => 'required|string|max:20',
        'country' => 'required|string|max:255',
        'password' => 'required|string|min:8|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/',
        'confirm_password' => 'required|same:password',
    ];

    public function mount()
    {
        // Initialize Stripe with your secret key
        Stripe::setApiKey(config('stripe.stripe_sk'));
    }

    public function nextStep()
    {
        if ($this->step == 1) {
            $this->validate();
            // Create or update user
            $user = Auth::user();
            if (!$user) {
                $user = \App\Models\User::create([
                    'name' => $this->first_name . ' ' . $this->last_name,
                    'email' => $this->email,
                    'password' => Hash::make($this->password),
                    'phone' => $this->phone,
                    'street_address' => $this->street_address,
                    'city' => $this->city,
                    'county' => $this->county,
                    'postal_code' => $this->postal_code,
                    'country' => $this->country,
                ]);
                Auth::login($user);
            }
            // Create Payment Intent
            try {
                $amount = $this->plan == 'monthly' ? 5999 : 59999; // £59.99 or £599.99 in cents
                $paymentIntent = PaymentIntent::create([
                    'amount' => $amount,
                    'currency' => 'gbp',
                    'payment_method_types' => ['card'],
                    'metadata' => [
                        'user_id' => $user->id,
                        'plan' => $this->plan,
                    ],
                ]);
                $this->clientSecret = $paymentIntent->client_secret;
            } catch (\Exception $e) {
                $this->errorMessage = 'Error initializing payment: ' . $e->getMessage();
                return;
            }
        }
        if ($this->step < 3) {
            $this->step++;
        }
    }

    public function previousStep()
    {
        if ($this->step > 1) {
            $this->step--;
        }
    }

    public function confirmPayment($paymentMethodId)
    {
        try {
            $paymentIntent = PaymentIntent::retrieve($this->clientSecret);
            $paymentIntent->confirm(['payment_method' => $paymentMethodId]);
            // Save subscription details to database
            \App\Models\Subscription::create([
                'user_id' => Auth::id(),
                'plan' => $this->plan,
                'amount' => $this->plan == 'monthly' ? 59.99 : 599.99,
                'status' => 'active',
                'next_billing_date' => now()->addMonth(),
                'payment_method' => 'card',
                'order_number' => 'TW-' . now()->format('Ymd') . '-' . rand(100000, 999999),
            ]);
            $this->step = 3;
        } catch (\Exception $e) {
            $this->errorMessage = 'Payment failed: ' . $e->getMessage();
        }
    }

    public function render()
    {
        $subtotal = $this->plan == 'monthly' ? 59.99 : 599.99;
        $discount = $this->plan == 'annual' ? 15 : 0;
        $total = $subtotal * (1 - $discount / 100);

        return view('livewire.checkout.checkout-page', [
            'subtotal' => $subtotal,
            'total' => $total,
            'discount' => $discount,
        ]);
        // return view('livewire.checkout.checkout-page');
    }
}
