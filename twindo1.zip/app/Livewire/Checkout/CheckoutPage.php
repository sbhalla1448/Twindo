<?php

namespace App\Livewire\Checkout;

use Stripe\Stripe;
use App\Models\User;
use App\Models\Coupon;
use App\Models\Country;
use Livewire\Component;
use Stripe\PaymentIntent;
use App\Models\UserAddress;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Stripe\Customer;
use Stripe\StripeClient;
use Illuminate\Support\Facades\Log;

class CheckoutPage extends Component
{
    public $selectedPlan = 'monthly';
    public $progress = 0;
    public $progressAccount = 'active';
    public $logedInStatus;

    public $plan_id = 1;
    public $geustUser;
    public $progressPayment;
    public $couponCode;
    public $splan;
    public $newTotal = 0;
    public $subtotal;
    public $discount;
    public $total = 0;
    public $progressComplete;
    public $first_name, $last_name, $email, $phone, $street_address, $city, $county, $postal_code, $country, $password, $confirm_password,$countryId;
    public $payment_method = 'card';
    public $card_number, $expiry_date, $cvc, $name_on_card, $billing_postal_code;
    public $useremail;
    public $plan = 'monthly';
    public $clientSecret;
    public $paymentIntentId;
    // public $checkoutKey;
    public $errorMessage;

    protected StripeClient $stripe;
    protected ?string $checkoutKey = null;
    public $userEmail,$userPassword;


    protected $rules = [
        'first_name' => 'required|string|max:255',
        'last_name' => 'required|string|max:255',
        'email' => 'required|email|unique:users,email',
        'phone' => 'required|string|max:20',
        'street_address' => 'required|string|max:255',
        'city' => 'required|string|max:255',
        'county' => 'required|string|max:255',
        'postal_code' => 'required|string|max:20',
        'country' => 'required|string|max:255',
        'password' => 'required|string|min:8|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/',
        'confirm_password' => 'required|same:password',
    ];

    public function __construct()
    {
        $this->stripe = New StripeClient(config('stripe.stripe_sk'));
    }


    public function mount($splan)
    {

        $this->splan = $splan;
        $this->checkoutKey = "checkout_". $splan->id;
        $this->geustUser = Auth::check() ? '' : 'active';
        $this->logedInStatus = Auth::check() ? 'active' : '';
        $this->progress = Auth::check() ? '50' : '0';
        $this->progressPayment = Auth::check() ? 'active' : '0';
        $this->subtotal = $splan->monthly_price;
        $this->total = $this->subtotal; // Default monthly plan price

        // $this->clientSecret = $paymentIntent->client_secret;
        if (Auth::check()) {

            $paymentIntent = $this->createOrUpdatePaymentIntent(false);
            $this->clientSecret = $paymentIntent->client_secret;
            $this->useremail = Auth::user()->email;
        }

    }
    public function userSignUp()
    {
        $this->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'phone' => 'required|string|max:20',
            'street_address' => 'required|string|max:255',
            'city' => 'required|string|max:255',
            'county' => 'required|string|max:255',
            'postal_code' => 'required|string|max:20',
            'countryId' => 'required|string|max:255',
            'password' => 'required|string|min:8|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]+$/',
            'confirm_password' => 'required|same:password',
        ]);

        $user = User::create([
            'name' => $this->first_name . ' ' . $this->last_name,
            'email' => $this->email,
            'password' => Hash::make($this->password),
            'phone' => $this->phone,
            'role_id' => 2,
            'status' => 1,
        ]);

        Auth::login($user);

        UserAddress::create([
            'user_id' => $user->id,
            'street_address' => $this->street_address,
            'city' => $this->city,
            'post_code' => $this->postal_code,
            'country_code' => $this->countryId,
        ]);

        $this->reset(['password', 'confirm_password']);
        $this->progress = 50;
        $paymentIntent = $this->createOrUpdatePaymentIntent(false);
        $this->clientSecret = $paymentIntent->client_secret;
        $this->useremail = Auth::user()->email;
        $this->dispatch('$refresh');

    }

    public function userSignIn()
    {


        $this->validate([
            'userEmail' => 'required|email',
            'userPassword' => 'required|string',
        ]);

        if (Auth::attempt(['email' => $this->userEmail, 'password' => $this->userPassword])) {
            $user = Auth::user();
            if ($user->status === 0) {
                Auth::logout();
                $this->errorMessage = 'Your account is not active. Please contact support.';
                return;
            }

            $this->progress = 50;

            $paymentIntent = $this->createOrUpdatePaymentIntent(false);
            $this->clientSecret = $paymentIntent->client_secret;
            $this->useremail = Auth::user()->email;
            $user->update(['last_login_at'=>now()]);
            $this->dispatch('reloadPage');

        } else {
            $this->errorMessage = 'Invalid email or password.';
        }
    }



    public function setPaymentPlan($plan)
{
    $this->selectedPlan = $plan;
    $this->subtotal = $plan === 'monthly' ? $this->splan->monthly_price : $this->splan->yearly_price;
    $this->recalculateTotal();

    // Force create a new payment intent to avoid conflicts
    $paymentIntent = $this->createOrUpdatePaymentIntent(true);
    $this->clientSecret = $paymentIntent->client_secret;
    $this->paymentIntentId = $paymentIntent->id;

    $this->dispatch('stripe-updated', [
        'clientSecret' =>  $this->clientSecret,
        'paymentIntentId' =>  $this->paymentIntentId,
    ]);

    \Log::info($this->clientSecret );
    // $this->dispatch('render');
}

        // Apply Coupon
        public function applyCoupon()
        {
            $this->couponCode = is_array($this->couponCode) ? '' : (string) $this->couponCode;



            $this->validate([
                'couponCode' => 'required|string',
            ]);

            $coupon = Coupon::where('code', $this->couponCode)
                ->where('active', true)
                ->lockForUpdate()
                ->first();

            if (!$coupon) {
                $this->addError('couponCode', 'Invalid coupon code.');
                return;
            }

            $validation = $coupon->isValid($this->subtotal);
            if (!$validation['valid']) {
                $this->addError('couponCode', $validation['message']);
                return;
            }

            $this->discount = $coupon->calculateDiscount($this->subtotal);
            $this->couponCode = $coupon->code; // Make sure it stays a string
            $this->recalculateTotal();

    // Force create a new payment intent to avoid conflicts
    $paymentIntent = $this->createOrUpdatePaymentIntent(true);
    $this->clientSecret = $paymentIntent->client_secret;
    $this->paymentIntentId = $paymentIntent->id;

    $this->dispatch('stripe-updated', [
        'clientSecret' =>  $this->clientSecret,
        'paymentIntentId' =>  $this->paymentIntentId,
    ]);

            // if (Auth::check()) {

            //     $this->clientSecret = $this->createOrUpdatePaymentIntent(false);
            //     $this->dispatch('stripe-updated', ['clientSecret' => $this->clientSecret]);

            // }
        }


        private function recalculateTotal()
        {
            $this->total = max(0, $this->subtotal - $this->discount);
        }






        protected function getStripeCustomer(User $user): Customer
        {
            if ($user->stripe_customer_id) {
                return $this->stripe->customers->retrieve($user->stripe_customer_id);
            }

            $customer = $this->stripe->customers->create([
                'email' => $user->email,
                'name' => $user->name,
            ]);

            $user->update(['stripe_customer_id' => $customer->id]);

            return $customer;
        }


        protected function getPaymentIntent(Customer $customer): ?PaymentIntent
{
    $paymentIntentData = session()->get($this->checkoutKey);

    // If it's an array, extract the ID
    $paymentIntentId = is_array($paymentIntentData) ? ($paymentIntentData['id'] ?? null) : $paymentIntentData;

    if (!$paymentIntentId || !is_string($paymentIntentId)) {
        return null;
    }

    try {
        return $this->stripe->paymentIntents->retrieve($paymentIntentId);
    } catch (\Exception $e) {
        return null;
    }
}


protected function createOrUpdatePaymentIntent(bool $forceCreate = false): PaymentIntent
{
    $user = Auth::user();
    $customer = $this->getStripeCustomer($user);
    $paymentIntent = $forceCreate ? null : $this->getPaymentIntent($customer);
    $amount = intval($this->total * 100);

    if ($paymentIntent && !$forceCreate && in_array($paymentIntent->status, ['requires_payment_method', 'requires_confirmation'])) {
        $updated = $this->stripe->paymentIntents->update($paymentIntent->id, [
            'amount' => $amount,
            'metadata' => [
                'user_id' => $user->id,
                'plan_id' => $this->plan_id,
                'duration' => $this->selectedPlan,
                'couponCode' => $this->couponCode,
                'discount' => $this->discount,
            ],
        ]);
        session()->put($this->checkoutKey, $updated->id); // Update session
        return $updated;
    }

    $newIntent = $this->stripe->paymentIntents->create([
        'customer' => $customer->id,
        'setup_future_usage' => 'off_session',
        'amount' => $amount,
        'currency' => config('stripe.currency'),
        'automatic_payment_methods' => ['enabled' => true], // Enable automatic payment methods
        'metadata' => [
            'user_id' => $user->id,
            'plan_id' => $this->plan_id,
            'duration' => $this->selectedPlan,
            'couponCode' => $this->couponCode,
            'discount' => $this->discount,
        ],
    ]);
    $this->paymentIntentId = $newIntent->id;
    session()->put($this->checkoutKey, $newIntent->id); // Store new intent ID
    return $newIntent;
}
public function render()
    {

        if (!$this->discount) {
            $this->total = $this->subtotal;
        } else {
            $this->total = $this->subtotal - $this->discount;
        }

        $countries = Country::all();
        return view('livewire.checkout.checkout-page', [
            'countries' => $countries,
        ]);
        // return view('livewire.checkout.checkout-page');
    }
}
