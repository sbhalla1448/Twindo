<?php

namespace App\Livewire\MessageAction;

use Livewire\Component;

class MessageAction extends Component
{
    public function render()
    {
        return view('livewire.message-action.message-action');
    }
}
