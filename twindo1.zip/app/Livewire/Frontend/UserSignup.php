<?php

namespace App\Livewire\Frontend;

use App\Models\User;
use App\Notifications\WelcomeUser;
use Illuminate\Support\Facades\Hash;
use Livewire\Component;

class UserSignup extends Component
{


    public $name;
    public $email;
    public $password;
    public $password_confirmation;
    public $passwordStrength = 0;




    // Real-time password strength calculation
    public function updatedPassword($value)
    {
        $this->passwordStrength = $this->calculatePasswordStrength($value);
    }

    // Calculate password strength based on criteria
    private function calculatePasswordStrength($password)
    {
        $strength = 0;

        // Length (at least 8 characters)
        if (strlen($password) >= 6) {
            $strength += 25;
        }

        // Uppercase letters
        if (preg_match('/[A-Z]/', $password)) {
            $strength += 25;
        }

        // Lowercase letters
        if (preg_match('/[a-z]/', $password)) {
            $strength += 25;
        }

        // Numbers or symbols
        if (preg_match('/[0-9\W]/', $password)) {
            $strength += 25;
        }

        return min($strength, 100);
    }

    public function userSignUp()
    {

        $this->validate([
            'name' => 'required',
            'email' => 'required|unique:users,email',
            'password' => 'required|min:6|confirmed',
        ]);

        $user= User::create([
            'name' => $this->name,
            'email' => $this->email,
            'role_id' => 2,
            'status' => 1,
            'password' => Hash::make($this->password),
        ]);
         $user->notify(new WelcomeUser());

        return redirect()->route('login');
    }

    public function render()
    {
        return view('livewire.frontend.user-signup');
    }
}
