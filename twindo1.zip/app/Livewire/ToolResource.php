<?php

namespace App\Livewire;

use App\Models\Category;

use App\Models\ToolResource as ModelsToolResource;
use Livewire\Component;

class ToolResource extends Component
{
    public $viewTools = false;
    public $title,$content,$url;
    public $search = '';
    public $categoryId = '';
    public function view($id)
    {
        $this->viewTools = true;
        $tool= ModelsToolResource::findorfail($id);
        $this->title = $tool->title;
        $this->url = $tool->url;
        $this->content = @file_get_contents($tool->url);

    }
    public function deleteTool($id)
    {
       ModelsToolResource::findorfail($id)->delete();
    }
    public function closeDialog()
    {

        $this->viewTools = false;
    }


    public function render()
    {
        $cats = Category::get(['id','name']);
        // $categories = Category::with('tools')
        // ->when($this->categoryId !== '', function ($query) {
        //     $query->where('id', $this->categoryId);
        // })
        // ->when($this->search, function ($q) {
        //     $q->where(function ($sub) {
        //         $sub->where('name', 'like', "%{$this->search}%")
        //             ->orWhereHas('tools', fn($userQ) => $userQ->where('title', 'like', "%{$this->search}%"))
        //             ->orWhereHas('tools', fn($userQ) => $userQ->where('url', 'like', "%{$this->search}%"));
        //     });
        // })
        // ->get();
        $categories = Category::with(['tools' => function ($query) {
            $query->where('title', 'like', "%{$this->search}%")
                  ->orWhere('url', 'like', "%{$this->search}%");
        }])
        ->when($this->categoryId, function ($q) {
            $q->where('id', $this->categoryId);
        })
        ->when($this->search, function ($q) {
            $q->where(function ($sub) {
                $sub->where('name', 'like', "%{$this->search}%")
                    ->orWhereHas('tools', function ($toolQuery) {
                        $toolQuery->where('title', 'like', "%{$this->search}%")
                                  ->orWhere('url', 'like', "%{$this->search}%");
                    });
            });
        })
        ->get();
        return view('livewire.tool-resource',[
            'categories' => $categories,
            'cats' => $cats,
        ]);
    }
}
