<?php

namespace App\Livewire;

use Livewire\Component;

class EmailBlast extends Component
{
    public function render()
    {
        return view('livewire.email-blast');
    }
}
