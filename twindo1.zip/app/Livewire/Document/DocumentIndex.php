<?php

namespace App\Livewire\Document;

use App\Mail\SendAttachmentMail;
use App\Models\Document;
use App\Models\DocumentUpload;
use App\Models\EmailTemplate;
use App\Models\User;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Mail;
use Livewire\Component;
use Livewire\WithFileUploads;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;

class DocumentIndex extends Component
{
    use WithFileUploads;

    public $search = '';
    public $status = '';

    public $bulkSelect = [];
    public $bulkAction = '';
    public $types = '';

    public $drawarShow = false;
    public $documents, $fromDate, $toDate;



    public $users = [];
    public $templateId;
    public $selectedTemplate;
    public $cc;
    public $bcc;
    public $attachment;
    public $user;
    public $emailTemplates;
    public $mailBody;
    public $showPreview = false;

    public $previewContent;
    public $subject = '';
    public $manageTemplatePreview = false;
    public $templateSubject = '';
    public $templateBody = '';
    public $editingTemplateId = null;


    public function mount()
    {

        $this->users = User::where('role_id', 2)->get(['id', 'name']);
        $this->emailTemplates = EmailTemplate::all();
    }
    public function updatedUser($value)
    {
        $this->user = User::findorfail($value);
        $this->reset([
            'templateId',
            'selectedTemplate',
            'mailBody',
            'subject',
            'cc',
            'bcc',
            'attachment'
        ]);
    }


    public function updatedTemplateId($value)
    {

        $this->selectedTemplate = EmailTemplate::find($value);
        $userName = $this->user->name;
        $templateBody = $this->selectedTemplate->email_body;
        $this->mailBody = "Hi {$userName},\n\n{$templateBody}\n\nRegards,\nThe Twindo Team";
        $this->subject = $this->selectedTemplate->email_subject;
    }

    public function previewEmail()
    {

        $mailData = [
            'subject' => $this->subject,
            'body' => $this->mailBody,
        ];

        $filePath = null;
        if ($this->attachment) {
            $filePath = $this->attachment->getClientOriginalName();
        }

        $this->previewContent = Blade::render('emails.send_template_email', [
            'data' => $mailData,
            'filePath' => $filePath,
        ]);

        $this->showPreview = true;
    }

    public function closePreview()
    {
        $this->showPreview = false;
        $this->previewContent = null;
    }

    public function sendEmail()
    {
        $this->validate([
            'templateId' => 'required|exists:email_templates,id',
            'cc' => 'nullable|email',
            'bcc' => 'nullable|email',
            'mailBody' => 'nullable|string',
            'attachment' => 'nullable|file|max:2048',
        ]);
        $filePath = null;
        if ($this->attachment) {
            $filePath = $this->attachment->store('temp', 'public');
            $filePath = storage_path('app/public/' . $filePath);
        }


        $template = EmailTemplate::find($this->templateId);

        $mailData = [
            'subject' => $this->selectedTemplate->email_subject,
            'user' => $this->user->name,
            'body' => $this->mailBody,
            'cc' => $this->cc,
            'bcc' => $this->bcc,
        ];

        try {

            Mail::to($this->user->email)->send(new SendAttachmentMail($mailData, $filePath));

            if ($filePath) {
                \Storage::disk('public')->delete(str_replace(storage_path('app/public/'), '', $filePath));
            }


            $this->mailBody = "";

            session()->flash('message', 'Email sent successfully!');
        } catch (\Exception $e) {
            session()->flash('error', 'Failed to send email: ' . $e->getMessage());
            if ($filePath) {
                \Storage::disk('public')->delete(str_replace(storage_path('app/public/'), '', $filePath));
            }
        }
        session()->flash('message', 'Email sent successfully!');
    }


    public function manageTemplate()
    {
        $this->manageTemplatePreview = true;
        $this->templateSubject = '';
        $this->templateBody = '';
        $this->editingTemplateId = null;
    }
    public function closeManagePreview()
    {
        $this->manageTemplatePreview = false;
        $this->templateSubject = '';
        $this->templateBody = '';
        $this->editingTemplateId = null;
    }

    public function saveTemplate()
    {
        $this->validate([
            'templateSubject' => 'required|string|max:255',
            'templateBody' => 'required|string',
        ]);

        if ($this->editingTemplateId) {
            EmailTemplate::find($this->editingTemplateId)->update([
                'email_subject' => $this->templateSubject,
                'email_body' => $this->templateBody,
            ]);
            session()->flash('template_message', 'Template updated successfully!');
        } else {
            EmailTemplate::create([
                'email_subject' => $this->templateSubject,
                'email_body' => $this->templateBody,
            ]);
            session()->flash('template_message', 'Template created successfully!');
        }
        $this->mount($this->user, $this->emailTemplates);
        $this->closeManagePreview();
    }

    public function editTemplate($id)
    {
        $template = EmailTemplate::findOrFail($id);
        $this->editingTemplateId = $id;
        $this->templateSubject = $template->email_subject;
        $this->templateBody = $template->email_body;
        $this->manageTemplatePreview = true;
    }

    public function deleteTemplate($id)
    {
        EmailTemplate::findOrFail($id)->delete();
        $this->closeManagePreview();
        session()->flash('template_message', 'Template deleted successfully!');
        $this->mount($this->user, $this->emailTemplates);
    }
    public function deleteDocument($id)
    {
        $doc = Document::findOrFail($id);

        $files = DocumentUpload::where('document_id', $id)->get();
        foreach ($files as $file) {
            $filePath = 'uploads/' . $file->file_name;
            if (Storage::disk('public')->exists($filePath)) {
                Storage::disk('public')->delete($filePath);
            } else {
                session()->flash('error', 'File not found.');
            }
        }
        $doc->delete();
        session()->flash('delete_documents', 'Document deleted successfully!');
    }


    public function updatedBulkAction($value)
    {

        if (count($this->bulkSelect) === 0) {
            return $this->addError('bulk', 'No users selected.');
        }


        switch ($value) {
            case 'approved':
                Document::whereIn('id', $this->bulkSelect)->update(['approve_status' => 1]);
                session()->flash('message', 'Selected Documents approved.');
                break;

            case 'deleted':
                foreach ($this->bulkSelect as $id) {

                    $files = DocumentUpload::where('document_id', $id)->get();
                    foreach ($files as $file) {
                        $filePath = 'uploads/' . $file->file_name;
                        if (Storage::disk('public')->exists($filePath)) {
                            Storage::disk('public')->delete($filePath);
                        } else {
                            session()->flash('error', 'File not found.');
                        }
                    }
                    Document::findorfail($id)->delete();
                }

                session()->flash('message', 'Selected Documents  deleted.');
                break;

            default:
                $this->addError('bulk', 'Invalid action selected.');
                break;
        }

        // Refresh data
        $this->mount();
        $this->bulkSelect = [];
    }

    public function togleFilter()
    {
        $this->drawarShow = !$this->drawarShow;
    }
    public function resetFilter()
    {
        $this->drawarShow = false;
        $this->reset(
            'types',
            'fromDate',
            'toDate',
        );
    }



    public function render()
    {
        $this->documents = Document::with('user')
            ->when($this->search, function ($query) {
                $query->where(function ($q) {
                    $q->where('document_name', 'like', '%' . $this->search . '%')
                        ->orWhere('document_type', 'like', '%' . $this->search . '%')
                        ->orWhereHas('user', fn($userQ) => $userQ->where('name', 'like', "%{$this->search}%"));
                });
            })

            ->when($this->types !== '', function ($query) {
                $query->where('document_type', $this->types);
            })

            ->when($this->fromDate, function ($query) {
                $query->where('created_at', '>=', Carbon::parse($this->fromDate)->startOfDay());
            })
            ->when($this->toDate, function ($query) {
                $query->where('created_at', '<=', Carbon::parse($this->toDate)->endOfDay());
            })

            ->where('archive_status', 0)->get();
        return view('livewire.document.document-index', [
            'documents' => $this->documents,
        ]);
    }
}
