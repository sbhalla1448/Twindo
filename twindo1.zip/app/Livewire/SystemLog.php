<?php

namespace App\Livewire;

use App\Models\ActivityLog;
use Livewire\WithPagination;
use Livewire\Component;
use Carbon\Carbon;

class SystemLog extends Component
{
    use WithPagination;
    public $action = '';
    public $search, $fromDate, $toDate;

    public function resetFilterData()
    {
        $this->reset();
    }

    public function render()
    {
        // dd($this->fromDate);
        $systemLogs = ActivityLog::with('user')
        ->when($this->action, fn($q) => $q->where('action', $this->action))
        ->when($this->search, function ($q) {
            $q->where(function ($sub) {
                $sub->where('ip_address', 'like', "%{$this->search}%")
                    ->orWhere('action', 'like', "%{$this->search}%")
                    ->orWhere('descriptions', 'like', "%{$this->search}%")
                    ->orWhereHas('user', fn($userQ) => $userQ->where('name', 'like', "%{$this->search}%"));
            });
        })
        ->when($this->fromDate, function ($query) {
            $query->where('created_at', '>=', Carbon::parse($this->fromDate)->startOfDay());
        })
        ->when($this->toDate, function ($query) {
            $query->where('created_at', '<=', Carbon::parse($this->toDate)->endOfDay());
        })
        ->paginate(10);


        return view('livewire.system-log',[
            'systemLogs' => $systemLogs
        ]);
    }
}
