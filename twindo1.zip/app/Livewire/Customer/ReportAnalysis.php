<?php

namespace App\Livewire\Customer;

use Livewire\Component;
use App\Models\TemplateReport;
use Illuminate\Support\Facades\Auth;

class ReportAnalysis extends Component
{

public $templateReport;
    public function mount($id)
    {

$this->templateReport = TemplateReport::where('id',$id)->where('user_id', Auth::user()->id)->first();

    }
    public function render()
    {
        return view('livewire.customer.report-analysis');
    }
}
