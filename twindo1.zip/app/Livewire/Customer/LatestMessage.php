<?php

namespace App\Livewire\Customer;

use Livewire\Component;
use App\Models\MessageAction;
use App\Models\MessageThread;
use Illuminate\Support\Facades\Auth;

class LatestMessage extends Component
{

    public $viewTools = false;

    public $messageId,$replyMessage,$uploadFile,$message;

    public function readMessage($id)
    {
       $this->message= MessageAction::find($id);
       $this->messageId = $id;
        $this->viewTools = true;
       $this->message->update((['read_status_user' => 1]));

    }
    public function closeDialog()
    {
        $this->viewTools = false;
    }

    public function replyMessageSubmit()
    {

        $this->validate([
            'replyMessage' => 'required|string',
            'uploadFile' => 'nullable|file|mimes:png,jpg,webp,gif,jpeg,pdf,doc,docx|max:5048'
        ]);

        $name = null;

        if ($this->uploadFile) {
            $name = uniqid() . '.' . $this->uploadFile->getClientOriginalExtension();
            $this->uploadFile->storeAs('uploads', $name);
        }

        MessageThread::create([
            'message_id' => $this->messageId,
            'message' => $this->replyMessage,
            'user_id' => Auth::user()->id,
            'file' => $name,
        ]);

        $this->replyMessage = '';
        $this->uploadFile = null;
        $this->viewTools = false;

    }
    public function render()
    {
        $messages = MessageAction::where('user_id',auth()->user()->id)->latest()->take(3)->get();
        $usermessages = $this->messageId
        ? MessageThread::where('message_id', $this->messageId)
            ->where('user_id', Auth::user()->id)
            ->latest()
            ->paginate(2)
        : [];

        return view('livewire.customer.latest-message',[
            'messages'=>$messages,
            'usermessages' => $usermessages,
        ]);
    }
}
