<?php

namespace App\Livewire\Customer;

use Livewire\Component;
use App\Models\MessageAction;
use App\Models\UserNotification;
use Illuminate\Support\Facades\Auth;

class GDRPMarketingPrefernece extends Component
{
   public bool $emailUpdates = false;
    public bool $smsAlerts = false;
    public $exportdata = false;

    public function mount()
    {

        $userNotification = UserNotification::where('user_id', Auth::user()->id)->first();

        if ($userNotification) {
            $this->emailUpdates = (bool) $userNotification->new_feature_offer;
            $this->smsAlerts = (bool) $userNotification->sms_alert_account_activity;
        }
    }


    public function updatedEmailUpdates($value)
    {
        $this->emailUpdates = (bool) $value;
          UserNotification::updateOrCreate(
            ['user_id' => Auth::user()->id],
            [

                'new_feature_offer'    => $this->emailUpdates ? 1 : 0,
            ]
        );

        session()->flash('message', 'Preferences saved successfully!');
    }

    public function updatedSmsAlerts($value)
    {

        $this->smsAlerts = (bool) $value;

            UserNotification::updateOrCreate(
            ['user_id' => Auth::user()->id],
            [

                'sms_alert_account_activity'    => $this->smsAlerts ? 1 : 0,
            ]
        );

        session()->flash('message', 'Preferences saved successfully!');

    }


    public function dataExport()
    {


            MessageAction::create([
                'user_id' => Auth::user()->id,
                'subject' => 'Request To Data Export',
                'messages' => 'I want to export my data',
            ]);
            $this->reset();
            session()->flash('message', 'Request submited successfully!');
    }
    public function dataDeletion()
    {


            MessageAction::create([
                'user_id' => Auth::user()->id,
                'subject' => 'Request To Data Deletion',
                'messages' => 'I want to delete  my all data',
            ]);
            $this->reset();
            session()->flash('message', 'Request submited successfully!');
    }

    public function render()
    {
        return view('livewire.customer.g-d-r-p-marketing-prefernece');
    }
}
