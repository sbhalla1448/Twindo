<?php

namespace App\Livewire\Customer;

use App\Models\Category;
use Livewire\Component;
use App\Models\ToolResource as ModelToolResource;

class ToolResource extends Component
{
    public $categoryId = '';
    public $search = '';
    public $viewTools = false;
    public $title,$content,$url;

    public function view($id)
    {
        $this->viewTools = true;
        $tool= ModelToolResource::findorfail($id);
        $this->title = $tool->title;
        $this->url = $tool->url;
        $this->content = @file_get_contents($tool->url);

    }
    public function deleteTool($id)
    {
        ModelToolResource::findorfail($id)->delete();
    }
    public function closeDialog()
    {

        $this->viewTools = false;
    }

    public function render()
    {
        $tools = ModelToolResource::with('category')
        ->when($this->categoryId !== '', function ($query) {
            $query->where('category_id', $this->categoryId);
        })
        ->when($this->search, function ($query) {
            $query->where(function ($q) {
                $q->where('title', 'like', '%' . $this->search . '%')
                    ->orWhere('url', 'like', '%' . $this->search . '%')
                    ->orWhereHas('category', fn($userQ) => $userQ->where('name', 'like', "%{$this->search}%"));
            });
        })

        ->get();

        $categories = Category::get(['id', 'name']);
        return view('livewire.customer.tool-resource',[
            'tools' => $tools,
            'categories'=> $categories,
        ]);
    }
}
