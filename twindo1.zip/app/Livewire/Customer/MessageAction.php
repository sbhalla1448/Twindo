<?php

namespace App\Livewire\Customer;

use App\Models\Note;
use Livewire\Component;
use App\Models\MessageThread;
use Livewire\WithFileUploads;
use Livewire\Attributes\Validate;
use Livewire\WithPagination;
use Illuminate\Support\Facades\Auth;
use App\Models\MessageAction as ModelsMessageAction;

class MessageAction extends Component
{
    use WithFileUploads;
    use WithPagination;

    public $viewmsg = false;
    public $messageId,$replyMessage,$uploadFile;
    public function viewMessage($id)
    {

        $this->messageId = $id;
        $this->viewmsg = true;


    }

    public function replyMessageSubmit()
    {

        $this->validate([
            'replyMessage' => 'required|string',
            'uploadFile' => 'nullable|file|mimes:png,jpg,webp,gif,jpeg,pdf,doc,docx|max:5048'
        ]);

        $name = null;

        if ($this->uploadFile) {
            $name = uniqid() . '.' . $this->uploadFile->getClientOriginalExtension();
            $this->uploadFile->storeAs('uploads', $name);
        }

        MessageThread::create([
            'message_id' => $this->messageId,
            'message' => $this->replyMessage,
            'user_id' => Auth::user()->id,
            'file' => $name,
        ]);

        $this->replyMessage = '';
        $this->uploadFile = null;

    }

    public function render()
    {
        $userId = Auth::user()->id;
        $messages = ModelsMessageAction::where('user_id',$userId)->orderBy("created_at","desc")->paginate(2);
        $note = Note::where('user_id', $userId)->first();
        $usermessages = $this->messageId
        ? MessageThread::where('message_id', $this->messageId)
            ->where('user_id', Auth::user()->id)
            ->latest()
            ->paginate(2)
        : [];

        return view('livewire.customer.message-action', compact('messages','note','usermessages'));
    }
}
