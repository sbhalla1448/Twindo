<?php

namespace App\Livewire\Customer;

use Livewire\Component;
use App\Models\Subscription;

class ProductService extends Component
{
    public $currentSubscription, $title;
    public $viewTools = false;
    public function mount()
    {
       $this->currentSubscription= Subscription::where('user_id', auth()->id())->latest()->take(1)->first();
    }

    public function planActivity($data)
    {

        $this->viewTools = true;
        $this->title = $data;

    }
    public function closeDialog()
    {
        $this->viewTools = false;
    }
    public function makeYes()
    {
        $this->currentSubscription->update(['status'=>$this->title]);
        $this->viewTools = false;
    }

    public function render()
    {
        return view('livewire.customer.product-service');
    }
}
