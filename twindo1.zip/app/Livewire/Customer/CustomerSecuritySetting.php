<?php

namespace App\Livewire\Customer;

use Livewire\Component;
use Illuminate\Support\Facades\Auth;
use Livewire\Attributes\Validate;
use PragmaRX\Google2FALaravel\Google2FA;
use ZxcvbnPhp\Zxcvbn;
use Illuminate\Support\Facades\Hash;

class CustomerSecuritySetting extends Component
{
    public $user, $urlQRcode, $secretkey, $sessiontimeout, $suspiciousloginalert;



    public $twofaenable = false;
    public $twofasuccess = false;
    public $passwordchange = false;

    public $errorPass;
    public $current_password;
    public $currentPassword;
    public $newPassword;
    public $password;
    public $password_confirmation;
    public $passwordStrength = 0;
    public $otp;

    // protected $rules = [
    //     'currentPassword' => 'required',
    //     'newPassword' => 'required|min:6',
    //     'confirmPassword' => 'required|same:newPassword',
    // ];

    protected $rules = [
        // 'currentPassword' => 'required',
        // 'newPassword' => 'required|min:8|confirmed',
        // 'confirmPassword' => 'required',
        'currentPassword' => 'required',
        'newPassword' => 'required|min:6|confirmed|different:current_password',
    ];

    // $this->validate([
    //     'current_password' => 'required',
    //     'password' => 'required|min:8|confirmed|different:current_password',
    // ]);

    public function twofa()
    {
        $this->twofaenable = true;
    }
    public function twofaCancel()
    {
        $this->reset('otp');
        $this->twofaenable = false;
        $this->resetErrorBag();
    }

    public function mount()
    {

        $this->user = Auth::user();


        $google2fa = app('pragmarx.google2fa');

        if ($this->user->google2fa_secret) {
            $this->secretkey = $this->user->google2fa_secret;
        } else {
            $this->secretkey = $google2fa->generateSecretKey();
        }


        $this->urlQRcode = $google2fa->getQRCodeInline(
            config('app.name'),
            $this->user->email,
            $this->secretkey
        );
    }

    public function otpVerify()
    {
        $this->resetErrorBag(); // Optional: clears old validation errors
        $this->validate([
            'otp' => 'required',
        ]);

        $google2fa = app('pragmarx.google2fa');
        $isValid = $google2fa->verifyKey($this->secretkey, $this->otp);

        if ($isValid) {
            $this->user->google2fa_secret = $this->secretkey;
            // $this->user->google2fa_enable = true;
            $this->user->save();

            $this->twofaenable = false;
            $this->twofasuccess = true;

            session()->flash('message', 'Two Factor Authentication has been enabled successfully.');
        } else {
            $this->addError('otp', 'Invalid OTP');
            session()->flash('error', 'Invalid OTP');
        }
    }

    public function passwordUp()
    {
        $this->passwordchange = true;
    }
    public function closePasswordModal()
    {
        $this->password = '';
        $this->current_password = '';
        $this->password_confirmation = '';
        $this->passwordchange = false;

    }



    // Real-time password strength calculation
    public function updatedPassword($value)
    {
        $this->passwordStrength = $this->calculatePasswordStrength($value);
    }

    // Calculate password strength based on criteria
    private function calculatePasswordStrength($password)
    {
        $strength = 0;

        // Length (at least 8 characters)
        if (strlen($password) >= 8) {
            $strength += 25;
        }

        // Uppercase letters
        if (preg_match('/[A-Z]/', $password)) {
            $strength += 25;
        }

        // Lowercase letters
        if (preg_match('/[a-z]/', $password)) {
            $strength += 25;
        }

        // Numbers or symbols
        if (preg_match('/[0-9\W]/', $password)) {
            $strength += 25;
        }

        return min($strength, 100); // Cap at 100%
    }

    public function updatePassword()
    {
        $this->validate([
            'current_password' => 'required',
            'password' => 'required|min:8|confirmed|different:current_password',
        ]);
        $user = Auth::user();

        if (Hash::check($this->current_password, $user->password)) {
            $user->update([
                'password' => Hash::make($this->password),
                'password_change_at' => now(),
            ]);

            Auth::logout();
            return redirect()->route('login');
        } else {
            $this->addError('currentPassword', 'The current password is incorrect.');
        }

    }

    public function render()
    {
        return view('livewire.customer.customer-security-setting');
    }
}
