<?php

namespace App\Livewire\Product;

use App\Models\Product;
use Livewire\Component;
use App\Models\Category;
use Livewire\WithPagination;

class ProductIndex extends Component
{
    use WithPagination;
    public $search = '';
    public $categoryId = '';
    public $status = '';
    public $bulkSelect = [];
    public $bulkAction = '';

    public function mount() {}
    public function applyBulkAction()
    {
        if (count($this->bulkSelect) === 0) {
            return $this->addError('bulk', 'No product selected.');
        }

        switch ($this->bulkAction) {
            case 'hidden':
                Product::whereIn('id', $this->bulkSelect)->update(['status' => 0]);
                session()->flash('message', 'Selected product is Hidden.');
                break;

            case 'delete':
                // Product::whereIn('id', $this->bulkSelect)->delete();
                foreach ($this->bulkSelect as $id) {
                    $product = Product::find($id);
                    if ($product) {
                        $imagePath = public_path('images/' . $product->image);
                        if (file_exists($imagePath)) {
                            unlink($imagePath);
                        }
                        $product->delete();
                    }
                }
                session()->flash('message', 'Selected product is deleted.');
                break;
            case 'Feature':
                Product::whereIn('id', $this->bulkSelect)->update(['product_status' => 'Featured']);
                session()->flash('message', 'Selected product is featured.');
                break;

            default:
                $this->addError('bulk', 'Invalid action selected.');
                break;
        }

        // Refresh data
        $this->mount();
        $this->bulkSelect = [];
    }

    public function render()
    {
        $categories = Category::get(['id', 'name']);
        $products = Product::with('category')
            ->when($this->categoryId !== '', function ($query) {
                $query->where('category_id', $this->categoryId);
            })
            ->when($this->status !== '', function ($query) {
                $query->where('status', $this->status);
            })
            ->when($this->search, function ($q) {
                $q->where(function ($sub) {
                    $sub->where('title', 'like', "%{$this->search}%");
                    // ->orWhereHas('tools', function ($toolQuery) {
                    //     $toolQuery->where('title', 'like', "%{$this->search}%")
                    //               ->orWhere('url', 'like', "%{$this->search}%");
                    // });
                });
            })
            ->latest()->paginate(3);
        return view('livewire.product.product-index', [
            'products' => $products,
            'categories' => $categories
        ]);
    }
}
