<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class SuspiciousLoginNotification extends Notification
{
    use Queueable;
    protected $loginDetails;
    /**
     * Create a new notification instance.
     */
    public function __construct(array $loginDetails)
    {
        $this->loginDetails = $loginDetails;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @return array<int, string>
     */
    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     */
    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject('Suspicious Login Attempt Detected')
            ->greeting("Hello {$notifiable->name},")
            ->line('We detected a suspicious login attempt on your account.')
            ->line('**Login Details:**')
            ->line("**Time:** {$this->loginDetails['login_at']}")
            ->line("**Device:** {$this->loginDetails['device']}")
            ->line("**Browser:** {$this->loginDetails['browser']}")
            ->line("**IP Address:** {$this->loginDetails['ip']}")
            ->line("**Location:** {$this->loginDetails['city']}, {$this->loginDetails['country']}")
            ->line('If this was you, you can ignore this email. If not, please secure your account immediately.')
            ->action('Secure Your Account', url('/admin/setting/Security'))
            ->line('Thank you for keeping your account secure.');
        // ->line('The introduction to the notification.')
        // ->action('Notification Action', url('/'))
        // ->line('Thank you for using our application!');
    }

    /**
     * Get the array representation of the notification.
     *
     * @return array<string, mixed>
     */
    public function toArray(object $notifiable): array
    {
        return [
            //
        ];
    }
}
