<?php

namespace App\Notifications;

use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;

class CustomResetPassword extends Notification
{
    public $token;
    public $ip;
    public $device;
    public $timestamp;

    public function __construct($token, $ip, $device, $timestamp)
    {
        $this->token = $token;
        $this->ip = $ip;
        $this->device = $device;
        $this->timestamp = $timestamp;
    }

    public function via($notifiable)
    {
        return ['mail'];
    }

    public function toMail($notifiable)
    {
        $resetUrl = url(route('password.reset', [
            'token' => $this->token,
            'email' => $notifiable->getEmailForPasswordReset(),
        ], false));

        return (new MailMessage)
            ->subject('Reset Your Password')
            ->view('emails.password-reset', [
                'url' => $resetUrl,
                'user' => $notifiable,
                'user_ip' => $this->ip,
                'user_device' => $this->device,
                'timestamp' => $this->timestamp,
            ]);
    }
}
