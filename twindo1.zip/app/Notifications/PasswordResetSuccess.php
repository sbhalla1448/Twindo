<?php

namespace App\Notifications;

use Illuminate\Notifications\Notification;
use Illuminate\Notifications\Messages\MailMessage;

class PasswordResetSuccess extends Notification
{
    public $device;
    public $ip;
    public $location;
    public $timestamp;

    public function __construct($device, $ip, $location, $timestamp)
    {
        $this->device = $device;
        $this->ip = $ip;
        $this->location = $location;
        $this->timestamp = $timestamp;
    }

    public function via($notifiable)
    {
        return ['mail'];
    }

    public function toMail($notifiable)
    {
        return (new MailMessage)
            ->subject('Password Successfully Reset')
            ->view('emails.password-reset-success', [
                'user' => $notifiable,
                'user_ip' => $this->ip,
                'user_device' => $this->device,
                'location' => $this->location,
                'timestamp' => $this->timestamp,
        ]);
    }
}
