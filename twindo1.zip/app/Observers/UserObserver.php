<?php

namespace App\Observers;

use App\Models\User;

class UserObserver
{
    /**
     * Handle the User "created" event.
     */
    public function created(User $user): void
    {
        // Log the user creation
        $user->activityLogs()->create([
            'action' => 'created',
            'descriptions' => 'User created successfully',
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
            'url' => request()->url(),
            'method' => request()->method(),
            'icon' => '➕ ',
        ]);
    }

    /**
     * Handle the User "updated" event.
     */
    public function updated(User $user): void
    {
        // Log the user update



                    // $user->activityLogs()->create([
                    //     'action' => 'updated',
                    //     'descriptions' => 'User updated successfully',
                    //     'ip_address' => request()->ip(),
                    //     'user_agent' => request()->userAgent(),
                    //     'url' => request()->url(),
                    //     'method' => request()->method(),
                    //     'icon' => '✏️',
                    // ]);


    }

    /**
     * Handle the User "deleted" event.
     */
    public function deleted(User $user): void
    {
        // Log the user deletion


        $user->activityLogs()->create([
            'action' => 'deleted',
            'descriptions' => 'User deleted successfully',
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
            'url' => request()->url(),
            'method' => request()->method(),
            'icon' => '🗑️',
        ]);
    }

    /**
     * Handle the User "restored" event.
     */
    public function restored(User $user): void
    {
        //
    }

    /**
     * Handle the User "force deleted" event.
     */
    public function forceDeleted(User $user): void
    {
        //
    }
}
