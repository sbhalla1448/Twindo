<?php

namespace App\Enums;


enum DocumentType: string
{

    case IdentityProof = 'Identity Proof';
    case AddressVerification = 'Address Verification';
    case FinancialRecord = 'Financial Record';
    case Other = 'Other';


    public static function options(): array
    {
        return [
            self::IdentityProof,
            self::AddressVerification,
            self::FinancialRecord,
            self::Other,
        ];
    }

    public function label(): string
    {
        return match($this) {
            self::IdentityProof => 'Identity Proof',
            self::AddressVerification => 'Address Verification',
            self::FinancialRecord => 'Financial Record',
            self::Other => 'Other',
        };
    }
}
