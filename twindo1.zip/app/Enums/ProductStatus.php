<?php

namespace App\Enums;


enum ProductStatus: string
{
    case Featured = 'Featured';
    case OnlineExclusive = 'Online Exclusive';
    case Popular = 'Popular';
    case TwindoRecommended = 'Twindo Recommended';
    case TopRated = 'Top Rated';
    case TrustedChoice = 'Trusted Choice';

    public static function options(): array
    {
        return [
            self::Featured,
            self::OnlineExclusive,
            self::Popular,
            self::TwindoRecommended,
            self::TopRated,
            self::TrustedChoice,
        ];
    }

    public function label(): string
    {
        return match($this) {
            self::Featured => 'Featured',
            self::OnlineExclusive => 'Online Exclusive',
            self::Popular => 'Popular',
            self::TwindoRecommended => 'Twindo Recommended',
            self::TopRated => 'Top Rated',
            self::TrustedChoice => 'Trusted Choice',
        };
    }
}
