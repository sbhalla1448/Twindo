<?php

namespace App\Enums;


enum CreditRefAgency: string
{
    case Experian = 'Experian';
    case Transunion = 'Transunion';
    case Equifax = 'Equifax';
 

    public static function options(): array
    {
        return [
            self::Experian,
            self::Transunion,
            self::Equifax,
           
        ];
    }

    public function label(): string
    {
        return match($this) {
            self::Experian => 'Experian',
            self::Transunion => 'Transunion',
            self::Equifax => 'Equifax',
           
        };
    }
}
