<?php
namespace App\Listeners;

use Illuminate\Auth\Events\Login;
use Illuminate\Events\Attributes\AsListener;

class LogUserLogin
{
    #[AsListener]
    public function handle(Login $event): void
    {
        $user = $event->user;

        $user->activityLogs()->create([
            'action' => 'login',
            'descriptions' => 'User login successfully',
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
            'url' => request()->fullUrl(),
            'method' => request()->method(),
            'icon' => '🔐',
        ]);
    }
}
