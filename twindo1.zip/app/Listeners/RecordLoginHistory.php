<?php

namespace App\Listeners;

use App\Models\LoginHistory;
use Illuminate\Auth\Events\Login;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Events\Attributes\AsListener;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Facades\Http;
use Jenssegers\Agent\Agent;

class RecordLoginHistory
{
    #[AsListener]
    public function handle(Login $event): void
    {
        // $user = $event->user;
        // $ip = request()->ip();
        // $agent = new Agent();
        // $agent->setUserAgent(request()->userAgent());

        // $geo = $this->getGeoLocation($ip);
        // if (empty($geo)) {
        //     $geo = [
        //         'city' => null,
        //         'country' => null,
        //     ];
        // }
        // LoginHistory::create([
        //     'user_id' => $user->id,
        //     'ip_address' => $ip,
        //     'user_agent' => request()->userAgent(),
        //     'device' => $agent->device(),
        //     'platform' => $agent->platform(),
        //     'browser' => $agent->browser(),
        //     'city' => $geo['city'] ?? null,
        //     'country' => $geo['country'] ?? null,
        //     'login_at' => now(),
        // ]);

        // if ($user->suspicious_login_alert == 1) {
        //     $this->checkSuspiciousLogin($user, $ip, $agent, $geo);
        // }
    }

    protected function getGeoLocation($ip)
    {
        try {
            $response = Http::get("http://ip-api.com/json/{$ip}");
            return $response->successful() ? $response->json() : [];
        } catch (\Exception $e) {
            return [];
        }
    }

    protected function checkSuspiciousLogin($user, $ip, Agent $agent, array $geo)
    {
        $lastLogin = $user->loginHistories()
            ->where('id', '!=', $user->loginHistories()->latest()->first()->id)
            ->latest()
            ->first();

        $isNewDevice = $lastLogin && $lastLogin->user_agent !== request()->userAgent();
        $isUnusualLocation = $lastLogin && $geo['country'] && $lastLogin->country !== $geo['country'];

        if ($isNewDevice || $isUnusualLocation) {
            // Send notification
            $user->notify(new \App\Notifications\SuspiciousLoginNotification([
                'ip' => $ip,
                'device' => $agent->device(),
                'browser' => $agent->browser(),
                'city' => $geo['city'] ?? 'Unknown',
                'country' => $geo['country'] ?? 'Unknown',
                'login_at' => now(),
            ]));
        }
    }
}
