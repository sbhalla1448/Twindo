<!--[if BLOCK]><![endif]--><?php if($paginator->hasPages()): ?>

    <div class="flex justify-center items-center space-x-2 mt-6">
        <!--[if BLOCK]><![endif]--><?php if($paginator->onFirstPage()): ?>
            <button class="px-3 py-1 border rounded-md">Previous</button>
        <?php else: ?>
            <button class="px-3 py-1 border rounded-md">
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">Previous</a>
            </button>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->





        
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <!--[if BLOCK]><![endif]--><?php if(is_string($element)): ?>
                <button class="px-3 py-1 border rounded-md"><?php echo e($element); ?></button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            
            <!--[if BLOCK]><![endif]--><?php if(is_array($element)): ?>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!--[if BLOCK]><![endif]--><?php if($page == $paginator->currentPage()): ?>
                        <button class="px-3 py-1 border rounded-md bg-indigo-600 text-white"
                            aria-current="page"><?php echo e($page); ?></button>
                    <?php else: ?>
                        <button class="px-3 py-1 border rounded-md"><a
                                href="<?php echo e($url); ?>"><?php echo e($page); ?></a></button>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->


        
        <!--[if BLOCK]><![endif]--><?php if($paginator->hasMorePages()): ?>
            <button class="px-3 py-1 border rounded-md"><a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next"
                    aria-label="<?php echo app('translator')->get('pagination.next'); ?>">Next</a></button>
        <?php else: ?>
            <button class="px-3 py-1 border rounded-md">Next</button>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>

<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH I:\laragon\www\twindo\resources\views/vendor/pagination/product-pagination.blade.php ENDPATH**/ ?>