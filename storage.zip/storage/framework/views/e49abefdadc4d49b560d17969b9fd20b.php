<?php $__env->startSection('content'); ?>

<main class="flex-1 overflow-auto">
    <div class="max-w-7xl mx-auto px-6 py-10">
    <div class="flex justify-between items-center mb-6">
        <h1 class="text-2xl font-bold">Coupons</h1>
        <a href="<?php echo e(route('admin.coupons.create')); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            Add New Coupon
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-4" role="alert">
            <p><?php echo e(session('success')); ?></p>
        </div>
    <?php endif; ?>

    <table class="min-w-full bg-white border border-gray-300">
        <thead>
            <tr class="bg-gray-100">
                <th class="py-2 px-4 border-b">Code</th>
                <th class="py-2 px-4 border-b">Type</th>
                <th class="py-2 px-4 border-b">Value</th>
                <th class="py-2 px-4 border-b">Min Spend</th>
                <th class="py-2 px-4 border-b">Valid From</th>
                <th class="py-2 px-4 border-b">Valid To</th>
                <th class="py-2 px-4 border-b">Usage Limit</th>
                <th class="py-2 px-4 border-b">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50">
                    <td class="py-2 px-4 border-b"><?php echo e($coupon->code); ?></td>
                    <td class="py-2 px-4 border-b"><?php echo e(ucfirst($coupon->type)); ?></td>
                    <td class="py-2 px-4 border-b"><?php echo e($coupon->value); ?></td>
                    <td class="py-2 px-4 border-b"><?php echo e($coupon->min_spend ?? 'N/A'); ?></td>
                    <td class="py-2 px-4 border-b"><?php echo e($coupon->valid_from ? \Carbon\Carbon::parse($coupon->valid_from)->format('Y-m-d') : 'N/A'); ?></td>
                    <td class="py-2 px-4 border-b"><?php echo e($coupon->valid_to ? \Carbon\Carbon::parse($coupon->valid_to)->format('Y-m-d') : 'N/A'); ?></td>
                    <td class="py-2 px-4 border-b"><?php echo e($coupon->usage_limit); ?></td>
                    <td class="py-2 px-4 border-b">
                        <a href="<?php echo e(route('admin.coupons.edit', $coupon)); ?>" class="text-blue-500 hover:text-blue-700 mr-2">Edit</a>
                        <a href="<?php echo e(route('admin.coupons.show', $coupon)); ?>" class="text-blue-500 hover:text-blue-700 mr-2">Show</a>
                        <form action="<?php echo e(route('admin.coupons.destroy', $coupon)); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-500 hover:text-red-700">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="py-2 px-4 text-center text-gray-500">No coupons found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH I:\laragon\www\twindo\resources\views/backend/coupons/index.blade.php ENDPATH**/ ?>