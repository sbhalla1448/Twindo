<?php $__env->startSection('content'); ?>

<main class="flex-1 overflow-auto">
    <div class="max-w-2xl mx-auto px-6 py-10">

        <!-- Breadcrumb & Hero -->
        <section class="mb-8">
            <nav class="text-sm text-gray-500">Home / Admin / Users / Suspend John Smith</nav>
            <h2 class="text-3xl font-bold text-gray-800">Locked User</h2>
        </section>

        <!-- Suspend User Confirmation Card -->
        <section class="bg-white rounded-xl shadow p-8 text-center">
            <div class="mb-6">
                <div
                    class="h-20 w-20 mx-auto bg-yellow-100 rounded-full flex items-center justify-center text-yellow-600 text-3xl mb-4">
                    🔒</div>
                <h3 class="text-xl font-semibold text-gray-800 mb-2">Are you sure you want to temmporary locked John
                    Smith?</h3>
                <p class="text-sm text-gray-500">This will prevent the user from accessing their account until
                    manually reactivated.</p>
            </div>
            <div class="flex justify-center space-x-4">
                <?php if($user->id == Auth::user()->id): ?>
                <a href="<?php echo e(route('admin.users.index')); ?>">
                    <button
                    class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold px-6 py-3 rounded-xl">Cancel</button></a>
                <?php else: ?>
                <form action="<?php echo e(route('admin.user.status.change')); ?>"
                    method="POST" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="userId" value="<?php echo e($user->id); ?>">
                    <input type="hidden" name="status" value="3">
                <button  type="submit"
                    class="bg-yellow-500 hover:bg-yellow-600 text-white font-semibold px-6 py-3 rounded-xl">Confirm
                    Locked</button>
                </form>
                 <a href="<?php echo e(route('admin.users.index')); ?>">
                <button
                class="bg-gray-300 hover:bg-gray-400 text-gray-800 font-semibold px-6 py-3 rounded-xl">Cancel</button></a>
                <?php endif; ?>
            </div>
        </section>

    </div>
</main>

<!-- Main Content -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH I:\laragon\www\twindo\resources\views/backend/users/locked_user.blade.php ENDPATH**/ ?>