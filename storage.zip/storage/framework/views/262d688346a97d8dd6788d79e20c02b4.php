<main class="flex-1 overflow-auto">
    <div class="max-w-7xl mx-auto px-6 py-10">

      <!-- Breadcrumb & Hero -->
      <section class="mb-8">
        <nav class="text-sm text-gray-500">Home / Admin / Report Analysis</nav>
        <h2 class="text-3xl font-bold text-gray-800">Report Analysis</h2>
      </section>

      <!-- Filters, Search and Bulk Actions All on One Line -->
      <section class="bg-white rounded-xl shadow p-6 mb-6">
        <div class="flex flex-wrap items-center gap-4">
          <select class="border border-gray-300 rounded-md px-3 py-2" wire:model.change="userId">
            <option value="">All Customer</option>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

          </select>

          <input type="search" placeholder="Search..." class="w-48 border border-gray-300 rounded-md px-3 py-2" wire:model.live="search">
          
          
          <button  class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md"> <a href="<?php echo e(route('admin.tempateReports.create')); ?>">Create New Report</a> </button>
        </div>
      </section>

      <!-- Subscriptions Table -->
      <section class="bg-white rounded-xl shadow p-6">
        <table class="w-full text-left">
          <thead>
            <tr class="text-sm text-gray-400">
              
              <th class="py-2">Name</th>
              <th class="py-2">Title</th>
              <th class="py-2">Report Date</th>

              <th class="py-2">Actions</th>
            </tr>
          </thead>
          <tbody>

              <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <tr class="border-t">
              
              <td class="py-3"><?php echo e($report->user->name); ?></td>
              <td class="py-3"><?php echo e($report->title); ?></td>

              <td class="py-3"> <?php echo e($report->date->format('d M Y')); ?></td>

              <td class="py-3 space-x-2">
                <a href="<?php echo e(route('admin.tempateReports.edit',$report->id)); ?>" class="text-indigo-600">edit</a>
                <a href="<?php echo e(route('admin.tempateReports.show',$report->id)); ?>" target="_blank" class="text-yellow-500">view</a>
                <a href="#" class="text-red-600" wire:click="showModel(<?php echo e($report->id); ?>)">delete</a>
              </td>
            </tr>

           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tr>
          </tbody>
        </table>
      </section>

    </div>


    <!--[if BLOCK]><![endif]--><?php if($viewTools): ?>
    
<div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
  <!-- Modal Container -->
  <div class="bg-white rounded-lg shadow-xl w-full max-w-md">
      <!-- Modal Header -->
      <div class="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 class="text-lg font-semibold text-gray-900"> Delete Report activity?</h2>
          <button wire:click="closeDialog" class="text-gray-400 hover:text-gray-600 transition-colors">
              <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
              </svg>
          </button>
      </div>

      <!-- Modal Body -->
      <div class="p-6 space-y-4">
          <!-- Warning Alert -->
          <div class="bg-red-50 border border-red-200 rounded-md p-4">
              <div class="flex items-start">
                  <div class="flex-shrink-0">
                      <svg class="w-5 h-5 text-red-400 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                          <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"></path>
                      </svg>
                  </div>
                  <div class="ml-3">
                      <p class="text-sm text-red-800">
                          Are you sure that you want to delete "<?php echo e($report->title); ?>"?
                      </p>
                      <ul class="mt-2 text-sm text-red-700">
                          <li class="flex items-start">
                              <span class="inline-block w-1 h-1 bg-red-400 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                              Deleted activities cannot be restored.
                          </li>
                      </ul>
                  </div>
              </div>
          </div>

          <!-- Checkbox -->
          <div class="flex items-start">
              <input
                  type="checkbox"
                  id="understand"
                  class="mt-1 h-4 w-4 text-teal-600 border-gray-300 rounded focus:ring-teal-500"
                  checked
              >
              <label for="understand" class="ml-3 text-sm text-gray-700">
                  I understand that this action cannot be undone.
              </label>
          </div>
      </div>

      <!-- Modal Footer -->
      <div class="flex justify-end space-x-3 px-6 py-4 border-t border-gray-200">
          <button wire:click="closeDialog" class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition-colors">
              Cancel
          </button>
          <button wire:click="makeYes" class="px-4 py-2 text-sm font-medium text-white bg-teal-600 border border-transparent rounded-md hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition-colors">
              OK
          </button>
      </div>
  </div>
</div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
  </main><?php /**PATH I:\laragon\www\twindo\resources\views/livewire/report-analysis/report-analysis.blade.php ENDPATH**/ ?>