 <!-- Main Content -->
 <main class="flex-1 overflow-auto">
    <div class="max-w-7xl mx-auto px-6 py-10">

        <!-- Breadcrumb & Hero -->
        <section class="mb-8">
            <nav class="text-sm text-gray-500">Home / Admin / Products</nav>
            <div class="flex justify-between items-center">
                <h2 class="text-3xl font-bold text-gray-800">Products</h2>
                <a href="<?php echo e(route('admin.products.create')); ?>" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-xl">➕ Add New
                    Product</a>
            </div>
        </section>

        <!-- Filters and Search -->
        <section class="bg-white rounded-xl shadow p-6 mb-6">
            <div class="flex flex-wrap gap-4 items-center mb-4">
                <select  wire:model.change="status" class="border border-gray-300 rounded-md px-3 py-2">
                    <option>All Statuses</option>
                    <option value="1">Active</option>
                    <option value="0">Hidden</option>
                </select>
                <select  wire:model.change="categoryId" class="border border-gray-300 rounded-md px-3 py-2">
                    <option value="">All Categories</option>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($cat->id); ?> > <?php echo e($cat->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </select>
                <input type="search" placeholder="Search products..."
                    class="border border-gray-300 rounded-md px-3 py-2 flex-1" wire:model.live="search">
            </div>
        </section>

        <!-- Products Table with Bulk Actions -->
        <section class="bg-white rounded-xl shadow p-6" >
            <div class="mb-4 flex justify-between items-center">
                <div class="flex items-center space-x-2">
                    <select class="border border-gray-300 rounded-md px-3 py-2" wire:model="bulkAction">
                        <option value="">Bulk Actions</option>
                        <option value="delete">Delete Selected</option>
                        <option value="Feature">Feature Selected</option>
                        <option value="hidden">Hide Selected</option>
                    </select>
                    <button wire:click="applyBulkAction"
                        class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md">Apply</button>
                </div>
                <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                <div class="bg-green-100 text-green-800 p-4 mb-4 rounded">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['bulk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="bg-green-100 text-green-800 p-4 mb-4 rounded">
                    <?php echo e($message); ?>

                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

            <table class="w-full text-left">
                <thead>
                    <tr class="text-sm text-gray-400">
                        <th class="py-2 cursor-pointer">🔽</th>
                        <th class="py-2">Image</th>
                        <th class="py-2 cursor-pointer">Title 🔽</th>
                        <th class="py-2 cursor-pointer">Price (per month) 🔽</th>
                        <th class="py-2 cursor-pointer">Category 🔽</th>
                        <th class="py-2 cursor-pointer">Status 🔽</th>
                        <th class="py-2 cursor-pointer">Featured 🔽</th>
                        <th class="py-2">Actions</th>
                    </tr>
                </thead>
                <tbody>

                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <tr class="border-t">
                        <td class="py-3"><input type="checkbox" wire:model="bulkSelect" value="<?php echo e($product->id); ?>"></td>
                        <td class="py-3"><img width="50" height="50" src="<?php echo e(asset('images')); ?>/<?php echo e($product->image); ?>" alt="Product"
                                class="rounded"></td>
                        <td class="py-3"><?php echo e($product->title); ?></td>
                        <td class="py-3">£<?php echo e($product->price_per_month); ?> / month <br>
                            £<?php echo e($product->price_annual); ?> / year

                        </td>
                        <td class="py-3"><?php echo e($product->category?->name); ?></td>
                        <td class="py-3">
                            <button
                                class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-green-100 text-green-800"><?php echo e($product->status == 1 ? 'Active':'hidden'); ?></button>
                        </td>
                        <td class="py-3">
                            <button
                                class="inline-flex items-center px-2 py-1 rounded-full text-xs bg-yellow-100 text-yellow-800"><?php echo e($product->product_status); ?></button>
                        </td>
                        <td class="py-3 space-x-2">
                            <a href="<?php echo e(route('admin.products.edit',$product->id)); ?>" class="text-indigo-600">Edit</a>

                            <form action="<?php echo e(route('admin.products.destroy', $product->id)); ?>"
                                method="POST" style="display: inline;">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" onclick="return confirm('Are your sure?')"
                                    style="border: none">

                                    <span class="text-red-600">Delete</span>
                                </button>
                            </form>
                            
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                </tbody>
            </table>

            <!-- Pagination -->
                <?php echo e($products->links('vendor.pagination.product-pagination')); ?>


        </section>

    </div>
</main><?php /**PATH I:\laragon\www\twindo\resources\views/livewire/product/product-index.blade.php ENDPATH**/ ?>