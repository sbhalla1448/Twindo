   <main class="flex-1 overflow-auto">
      <div class="max-w-7xl mx-auto px-6 py-10">

        <!-- Breadcrumb & Hero -->
        <section class="mb-8">
          <nav class="text-sm text-gray-500">Home / Admin / Subscriptions</nav>
          <h2 class="text-3xl font-bold text-gray-800">Subscriptions</h2>
        </section>

        <!-- Filters, Search and Bulk Actions All on One Line -->
        <section class="bg-white rounded-xl shadow p-6 mb-6">
          <div class="flex flex-wrap items-center gap-4">
            <select class="border border-gray-300 rounded-md px-3 py-2" wire:model.change="status">
              <option value="">All Statuses</option>
              <option value="Active">Active</option>
              <option value="Paused">Paused</option>
              <option value="Expired">Expired</option>
              <option value="Cancelled">Cancelled</option>

            </select>
            <select class="border border-gray-300 rounded-md px-3 py-2" wire:model.change="plan">
              <option value="">All Plans</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $subplans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $splan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              <option value="<?php echo e($splan->id); ?>"><?php echo e($splan->name); ?></option>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
            <input type="search" placeholder="Search..." class="w-48 border border-gray-300 rounded-md px-3 py-2" wire:model.live="search">
            <select class="border border-gray-300 rounded-md px-3 py-2">
              <option>Bulk Actions</option>
              <option>Pause Selected</option>
              <option>Cancel Selected</option>
              <option>Delete Selected</option>
            </select>
            <button wire:click="" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md">Apply</button>
            <button wire:click="resetFilter" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md">Reset</button>
          </div>
        </section>

        <!-- Subscriptions Table -->
        <section class="bg-white rounded-xl shadow p-6">
          <table class="w-full text-left">
            <thead>
              <tr class="text-sm text-gray-400">
                <th class="py-2"><input type="checkbox" wire:click="$set('bulkSelect', <?php echo \Illuminate\Support\Js::from($subscriptions->pluck('id'))->toHtml() ?>)">
                </th>
                <th class="py-2">User</th>
                <th class="py-2">Plan</th>
                <th class="py-2">Status</th>
                <th class="py-2">Start Date</th>
                <th class="py-2">Next Billing</th>
                <th class="py-2">Actions</th>
              </tr>
            </thead>
            <tbody>

                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


              <tr class="border-t">
                <td class="py-3"><input type="checkbox" wire:model="bulkSelect" value="<?php echo e($subscription->id); ?>"></td>
                <td class="py-3"><?php echo e($subscription->user->name); ?></td>
                <td class="py-3"><?php echo e($subscription->plan->name); ?></td>
                <td class="py-3 text-green-500"><?php echo e($subscription->status); ?></td>
                <td class="py-3"> <?php echo e($subscription->start_date->format('d M Y')); ?></td>
                <td class="py-3"> <?php echo e($subscription->end_date->format('d M Y')); ?></td>
                <td class="py-3 space-x-2">
                  <a style="cursor: pointer" wire:click="viewModal(<?php echo e($subscription->id); ?>)" class="text-indigo-600">Manage</a>
                  <a style="cursor: pointer" wire:click="changeSubscriptionActitvity(<?php echo e($subscription->id); ?>,'Paused')" class="text-yellow-500">Pause</a>
                  <a style="cursor: pointer" wire:click="changeSubscriptionActitvity(<?php echo e($subscription->id); ?>,'Cancelled')" class="text-red-600">Cancel</a>
                </td>
              </tr>

             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
              </tr>
            </tbody>
          </table>
        </section>

      </div>

      <!--[if BLOCK]><![endif]--><?php if($viewTools): ?>

      <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
        <!-- Modal Container -->
        <div class="bg-white rounded-lg shadow-xl w-full max-w-md">
            <!-- Modal Header -->
            <div class="flex items-center justify-between p-6 border-b border-gray-200">
                <h2 class="text-lg font-semibold text-gray-900"> <?php echo e($selectSubscription->user->name); ?> Manage Subscription?</h2>
                <button wire:click="closeDialog" class="text-gray-400 hover:text-gray-600 transition-colors">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                    </svg>
                </button>
            </div>

            <!-- Modal Body -->
            <div class="p-6 space-y-4">
                <!-- Warning Alert -->
                <div class="bg-red-50 border border-red-200 rounded-md p-4">
                    <div class="flex items-start">


                        <div class="flex space-x-4">
                            <button wire:click="changeSubscriptionActitvity(<?php echo e($selectSubscription->id); ?>,  'Active')" class="bg-blue-500 hover:bg-blue-600 text-white font-semibold py-2 px-4 rounded">
                               Active
                            </button>
                            <button wire:click="changeSubscriptionActitvity(<?php echo e($selectSubscription->id); ?>,'Paused')" class="bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-4 rounded">
                                Paused
                            </button>
                            <button wire:click="changeSubscriptionActitvity(<?php echo e($selectSubscription->id); ?>,'Expired')" class="bg-yellow-500 hover:bg-yellow-600 text-white font-semibold py-2 px-4 rounded">
                                Expired
                            </button>
                            <button wire:click="changeSubscriptionActitvity(<?php echo e($selectSubscription->id); ?>,'Cancelled')" class="bg-red-500 hover:bg-red-600 text-white font-semibold py-2 px-4 rounded">
                               Cancelled
                            </button>
                        </div>


                    </div>
                </div>


            </div>

            <!-- Modal Footer -->
            <div class="flex justify-end space-x-3 px-6 py-4 border-t border-gray-200">
                <button wire:click="closeModal" class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition-colors">
                    Cancel
                </button>

            </div>
        </div>
    </div>
      <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    </main><?php /**PATH I:\laragon\www\twindo\resources\views/livewire/subscription/index.blade.php ENDPATH**/ ?>