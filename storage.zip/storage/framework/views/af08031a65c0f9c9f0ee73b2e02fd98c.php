<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH I:\laragon\www\twindo\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>