<?php $__env->startSection('content'); ?>


<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('system-log', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3431693396-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
<script>
    function openLogDetails(user, action, ip, timestamp) {
        document.getElementById('logUser').innerText = user;
        document.getElementById('logAction').innerText = action;
        document.getElementById('logIP').innerText = ip;
        document.getElementById('logTime').innerText = timestamp;
        document.getElementById('logModal').classList.remove('hidden');
    }

    function closeLogModal() {
        document.getElementById('logModal').classList.add('hidden');
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH I:\laragon\www\twindo\resources\views/backend/system_logs/index.blade.php ENDPATH**/ ?>