<?php $__env->startPush('css'); ?>
    <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(135deg, #e5f4ec, #ffffff);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-card {
            background: white;
            padding: 3rem;
            border-radius: 12px;
            box-shadow: 0 0 25px rgba(0, 0, 0, 0.08);
            width: 100%;
            max-width: 420px;
            text-align: center;
            margin-top: auto;
        }

        .login-card h2 {
            color: #004225;
            margin-bottom: 1rem;
        }

        .login-card p {
            color: #666;
            margin-bottom: 2rem;
            font-size: 0.95rem;
        }

        .form-group {
            text-align: left;
            margin-bottom: 1.5rem;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 0.5rem;
            color: #004225;
        }

        input[type="email"],
        input[type="password"] {
            width: 100%;
            padding: 0.75rem;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 1rem;
        }

        button {
            width: 100%;
            padding: 1rem;
            background-color: #00cc66;
            color: white;
            border: none;
            border-radius: 6px;
            font-size: 1rem;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #00994d;
        }

        .social-login {
            margin-top: 2rem;
        }

        .social-login button {
            background-color: #ffffff;
            color: #1a1a1a;
            border: 1px solid #ccc;
            margin: 0.5rem 0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .social-login img {
            width: 20px;
            height: 20px;
            margin-right: 10px;
        }

        .divider {
            margin: 2rem 0 1rem;
            font-size: 0.85rem;
            color: #999;
        }

        .login-footer {
            margin-top: 1.5rem;
            font-size: 0.9rem;
        }

        .login-footer a {
            color: #004225;
            text-decoration: none;
            font-weight: bold;
        }

        .social-icons {
            margin-top: 1.5rem;
        }

        .social-icons a {
            display: inline-block;
            margin: 0 8px;
        }

        .social-icons img {
            width: 24px;
            height: 24px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="justify-top flex h-full w-full flex-col justify-between overflow-auto">
        <div class="login-card">
            <h2>Welcome back to Twindo</h2>
            <p>Secure access to your credit dashboard</p>
            <?php if(session('error')): ?>
    <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
        <span class="block sm:inline"><?php echo e(session('error')); ?></span>
    </div>
<?php endif; ?>

            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>"
                        placeholder="you@twindo.co.uk" required>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="••••••••" required>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
                <button type="submit">Login</button>
            </form>

            <div class="divider">or sign in with</div>

            <div class="social-login">
                <button><img src="https://cdn-icons-png.flaticon.com/512/2702/2702602.png" alt="Google">
                    <a href="<?php echo e(route('social.redirect', 'google')); ?>">Continue with Google</a> </button>
                <button><img src="https://cdn-icons-png.flaticon.com/512/179/179309.png" alt="Apple">
                    <a href="<?php echo e(route('social.redirect', 'apple')); ?>">Continue with Apple
                        ID</a> </button>
            </div>

            <div class="login-footer">
                <p><a href="<?php echo e(route('password.request')); ?>">Forgot your password?</a></p>
                <p>Don't have an account? <a href="<?php echo e(route('sign.up')); ?>">Create one</a></p>
            </div>

            <div class="social-icons">
                <a href="<?php echo e(route('social.redirect', 'facebook')); ?>"><img
                        src="https://cdn-icons-png.flaticon.com/512/733/733547.png" alt="Facebook"></a>
                <a href="<?php echo e(route('social.redirect', 'twitter')); ?>"><img
                        src="https://cdn-icons-png.flaticon.com/512/733/733579.png" alt="Twitter"></a>
                <a href="<?php echo e(route('social.redirect', 'instagram')); ?>"><img
                        src="https://cdn-icons-png.flaticon.com/512/733/733558.png" alt="Instagram"></a>
                <a href="<?php echo e(route('social.redirect', 'google')); ?>"><img
                        src="https://cdn-icons-png.flaticon.com/512/1384/1384060.png" alt="LinkedIn"></a>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH I:\laragon\www\twindo\resources\views/auth/login.blade.php ENDPATH**/ ?>