 
<?php $__env->startSection('content'); ?>
    <main class="flex-1 overflow-auto">
        <div class="max-w-4xl mx-auto px-6 py-10">
            <!-- Breadcrumb & Hero -->
            <section class="mb-8">
                <nav class="text-sm text-gray-500">Home / Admin / Users / Manage User</nav>
                <h2 class="text-3xl font-bold text-gray-800">Manage User: <?php echo e($user->name); ?></h2>
            </section>
            <!-- Manage Profile -->
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('user.manage-user', ['user' => $user]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3193517136-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <!-- Spacer -->
            <section class="mt-8"></section>
            <!-- Security Settings -->
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('user.security-settings', ['user' => $user]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3193517136-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <!-- Spacer -->
            <section class="mt-8"></section>

            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('user.address-management', ['user' => $user]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3193517136-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <!-- Spacer -->
            <section class="mt-8"></section>

            <!-- Email Template Trigger -->
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('user.send-email-to-user', ['user' => $user]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3193517136-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <!-- Spacer -->
            <section class="mt-8"></section>
            <!-- Account Manager Card -->
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('user.account-mangager', ['user' => $user]);

$__html = app('livewire')->mount($__name, $__params, 'lw-3193517136-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <!-- Security Actions Card -->
            <section class="bg-white rounded-xl shadow p-6 mb-10">
                <h3 class="text-lg font-semibold text-gray-800 mb-4">🔐 Security Actions</h3>
                <p class="text-sm text-gray-600 mb-6">Manage sensitive account-level operations with care. Use the
                    options below to update security status for this user.</p>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div class="bg-gray-50 rounded-lg p-4 shadow-sm">
                        <h4 class="text-sm font-medium text-gray-800 mb-2">🔄 Reset Password</h4>
                        <p class="text-xs text-gray-600 mb-3">Force the user to reset their login credentials.</p>
                        <a
                            href="<?php echo e(route('admin.user.reset.credential', \Illuminate\Support\Facades\Crypt::encryptString($user->id))); ?>">
                            <button class="bg-red-100 text-red-700 px-3 py-1 rounded text-sm hover:bg-red-200 w-full"
                                onclick="confirmAction('Reset Password')">Reset</button> </a>
                    </div>
                    <div class="bg-gray-50 rounded-lg p-4 shadow-sm">
                        <h4 class="text-sm font-medium text-gray-800 mb-2">⏸️ Suspend Account</h4>
                        <p class="text-xs text-gray-600 mb-3">Temporarily deactivate this user's access.</p>
                        <a
                            href="<?php echo e(route('admin.user.suspend', \Illuminate\Support\Facades\Crypt::encryptString($user->id))); ?>">
                            <button
                                class="bg-yellow-100 text-yellow-700 px-3 py-1 rounded text-sm hover:bg-yellow-200 w-full"
                                onclick="confirmAction('Suspend Account')">Suspend</button> </a>
                    </div>
                    <div class="bg-gray-50 rounded-lg p-4 shadow-sm">
                        <h4 class="text-sm font-medium text-gray-800 mb-2">✅ Reactivate Account</h4>
                        <p class="text-xs text-gray-600 mb-3">Re-enable login for a previously suspended user.</p>
                        <a
                            href="<?php echo e(route('admin.user.reactive', \Illuminate\Support\Facades\Crypt::encryptString($user->id))); ?>">
                            <button class="bg-green-100 text-green-700 px-3 py-1 rounded text-sm hover:bg-green-200 w-full"
                                onclick="confirmAction('Reactivate Account')">Reactivate</button></a>
                    </div>
                    <div class="bg-gray-50 rounded-lg p-4 shadow-sm">
                        <h4 class="text-sm font-medium text-gray-800 mb-2">🗑️ Delete User</h4>
                        <p class="text-xs text-gray-600 mb-3">Permanently remove this user and their data.</p>
                        <a
                            href="<?php echo e(route('admin.user.delete', \Illuminate\Support\Facades\Crypt::encryptString($user->id))); ?>">
                            <button
                                class="bg-gray-200 text-gray-800 px-3 py-1 rounded text-sm hover:bg-gray-300 w-full">Delete</button></a>
                    </div>
                    <div class="bg-gray-50 rounded-lg p-4 shadow-sm">
                        <h4 class="text-sm font-medium text-gray-800 mb-2">🔍 View Login History</h4>
                        <p class="text-xs text-gray-600 mb-3">Review the last 3 logins from devices, IPs, and
                            timestamps.</p>
                        <a href="<?php echo e(route('admin.login.history', $user->id)); ?>">
                            <button class="bg-blue-100 text-blue-700 px-3 py-1 rounded text-sm hover:bg-blue-200 w-full"
                                onclick="confirmAction('View Login History')">View</button>
                        </a>
                    </div>
                    <div class="bg-gray-50 rounded-lg p-4 shadow-sm">
                        <h4 class="text-sm font-medium text-gray-800 mb-2">🔐 Temporarily Lock Account</h4>
                        <p class="text-xs text-gray-600 mb-3">Prevent access until manually reactivated or unlocked.
                        </p>
                        <a
                            href="<?php echo e(route('admin.user.locked', \Illuminate\Support\Facades\Crypt::encryptString($user->id))); ?>">
                            <button
                                class="bg-purple-100 text-purple-700 px-3 py-1 rounded text-sm hover:bg-purple-200 w-full"
                                onclick="confirmAction('Temporarily Lock Account')">Lock</button></a>
                    </div>
                </div>
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH I:\laragon\www\twindo\resources\views/backend/users/manage_user.blade.php ENDPATH**/ ?>