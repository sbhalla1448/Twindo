<?php $__env->startSection('content'); ?>
<main class="flex-1 overflow-auto">
    <div class="max-w-7xl mx-auto px-6 py-10">
      <section class="bg-white rounded-xl shadow p-8 mb-8">
        <h3 class="text-2xl font-bold text-gray-800 mb-2">📄 Upload & Manage Your Documents</h3>
        <p class="text-gray-500 mb-6">Securely upload your identity verification documents, proof of address, and credit report for your credit repair journey.</p>
        <div class="border-t border-gray-200 mb-8"></div>

        <div class="mb-8">
          <h4 class="text-lg font-semibold text-gray-700 mb-2">Recommended Documents to Upload <span class="tooltip">ℹ️<span class="tooltiptext">PDF, JPG, or PNG only. Max 5MB.</span></span></h4>
          <ul class="list-disc list-inside text-gray-600">
            <li>Proof of ID: Passport, Driver’s Licence or National ID card</li>
            <li>Proof of Address: Utility Bill, Council Tax Bill, or Bank Statement (within 3 months)</li>
            <li>Credit Report: Experian, Equifax or TransUnion (PDF or screenshot)</li>
          </ul>
        </div>

        <div class="mb-8">
          <h4 class="text-lg font-semibold text-gray-700 mb-2">Next Steps</h4>
          <ul class="list-disc list-inside text-gray-600">
            <li>Use the upload form below to send your documents securely to the Twindo team.</li>
            <li>Each document will be reviewed and marked as Verified or Needs Resubmission.</li>
            <li>Once approved, the document status will update and you’ll be notified via email.</li>
          </ul>
        </div>
    <form action="<?php echo e(route('document.upload')); ?>" method="POST" enctype="multipart/form-data" onsubmit="simulateUpload(event)">
        <?php echo csrf_field(); ?>
        <div>
            <label class="block text-sm font-medium text-gray-700">Document Type</label>
            <select name="document_type"
                class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm px-4 py-2 focus:ring-indigo-500 focus:border-indigo-500">
                <option value="">Select Document Type</option>
                <?php $__currentLoopData = \App\Enums\DocumentType::options(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status->value); ?>">
                        <?php echo e($status->label()); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['document_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700">Document Name</label>
            <input type="text" name="document_name"
                class="mt-1 block w-full border border-gray-300 rounded-md shadow-sm px-4 py-2 focus:ring-indigo-500 focus:border-indigo-500">
            <?php $__errorArgs = ['document_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <br>

        <div>
            <label class="block text-sm font-medium text-gray-700">Upload Files</label>
            <div
                class="mt-2 flex flex-col items-center justify-center px-6 pt-5 pb-6 border-2 border-dashed border-gray-300 rounded-md text-center">
                <svg class="mx-auto h-10 w-10 text-gray-400" fill="none" stroke="currentColor"
                    viewBox="0 0 48 48">
                    <path d="M14 22l10-10 10 10m-10-10v20M5 38h38" stroke-width="2" stroke-linecap="round"
                        stroke-linejoin="round" />
                </svg>
                <label class="mt-2 text-sm text-indigo-600 font-medium cursor-pointer hover:underline">
                    <span>Upload files</span>
                    <input name="file_names[]" type="file" class="sr-only" multiple
                        onchange="updateFileName(event)">
                </label>
                <p class="text-xs text-gray-500 mt-1">PNG, JPG, PDF up to 10MB each</p>
                <p id="fileNameDisplay" class="text-sm text-gray-700 mt-2"></p>
            </div>
            <?php $__errorArgs = ['file_names'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div id="uploadProgressBar" class="hidden w-full bg-gray-200 rounded-full h-4 mt-4">
            <div class="bg-indigo-600 h-4 rounded-full transition-all duration-300" style="width: 0%"></div>
        </div>

       

        <div id="cancelUploadButton" class="hidden flex justify-end mt-2">
            <button type="button" onclick="cancelUpload()"
                class="text-red-600 hover:text-red-800 font-semibold text-sm">Cancel Upload</button>
        </div>
        <br>
        <div class="flex justify-end">
            <button type="submit"
                class="bg-indigo-600 text-white px-6 py-2 rounded-md hover:bg-indigo-700 transition-all">Upload
                Document</button>
        </div>
    </form>

        <div class="mt-8">
          <h4 class="text-lg font-semibold text-gray-700 mb-4">Uploaded Documents</h4>
          <table class="w-full text-sm text-left text-gray-500">
            <thead class="text-xs text-gray-700 uppercase bg-gray-100">
              <tr>
                <th class="px-6 py-3">Document Type</th>
                <th class="px-6 py-3">Uploaded On</th>
                <th class="px-6 py-3">Status</th>
                <th class="px-6 py-3">Action</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


              <tr class="bg-white border-b">
                <td class="px-6 py-4"><?php echo e($doc->document_type); ?> <?php echo e($doc->id); ?></td>
                <td class="px-6 py-4"><?php echo e($doc->created_at->format('d M Y')); ?></td>
                <td class="px-6 py-4 text-green-600 font-medium"><?php echo e($doc->approved_status==1 ? '✅ Verified':'⏳ Pending'); ?></td>
                <td class="px-6 py-4 text-indigo-600 hover:underline cursor-pointer view-link" data-id="<?php echo e($doc->id); ?>">View</td>
              </tr>




              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
          </table>
        </div>
      </section>
<!-- Modal for Document Preview -->
<div id="viewModal" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-lg p-8 shadow-lg max-w-5xl w-full max-h-screen overflow-auto">
        <h3 class="text-lg font-bold text-gray-800 mb-4">📄 Document Preview</h3>
        <div id="modal-carousel" class="mb-4 space-y-4 flex justify-center items-center">
            <!-- File preview will be injected here -->
        </div>
        <div class="flex justify-between">
            
            
            <a id="downloadLink" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 cursor-pointer" download>Download</a>
            <button id="closeModal" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600">Close</button>
        </div>
    </div>
</div>
    </div>
  </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<style>
    .tooltip {
      position: relative;
      display: inline-block;
    }
    .tooltip .tooltiptext {
      visibility: hidden;
      width: 200px;
      background-color: #4b5563;
      color: #fff;
      text-align: center;
      border-radius: 6px;
      padding: 6px;
      position: absolute;
      z-index: 1;
      bottom: 125%;
      left: 50%;
      transform: translateX(-50%);
      opacity: 0;
      transition: opacity 0.3s;
    }
    .tooltip:hover .tooltiptext {
      visibility: visible;
      opacity: 1;
    }
  </style>
   <script>
    let uploadInterval;

    function showToast(message = '✅ Document uploaded successfully!') {
        const toast = document.getElementById('successToast');
        toast.innerText = message;
        toast.classList.remove('hidden');
        setTimeout(() => toast.classList.add('hidden'), 3000);
    }

    function updateFileName(event) {
        const files = Array.from(event.target.files).map(f => f.name).join(', ');
        const fileLabel = document.getElementById('fileNameDisplay');
        fileLabel.innerText = files ? `Selected Files: ${files}` : '';
    }

    function simulateUpload(event) {
        event.preventDefault(); // Prevent immediate form submission

        const progressBar = document.getElementById('uploadProgressBar');
        const cancelButton = document.getElementById('cancelUploadButton');
        const form = event.target;

        progressBar.classList.remove('hidden');
        cancelButton.classList.remove('hidden');

        let width = 1;
        uploadInterval = setInterval(() => {
            if (width >= 100) {
                clearInterval(uploadInterval);
                progressBar.classList.add('hidden');
                cancelButton.classList.add('hidden');
                progressBar.firstElementChild.style.width = '0%';

                // Now submit the form after simulation completes
                form.submit();
            } else {
                width++;
                progressBar.firstElementChild.style.width = width + '%';
            }
        }, 20); // Simulate faster upload
    }

    function cancelUpload() {
        clearInterval(uploadInterval);
        const progressBar = document.getElementById('uploadProgressBar');
        const cancelButton = document.getElementById('cancelUploadButton');
        progressBar.classList.add('hidden');
        cancelButton.classList.add('hidden');
        progressBar.firstElementChild.style.width = '0%';
    }
</script>

<script>
    document.querySelectorAll('.view-link').forEach(link => {
        link.addEventListener('click', async function () {
            const docId = this.getAttribute('data-id');

            try {
                const response = await fetch(`/account/documents/${docId}/files`);
                const files = await response.json();

                const carousel = document.getElementById('modal-carousel');
                carousel.innerHTML = ''; // Clear previous content

            files.forEach(file => {
    const ext = file.file_name.split('.').pop().toLowerCase();
    let preview;

    if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext)) {
        preview = `<img src="/storage/uploads/${file.file_name}" class="max-w-full h-auto" alt="Document Image">`;
    } else if (ext === 'pdf') {
        preview = `<iframe src="/storage/uploads/${file.file_name}" class="w-full h-[600px]"></iframe>`;
    } else {
        preview = `<p>Unsupported file type: ${file.file_name}</p>`;
    }

    carousel.innerHTML += `<div>${preview}</div>`;
});

// Set the first file as download target
if (files.length > 0) {
    document.getElementById('downloadLink').href = `/storage/uploads/${files[0].file_name}`;
}




                document.getElementById('viewModal').classList.remove('hidden');

            } catch (error) {
                console.error('Error fetching files:', error);
            }
        });
    });

    document.getElementById('closeModal').addEventListener('click', () => {
        document.getElementById('viewModal').classList.add('hidden');
    });
    </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('customer.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH I:\laragon\www\twindo\resources\views/customer/my_document.blade.php ENDPATH**/ ?>