<?php echo e($slot); ?>

<?php /**PATH I:\laragon\www\twindo\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>