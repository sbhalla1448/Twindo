<div class="bg-white p-6 rounded-xl shadow">
    <h3 class="text-lg font-semibold text-gray-800 mb-2">🧩 Quick Actions</h3>
    <div class="space-y-2">
        <button wire:click="viewEmailBlast" class="w-full bg-indigo-100 text-indigo-800 py-2 rounded text-sm hover:bg-indigo-200">📤
            Send Email Blast</button>
        <button class="w-full bg-green-100 text-green-800 py-2 rounded text-sm hover:bg-green-200">
            <a  href="<?php echo e(route('admin.users.create')); ?>">
            ➕
            Add New User </a></button>
        <button wire:click="viewModal" class="w-full bg-yellow-100 text-yellow-800 py-2 rounded text-sm hover:bg-yellow-200">⚠️
            Flagged Accounts</button>
    </div>



    <!--[if BLOCK]><![endif]--><?php if($modalShow): ?>

<div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
    <!-- Modal Container -->
    <div class="bg-white rounded-lg shadow-xl w-full max-w-md relative">
     <!-- Close Button -->
     <button wire:click="$set('modalShow', false)"
     class="absolute top-2 right-2 text-gray-500 hover:text-red-600 text-xl font-bold focus:outline-none">
 &times;
</button>

<h2 class="text-lg font-semibold mb-4">User List</h2>
        <table class="min-w-full table-auto border border-gray-200">
            <thead class="bg-gray-100 text-left text-sm font-semibold text-gray-700">
                <tr>
                    <th class="p-3">ID</th>
                    <th class="p-3">Name</th>
                    <th class="p-3">Email</th>
                    <th class="p-3">Last Login</th>
                    <th class="p-3">Flagged Account</th>
                </tr>
            </thead>
            <tbody class="text-sm divide-y divide-gray-100">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-gray-50">
                        <td class="p-3"><?php echo e(($users->currentPage() - 1) * $users->perPage() + $index + 1); ?></td>
                        <td class="p-3"><?php echo e($user->name); ?></td>
                        <td class="p-3"><?php echo e($user->email); ?></td>
                        <td class="p-3"><?php echo e($user->last_login_at ?? 'N/A'); ?></td>
                        <td class="p-3">
                            <label class="inline-flex items-center cursor-pointer">
                                <input type="checkbox"
                                       class="sr-only peer"
                                       wire:click="toggleFlag(<?php echo e($user->id); ?>)"
                                       <?php echo e($user->flaged_account ? 'checked' : ''); ?>>
                                <div class="w-11 h-6 bg-gray-200 rounded-full peer peer-checked:bg-blue-600 relative transition-all duration-300">
                                    <div class="absolute left-1 top-1 bg-white w-4 h-4 rounded-full shadow-md transform peer-checked:translate-x-5 transition"></div>
                                </div>
                            </label>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </tbody>
        </table>
        <div class="flex justify-between items-center mt-4">
            <?php echo e($users->links('vendor.pagination.message-action-pagination')); ?>


         </div>
    </div>
  </div>





  <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

<!--[if BLOCK]><![endif]--><?php if($modalBlashShow): ?>

<div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
    <div class="bg-white rounded-lg shadow-xl w-full max-w-md relative">
    <h3 class="text-lg font-semibold text-gray-800 mb-4">📧 Send Email to User</h3>
    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
    <div class="mb-4 text-green-600 text-sm font-medium">
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <?php if(session()->has('error')): ?>
    <div class="mb-4 text-green-600 text-sm font-medium">
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <form  wire:submit="sendEmail" class="space-y-4" enctype="multipart/form-data">
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Select User</label>
            <select wire:model="userID" class="w-full border rounded p-2 text-sm">
                <option value="all">All User</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $useremails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($us->id); ?>"><?php echo e($us->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Subject</label>
            <input type="text" wire:model="subject" class="block w-full text-sm text-gray-700" >
        </div>

        <div class="grid md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">CC</label>
                <input type="email" wire:model="cc" class="w-full border rounded p-2 text-sm" placeholder="cc@example.com">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">BCC</label>
                <input type="email"  wire:model="bcc"  class="w-full border rounded p-2 text-sm" placeholder="bcc@example.com">
            </div>
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Attachments</label>
            <input type="file" wire:model="attachment"
                class="block w-full text-sm text-gray-700 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Message Preview</label>
            <textarea wire:model="mailBody"  rows="6" class="w-full border rounded p-2 text-sm" placeholder="Message preview...">



</textarea>
            <p class="mt-1 text-xs text-gray-500 italic">You can preview the final version of this email
                before sending.</p>
        </div>
        <div class="text-right">
            <?php if(session()->has('error')): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <?php if(session()->has('template_message')): ?>
        <div class="bg-blue-100 border border-blue-400 text-blue-700 px-4 py-3 rounded mb-4">
            <?php echo e(session('template_message')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <button wire:click="viewEmailBlastClose" type="button" class="text-sm text-indigo-600 hover:underline mr-4">x Close</button>
            <button wire:click="previewEmail" type="button" class="text-sm text-indigo-600 hover:underline mr-4">👁️ Preview
                Email</button>
                <div wire:loading>

                    <svg aria-hidden="true"
                        class="inline w-8 h-8 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600"
                        viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                            fill="currentColor" />
                        <path
                            d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                            fill="currentFill" />
                    </svg>

                </div>
            <button type="submit"
                class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm">📤
                Send Email</button>
        </div>
    </form>

    <!--[if BLOCK]><![endif]--><?php if($showPreview): ?>
        <div class="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
            <div class="bg-white rounded-lg shadow-lg p-6 w-full max-w-2xl max-h-[80vh] overflow-y-auto">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-xl font-semibold">Email Preview</h2>
                    <button wire:click="closePreview" class="text-gray-500 hover:text-gray-700">&times;</button>
                </div>
                <div class="prose">
                    <?php echo $previewContent; ?>

                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    </div>
</div>

<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div><?php /**PATH I:\laragon\www\twindo\resources\views/livewire/quick-action.blade.php ENDPATH**/ ?>