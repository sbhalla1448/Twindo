<?php $__env->startSection('content'); ?>

<main class="flex-1 overflow-auto">
    <div class="max-w-7xl mx-auto px-6 py-10">

      <section class="bg-white rounded-xl shadow p-8 mb-8">
        <h3 class="text-2xl font-bold text-gray-800 mb-2">📈 Analysis Report</h3>

        <div class="border-t border-gray-200 mb-8"></div>

          

   <!-- Upcoming Tasks -->
   <div class="bg-white p-8 rounded-xl shadow">
    <h3 class="text-2xl font-bold text-indigo-700 mb-4">Analysis Reports (<?php echo e(count($reports)); ?>)</h3>
    <div class="overflow-x-auto">
      <table class="min-w-full text-sm">
        <thead class="bg-gray-100 text-gray-700">
          <tr>
            <th class="py-3 px-4 text-left">Title</th>
            <th class="py-3 px-4 text-left">Date</th>

            <th class="py-3 px-4 text-left">Action</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-200">
            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


          <tr>
            <td class="py-3 px-4"><?php echo e($report->title); ?></td>

            <td class="py-3 px-4"><?php echo e($report->date->format('d M Y')); ?></td>

            <td class="py-3 px-4"><a href="<?php echo e(route('report.analysis.show',$report->id)); ?>" target="_blank"  class="text-indigo-600 hover:underline">View</a></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>


      </section>

    </div>
         <!-- View Resource Modal -->

  </main>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH I:\laragon\www\twindo\resources\views/customer/analysis_report/analysis_report.blade.php ENDPATH**/ ?>