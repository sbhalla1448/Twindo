<?php $__env->startSection('content'); ?>
    <div class="alert alert-danger">
        <h2>Payment Failed</h2>
        <p><?php echo e($message); ?></p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.payment.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH I:\laragon\www\twindo\resources\views/customer/payment/failed.blade.php ENDPATH**/ ?>