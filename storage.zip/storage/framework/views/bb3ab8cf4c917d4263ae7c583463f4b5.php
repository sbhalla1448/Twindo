  <main class="flex-1 overflow-auto">
      <div class="max-w-7xl mx-auto px-6 py-10">

          <!-- Breadcrumb & Hero -->
          <section class="mb-8">
              <nav class="text-sm text-gray-500">Home / Admin / Messages & Actions</nav>
              <h2 class="text-3xl font-bold text-gray-800">Messages & Actions</h2>
          </section>

          <!-- Search, Filters, and Actions -->
          <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-6 space-y-4 md:space-y-0">


              <div class="flex space-x-4">
                  <input type="search" placeholder="Search Messages..." class="border px-4 py-2 rounded-lg w-64" wire:model.live="search">
                  <select class="border px-4 py-2 rounded-lg" wire:model.change="filter">
                      <option value="">Filter by Status</option>
                      <option value="0">Pending</option>
                      <option value="1">Completed</option>
                      <option value="deleted">Deleted</option>
                  </select>
                  <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['bulk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <p>
                          <?php echo e($message); ?>

                      </p>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                  <!--[if BLOCK]><![endif]--><?php if(session('message')): ?>
                      <p>
                          <?php echo e(session('message')); ?>

                      </p>
                  <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
              </div>
              <div class="flex flex-wrap gap-2 items-center">
                  <span id="selectedCountBadge" class="text-sm text-gray-600"><?php echo e(count($bulkSelect)); ?> Selected</span>
                  <button wire:click="applyBulkAction('markAsDone')"
                      class="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600">✔️ Mark Done</button>
                  <button wire:click="applyBulkAction('delete')"
                      class="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-600">🗑️ Delete</button>
                  <button class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700"><a
                          href="<?php echo e(route('admin.messageActions.create')); ?>">➕ Compose</a></button>
              </div>
          </div>

          <!-- Messages List -->
          <section class="bg-white rounded-xl shadow p-6">
              <table class="w-full text-left">
                  <thead>
                      <tr class="text-sm text-gray-400">
                          <th class="py-2"><input type="checkbox"
                                  wire:click="$set('bulkSelect', <?php echo \Illuminate\Support\Js::from($messages->pluck('id'))->toHtml() ?>)"></th>
                          <th class="py-2">From</th>
                          <th class="py-2">Subject</th>
                          <th class="py-2">Received/Created</th>
                          <th class="py-2">Status</th>
                          <th class="py-2">Actions</th>
                          <th class="py-2">Notification</th>
                      </tr>
                  </thead>
                  <tbody>

                      <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr class="border-t hover:bg-gray-50">
                              <td class="py-3"><input type="checkbox" wire:model="bulkSelect"
                                      value="<?php echo e($message->id); ?>">
                              </td>
                              <td class="py-3"><?php echo e($message->user->name); ?></td>
                              <td class="py-3"><?php echo e($message->subject); ?></td>
                              <td class="py-3"><?php echo e($message->created_at->format('d M Y')); ?></td>
                              <td class="py-3 text-yellow-500">
                                <!--[if BLOCK]><![endif]--><?php if($message->draft_status == 1 ): ?>
                                    Draft
                                <?php else: ?>
                                <?php echo e($message->status == 0 ? 'Pending' : 'Completed'); ?>

                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                              </td>
                              <td class="py-3 flex space-x-2">
                                  <button  class="text-indigo-600"
                                  wire:click="viewMessage(<?php echo e($message->id); ?>)" style="cursor: pointer;">View</button>
                                  <!--[if BLOCK]><![endif]--><?php if($message->done_status == 0): ?>
                                      <a href="#" class="text-green-600">Mark Done</a>
                                  <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                  <!--[if BLOCK]><![endif]--><?php if($message->deleted_at != null): ?>
                                      <a href="#" class="text-red-500"
                                          wire:click="restoreMessage(<?php echo e($message->id); ?>)">Restore</a>
                                  <?php else: ?>
                                      <a href="#" class="text-red-500"
                                          wire:click="deleteMessage(<?php echo e($message->id); ?>)">Delete</a>
                                  <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                              </td>
                              <td class="py-3 flex space-x-2">
                                <td class="py-3">
                                    
                                    <?php echo e($message?->latestMessage); ?>

                                    
                                </td>
                              </td>
                          </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                  </tbody>
              </table>
          </section>

          <!-- Pagination -->
          

          <?php echo e($messages->links('vendor.pagination.message-action-admin-pagination')); ?>


      </div>

      <!--[if BLOCK]><![endif]--><?php if($viewmsg == true): ?>
      <!-- Message Thread -->
      <div class="bg-white p-6 rounded-xl shadow space-y-6">
        <h3 class="text-2xl font-bold text-indigo-700 mb-2">Message Thread</h3>
        <div class="space-y-4">
          <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $usermessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="p-4 bg-gray-50 border rounded-lg text-sm">
              <!--[if BLOCK]><![endif]--><?php if($msg->admin_id != null): ?>
              <strong class="text-indigo-700">Twindo Team</strong> <span class="text-gray-400 text-xs">(<?php echo e($msg->created_at->format('d M Y')); ?> - <?php echo e($msg->created_at->format('h:i A')); ?>)</span>
              <?php else: ?>
              <strong class="text-indigo-700"><?php echo e($msg->user->name); ?></strong> <span class="text-gray-400 text-xs">(<?php echo e($msg->created_at->format('d M Y')); ?> - <?php echo e($msg->created_at->format('h:i A')); ?>)</span>
              <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
              <p class="mt-1 text-gray-700"><?php echo e($msg->message); ?></p>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

          
          
        </div>
        <div class="flex justify-between mt-4">
              <?php echo e($usermessages->links('vendor.pagination.message-action-pagination')); ?>

        </div>
        <form class="space-y-4 mt-6" wire:submit="replyMessageSubmit">

          <label for="reply" class="text-gray-700 text-sm font-semibold">✏️ Write a Reply</label>
          <textarea wire:model="replyMessage" id="reply" class="w-full border-2 border-gray-300 rounded-lg p-3 text-sm bg-gray-50" rows="3" placeholder="Write your reply here..."></textarea>
              <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['replyMessage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span><?php echo e($message); ?></span>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
          <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center bg-white" style="position: relative;">
            <p class="text-gray-500">Drag & drop a file here or click to upload</p>
            <input type="file" class="opacity-0 absolute inset-0 cursor-pointer" wire:model="uploadFile">
          </div>
          <div class="flex justify-end">
            <button type="submit"  class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-2 rounded-lg">Post Reply</button>
          </div>
        </form>
      </div>
  <?php endif; ?><!--[if ENDBLOCK]><![endif]-->



  </main>
<?php /**PATH I:\laragon\www\twindo\resources\views/livewire/message/message-index.blade.php ENDPATH**/ ?>