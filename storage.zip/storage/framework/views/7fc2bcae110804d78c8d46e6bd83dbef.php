<section class="bg-white rounded-xl shadow p-6 mb-8">
                <h3 class="text-xl font-semibold text-gray-800 mb-4">Last 6 Activities</h3>
                <table class="w-full text-left">
                    <thead>
                        <tr class="text-sm text-gray-400">
                            <th class="py-2">Name</th>
                            <th class="py-2">Email</th>
                            <th class="py-2">Plan</th>
                            <th class="py-2">Status</th>
                            <th class="py-2">Score</th>
                            <th class="py-2">Last Login</th>
                            <th class="py-2 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $userLastActivities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userlast): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <tr class="border-t">
                            <td class="py-3"><?php echo e($userlast->name); ?></td>
                            <td class="py-3"><?php echo e($userlast->email); ?></td>
                            <td class="py-3"><?php echo e($userlast->plan->name ?? ''); ?></td>
                            <td class="py-3 text-green-600"><?php echo e($userlast->status_label); ?></td>
                            <td class="py-3"><?php echo e($userlast->score->score ?? ''); ?></td>
                            <td class="py-3">
                                <!--[if BLOCK]><![endif]--><?php if(!empty($userlast->last_login_at)): ?>
                                <?php echo e($userlast->last_login_at ?->format('d M Y')); ?>

                                <?php else: ?>

                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </td>
                            <td class="py-3 text-right space-x-2">
                                <a style="cursor: pointer" wire:click="modalview(<?php echo e($userlast->id); ?>)" class="text-indigo-600 hover:underline">View</a>
                                <a style="cursor: pointer" wire:click="viewMessage(<?php echo e($userlast->id); ?>)"  class="text-blue-600 hover:underline">Message</a>
                                <a style="cursor: pointer" wire:click="viewActive(<?php echo e($userlast->id); ?>)" class="text-red-600 hover:underline">Deactivate</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                    </tbody>
                </table>
                <div class="flex justify-between items-center mt-4">
                    
                     <?php echo e($userLastActivities->links('vendor.pagination.message-action-pagination')); ?>

                </div>

                <!--[if BLOCK]><![endif]--><?php if($modalShow): ?>
  <!-- View Log Modal -->
    <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div class="bg-white rounded-xl p-8 shadow-lg max-w-md w-full">
            <h2 class="text-2xl font-bold mb-4">Log Details</h2>
            <p><strong>User:</strong><span id="logTime"><?php echo e($activitylog->user->name ??''); ?></span></p>
            <p><strong>Action:</strong> <span id="logTime"><?php echo e($activitylog->action); ?></span></p>
            <p><strong>IP Address:</strong> <span id="logIP"><?php echo e($activitylog->ip_address); ?></span></p>
            <p><strong>Timestamp:</strong> <span id="logTime"><?php echo e($activitylog->created_at); ?></span></p>
            <div class="text-right mt-6">
                <button wire:click="closeLogModal"
                    class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg">Close</button>
            </div>
        </div>
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

      <!--[if BLOCK]><![endif]--><?php if($viewTools): ?>
      
  <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4">
    <!-- Modal Container -->
    <div class="bg-white rounded-lg shadow-xl w-full max-w-md">
        <!-- Modal Header -->
        <div class="flex items-center justify-between p-6 border-b border-gray-200">
            <h2 class="text-lg font-semibold text-gray-900"> <?php echo e($selectUser->name); ?> activity?</h2>
            <button wire:click="closeDialog" class="text-gray-400 hover:text-gray-600 transition-colors">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>
        </div>

        <!-- Modal Body -->
        <div class="p-6 space-y-4">
            <!-- Warning Alert -->
            <div class="bg-red-50 border border-red-200 rounded-md p-4">
                <div class="flex items-start">
                    <div class="flex-shrink-0">
                        <svg class="w-5 h-5 text-red-400 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                            <path fill-rule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clip-rule="evenodd"></path>
                        </svg>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-red-800">
                            Are you sure that you want to Deactive "<?php echo e($selectUser->name); ?>"?
                        </p>
                        
                    </div>
                </div>
            </div>

            <!-- Checkbox -->
            
        </div>

        <!-- Modal Footer -->
        <div class="flex justify-end space-x-3 px-6 py-4 border-t border-gray-200">
            <button wire:click="closeLogModal" class="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition-colors">
                Cancel
            </button>
            <button wire:click="makeYes" class="px-4 py-2 text-sm font-medium text-white bg-teal-600 border border-transparent rounded-md hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500 transition-colors">
                OK
            </button>
        </div>
    </div>
</div>
  <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

  <!--[if BLOCK]><![endif]--><?php if($viewToolmsg): ?>
  <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
    <div class="bg-white rounded-xl p-8 shadow-lg max-w-md w-full">

        <h2 class="text-2xl font-semibold mb-4 text-gray-800"><?php echo e($selectUser->name); ?></h2>
        <form wire:submit="messageSave" class="space-y-4">
          <div>
            <label for="subject" class="block text-sm font-medium text-gray-700">Subject</label>
            <input type="text" id="subject" name="subject" wire:model="subject" required
              class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" />
            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
          </div>

          <div>
            <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
            <textarea wire:model="message" id="description" name="description" rows="4" required
              class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"></textarea>
              <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span><?php echo e($message); ?></span>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
            </div>

          <div class="flex justify-between gap-4">
            <button type="submit"
              class="flex-1 bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition duration-200">
              Submit
            </button>

            <button type="button" wire:click="closeLogModal"
              class="flex-1 bg-gray-200 text-gray-800 py-2 px-4 rounded-lg hover:bg-gray-300 transition duration-200">
              Cancel
            </button>
          </div>
        </form>


    </div>
</div>
  <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</section>
<?php /**PATH I:\laragon\www\twindo\resources\views/livewire/last-login-actitvity.blade.php ENDPATH**/ ?>