

<!--[if BLOCK]><![endif]--><?php if($paginator->hasPages()): ?>

        <!--[if BLOCK]><![endif]--><?php if($paginator->onFirstPage()): ?>
            <button class="text-indigo-600 disabled:opacity-75 cursor-not-allowed">⬅️ Previous</button>
        <?php else: ?>
            <button wire:click="previousPage" class="text-indigo-600 hover:underline">⬅️ Previous</button>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        <!--[if BLOCK]><![endif]--><?php if($paginator->hasMorePages()): ?>
            <button wire:click="nextPage" class="text-indigo-600 hover:underline">Next ➡️</button>
        <?php else: ?>
            <button class="text-indigo-600 disabled:opacity-75 cursor-not-allowed">Next ➡️</button>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH I:\laragon\www\twindo\resources\views/vendor/pagination/message-action-pagination.blade.php ENDPATH**/ ?>