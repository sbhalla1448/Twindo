

    <section class="bg-white rounded-xl shadow p-6 mb-8">
        <h3 class="text-lg font-semibold text-gray-700 mb-4">📩 Latest Messages</h3>
        <table class="min-w-full text-sm text-left text-gray-700">
            <thead class="text-xs text-gray-500 uppercase">
                <tr>
                    <th scope="col" class="px-4 py-2">Subject</th>
                    <th scope="col" class="px-4 py-2">Status</th>
                    <th scope="col" class="px-4 py-2">Action</th>
                </tr>
            </thead>
            <tbody>

                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <tr class="border-t hover:bg-gray-50">
                    <td class="px-4 py-3"><?php echo e($msg->subject); ?></td>
                    <td class="px-4 py-3 text-red-500 font-semibold"><?php echo e($msg->read_status_user == 1 ? 'Read':'Unread'); ?></td>
                    <td class="px-4 py-3">
                        <a style="cursor: pointer" wire:click="readMessage(<?php echo e($msg->id); ?>)" class="text-indigo-600 hover:underline">View</a> /
                        <a style="cursor: pointer" wire:click="readMessage(<?php echo e($msg->id); ?>)" class="text-indigo-600 hover:underline">Respond</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                
            </tbody>
        </table>

        <!--[if BLOCK]><![endif]--><?php if($viewTools): ?>
        <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-40">
           <div class="bg-white rounded-lg shadow-lg p-6 w-1/2">
               <div class="bg-white p-6 rounded-xl shadow space-y-6">
                   <h3 class="text-2xl font-bold text-indigo-700 mb-2">Message Thread</h3>
                   <div class="space-y-4">
                     <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $usermessages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <div class="p-4 bg-gray-50 border rounded-lg text-sm">
                         <!--[if BLOCK]><![endif]--><?php if($msg->admin_id != null): ?>
                         <strong class="text-indigo-700">Twindo Team</strong> <span class="text-gray-400 text-xs">(<?php echo e($msg->created_at->format('d M Y')); ?> - <?php echo e($msg->created_at->format('h:i A')); ?>)</span>
                         <?php else: ?>
                         <strong class="text-indigo-700">You</strong> <span class="text-gray-400 text-xs">(<?php echo e($msg->created_at->format('d M Y')); ?> - <?php echo e($msg->created_at->format('h:i A')); ?>)</span>
                         <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                         <p class="mt-1 text-gray-700"><?php echo e($msg->message); ?></p>
                       </div>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                     
                     
                   </div>
                   <div class="flex justify-between mt-4">
                         <?php echo e($usermessages->links('vendor.pagination.message-action-pagination')); ?>

                   </div>
                   <form class="space-y-4 mt-6" wire:submit="replyMessageSubmit">
                     <label for="reply" class="text-gray-700 text-sm font-semibold">✏️ Write a Reply</label>
                     <textarea wire:model="replyMessage" id="reply" class="w-full border-2 border-gray-300 rounded-lg p-3 text-sm bg-gray-50" rows="3" placeholder="Write your reply here..."></textarea>
                         <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['replyMessage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                             <span><?php echo e($message); ?></span>
                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                     <div class="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center bg-white" style="position: relative;">
                       <p class="text-gray-500">Drag & drop a file here or click to upload</p>
                       <input type="file" class="opacity-0 absolute inset-0 cursor-pointer" wire:model="uploadFile">
                     </div>
                     <div class="flex justify-end">
                        <button wire:click="closeDialog"
                        class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg">Cancel</button>
                       <button type="submit"  class="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-2 rounded-lg">Post Reply</button>
                     </div>
                   </form>
                 </div>




           </div>
       </div>
       <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    </section>




<?php /**PATH I:\laragon\www\twindo\resources\views/livewire/customer/latest-message.blade.php ENDPATH**/ ?>