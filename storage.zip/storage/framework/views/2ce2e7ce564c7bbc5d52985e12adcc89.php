<main class="flex-1 overflow-auto">
    <div class="max-w-7xl mx-auto px-6 py-10 space-y-10">

      <!-- Filtering & Sorting -->
      <section class="bg-white p-6 rounded-xl shadow">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">🔎 Filter & Sort Uploads</h3>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          <select class="border rounded p-2 w-full text-sm" wire:model.change="status">
            <option value="">All</option>
            <option value="highToLow">Sort by Score (High to Low)</option>
            <option value="lowToHigh">Sort by Score (Low to High)</option>
            <option value="Approve">Sort by Approve</option>
            <option value="Pending">Sort by Pending</option>
            <option value="Reject">Sort by Reject</option>

          </select>
          <input type="date" wire:model.live="date" class="border rounded p-2 w-full text-sm" placeholder="Filter by Date">
          <input type="search" wire:model.live="search" class="border rounded p-2 w-full text-sm" placeholder="Search by User Email">
          <button wire:click="reseFilter" class="bg-indigo-600 text-white px-4 py-2 rounded text-sm hover:bg-indigo-700 transition">Reset</button>
        </div>
      </section>

      <!-- Credit Score Upload Management Table with Bulk Actions -->
      <section class="bg-white p-6 rounded-xl shadow">
        <div class="flex justify-between items-center mb-4">
          <h2 class="text-xl font-semibold text-gray-800">📤 User Credit Score Uploads</h2>
               <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
            <div class="bg-green-100 text-green-800 p-4 mb-4 rounded">
                <?php echo e(session('message')); ?>

            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['bulk'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="bg-green-100 text-green-800 p-4 mb-4 rounded">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
   <div wire:loading>

                    <svg aria-hidden="true"
                        class="inline w-8 h-8 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600"
                        viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                            fill="currentColor" />
                        <path
                            d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                            fill="currentFill" />
                    </svg>

                </div>
          <button class="bg-indigo-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-indigo-700 transition" wire:click="applyBulkAction" >
          
            
            ⬇️ Download CSV</button>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-sm text-left">
            <thead class="text-gray-600 border-b">
              <tr>
                <th class="py-2"><input type="checkbox" class="form-checkbox" wire:click="$set('bulkSelect', <?php echo \Illuminate\Support\Js::from($creditScores->pluck('id'))->toHtml() ?>)"></th>
                <th>User</th>
                <th>Upload Date</th>
                <th>Score</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>

                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $creditScores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cscore): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


              <tr class="border-t hover:bg-gray-50"  wire:click="selectedUser(<?php echo e($cscore->user_id); ?>, '<?php echo e($cscore->id); ?>')" <?php if(isset($selectedScore)): ?>
                
              <?php if($selectedScore->id === $cscore->id): ?> style="background-color: #f0f4ff;" <?php endif; ?> <?php endif; ?>>
                
                <td><input type="checkbox" class="form-checkbox" wire:model="bulkSelect" value="<?php echo e($cscore->id); ?>" >
                
                
                </td>
                
                <td class="py-3"><?php echo e($cscore->user->name); ?><br><span class="text-xs text-gray-500"><?php echo e($cscore->user->email); ?></span></td>
                <td><?php echo e($cscore->created_at->format('d M Y')); ?></td>
                <td><?php echo e($cscore->score); ?></td>
                <td><span class="bg-yellow-100 text-yellow-700 px-2 py-1 rounded text-xs"><?php echo e($cscore->score_status); ?></span></td>
                <td class="space-x-2">
                  <button class="text-green-600 hover:underline" wire:click="approve(<?php echo e($cscore->id); ?>)">✅ Approve</button>
                  <button class="text-red-600 hover:underline" wire:click="reject(<?php echo e($cscore->id); ?>)">❌ Reject</button>
                  <button   onclick="focusCommentTextarea()"  class="text-indigo-600 hover:underline">🗨️ Comment</button>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
              <!-- More rows... -->
            </tbody>
          </table>
        </div>
      </section>

      <!-- Email Template Trigger -->
      
      <section class="bg-white p-6 rounded-xl shadow">
    <h3 class="text-lg font-semibold text-gray-800 mb-4">📧 Send Email to User</h3>
    <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
    <div class="mb-4 text-green-600 text-sm font-medium">
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <?php if(session()->has('error')): ?>
    <div class="mb-4 text-green-600 text-sm font-medium">
        <?php echo e(session('message')); ?>

    </div>
<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <form  wire:submit="sendEmail" class="space-y-4" enctype="multipart/form-data">
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Select Template</label>
            <select wire:model.live="templateId" class="w-full border rounded p-2 text-sm">
                <option value="">Choose an email template</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $emailTemplates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $temp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($temp->id); ?>"><?php echo e($temp->email_subject); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
        </div>
        <div class="grid md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">CC</label>
                <input type="email" wire:model="cc" class="w-full border rounded p-2 text-sm" placeholder="cc@example.com">
            </div>
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">BCC</label>
                <input type="email"  wire:model="bcc"  class="w-full border rounded p-2 text-sm" placeholder="bcc@example.com">
            </div>
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Attachments</label>
            <input type="file" wire:model="attachment"
                class="block w-full text-sm text-gray-700 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100">
        </div>
        <div>
            <label class="block text-sm font-medium text-gray-700 mb-1">Message Preview</label>
            <textarea wire:model="mailBody"  rows="6" class="w-full border rounded p-2 text-sm" placeholder="Message preview...">

                

</textarea>
            <p class="mt-1 text-xs text-gray-500 italic">You can preview the final version of this email
                before sending.</p>
        </div>
        <div class="text-right">
            <?php if(session()->has('error')): ?>
        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <?php if(session()->has('template_message')): ?>
        <div class="bg-blue-100 border border-blue-400 text-blue-700 px-4 py-3 rounded mb-4">
            <?php echo e(session('template_message')); ?>

        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <button wire:click="manageTemplate" type="button"
                class="text-sm text-gray-600 hover:underline mr-4">🛠️ Manage Templates</button>
            <button wire:click="previewEmail" type="button" class="text-sm text-indigo-600 hover:underline mr-4">👁️ Preview
                Email</button>
                <div wire:loading>

                    <svg aria-hidden="true"
                        class="inline w-8 h-8 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600"
                        viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                            fill="currentColor" />
                        <path
                            d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                            fill="currentFill" />
                    </svg>

                </div>
            <button type="submit"
                class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm">📤
                Send Email</button>
        </div>
    </form>

    <!--[if BLOCK]><![endif]--><?php if($showPreview): ?>
        <div class="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
            <div class="bg-white rounded-lg shadow-lg p-6 w-full max-w-2xl max-h-[80vh] overflow-y-auto">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-xl font-semibold">Email Preview</h2>
                    <button wire:click="closePreview" class="text-gray-500 hover:text-gray-700">&times;</button>
                </div>
                <div class="prose">
                    <?php echo $previewContent; ?>

                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($manageTemplatePreview): ?>
        <div class="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
            <div class="bg-white rounded-lg shadow-lg p-6 w-full max-w-2xl max-h-[80vh] overflow-y-auto">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-xl font-semibold"><?php echo e($editingTemplateId ? 'Edit Template' : 'Create Template'); ?></h2>
                    <button wire:click="closeManagePreview" class="text-gray-500 hover:text-gray-700">×</button>
                </div>
                <div class="prose">
                    <form wire:submit.prevent="saveTemplate">
                        <div class="mb-4">
                            <label for="templateSubject" class="block text-sm font-medium text-gray-700">Email Subject</label>
                            <input type="text" class="w-full border rounded p-2 text-sm" id="templateSubject" wire:model="templateSubject">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['templateSubject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="mb-4">
                            <label for="templateBody" class="block text-sm font-medium text-gray-700">Email Body</label>
                            <textarea rows="6" class="w-full border rounded p-2 text-sm" id="templateBody" wire:model="templateBody" placeholder="Enter email body..."></textarea>
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['templateBody'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-red-500 text-sm"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <div class="flex justify-end">
                            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">
                                <?php echo e($editingTemplateId ? 'Update Template' : 'Save Template'); ?>

                            </button>
                        </div>
                    </form>

                    <h3 class="text-lg font-semibold mt-6">Template List</h3>
                    <!--[if BLOCK]><![endif]--><?php if($emailTemplates->isEmpty()): ?>
                        <p class="text-gray-500">No templates found.</p>
                    <?php else: ?>
                        <table class="w-full mt-4 border-collapse">
                            <thead>
                                <tr class="bg-gray-100">
                                    <th class="border p-2 text-left">Subject</th>
                                    <th class="border p-2 text-left">Body</th>
                                    <th class="border p-2 text-left">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $emailTemplates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class "border p-2"><?php echo e($template->email_subject); ?></td>
                                        <td class="border p-2"><?php echo e(Str::limit($template->email_body, 50)); ?></td>
                                        <td class="border p-2">
                                            <button wire:click="editTemplate(<?php echo e($template->id); ?>)" class="bg-yellow-500 text-white px-2 py-1 rounded hover:bg-yellow-600">Edit</button>
                                            <button wire:click="deleteTemplate(<?php echo e($template->id); ?>)" class="bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600" onclick="return confirm('Are you sure you want to delete this template?')">Delete</button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </tbody>
                        </table>
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</section>

<form wire:submit="saveComment" class="space-y-6">
       <section class="bg-white p-6 rounded-xl shadow">
        <h3 class="text-lg font-semibold text-gray-800 mb-2">🔍 Document Preview & Comment <?php echo e($selectedScore->score ?? ''); ?>  <?php echo e($selectedScore->image ?? ''); ?> </h3>
        <div class="grid md:grid-cols-2 gap-6">
          <div class="border rounded p-4 bg-gray-100 text-center text-sm text-gray-500">
            <img src="<?php echo e(asset('storage/uploads/' . ($selectedScore->image ?? 'default.jpg'))); ?>" alt="Score Image">
          </div>
          <div>
            <textarea  id="commentTextarea" wire:model='comment' class="w-full border rounded p-2 text-sm mb-2" rows="4" placeholder="Add a comment for the user..."></textarea>
            <div class="flex flex-row flex-wrap gap-3">
              <button type="button" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg text-sm" wire:click="setComment('✅ Approve')" >✅ Approve</button>
              <button type="button" class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-lg text-sm" wire:click="setComment('❌ Reject')">❌ Reject</button>
              <button type="button" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm" wire:click="setComment('🏷️ Tag as Highest')">🏷️ Tag as Highest</button>
              <button type="button" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-lg text-sm" wire:click="setComment('🏷️ Tag as Lowest')">🏷️ Tag as Lowest</button>
              
            </div>
          </div>
        </div>
      </section> 

  




      <!-- Comment History Log -->
      <section class="bg-white p-6 rounded-xl shadow">
        <div class="flex justify-between items-center mb-4">
          <h3 class="text-lg font-semibold text-gray-800">🗨️ Admin Comments</h3>
              <div wire:loading>

                    <svg aria-hidden="true"
                        class="inline w-8 h-8 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600"
                        viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                            fill="currentColor" />
                        <path
                            d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                            fill="currentFill" />
                    </svg>

                </div>
           <!--[if BLOCK]><![endif]--><?php if(isset($selectedScore)): ?> 
          <button type="submit" class="text-sm text-indigo-600 hover:underline">➕ Add Comment</button>
          <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div></h3>
        <ul class="text-sm text-gray-700 space-y-2">
 <!--[if BLOCK]><![endif]--><?php if(isset($selectedScore)): ?> 
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $selectedScore->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <li><strong><?php echo e($comment->user->name); ?></strong> on <em><?php echo e($comment->created_at->format('d M Y')); ?></em>: <?php echo e($comment->body); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
         <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        
          
          <!-- More comment logs... -->
        </ul>
      </section>
    </form>

      <!-- Real-Time Status Sync Note -->
      <section class="bg-white p-4 rounded-xl shadow text-sm text-gray-600">
        <p>ℹ️ All score status changes are synced live with the user's dashboard. Updates reflect in real time across both panels.</p>
      </section>


      <section class="bg-white p-6 rounded-xl shadow">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">🕒 User Timeline</h3>
        <ul class="text-sm text-gray-700 space-y-2">
           <!--[if BLOCK]><![endif]--><?php if(isset($selectedScore)): ?> 
          <li>📤 User uploaded score on <strong><?php echo e($selectedScore->created_at->format('d M Y')); ?></strong></li>
                <!--[if BLOCK]><![endif]--><?php if(!empty($selectedScore->approved_by) ): ?>
          <li><?php echo e($selectedScore->score_status); ?> by <?php echo e($selectedScore?->approved->name); ?>on <strong><?php echo e($selectedScore?->updated_at->format('d M Y')); ?></strong></li>
          <?php endif; ?><!--[if ENDBLOCK]><![endif]-->  
          <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
          <!-- More logs... -->
        </ul>
      </section>

    </div>




</main>


    <?php
        $__scriptKey = '2160583588-0';
        ob_start();
    ?>
<?php $__env->startPush('js'); ?>
<script>
  function focusCommentTextarea() {
    const textarea = document.getElementById('commentTextarea');
    if (textarea) {
      textarea.focus();
    }
  }
</script>
  
<?php $__env->stopPush(); ?>
    <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?><?php /**PATH I:\laragon\www\twindo\resources\views/livewire/credit/credit-socre-history.blade.php ENDPATH**/ ?>