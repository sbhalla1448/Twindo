<?php $__env->startPush('css'); ?>
<style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background: linear-gradient(135deg, #e5f4ec, #ffffff);
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .reset-card {
      background: white;
      padding: 3rem;
      border-radius: 12px;
      box-shadow: 0 0 25px rgba(0, 0, 0, 0.08);
      width: 100%;
      max-width: 420px;
      text-align: center;
    }
    .reset-card h2 {
      color: #004225;
      margin-bottom: 1rem;
    }
    .reset-card p {
      color: #555;
      font-size: 0.95rem;
      margin-bottom: 2rem;
    }
    .form-group {
      text-align: left;
      margin-bottom: 1.5rem;
    }
    label {
      display: block;
      font-weight: bold;
      margin-bottom: 0.5rem;
      color: #004225;
    }
    input[type="email"] {
      width: 100%;
      padding: 0.75rem;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 1rem;
    }
    button {
      width: 100%;
      padding: 1rem;
      background-color: #00cc66;
      color: white;
      border: none;
      border-radius: 6px;
      font-size: 1rem;
      font-weight: bold;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }
    button:hover {
      background-color: #00994d;
    }
    .back-link {
      margin-top: 2rem;
      display: block;
      font-size: 0.9rem;
    }
    .back-link a {
      color: #004225;
      text-decoration: none;
      font-weight: bold;
    }
  </style>
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
<div class="reset-card">
    <h2>Forgot your password?</h2>
    <p>No worries — just enter your email below and we’ll send you a link to reset it.</p>
    <?php if(session('status')): ?>
    <div class="alert alert-success" role="alert">
        <?php echo e(session('status')); ?>

    </div>
<?php endif; ?>

    <form method="POST" action="<?php echo e(route('password.email')); ?>">
        <?php echo csrf_field(); ?>
      <div class="form-group">
        <label for="email">Email Address</label>
        <input type="email" id="email" name="email" placeholder="you@twindo.co.uk" required>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
      <button type="submit">Send Reset Link</button>
    </form>
    <div class="back-link">
      <p><a href="#">Back to login</a></p>
    </div>
  </div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH I:\laragon\www\twindo\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>