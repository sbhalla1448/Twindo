<!-- Twindo Admin Dashboard (Enhanced Frontend UI/UX Match with Quick Actions, System Alerts, and Mini Charts) -->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Twindo Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/tom-select @2.3.1/dist/css/tom-select.css" rel="stylesheet">

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <?php echo $__env->yieldPushContent('css'); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>

<body class="bg-gray-50 min-h-screen">

    <?php echo $__env->make('backend.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="flex pt-20">

        <!-- Sidebar -->
        <?php echo $__env->make('backend.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


        <?php echo $__env->yieldContent('content'); ?>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/tom-select @2.3.1/dist/js/tom-select.min.js"></script>

    <?php echo $__env->yieldPushContent('js'); ?>

    <?php if(auth()->guard()->check()): ?>
        <script>
            let inactivityTimeout;

            function resetTimer() {
                clearTimeout(inactivityTimeout);
                inactivityTimeout = setTimeout(logout, 15 * 60 * 1000); // 15 minutes in milliseconds
            }

            function logout() {
                fetch('<?php echo e(route('admin.sessionlogout')); ?>', {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                        'Accept': 'application/json',
                    },
                }).then(response => {
                    if (response.ok) {
                        window.location.href = '/login';
                    }
                });
            }

            // Listen for user activity
            window.onload = resetTimer;
            ['mousemove', 'mousedown', 'keypress', 'scroll', 'touchstart'].forEach(event => {
                document.addEventListener(event, resetTimer);
            });
        </script>
    <?php endif; ?>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

</body>

</html>
<?php /**PATH I:\laragon\www\twindo\resources\views/backend/master.blade.php ENDPATH**/ ?>