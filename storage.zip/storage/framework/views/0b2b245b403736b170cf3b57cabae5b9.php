<div class="bg-white p-6 rounded-xl shadow">
    <h3 class="text-lg font-semibold text-gray-800 mb-2">📅 Recent Activity</h3>
    <ul class="text-sm text-gray-700 space-y-2">

        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $recentActivtities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($activity->user->name ?? ''); ?> <?php echo e($activity->descriptions); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->


    </ul>
    <div class="flex justify-between items-center mt-4">
       <?php echo e($recentActivtities->links('vendor.pagination.message-action-pagination')); ?>


    </div>
</div><?php /**PATH I:\laragon\www\twindo\resources\views/livewire/recent-activitiy.blade.php ENDPATH**/ ?>