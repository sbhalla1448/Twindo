<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Compare Credit Repair & Financial Products</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap" rel="stylesheet">
    

    <?php echo $__env->yieldPushContent('css'); ?>
</head>

<body>

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->yieldPushContent('js'); ?>
</body>

</html>
<?php /**PATH I:\laragon\www\twindo\resources\views/layouts/app.blade.php ENDPATH**/ ?>