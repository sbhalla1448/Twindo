
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Twindo | Financial Journey</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        body {
            background: linear-gradient(135deg, #f0f8ff 0%, #e6f7ff 100%);
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        
        .email-container {
            max-width: 845px;
            background-color: #ffffff;
            border-radius: 20px;
            box-shadow: 0 15px 50px rgba(0, 0, 0, 0.15);
            overflow: hidden;
        }
        
        .email-header {
            background: linear-gradient(135deg, #033333 0%, #0a4a4a 100%);
            padding: 35px 30px 30px;
            text-align: center;
            color: white;
            position: relative;
            overflow: hidden;
        }
        
        .email-header::before {
            content: "";
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: radial-gradient(circle, rgba(92, 180, 106, 0.15) 0%, transparent 70%);
            transform: rotate(15deg);
        }
        
        .logo {
            font-size: 38px;
            font-weight: 800;
            letter-spacing: -0.5px;
            margin-bottom: 8px;
            color: #EEFCFC;
            position: relative;
            z-index: 2;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }
        
        .tagline {
            font-weight: 300;
            font-size: 18px;
            opacity: 0.85;
            margin-bottom: 15px;
            color: #5CB46A;
            position: relative;
            z-index: 2;
            font-style: italic;
        }
        
        h1 {
            font-weight: 600;
            font-size: 28px;
            padding: 12px 0;
            border-top: 1px solid rgba(92, 180, 106, 0.3);
            border-bottom: 1px solid rgba(92, 180, 106, 0.3);
            margin: 0 auto;
            max-width: 80%;
            color: #EEFCFC;
            position: relative;
            z-index: 2;
        }
        
        .email-content {
            padding: 35px 45px;
            color: #033333;
            line-height: 1.6;
            font-size: 15px;
        }
        
        .greeting {
            font-size: 24px;
            margin-bottom: 20px;
            color: #033333;
            position: relative;
        }
        
        .greeting::after {
            content: "";
            display: block;
            width: 60px;
            height: 4px;
            background: linear-gradient(90deg, #5CB46A, #033333);
            border-radius: 2px;
            margin-top: 10px;
        }
        
        .highlight {
            color: #5CB46A;
            font-weight: 600;
        }
        
        .cta-button {
            display: inline-block;
            background: linear-gradient(135deg, #5CB46A 0%, #4CA05A 100%);
            color: white !important;
            text-decoration: none;
            padding: 16px 36px;
            border-radius: 50px;
            font-weight: 700;
            font-size: 17px;
            margin: 25px 0;
            text-align: center;
            transition: all 0.3s ease;
            box-shadow: 0 6px 20px rgba(92, 180, 106, 0.35);
            border: none;
            cursor: pointer;
            width: 100%;
            max-width: 320px;
            position: relative;
            overflow: hidden;
        }
        
        .cta-button::before {
            content: "";
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
            transition: 0.6s;
        }
        
        .cta-button:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 25px rgba(92, 180, 106, 0.5);
            background: linear-gradient(135deg, #4CA05A 0%, #3e8e4c 100%);
        }
        
        .cta-button:hover::before {
            left: 100%;
        }
        
        .section {
            margin: 25px 0;
            padding: 24px;
            border-radius: 16px;
            background-color: #f8fdfd;
            border: 1px solid #e0f0f0;
        }
        
        .section-title {
            display: flex;
            align-items: center;
            font-size: 18px;
            margin-bottom: 12px;
            color: #033333;
        }
        
        .section-title .icon {
            margin-right: 12px;
            font-size: 22px;
            color: #5CB46A;
        }
        
        .link-box {
            background-color: #f0faf0;
            padding: 14px 18px;
            border-radius: 12px;
            margin: 15px 0;
            word-break: break-all;
            font-family: monospace;
            color: #033333;
            border: 1px dashed #5CB46A;
            font-size: 13px;
            position: relative;
        }
        
        /* Account details styles */
        .detail-grid {
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 15px;
            margin-top: 15px;
        }
        
        .detail-item {
            padding: 12px 0;
            border-bottom: 1px solid #d9f0f0;
            display: flex;
            flex-direction: column;
        }
        
        .detail-item:last-child {
            border-bottom: none;
        }
        
        .detail-label {
            font-weight: 600;
            color: #033333;
            margin-bottom: 5px;
            font-size: 16px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        
        .detail-value {
            font-size: 17px;
            color: #033333;
        }
        
        .detail-value a {
            color: #5CB46A;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .detail-value a:hover {
            color: #033333;
            text-decoration: underline;
        }
        
        /* Security note */
        .security-note {
            margin-top: 20px;
            padding: 18px;
            background: #f8fafc;
            border-radius: 10px;
            border-left: 3px solid #3b82f6;
            border-image: linear-gradient(to bottom, #3b82f6, #1d4ed8);
            border-image-slice: 1;
            display: flex;
            gap: 12px;
        }
        
        .security-icon {
            flex-shrink: 0;
            width: 40px;
            height: 40px;
            border-radius: 8px;
            background: linear-gradient(135deg, #3b82f6, #1d4ed8);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 18px;
        }
        
        /* Package features grid */
        .essentials-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 18px;
            margin-top: 15px;
        }
        
        .essentials-feature {
            background: white;
            border-radius: 10px;
            padding: 18px;
            border: 1px solid #dbeafe;
            transition: all 0.3s ease;
            display: flex;
            gap: 12px;
            align-items: flex-start;
        }
        
        .essentials-feature:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 15px rgba(59, 130, 246, 0.15);
        }
        
        .feature-icon-blue {
            color: #5CB46A;
            font-size: 20px;
            margin-top: 3px;
        }
        
        .feature-text h4 {
            font-size: 18px;
            color: #033333;
            margin-bottom: 6px;
        }
        
        /* Report options */
        .report-options {
            display: flex;
            flex-direction: column;
            gap: 25px;
            margin: 30px 0;
        }
        
        .option-card {
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.08);
            border: 1px solid #d9f0f0;
            transition: all 0.3s ease;
        }
        
        .option-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.12);
        }
        
        .option-header {
            padding: 20px;
            text-align: center;
            font-weight: 700;
            font-size: 20px;
        }
        
        .option-1 .option-header {
            background: linear-gradient(135deg, #4361ee, #3a0ca3);
            color: white;
        }
        
        .option-2 .option-header {
            background: linear-gradient(135deg, #06d6a0, #118ab2);
            color: white;
        }
        
        .option-body {
            padding: 25px;
            background: white;
        }
        
        .option-steps {
            counter-reset: step-counter;
            padding-left: 0;
        }
        
        .option-steps li {
            margin-bottom: 20px;
            position: relative;
            padding-left: 40px;
            list-style-type: none;
        }
        
        .option-steps li:before {
            content: counter(step-counter);
            counter-increment: step-counter;
            position: absolute;
            left: 0;
            top: 0;
            width: 30px;
            height: 30px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            font-size: 15px;
            color: white;
        }
        
        .option-1 .option-steps li:before {
            background: #4361ee;
        }
        
        .option-2 .option-steps li:before {
            background: #06d6a0;
        }
        
        .option-steps li strong {
            display: block;
            margin-bottom: 6px;
            color: #033333;
            font-size: 18px;
        }
        
        .tips-box {
            background: linear-gradient(to right, #fff9db, #fff4c4);
            border-left: 4px solid #ffd43b;
            padding: 28px;
            margin: 30px 0;
            border-radius: 0 14px 14px 0;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
        }
        
        .tips-box h3 {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 15px;
            color: #033333;
            font-size: 20px;
        }
        
        /* Financial tools grid */
        .tools-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 25px;
            margin: 25px 0;
        }
        
        .tool-card {
            background: linear-gradient(to bottom, #ffffff, #f8fafc);
            border-radius: 14px;
            padding: 28px;
            border: 1px solid #d9f0f0;
            transition: all 0.4s ease;
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .tool-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 8px 25px rgba(0, 71, 52, 0.15);
            border-color: #c6f6d5;
        }
        
        .tool-icon {
            width: 65px;
            height: 65px;
            border-radius: 16px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 26px;
            margin-bottom: 20px;
            background: linear-gradient(135deg, #033333, #5CB46A);
            color: white;
        }
        
        .tool-title {
            font-size: 20px;
            font-weight: 600;
            color: #033333;
            margin-bottom: 12px;
        }
        
        .tool-desc {
            font-size: 16px;
            color: #64748b;
            margin-bottom: 15px;
            line-height: 1.5;
        }
        
        .tool-link {
            display: inline-block;
            color: #5CB46A;
            font-weight: 600;
            text-decoration: none;
            margin-top: auto;
            padding: 8px 16px;
            border-radius: 6px;
            background: rgba(92, 180, 106, 0.08);
            transition: all 0.3s ease;
        }
        
        .tool-link:hover {
            background: rgba(92, 180, 106, 0.15);
            color: #033333;
        }
        
        .email-footer {
            background-color: #f0fafa;
            padding: 25px 20px;
            text-align: center;
            border-top: 1px solid #d9f0f0;
            font-size: 14px;
            color: #033333;
        }
        
        .social-links {
            display: flex;
            justify-content: center;
            margin: 15px 0;
            gap: 15px;
        }
        
        .social-icon {
            display: inline-flex;
            width: 44px;
            height: 44px;
            background-color: #e0f5f5;
            border-radius: 50%;
            align-items: center;
            justify-content: center;
            color: #5CB46A;
            text-decoration: none;
            font-weight: bold;
            transition: all 0.3s ease;
            font-size: 18px;
        }
        
        .social-icon:hover {
            background-color: #5CB46A;
            color: white;
            transform: translateY(-4px) scale(1.1);
        }
        
        .social-icon.tiktok:hover {
            background: linear-gradient(135deg, #000, #25F4EE, #FE2C55);
            color: white;
        }
        
        .footer-links {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 20px;
            gap: 15px;
        }
        
        .footer-links a {
            color: #5CB46A;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.2s ease;
            padding: 5px 10px;
            border-radius: 6px;
        }
        
        .footer-links a:hover {
            color: #033333;
            background-color: rgba(92, 180, 106, 0.1);
            text-decoration: none;
        }
        
        .security-badge {
            display: inline-flex;
            align-items: center;
            background: linear-gradient(135deg, #e0f5f5 0%, #d0f0f0 100%);
            padding: 10px 20px;
            border-radius: 30px;
            margin-top: 15px;
            font-size: 14px;
            color: #033333;
        }
        
        .security-badge .icon {
            color: #5CB46A;
            margin-right: 8px;
            font-size: 16px;
        }
        
        .legal-disclaimer {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f7f7;
            padding: 20px 22px;
            text-align: center;
            border-top: 1px solid #e0e0e0;
            border-bottom: 1px solid #e0e0e0;
            border-left: 1px solid #e0e0e0;
            border-right: 1px solid #e0e0e0;
            border-radius: 0 0 16px 16px;
            margin-top: -1px;
        }
        
        .legal-section {
            margin-bottom: 15px;
            position: relative;
        }
        
        .legal-section::after {
            content: "";
            display: block;
            width: 120px;
            height: 1px;
            background: linear-gradient(90deg, transparent, #c0d0d0, transparent);
            margin: 15px auto 12px;
        }
        
        .legal-section:last-child::after {
            display: none;
        }
        
        .legal-title {
            display: flex;
            align-items: center;
            justify-content: center;
            color: #5a6a6a;
            margin-bottom: 10px;
            font-weight: 700;
            font-size: 12px;
            letter-spacing: 0.5px;
        }
        
        .legal-content {
            font-size: 11px;
            color: #6c757d;
            max-width: 580px;
            margin: 0 auto;
            line-height: 1.5;
        }
        
        .legal-content a {
            color: #5CB46A;
            text-decoration: underline;
            transition: all 0.2s;
        }
        
        .legal-content a:hover {
            color: #033333;
            text-decoration: none;
        }
        
        .legal-content ul {
            padding-left: 0;
            margin: 5px 0;
            text-align: center;
            list-style: none;
        }
        
        .legal-content li {
            margin-bottom: 3px;
            position: relative;
            padding-left: 0;
            text-align: center;
        }
        
        .key-rights-section .legal-content {
            margin-top: 3px;
        }
        
        .key-rights-section .legal-content ul {
            margin-top: 3px;
            margin-bottom: 3px;
        }
        
        .compliance-row {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 6px;
        }
        
        .compliance-item {
            display: flex;
            align-items: center;
            gap: 6px;
            font-size: 11px;
        }
        
        .compliance-item .icon {
            color: #8ca9a9;
            font-size: 11px;
        }
        
        @media (max-width: 845px) {
            .email-container {
                max-width: 95%;
            }
            
            .email-content {
                padding: 30px;
            }
            
            .email-header {
                padding: 30px 20px 25px;
            }
            
            .logo {
                font-size: 34px;
            }
            
            h1 {
                font-size: 24px;
                max-width: 90%;
            }
            
            .greeting {
                font-size: 22px;
            }
            
            .cta-button {
                padding: 14px 28px;
                font-size: 16px;
            }
            
            .section {
                padding: 20px;
            }
            
            .social-links {
                gap: 10px;
            }
            
            .social-icon {
                width: 40px;
                height: 40px;
                font-size: 16px;
            }
            
            .footer-links {
                gap: 12px;
            }
            
            .legal-disclaimer {
                padding: 18px;
            }
            
            .compliance-row {
                gap: 10px;
            }
            
            .detail-grid {
                grid-template-columns: 1fr;
            }
            
            .essentials-grid {
                grid-template-columns: 1fr;
            }
            
            .tools-grid {
                grid-template-columns: 1fr;
            }
        }
        
        @media (max-width: 480px) {
            .email-header {
                padding: 25px 15px 20px;
            }
            
            .email-content {
                padding: 25px 20px;
            }
            
            .footer-links {
                flex-direction: column;
                gap: 8px;
            }
            
            .compliance-row {
                flex-direction: column;
                gap: 8px;
            }
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="email-header">
            <div class="logo">Twindo</div>
            <div class="tagline">Your journey to financial freedom starts today</div>
            <h1>Welcome to Twindo</h1>
        </div>
        
        <div class="email-content">
            <h2 class="greeting">Hi <?php echo e($user->name); ?>,</h2>
            
            <p>Thank you for choosing <span class="highlight">Twindo</span> as your trusted partner on the road to financial freedom.</p>
            <p>You've successfully signed up for the <span class="highlight">Essentials Package</span>, and we're excited to guide you every step of the way.</p>
            <p>At Twindo, we leverage AI alongside advanced credit repair tools and expert advisors to deliver personalised analysis and guidance, helping you build a stronger financial future.</p>
            
            <!-- Account details section -->
            <div class="section">
                <h3 class="section-title">
                    <span class="icon"><i class="fas fa-user-circle"></i></span>
                    Your Account Details
                </h3>
                
                <div class="detail-grid">
                    <div class="detail-item">
                        <div class="detail-label">
                            <i class="fas fa-user"></i>
                            Username:
                        </div>
                        <div class="detail-value"><?php echo e($user->name); ?></div>
                    </div>
                    
                    <div class="detail-item">
                        <div class="detail-label">
                            <i class="fas fa-tachometer-alt"></i>
                            Dashboard:
                        </div>
                        <div class="detail-value"><a href="http://127.0.0.1:8000/account/dashboard">http://127.0.0.1:8000/account/dashboard</a></div>
                    </div>
                    
                    <div class="detail-item">
                        <div class="detail-label">
                            <i class="fas fa-key"></i>
                            Password Setup:
                        </div>
                        <div class="detail-value"><a href="http://127.0.0.1:8000/password/reset">Set your password</a></div>
                    </div>
                    
                    <div class="detail-item">
                        <div class="detail-label">
                            <i class="fas fa-headset"></i>
                            IT Support:
                        </div>
                        <div class="detail-value"><a href="#">Contact IT Support</a></div>
                    </div>
                </div>
                
                <div style="text-align: center;">
                    <a href="https://rwpsychotherapy.ca/twindo/my-account/" class="cta-button">
                        <i class="fas fa-lock-open"></i>
                        Access My Account
                    </a>
                </div>
                
                <!-- Security note -->
                <div class="security-note">
                    <div class="security-icon">
                        <i class="fas fa-shield-alt"></i>
                    </div>
                    <div class="security-content">
                        <h4><i class="fas fa-lock"></i> Password Security Guidance</h4>
                        <p>Protect your financial information with these security best practices:</p>
                        <ul style="padding-left: 20px; margin-top: 10px;">
                            <li style="margin-bottom: 8px;">Use a <strong>minimum of 12 characters</strong> including uppercase, lowercase, numbers and symbols</li>
                            <li style="margin-bottom: 8px;">Avoid common words or personal information (£tR0ngP@ss!2023 is better than Password123)</li>
                            <li>Never reuse passwords across multiple sites</li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <!-- Essentials Package section -->
            <div class="section">
                <h3 class="section-title">
                    <span class="icon"><i class="fas fa-gem"></i></span>
                    Your Twindo Plan: Essentials Financial Package
                </h3>
                
                <p>Our Essentials package provides fundamental financial analysis and personalised guidance to improve your financial health at an accessible price point.</p>
                
                <div class="essentials-grid">
                    <div class="essentials-feature">
                        <div class="feature-icon-blue">
                            <i class="fas fa-file-invoice"></i>
                        </div>
                        <div class="feature-text">
                            <h4>Credit Report Analysis</h4>
                            <p>Detailed review of your credit report from the main CRA's with key improvement areas</p>
                        </div>
                    </div>
                    
                    <div class="essentials-feature">
                        <div class="feature-icon-blue">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <div class="feature-text">
                            <h4>Score Tracking</h4>
                            <p>Monthly updates on your credit score and monitoring for significant changes</p>
                        </div>
                    </div>
                    
                    <div class="essentials-feature">
                        <div class="feature-icon-blue">
                            <i class="fas fa-lightbulb"></i>
                        </div>
                        <div class="feature-text">
                            <h4>Action Plan</h4>
                            <p>Customised recommendations to improve your credit profile</p>
                        </div>
                    </div>
                    
                    <div class="essentials-feature">
                        <div class="feature-icon-blue">
                            <i class="fas fa-comments"></i>
                        </div>
                        <div class="feature-text">
                            <h4>Email Support</h4>
                            <p>Direct access to our credit repair experts for guidance</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Next Steps section -->
            <div class="section">
                <h3 class="section-title">
                    <span class="icon"><i class="fas fa-road"></i></span>
                    Your Next Steps
                </h3>
                
                <ol style="padding-left: 20px; margin-top: 10px;">
                    <li style="margin-bottom: 10px;"><strong>Log in to your account</strong> using the secure button above</li>
                    <li style="margin-bottom: 10px;"><strong>Set your password</strong> and complete your security setup</li>
                    <li style="margin-bottom: 10px;"><strong>Upload your proof of ID</strong> and address documents</li>
                    <li style="margin-bottom: 10px;"><strong>Obtain your credit reports</strong> using one of the methods below</li>
                    <li><strong>Schedule your initial consultation</strong> with a financial advisor</li>
                </ol>
            </div>
            
            <!-- How to Get Credit Reports section -->
            <div class="section">
                <h3 class="section-title">
                    <span class="icon"><i class="fas fa-file-alt"></i></span>
                    How to Get Your Credit Reports
                </h3>
                
                <p>To begin your financial analysis, you'll need to obtain your credit reports. We've outlined two reliable methods below:</p>
                
                <div class="report-options">
                    <!-- Option 1 -->
                    <div class="option-card option-1">
                        <div class="option-header">
                            Option 1: Get All 3 Reports via Checkmyfile
                        </div>
                        <div class="option-body">
                            <p><strong>Free 30-Day Trial Method</strong></p>
                            <ol class="option-steps">
                                <li>
                                    <strong>Visit Checkmyfile</strong>
                                    <div>Go to <a href="https://www.checkmyfile.com/">https://www.checkmyfile.com/</a> and click "Start Your 30-Day Trial"</div>
                                </li>
                                <li>
                                    <strong>Create an Account</strong>
                                    <div>Enter your personal details (name, current address, date of birth). Provide your email and set a password. You'll need a debit/credit card for verification (no charge during trial)</div>
                                </li>
                                <li>
                                    <strong>Verify Your Identity</strong>
                                    <div>Answer security questions based on your credit history (e.g., previous addresses, loan amounts)</div>
                                </li>
                                <li>
                                    <strong>Access Your Combined Report</strong>
                                    <div>Once verified, you'll see reports from all 3 CRAs (Experian, Equifax, TransUnion) in one dashboard</div>
                                </li>
                                <li>
                                    <strong>Download Your Report (PDF)</strong>
                                    <div>Navigate to "My Reports" → Select "Download Report". Save the PDF to your device</div>
                                </li>
                                <li>
                                    <strong>Cancel Before Trial Ends</strong>
                                    <div>Within 30 days: Go to "My Account" → "Subscription Settings" → "Cancel Subscription". Confirm cancellation (you'll retain access until trial ends)</div>
                                </li>
                            </ol>
                            <div style="text-align: center; margin: 20px 0 0;">
                                <a href="https://www.checkmyfile.com/" class="cta-button" style="max-width: 300px;">
                                    <i class="fas fa-file-download"></i>
                                    Start Checkmyfile Trial
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Option 2 -->
                    <div class="option-card option-2">
                        <div class="option-header">
                            Option 2: Get Free Reports Directly from Each CRA
                        </div>
                        <div class="option-body">
                            <p><strong>Statutory Reports (free, but no scores)</strong></p>
                            <ol class="option-steps">
                                <li>
                                    <strong>Experian</strong>
                                    <div>
                                        Online: <a href="https://www.experian.co.uk/free-credit-report">experian.co.uk/free-credit-report</a><br>
                                        Post: Download Form <a href="#">here</a>, mail to: Experian, PO Box 8000, Nottingham, NG80 7WF
                                    </div>
                                </li>
                                <li>
                                    <strong>Equifax</strong>
                                    <div>
                                        Online: <a href="https://www.equifax.co.uk/consumer/statutory-report.html">equifax.co.uk/consumer/statutory-report.html</a><br>
                                        Post: Request form via phone (0800 014 2955). Mail to: Equifax Ltd, PO Box 10036, Leicester, LE3 4FS
                                    </div>
                                </li>
                                <li>
                                    <strong>TransUnion</strong>
                                    <div>
                                        Online: <a href="https://www.transunionstatreport.co.uk">transunion.co.uk/consumer-information → "Free Report"</a><br>
                                        Post: Mail request to: TransUnion, PO Box 491, Leeds, LS3 1WZ
                                    </div>
                                </li>
                            </ol>
                            <p><strong>Note</strong>: Statutory reports are free by law but contain limited info (no credit scores). Updated monthly.</p>
                        </div>
                    </div>
                </div>
                
                <div class="tips-box">
                    <h3><i class="fas fa-lightbulb"></i> Key Tips for Obtaining Your Reports</h3>
                    <ul style="padding-left: 20px; margin-top: 10px;">
                        <li style="margin-bottom: 8px;"><strong>Checkmyfile Trial</strong>: Cancel within 30 days to avoid £14.99/month charges</li>
                        <li style="margin-bottom: 8px;"><strong>Direct CRA Reports</strong>: Use statutory reports for free basics, or sign up for free services:
                            <ul style="padding-left: 20px; margin-top: 8px;">
                                <li style="margin-bottom: 5px;">Experian: <a href="#">MoneySavingExpert Credit Club</a> (free full report + score)</li>
                                <li style="margin-bottom: 5px;">Equifax: <a href="#">ClearScore</a> (free report + score)</li>
                                <li>TransUnion: <a href="#">Credit Karma</a> (free report + score)</li>
                            </ul>
                        </li>
                        <li><strong>Security</strong>: Always use official websites. Never share your login details</li>
                    </ul>
                </div>
            </div>
            
            <!-- Financial Tools section -->
            <div class="section">
                <h3 class="section-title">
                    <span class="icon"><i class="fas fa-tools"></i></span>
                    Explore Our Financial Tools
                </h3>
                
                <p>Take control of your financial future with our comprehensive suite of tools designed to empower your financial decisions.</p>
                
                <div class="tools-grid">
                    <div class="tool-card">
                        <div class="tool-icon">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <div class="tool-title">Credit Score Simulator</div>
                        <div class="tool-desc">See how different financial decisions could impact your credit score over time. Test scenarios before making real changes.</div>
                        <a href="#" class="tool-link">Explore Tool</a>
                    </div>
                    
                    <div class="tool-card">
                        <div class="tool-icon">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                        <div class="tool-title">Debt Analysis Dashboard</div>
                        <div class="tool-desc">Visualise all your debts in one place, create repayment strategies, and track your progress toward becoming debt-free.</div>
                        <a href="#" class="tool-link">Explore Tool</a>
                    </div>
                    
                    <div class="tool-card">
                        <div class="tool-icon">
                            <i class="fas fa-calendar-check"></i>
                        </div>
                        <div class="tool-title">Financial Advisor Booking</div>
                        <div class="tool-desc">Schedule one-on-one sessions with our certified financial advisors for personalised guidance on your unique situation.</div>
                        <a href="#" class="tool-link">Book Session</a>
                    </div>
                    
                    <div class="tool-card">
                        <div class="tool-icon">
                            <i class="fas fa-graduation-cap"></i>
                        </div>
                        <div class="tool-title">Financial Education Centre</div>
                        <div class="tool-desc">Access courses, guides, and resources to build your financial literacy and make informed decisions about your money.</div>
                        <a href="#" class="tool-link">Start Learning</a>
                    </div>
                </div>
                
                <div style="text-align: center;">
                    <a href="https://rwpsychotherapy.ca/twindo/my-account/" class="cta-button" style="max-width: 320px;">
                        <i class="fas fa-rocket"></i>
                        Launch My Account Dashboard
                    </a>
                </div>
            </div>
            
            <!-- Closing section -->
            <p style="text-align: center; font-size: 16px; margin-top: 15px; padding-top: 15px; border-top: 1px dashed #d9f0f0;">
                If you have any questions, our support team is ready to help.<br>
                Simply reply to this email or <a href="#" style="font-weight: 600; color: #5CB46A;">visit our help centre</a>.
            </p>
            
            <p style="text-align: center; margin-top: 20px; font-size: 18px; font-weight: 600; color: #033333;">
                Let's fix. Let's build. Let's thrive.<br>
                <span style="font-size: 20px; display: block; margin-top: 5px;">The Twindo Team</span>
            </p>
        </div>
        
        <div class="email-footer">
            <div class="social-links">
                <a href="#" class="social-icon"><i class="fab fa-facebook-f"></i></a>
                <a href="#" class="social-icon"><i class="fab fa-linkedin-in"></i></a>
                <a href="#" class="social-icon"><i class="fab fa-instagram"></i></a>
                <a href="#" class="social-icon tiktok"><i class="fab fa-tiktok"></i></a>
            </div>
            
            <p>You received this email because you recently created a new Twindo account.</p>
            
            <div class="footer-links">
                <a href="#">Help Center</a>
                <a href="#">Privacy Policy</a>
                <a href="#">Terms of Service</a>
                <a href="#">Unsubscribe</a>
            </div>
            
            <div class="security-badge">
                <span class="icon">🔒</span> Secure and Encrypted
            </div>
            
            <p style="margin-top: 15px;">© 2025 Twindo t/a EDPLX Limited. All rights reserved.<br>
            124 City Road London, EC1V 2NX, UK</p>
        </div>
        
        <div class="legal-disclaimer">
            <div class="legal-section">
                <div class="legal-title">
                    CONFIDENTIALITY & GDPR NOTICE
                </div>
                <div class="legal-content">
                    This email and attachments are confidential and intended solely for the named recipient(s). Unauthorised disclosure, copying, or distribution is prohibited. If received in error, notify us immediately at <a href="mailto:data-privacy@twindo.co.uk">data-privacy@twindo.co.uk</a> and permanently delete all copies. We comply with UK GDPR and Data Protection Act 2018.
                </div>
            </div>
            
            <div class="legal-section key-rights-section">
                <div class="legal-title">
                    CREDIT REPAIR DISCLOSURES
                </div>
                <div class="legal-content">
                    Twindo (trading as EDPLX Limited) is not a Credit Reference Agency (CRA), lender, or government body. We do not guarantee specific credit score improvements or removal of accurate information.
                </div>
                <div class="legal-content">
                    <strong>Your key rights:</strong> 
                    <ul>
                        <li>Dispute inaccuracies directly with CRAs at no cost</li>
                        <li>Adverse information remains for <strong>6 years</strong> (including bankruptcies)</li>
                        <li><strong>14-day cooling-off period</strong> to cancel services</li>
                        <li>Full <a href="https://www.twindo.co.uk/t-cs" target="_blank">Terms & Conditions</a></li>
                    </ul>
                </div>
            </div>
            
            <div class="legal-section">
                <div class="legal-title">
                    REGULATORY COMPLIANCE
                </div>
                <div class="legal-content">
                    <div class="compliance-row">
                        <div class="compliance-item">
                            <span class="icon"><i class="fas fa-id-card"></i></span> ICO Registration: ZB553399
                        </div>
                        <div class="compliance-item">
                            <span class="icon"><i class="fas fa-building"></i></span> Registered in England & Wales: 15398152
                        </div>
                        <div class="compliance-item">
                            <span class="icon"><i class="fas fa-file-alt"></i></span> <a href="https://www.twindo.co.uk/privacy-policy" target="_blank">Privacy Policy</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html><?php /**PATH I:\laragon\www\twindo\resources\views/emails/welcome_mail.blade.php ENDPATH**/ ?>