<div>
    <?php echo $templateReport->html_content; ?>

</div>
<?php /**PATH I:\laragon\www\twindo\resources\views/livewire/customer/report-analysis.blade.php ENDPATH**/ ?>