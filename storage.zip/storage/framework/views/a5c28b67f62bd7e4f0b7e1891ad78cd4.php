
<?php echo $templateReport->html_content; ?>



<?php /**PATH I:\laragon\www\twindo\resources\views/customer/analysis_report/analysis_report_show.blade.php ENDPATH**/ ?>