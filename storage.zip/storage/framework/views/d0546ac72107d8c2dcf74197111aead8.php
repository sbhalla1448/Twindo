<!--[if BLOCK]><![endif]--><?php if($paginator->hasPages()): ?>


    <div class="flex justify-between items-center mt-6">

        <span class="text-sm text-gray-600">




            <?php echo __('Showing'); ?>

            <!--[if BLOCK]><![endif]--><?php if($paginator->firstItem()): ?>
                <?php echo e($paginator->firstItem()); ?>

                <?php echo __('to'); ?>

                <?php echo e($paginator->lastItem()); ?>

            <?php else: ?>
                <?php echo e($paginator->count()); ?>

            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php echo __('of'); ?>

            <?php echo e($paginator->total()); ?>

            <?php echo __('results'); ?>

        </span>


        <!-- Pagination -->







        <div class="flex space-x-2">
            <!--[if BLOCK]><![endif]--><?php if($paginator->onFirstPage()): ?>
                <button class="px-3 py-1 border rounded-md hover:bg-gray-100 cursor-not-allowed" >Previous</button>
            <?php else: ?>
                    <button wire:click="previousPage" class="px-3 py-1 border rounded-md hover:bg-gray-100">Previous</button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            <!--[if BLOCK]><![endif]--><?php if($paginator->hasMorePages()): ?>


                    <button wire:click="nextPage" class="px-3 py-1 border rounded-md hover:bg-gray-100">Next</button>

                
            <?php else: ?>
                <button class="px-3 py-1 border rounded-md hover:bg-gray-100 cursor-not-allowed">Next</button>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

        </div>
    </div>

<?php endif; ?><!--[if ENDBLOCK]><![endif]-->


<?php /**PATH I:\laragon\www\twindo\resources\views/vendor/pagination/message-action-admin-pagination.blade.php ENDPATH**/ ?>