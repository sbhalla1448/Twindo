

<?php $__env->startSection('content'); ?>
    

    <!-- Main Content -->

    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('message.message-index', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-3763159812-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH I:\laragon\www\twindo\resources\views/backend/message_actions/index.blade.php ENDPATH**/ ?>