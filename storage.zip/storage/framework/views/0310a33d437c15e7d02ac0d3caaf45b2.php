<aside class="w-56 bg-white shadow-sm min-h-screen">
    <nav class="mt-8 px-4 space-y-2">
        <a  href="<?php echo e(route('dashboard')); ?>"
            class="block py-2 px-3 <?php echo e(request()->is(['admin/dashboard*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100'); ?>">🏠
            Dashboard</a>
        <a href="<?php echo e(route('credit.history')); ?>"
            class="block py-2 px-3 <?php echo e(request()->is(['account/sasdsdaf*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100'); ?>">📈
            Credit Score History</a>
        <a href="<?php echo e(route('analysis.report')); ?>"
            class="block py-2 px-3 <?php echo e(request()->is(['account/sasdsdaf*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100'); ?>">📈
            Analysis Report</a>
        <a href="<?php echo e(route('message.action')); ?>"
            class="block py-2 px-3 <?php echo e(request()->is(['account/sasdsdaf*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100'); ?>">📩
            Messages & Actions</a>
        <a href="<?php echo e(route('product.service')); ?>"
            class="block py-2 px-3 <?php echo e(request()->is(['account/product/service']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100'); ?>">🛍️
            Products & Services</a>
        <a href="<?php echo e(route('tool.resource')); ?>"
            class="block py-2 px-3 <?php echo e(request()->is(['account/tool/resource*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100'); ?>">🛠️
            Tools & Resources</a>
        <a href="<?php echo e(route('my.documents')); ?>"
            class="block py-2 px-3 <?php echo e(request()->is(['account/my/documents*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100'); ?>">📄
            My Documents</a>
        <a href="<?php echo e(route('subscription')); ?>"
            class="block py-2 px-3 <?php echo e(request()->is(['account/subsctiption*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100'); ?>">💳
            My Subscription</a>
        
        <a href="<?php echo e(route('account.settings')); ?>"
            class="block py-2 px-3 <?php echo e(request()->is(['account/settings*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100'); ?>">⚙️
            Account
            Settings</a>
        <a href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"
            class="block py-2 px-3 rounded-md hover:bg-gray-100">🔓 Logout</a>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
        </form>
    </nav>
</aside>
<?php /**PATH I:\laragon\www\twindo\resources\views/customer/partials/sidebar.blade.php ENDPATH**/ ?>