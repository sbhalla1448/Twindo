<?php $__env->startSection('content'); ?>
    <!-- Main Content -->
    <main class="max-w-7xl mx-auto px-6 py-10">
        <div class="max-w-7xl mx-auto px-6 py-6 md:py-10">

            <!-- Breadcrumb & Hero -->
            <section class="mb-8 space-y-2">
                <nav class="text-sm text-gray-500">Home / Admin / Settings</nav>
                <div class="flex justify-between items-center">
                    <h2 class="text-3xl font-bold text-gray-800">Settings</h2>
                    <input type="search"  id="settingsSearch" placeholder="Search settings..."
                        class="w-64 border border-gray-300 rounded-xl px-3 py-2 shadow-sm">
                </div>
            </section>

            <!-- Settings Options -->
            <section class="settings-card grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-24">
                <div class="bg-white rounded-xl shadow p-6 hover:shadow-md transition flex flex-col h-full">
                    <h3 class="text-xl font-semibold text-gray-800">👤 Manage Profile</h3>
                    <p class="text-sm text-gray-500 flex-grow">Edit your full name, email address, phone number, and
                        profile picture.</p>
                    <button class="mt-auto bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition">
                        <a href="<?php echo e(route('admin.settings.user')); ?>">✏️
                            Edit Profile</a>
                    </button>
                </div>

                <div class="settings-card bg-white rounded-xl shadow p-6 hover:shadow-md transition flex flex-col h-full">
                    <h3 class="text-xl font-semibold text-gray-800">🔐 Security Settings</h3>
                    <p class="text-sm text-gray-500 flex-grow">Enable/disable two-factor authentication, change
                        password, and secure your account.</p>
                    <button class="mt-auto bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition">
                        <a href="<?php echo e(route('admin.settings.security')); ?>">🔐
                            Manage Security</a>

                    </button>
                </div>

                <div class="settings-card bg-white rounded-xl shadow p-6 hover:shadow-md transition flex flex-col h-full">
                    <h3 class="text-xl font-semibold text-gray-800">🔔 Notification Preferences</h3>
                    <p class="text-sm text-gray-500 flex-grow">Choose how and when to receive important
                        notifications.</p>

                    <button class="mt-auto bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition"> <a
                            href="<?php echo e(route('admin.settings.notification')); ?>">🔧
                            Manage Notifications </a></button>
                </div>

                
                <div class="settings-card bg-white rounded-xl shadow p-6 hover:shadow-md transition flex flex-col h-full">
                    <h3 class="text-xl font-semibold text-gray-800">🧑‍💼 Admin Roles</h3>
                    <p class="text-sm text-gray-500 flex-grow">Assign roles like Admin, Support Agent, or Viewer
                        with varying access rights.</p>
                    <button class="mt-auto bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition"> <a
                            href="<?php echo e(route('admin.roles.index')); ?>">🔧
                            Manage Roles </a></button>
                </div>
                
                <div class="settings-card bg-white rounded-xl shadow p-6 hover:shadow-md transition flex flex-col h-full">
                    <h3 class="text-xl font-semibold text-gray-800">👁️ Role Visibility</h3>
                    <p class="text-sm text-gray-500 flex-grow">Control which roles can see or interact with certain
                        admin tools and panels.</p>
                    <button class="mt-auto bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition"> <a
                            href="<?php echo e(route('admin.role.based.visibility')); ?>">
                            🔒
                            Configure Visibility </a></button>
                </div>

                <div class="settings-card bg-white rounded-xl shadow p-6 hover:shadow-md transition flex flex-col h-full">
                    <h3 class="text-xl font-semibold text-gray-800">🛂 Permission Controls</h3>
                    <p class="text-sm text-gray-500 flex-grow">Define specific actions users or admins can perform
                        by role or tier.</p>
                    <button class="mt-auto bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition"><a
                            href="<?php echo e(route('admin.permission.controll')); ?>">⚙️
                            Manage Permissions </a></button>
                </div>

                <div class="settings-card bg-white rounded-xl shadow p-6 hover:shadow-md transition flex flex-col h-full">
                    <h3 class="text-xl font-semibold text-gray-800">✉️ Change Admin Email</h3>
                    <p class="text-sm text-gray-500 flex-grow">Update the email address used for platform admin
                        access.</p>
                    <button class="mt-auto bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition"><a
                            href="<?php echo e(route('admin.change.email')); ?>">✉️
                            Update Email</a></button>
                </div>

                <div class="settings-card bg-white rounded-xl shadow p-6 hover:shadow-md transition flex flex-col h-full">
                    <h3 class="text-xl font-semibold text-gray-800">📤 Export Admin Activity</h3>
                    <p class="text-sm text-gray-500 flex-grow">Download a full log of recent admin actions in CSV
                        format.</p>
                    <button class="mt-auto bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition"><a href="<?php echo e(route('admin.activity.log')); ?>">📁 Export Logs </a></button>


                </div>
            </section>

            <!-- Save All Bar -->
            <div
                class="fixed bottom-0 left-0 right-0 bg-white border-t shadow-md p-4 flex justify-between items-center z-40">
                <span class="text-sm text-gray-600">✅ All settings are up to date</span>
                <button class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm">💾 Save
                    All Settings</button>
            </div>

            <!-- Modals -->
            <div id="profileModal"
                class="hidden fixed inset-0 bg-black bg-opacity-30 flex justify-center items-center z-50">
                <div class="bg-white p-6 rounded-xl shadow-xl w-full max-w-lg">
                    <h3 class="text-lg font-semibold mb-3">👤 Edit Profile (Coming Soon)</h3>
                    <p class="text-sm text-gray-600">This feature will allow editing of admin profile data.</p>
                    <div class="flex justify-end mt-4">
                        <button onclick="closeModal('profileModal')"
                            class="text-sm text-indigo-600 hover:underline">Close</button>
                    </div>
                </div>
            </div>

            <div id="securityModal"
                class="hidden fixed inset-0 bg-black bg-opacity-30 flex justify-center items-center z-50">
                <div class="bg-white p-6 rounded-xl shadow-xl w-full max-w-lg">
                    <h3 class="text-lg font-semibold mb-3">🔐 Manage Security (Coming Soon)</h3>
                    <p class="text-sm text-gray-600">Security settings for admin logins, 2FA, password, and more.
                    </p>
                    <div class="flex justify-end mt-4">
                        <button onclick="closeModal('securityModal')"
                            class="text-sm text-indigo-600 hover:underline">Close</button>
                    </div>
                </div>
            </div>

        </div>
    </main>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('js'); ?>
<script>
    function openModal(id) {
      document.getElementById(id).classList.remove('hidden');
    }
    function closeModal(id) {
      document.getElementById(id).classList.add('hidden');
    }
  </script>

  <script>
  document.getElementById('settingsSearch').addEventListener('input', function () {
    const searchTerm = this.value.toLowerCase();
    const cards = document.querySelectorAll('.grid > div');
    let visibleCount = 0;

    cards.forEach(card => {
      const title = card.querySelector('h3')?.textContent.toLowerCase() || '';
      const description = card.querySelector('p')?.textContent.toLowerCase() || '';

      if (title.includes(searchTerm) || description.includes(searchTerm)) {
        card.classList.remove('hidden');
        visibleCount++;
      } else {
        card.classList.add('hidden');
      }
    });

    const noResults = document.getElementById('noResults');
    if (visibleCount === 0 && searchTerm !== '') {
      noResults.classList.remove('hidden');
    } else {
      noResults.classList.add('hidden');
    }
  });
</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('backend.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH I:\laragon\www\twindo\resources\views/backend/settings/index.blade.php ENDPATH**/ ?>