<?php $__env->startSection('content'); ?>
<div>
    <header>
        <div class="logo">Twindo</div>
        <div class="tagline">Your journey to financial freedom starts here</div>
        <div class="secure-checkout">
            <i class="fas fa-lock"></i>
            <span>Secure Checkout</span>
        </div>

        <!-- Enhanced Progress Bar -->
        <div class="header-progress">
            <div class="progress-container-inner">
                <div class="progress-steps-inner">
                    <div class="progress-bar-inner" style="--progress-width: 100%"></div>
                    <div class="step-inner active">
                        <i class="fas fa-user"></i>
                        <div class="step-label-inner">Account</div>
                    </div>
                    <div class="step-inner active">
                        <i class="fas fa-credit-card"></i>
                        <div class="step-label-inner ">Payment</div>
                    </div>
                    <div class="step-inner active">
                        <i class="fas fa-check-circle"></i>
                        <div class="step-label-inner">Confirmation</div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Main Content -->
    <div class="main-content">




        <!-- Stage 3: Confirmation -->
        <div class="step-content active" id="step3">
            <div class="confirmation-container">
                <div class="confirmation-icon">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h1 class="confirmation-title">Thank You for Your Purchase!</h1>
                <p class="confirmation-subtitle">
                    Your <?php echo e($currentPlan->plan->name); ?> Plan subscription is now active. We've sent a confirmation email with all the details.
                    You can now access your dashboard and start on your credit improvement journey.
                </p>

                <div class="order-details">
                    <h3 style="font-size: 20px; margin-bottom: 20px; text-align: center; color: #033333;">Order Details</h3>
                    <div class="detail-row">
                        <span class="detail-label">Order Number:</span>
                        <span class="detail-value"><?php echo e($intent->id); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Subscription Plan:</span>
                        <span class="detail-value"><?php echo e($currentPlan->plan->name); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Billing Cycle:</span>
                        <span class="detail-value"><?php echo e($currentPlan->subcription_type); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Next Payment:</span>
                        <span class="detail-value"><?php echo e($currentPlan->end_date->format('d M Y')); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Total Paid:</span>
                        <span class="detail-value">£<?php echo e(number_format($intent->amount / 100, 2)); ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">Payment Method:</span>
                        <span class="detail-value"><?php echo e($intent->payment_method_types[0]); ?></span>
                    </div>
                </div>

                <div class="confirmation-buttons">
                    <a href="<?php echo e(route('dashboard')); ?>">
                    <button class="btn" id="go-to-dashboard">
                        <i class="fas fa-tachometer-alt"></i> Go to Dashboard
                    </button>
                    </a>
                    <a href="<?php echo e(route('index')); ?>">
                    <button class="btn btn-outline" id="back-to-home">
                        <i class="fas fa-home"></i> Back to Home
                    </button>
                    </a>
                </div>
            </div>
        </div>


    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.payment.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH I:\laragon\www\twindo\resources\views/customer/payment/success.blade.php ENDPATH**/ ?>