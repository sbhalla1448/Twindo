<!--[if BLOCK]><![endif]--><?php if($paginator->hasPages()): ?>

<div class="flex justify-between items-center mt-6">
    <!--[if BLOCK]><![endif]--><?php if($paginator->onFirstPage()): ?>
    <button class="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded-lg disabled:opacity-75">Previous</button>
    <?php else: ?>
    <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">
    <button class="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded-lg">Previous</button> </a>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($paginator->hasMorePages()): ?>
    <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">
    <button class="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded-lg">Next</button>
    </a>
    <?php else: ?>
    <button class="px-4 py-2 bg-gray-200 hover:bg-gray-300 rounded-lg disabled:opacity-75">Next</button>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</div>

<?php endif; ?><!--[if ENDBLOCK]><![endif]-->
<?php /**PATH I:\laragon\www\twindo\resources\views/vendor/pagination/system-log.blade.php ENDPATH**/ ?>