<section class="bg-white rounded-xl shadow p-8">
    <h2 class="text-2xl font-bold text-gray-800 mb-4">🔐 Security Settings</h2>
    <p class="text-sm text-gray-600 mb-6">Manage your password, two-factor authentication (2FA), and
        other security features.</p>

    <div class="space-y-6">
        <div class="flex justify-between items-center">
            <div>
                <h3 class="text-sm font-semibold text-gray-800">Password</h3>
                <p class="text-sm text-gray-600">You last changed your password
                    <?php echo e(\Carbon\Carbon::parse($user->password_change_at)->diffForHumans() ?? ''); ?> months ago.</p>
            </div>
            <button wire:click.prevent="passwordUp" class="text-sm text-indigo-600 hover:underline">Change
                Password</button>
        </div>

        <div class="flex justify-between items-center">
            <div>
                <h3 class="text-sm font-semibold text-gray-800">Two-Factor Authentication (2FA)</h3>
                <p class="text-sm text-gray-600">Secure your account by enabling 2FA login.</p>
            </div>
             <button wire:click.prevent="twofa"
                class="text-sm bg-indigo-600 text-white px-4 py-1 rounded hover:bg-indigo-700">Enable
                            2FA</button>
        </div>

        <div class="border-t pt-6">
            <h3 class="text-sm font-semibold text-gray-800 mb-2">Delete Account</h3>
            <p class="text-sm text-red-600">This will permanently delete your Twindo account and cannot
                be undone.</p>
                <a href="#">
            <button class="mt-2 text-sm text-red-600 hover:underline">Request Account Deletion</button>
                </a>
                
        </div>
    </div>

      <!--[if BLOCK]><![endif]--><?php if($twofaenable == 1): ?>
        <div class="relative z-10" aria-labelledby="modal-title" role="dialog" aria-modal="true">

            <div class="fixed inset-0 bg-gray-500/75 transition-opacity" aria-hidden="true"></div>

            <div class="fixed inset-0 z-10 w-screen overflow-y-auto">
                <div class="flex min-h-full items-center justify-center p-4 text-center sm:items-center sm:p-0">


                    <div class="bg-white rounded-xl shadow-xl p-8 w-full max-w-md">
                        <div class="space-y-6">

                            <div class="text-center">
                                <p class="text-gray-600 mb-4">Scan this QR code with your authenticator app:</p>
                                <p>Here is your secret key: <?php echo e($secretkey); ?></p>
                                <div class="flex justify-center">
                                    <div class="bg-gray-200 p-4 rounded-lg">
                                        
                                        <?php echo $urlQRcode; ?>


                                    </div>
                                </div>
                            </div>
                            <form wire:submit="otpVerify">
                                <div>
                                    <label class="block text-sm font-medium text-gray-700">Enter 6-digit
                                        Code</label>
                                    <input type="text" wire:model="otp" placeholder="123456"
                                        class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                                    <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['otp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="error"><?php echo e($message); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                                </div>

                                <div class="flex justify-end space-x-4">
                                    <button wire:click.prevent="twofaCancel"
                                        class="bg-gray-300 text-gray-700 px-5 py-2 rounded-lg hover:bg-gray-400">Cancel</button>
                                    <button type="submit"
                                        class="bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700">Verify
                                        &
                                        Enable</button>
                                </div>
                            </form>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($twofasuccess == 1): ?>
        <div class="relative z-10" aria-labelledby="modal-title" role="dialog" aria-modal="true">

            <div class="fixed inset-0 bg-gray-500/75 transition-opacity" aria-hidden="true"></div>

            <div class="fixed inset-0 z-10 w-screen overflow-y-auto">
                <div class="flex min-h-full items-center justify-center p-4 text-center sm:items-center sm:p-0">


                    <div class="bg-white rounded-xl shadow-xl p-8 w-full max-w-md text-center">

                        <div class="flex justify-center mb-6">
                            <div class="bg-green-100 rounded-full p-4">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-10 w-10 text-green-600" fill="none"
                                    viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M5 13l4 4L19 7" />
                                </svg>
                            </div>
                        </div>

                        <h2 class="text-2xl font-bold text-gray-800 mb-4">Two-Factor Authentication Enabled!</h2>
                        <p class="text-gray-600 mb-8">Your account is now protected with an extra layer of security.</p>

                        <button class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-lg">
                            <a href="<?php echo e(route('account.settings')); ?>">Return to Account
                                Settings</a>
                        </button>

                    </div>

                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->


    <!--[if BLOCK]><![endif]--><?php if($passwordchange == 1): ?>
        <!-- Modal -->
        <div id="passwordModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
            <div class="bg-white rounded-xl shadow-lg p-8 max-w-lg w-full relative">
                <!-- Close Button -->
                <button wire:click="closePasswordModal"
                    class="absolute top-4 right-4 text-gray-500 hover:text-gray-700">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                        xmlns="http://www.w3.org/2000/svg">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12">
                        </path>
                    </svg>
                </button>

                <h2 class="text-2xl font-bold text-gray-800 mb-4">🔐 Change <?php echo e($user->name); ?> Password</h2>
                <p class="text-sm text-gray-600 mb-6">Update your password to keep your administrator account secure.
                    Use a strong, unique password.</p>

                <form wire:submit="updatePassword">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">


                        <div class="md:col-span-2">
                            <label class="block text-sm font-medium text-gray-700 mb-1">Current Password</label>
                            <input type="password" wire:model="current_password"
                                class="w-full border border-gray-300 rounded-lg p-2 text-sm shadow-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                                placeholder="Enter current password">

                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">New Password</label>
                            <input type="password" wire:model.live="password"
                                class="w-full border border-gray-300 rounded-lg p-2 text-sm shadow-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                                placeholder="Enter new password">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-1">Confirm New Password</label>
                            <input type="password" wire:model="password_confirmation"
                                class="w-full border border-gray-300 rounded-lg p-2 text-sm shadow-sm focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                                placeholder="Confirm new password">
                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="text-red-500 text-xs"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>


                        <!-- Password Strength Meter -->
                        <div class="mt-4 text-sm text-gray-600 w-full">
                            <span class="block mb-1 font-medium">Password Strength:</span>
                            <div class="w-full bg-gray-200 rounded-full h-2">
                                <div class="bg-green-500 h-2 rounded-full" style="width: <?php echo e($passwordStrength); ?>%">
                                </div>
                            </div>
                            <p class="text-xs text-gray-500 mt-1">Include uppercase, lowercase, number, and symbol for
                                a
                                stronger password. <?php echo e($passwordStrength); ?></p>
                        </div>
                    </div>
                    <div class="mt-6 text-right">
                        <div wire:loading>

                            <svg aria-hidden="true"
                                class="inline w-8 h-8 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600"
                                viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                                    fill="currentColor" />
                                <path
                                    d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                                    fill="currentFill" />
                            </svg>

                        </div>
                        <!--[if BLOCK]><![endif]--><?php if($passwordStrength==100): ?>
                        <button type="submit"
                            class="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-lg text-sm font-medium shadow transition duration-150">
                            🔒 Update Password
                        </button>
                        <?php else: ?>
                        <button type="button"
                            class="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2 rounded-lg text-sm font-medium shadow transition duration-150 cursor-not-allowed" disabled>
                            🔒 Update Password
                        </button>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    </div>

                </form>

                <p class="mt-4 text-xs text-gray-500">Last changed on:  <?php echo e(\Carbon\Carbon::parse($user->password_change_at)->format('d M Y')); ?></p>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</section>
<?php /**PATH I:\laragon\www\twindo\resources\views/livewire/customer/customer-security-setting.blade.php ENDPATH**/ ?>