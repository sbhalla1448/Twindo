<main class="flex-1 overflow-auto">
    <div class="max-w-7xl mx-auto px-6 py-10">

      <section class="bg-white rounded-xl shadow p-8 mb-8">
        <h3 class="text-2xl font-bold text-gray-800 mb-2">🛠️ Your Tools & Resources</h3>
        <p class="text-gray-500 mb-6">Explore curated tools, templates, calculators, and guides designed to help accelerate your credit repair journey.</p>
        <div class="border-t border-gray-200 mb-8"></div>

        <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
          <input id="searchResources" type="search" wire:model.live="search" placeholder="🔍 Search Resources..." class="w-full md:w-1/3 border rounded-md p-2 text-sm mb-4 md:mb-0">
          <select wire:model.live="categoryId" class="w-full md:w-48 border rounded-md p-2 text-sm">
            <option value="">All Categories</option>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
          </select>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="resourcesList">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div class="resource-card bg-white border border-gray-200 rounded-lg p-6 hover:shadow-xl transition-all flex flex-col justify-between">
            <div>
              <h4 class="text-lg font-semibold text-indigo-700 mb-2"><?php echo e($tool->category->name); ?></h4>
              <p class="text-sm text-gray-500 mb-4"><?php echo e($tool->title); ?></p>
            </div>
            <a wire:click="view(<?php echo e($tool->id); ?>)" style="cursor: pointer" class="inline-block text-indigo-600 hover:underline font-medium text-sm mt-auto">📄 View Templates</a>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>

      </section>

    </div>
         <!-- View Resource Modal -->
         <!--[if BLOCK]><![endif]--><?php if($viewTools): ?>
         <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
         <div class="bg-white rounded-lg shadow-lg p-6 w-1/2">
             <h2 id="viewResourceTitle" class="text-2xl font-bold mb-4"></h2>
             <p class="text-gray-600"><?php echo e($title); ?></p>
             
             <iframe src="<?php echo e($url); ?>" class="w-full aspect-video"></iframe>
             
             <div class="text-right mt-6">
                 <button wire:click="closeDialog"
                     class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg">Close</button>
             </div>
         </div>
     </div>
     <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
  </main>


      <?php
        $__scriptKey = '3880729246-0';
        ob_start();
    ?>
  <?php $__env->startPush('js'); ?>
  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const searchInput = document.getElementById('searchResources');
      const resourceCards = document.querySelectorAll('.resource-card');

      searchInput.addEventListener('input', function(e) {
        const query = e.target.value.toLowerCase();
        resourceCards.forEach(card => {
          const text = card.innerText.toLowerCase();
          if (text.includes(query)) {
            card.style.display = 'block';
          } else {
            card.style.display = 'none';
          }
        });
      });
    });
  </script>

  <?php $__env->stopPush(); ?>
      <?php
        $__output = ob_get_clean();

        \Livewire\store($this)->push('scripts', $__output, $__scriptKey)
    ?><?php /**PATH I:\laragon\www\twindo\resources\views/livewire/customer/tool-resource.blade.php ENDPATH**/ ?>