<main class="flex-1 overflow-auto">
    <div class="max-w-7xl mx-auto px-6 py-10">

        <section class="mb-8 flex items-center justify-between">
            <div>
                <nav class="text-sm text-gray-500">Home / Admin / Tools & Resources</nav>
                <h2 class="text-3xl font-bold text-gray-800">Manage Tools & Resources</h2>
                <p class="text-gray-600 mt-2">Upload member-only tools, resources, blogs, how-to guides,
                    calculators, templates and more.</p>
            </div>
            <div>
                <button class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg"><a href="<?php echo e(route('admin.toolResources.create')); ?>">➕ Add New
                    Resource</a></button>
            </div>
        </section>

        <div class="flex mb-6 space-x-4">
            <input type="search" placeholder="🔎 Search Resources..."
                class="border px-6 py-3 rounded-lg w-full text-lg" wire:model.live="search">
            <select  wire:model.change="categoryId"
                class="border px-6 py-3 rounded-lg text-gray-600">
                <option value="">All Categories</option>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $cats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value=<?php echo e($cat->id); ?> > <?php echo e($cat->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </select>
        </div>

        <!-- Resource Tables -->
        <section class="bg-white rounded-xl shadow p-6 space-y-10">

            <!-- Credit Repair Resources -->
            <div>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h3 class="text-2xl font-semibold text-indigo-700 mb-4"><?php echo e($category->name); ?></h3>
                <table class="w-full">
                    <tbody>

                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $category->tools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tool): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr class="resource-item border-t hover:bg-gray-50" data-category="credit">
                            <td class="py-3"><?php echo e($tool->title); ?></td>
                            <td class="py-3 text-right space-x-2">
                                <button wire:click="view(<?php echo e($tool->id); ?>)"class="text-green-600 hover:underline">View</button>
                                <button class="text-blue-600 hover:underline"><a href="<?php echo e(route('admin.toolResources.edit',$tool->id)); ?>"> Edit </a></button>
                                <button wire:click="deleteTool(<?php echo e($tool->id); ?>)" return wire:confirm="Are You Sure?"
                                    class="text-red-600 hover:underline">Delete</button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                    </tbody>
                </table>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </div>



        </section>

    </div>

     <!-- View Resource Modal -->
     <!--[if BLOCK]><![endif]--><?php if($viewTools): ?>
     <div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
     <div class="bg-white rounded-lg shadow-lg p-6 w-1/2">
         <h2 id="viewResourceTitle" class="text-2xl font-bold mb-4"></h2>
         <p class="text-gray-600"><?php echo e($title); ?></p>
         
         <iframe src="<?php echo e($url); ?>" class="w-full aspect-video"></iframe>
         
         <div class="text-right mt-6">
             <button wire:click="closeDialog"
                 class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-2 rounded-lg">Close</button>
         </div>
     </div>
 </div>
 <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</main><?php /**PATH I:\laragon\www\twindo\resources\views/livewire/tool-resource.blade.php ENDPATH**/ ?>