    
    <header class="bg-white shadow fixed top-0 inset-x-0 z-10">
        <div class="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
            <h1 class="text-xl font-bold text-indigo-700">My Account</h1>

            <div class="flex items-center space-x-3">
                <span class="text-gray-600">Welcome, <?php echo e(Auth::user()->name); ?>!</span>
                <img
                src="<?php echo e(Auth::user()->image && file_exists(public_path('images/' . Auth::user()->image))
                    ? asset('images/' . Auth::user()->image)
                    : asset('images/default-avatar.png')); ?>"
                alt="Profile"
                class="w-10 h-10 rounded-full object-cover border border-gray-300"
            />
            </div>
        </div>
    </header><?php /**PATH I:\laragon\www\twindo\resources\views/customer/partials/header.blade.php ENDPATH**/ ?>