<aside class="w-56 bg-white shadow-sm min-h-screen">
    <nav class="mt-8 px-4 space-y-2">
        <a href="<?php echo e(route('admin.dashboard')); ?>"
            class="block py-2 px-3 <?php echo e(request()->is(['admin/dashboard*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100'); ?>">🏠
            Dashboard</a>
            <?php if(user_can_view('Credit Score History')): ?>
            <a href="<?php echo e(route('admin.credit.history')); ?>" class="block py-2 px-3 <?php echo e(request()->is(['admin/credit/history*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100'); ?>">📊 Credit Score History</a>
            <?php endif; ?>
            <?php if(user_can_view('Report Analysis')): ?>
            <a href="<?php echo e(route('admin.tempateReports.index')); ?>" class="block py-2 px-3 <?php echo e(request()->is(['admin/tempateReports*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100'); ?>">📊 Report Analysis</a>
            <?php endif; ?>
        <?php if(user_can_view('Users')): ?>
            <a href="<?php echo e(route('admin.users.index')); ?>"
                class="block py-2 px-3 <?php echo e(request()->is(['admin/users*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100'); ?>">👤
                Users</a>
        <?php endif; ?>
        <?php if(user_can_view('Subscription Management')): ?>
            <a href="<?php echo e(route('admin.subscriptions.index')); ?>"
                class="block py-2 px-3 <?php echo e(request()->is(['admin/sdfs*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100'); ?>">💳
                Subscriptions</a>
        <?php endif; ?>
        
        <?php if(user_can_view('Coupon Management')): ?>
            <a href="<?php echo e(route('admin.coupons.index')); ?>"
                class="block py-2 px-3 <?php echo e(request()->is(['admin/coupons*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100'); ?>">🛍️
                Coupon</a>
        <?php endif; ?>
        <?php if(user_can_view('Product Management')): ?>
            <a href="<?php echo e(route('admin.products.index')); ?>"
                class="block py-2 px-3 <?php echo e(request()->is(['admin/products*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100'); ?>">🛍️
                Products</a>
        <?php endif; ?>
        <?php if(user_can_view('Documents')): ?>
            <a href="<?php echo e(route('admin.documents.index')); ?>"
                class="block py-2 px-3 <?php echo e(request()->is(['admin/documents*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100'); ?>">📄
                Documents</a>
        <?php endif; ?>
        <?php if(user_can_view('Messages & Actions')): ?>
            <a href="<?php echo e(route('admin.messageActions.index')); ?>"
                class="block py-2 px-3 <?php echo e(request()->is(['admin/sdfsdfsadf*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100'); ?>">📩
                Messages & Actions</a>
        <?php endif; ?>
        <?php if(user_can_view('Tools & Resources')): ?>
            <a href="<?php echo e(route('admin.toolResources.index')); ?>"
                class="block py-2 px-3 <?php echo e(request()->is(['admin/toolResources*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100'); ?>">🛠️
                Tools & Resources</a>
        <?php endif; ?>
        
        <a href="<?php echo e(route('admin.settings.index')); ?>"
            class="block py-2 px-3 <?php echo e(request()->is(['admin/settings*', 'admin/roles*', 'admin/role/permission/control']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100'); ?>">⚙️
            Settings</a>
        
        <?php if(user_can_view('System Logs')): ?>
            <a href="<?php echo e(route('admin.system.log')); ?>"
                class="block py-2 px-3 <?php echo e(request()->is(['admin/system_log*']) ? 'rounded-md bg-indigo-600 text-white' : 'rounded-md hover:bg-gray-100'); ?>">📋
                System
                Logs</a>
        <?php endif; ?>

        <a href="<?php echo e(route('logout')); ?>"
            onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();"
            class="block py-2 px-3 rounded-md hover:bg-gray-100">🔓 Logout</a>

        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
            <?php echo csrf_field(); ?>
        </form>
    </nav>
</aside>
<?php /**PATH I:\laragon\www\twindo\resources\views/backend/partials/sidebar.blade.php ENDPATH**/ ?>